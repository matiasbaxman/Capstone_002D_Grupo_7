# Revisión del backend y preparación del PR

## Base de trabajo

Rama local: `codex/pulido-y-docker`, creada desde `origin/main`.
Al preparar el entorno no existían ramas remotas `dev` ni `develop`.
Destino previsto: `main`. Comprobarlo de nuevo antes de abrir el PR.

El frontend tiene una rama del mismo nombre y necesita su propio PR.
El Compose de este repo utiliza el Dockerfile del frontend hermano. Enlazar
ambos PR y coordinar su integración para que el arranque conjunto sea utilizable.

## Primer alcance

- Entorno Docker de desarrollo con recarga de código en ambos servicios.
- SQLite en volumen independiente, migraciones al iniciar y healthcheck.
- Correos en consola y OTP simulado para revisar flujos localmente.
- Ejemplo de credenciales opcionales y documentación de arranque.
- Plantilla de PR con validación y dependencias entre repositorios.

## Recorrido pendiente para pulir las funcionalidades existentes

- [ ] Ejecutar check, comprobación de migraciones y toda la suite de las tres apps.
- [ ] Revisar permisos de cada endpoint con cada rol y sin autenticación.
- [ ] Validar sesión, renovación y comportamiento al desactivar usuarios.
- [ ] Revisar inventario, validaciones y consistencia del stock.
- [ ] Probar recepción y subida fallida de fotos con datos de desarrollo.
- [ ] Verificar transiciones de OT, historial y asociación de insumos.
- [ ] Verificar reservas simultáneas, fechas, zona horaria y liberación de cupos.
- [ ] Revisar seguimiento público, OTP, PDF y errores de proveedores externos.

Registrar hallazgos y corregirlos en cambios concretos. Esta lista no acredita
que las funcionalidades ya estén verificadas. No implica conectar nuevos flujos
del frontend ni implementar módulos adicionales.

## Antes del PR

Registrar comandos y resultados reales, migraciones y variables nuevas.
Enlazar el PR del frontend y documentar limitaciones pendientes.
Separar infraestructura, documentación y correcciones en commits legibles.
Actualizar referencias remotas y revisar el diff contra la base antes de subir.
No incluir `.env`, credenciales, bases de datos ni archivos generados.

## Validación del entorno — 25 de octubre de 2026

- `docker compose -f compose.dev.yaml config --quiet`: correcto.
- Imágenes construidas y contenedores iniciados; backend saludable, migraciones
  locales aplicadas e inicio de sesión local verificado.
- Check de Django y `makemigrations --check --dry-run`: correctos en Docker.
- Suite backend en SQLite temporal: 106 pruebas, 104 aprobadas y 2 fallidas.
  Una detecta rechazo de JWT vencido en la API pública de citas; la otra espera
  HTTP 400 sin fecha, aunque la ruta ahora solicita autenticación para el listado
  administrativo (HTTP 401). No se corrigieron como parte del entorno Docker.
- Comprobaciones aisladas adicionales: PDF de OT y cotización generados, correo
  con adjunto en memoria y gestión de citas/permisos verificados.
- Hallazgos pendientes: `LISTO` no dispara el aviso de OT; el PDF de una OT sin
  repuestos responde HTTP 400. Entrega real SMTP y PostgreSQL no verificados.

El entorno está verificado en local, sin conexión a Neon ni envío de mensajes
reales. Los fallos registrados deben revisarse antes de integrar a producción.
