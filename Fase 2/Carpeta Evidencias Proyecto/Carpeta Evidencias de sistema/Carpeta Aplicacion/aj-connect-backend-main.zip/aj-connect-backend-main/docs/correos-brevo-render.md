# Brevo por HTTPS y cola de correos

El backend `apps.workshop.brevo_backend.BrevoEmailBackend` usa la API HTTPS de
Brevo para todos los envíos Django: códigos de acceso, recuperación, verificación
de citas, bienvenida, seguimiento y documentos PDF. No usa SMTP ni necesita
dependencias nuevas. La confirmación de la API indica aceptación por el proveedor;
la entrega final o un rebote se consulta en los registros de Brevo.

Referencia de API: https://developers.brevo.com/reference/send-transac-email

## Activar localmente

Crear una cuenta Brevo, habilitar el servicio transaccional y verificar el
remitente/dominio según las indicaciones de Brevo. Generar una **clave API**,
no una credencial SMTP. En el `.env` local ignorado por Git configurar:

```dotenv
EMAIL_PROVIDER=brevo
BREVO_API_KEY=<clave API privada>
DEFAULT_FROM_EMAIL=A&J Connect <remitente-verificado@tu-dominio.cl>
CLIENT_EMAIL_REQUIRED=True
CLIENT_OTP_DELIVERY_MODE=channel
PUBLIC_PORTAL_URL=http://localhost:5173
```

Eliminar la antigua variable `EMAIL_BACKEND` de SMTP o cambiarla a
`apps.workshop.brevo_backend.BrevoEmailBackend`: si está definida, tiene prioridad
sobre `EMAIL_PROVIDER`. Las variables `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_HOST_USER`,
`EMAIL_HOST_PASSWORD`, `EMAIL_USE_TLS` y `EMAIL_USE_SSL` no se usan con Brevo.
No subir `.env` ni claves a Git. Reiniciar mediante `start-local.ps1`, que
arranca el servidor y el procesador de correos. Docker ya incluye `notifications`;
recrear sus contenedores después de cambiar las variables.

La simulación de OTP sigue disponible mediante `CLIENT_OTP_DELIVERY_MODE=simulation`;
esa opción solo simula códigos, no las bienvenidas ni otros correos de la cola.
Las pruebas automatizadas usan transporte simulado y no envían correos reales.

## Render gratuito, sin worker separado

Después del PR y la fusión autorizada a `main`, configurar el **Web Service**
existente con las mismas variables anteriores, usando como `PUBLIC_PORTAL_URL`
la URL HTTPS real de Vercel. Mantener `DATABASE_URL` de Neon con SSL, `SECRET_KEY`
y las demás variables de producción del backend. No usar settings locales.
Los valores del `.env` local no se transfieren a Render con el PR.

Mantener el Build Command existente:

```sh
pip install -r requirements.txt && python manage.py migrate && python manage.py collectstatic --no-input
```

Cambiar el Start Command a:

```sh
python start_render.py
```

El script inicia Gunicorn en `$PORT` y un procesador de notificaciones en el
mismo servicio. Si cualquiera termina, detiene el otro y sale con error para
permitir el reinicio del servicio. Al recibir SIGTERM, termina ambos procesos.
Mantener Auto-Deploy conectado a `main`. No ejecutar además un worker separado.

Render gratuito suspende el servicio tras 15 minutos sin tráfico; mientras duerme
no hay procesamiento ni reintentos. Las tareas permanecen en Neon y se reanudan
al reactivar el servicio. Los trabajos `FAILED` que agotaron los tres intentos
no se reenvían automáticamente. SMTP 25/465/587 está bloqueado en el plan gratuito,
pero esta integración usa HTTPS 443.

Limitaciones: https://render.com/docs/free

## Verificación después de configurar las credenciales

1. Solicitar un código de verificación de cita y confirmar que llega.
2. Reservar con un cliente nuevo y comprobar la bienvenida.
3. Aceptar la cita y comprobar el aviso de aceptación.
4. Registrar el ingreso del vehículo y comprobar el enlace de seguimiento sin sesión.
5. Generar una cotización con ítems y comprobar el PDF enviado.

Revisar también los registros transaccionales de Brevo. Un error HTTP 401 suele
indicar credenciales rechazadas; 400 requiere revisar remitente y contenido;
429 indica límite del proveedor. Los errores de cola se reintentan hasta tres
veces. No ejecutar envíos de prueba masivos sobre la cola de producción.
