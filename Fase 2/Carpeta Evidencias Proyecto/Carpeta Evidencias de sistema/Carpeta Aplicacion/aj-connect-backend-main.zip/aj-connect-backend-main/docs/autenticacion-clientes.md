# Autenticación de clientes con RUT y contraseña (T-04)

Esta API utiliza la entidad `Client` de la tabla `clients`, sin crear usuarios
del personal. Los desafíos se guardan en `client_otps` (migración 0009), una
tabla auxiliar nueva que todavía no aparece en `database.dbml`.

## 1. Solicitar código

`POST /api/auth/client-login/`

```json
{"rut": "12.345.678-5"}
```

Normaliza y valida el RUT, incluyendo registros legados con puntos/guion.
Para un cliente registrado genera seis dígitos mediante `secrets`, guarda
solo un hash de Django y entrega el código por su `notification_channel`.
Un RUT válido desconocido recibe HTTP 404 con instrucciones para registrarse mediante recepción o agendamiento; no se envía código ni se crea una cuenta desde el login. Este es el comportamiento de UX solicitado. El límite por IP se mantiene.

```json
{"detail": "Enviamos un código por tu canal registrado. Si ya solicitaste uno, utiliza ese código."}
```

El código expira en cinco minutos. Cada reenvío reemplaza el desafío anterior.
El tiempo mínimo entre envíos es un minuto. Para clientes registrados, las solicitudes repetidas devuelven HTTP 200 y no reenvían el código durante ese período. Un RUT no registrado sigue devolviendo 404.
Si el proveedor falla, responde HTTP 503 y se revierte la actualización
del desafío. El OTP no se devuelve en respuestas HTTP.

## 2. Verificar y crear contraseña inicial

`POST /api/auth/client-otp/`

```json
{
  "rut": "123456785",
  "code": "012345",
  "password": "MotorSeguro!2026"
}
```

Enviar el código como cadena para conservar ceros iniciales. En primer ingreso
la contraseña es obligatoria y se valida con los validadores de Django. Se
almacena con `make_password`; también se reconocen como primer ingreso los
marcadores inutilizables legados. Una contraseña ausente o débil devuelve
HTTP 400 en `password`, sin consumir un OTP correcto aún vigente.

Después del primer ingreso se usa `POST /api/auth/client-login/` con RUT y contraseña.
No se solicita ni envía otro OTP para los ingresos habituales. El endpoint de
verificación no cambia contraseñas de cuentas ya activadas.

HTTP 200 devuelve:

```json
{
  "access": "<JWT de cliente>",
  "token_type": "Bearer",
  "expires_in": 3600,
  "first_login": true,
  "client": {"id": "<UUID>", "first_name": "Ana", "last_name": "Pérez"}
}
```

El JWT tiene tipo `client_access`, `client_id` y `principal_type=client`;
no contiene `user_id`, roles de empleados, RUT, teléfono ni correo. Su vida
es la de `SIMPLE_JWT.ACCESS_TOKEN_LIFETIME` (actualmente 60 minutos). No se
emite refresh de personal: al expirar, se repite el flujo OTP.

El portal React `/cliente` utiliza `GET /api/auth/client-session/`, que devuelve solo las órdenes del titular. Su access y caducidad se guardan en sessionStorage, con clave separada de la sesión del personal. El navegador elimina la sesión al expirar y solicita nuevo OTP.

Las vistas privadas del portal declaran explícitamente
`ClientJWTAuthentication` de `apps.authentication.client_tokens` y el permiso
`IsAuthenticated`. Los JWT de clientes no se habilitan en la autenticación
global de personal y no funcionan en `/api/auth/refresh/`.

Un OTP incorrecto, vencido o consumido devuelve HTTP 400:

```json
{"code": ["El código es incorrecto, expiró o ya fue utilizado."]}
```

Cinco intentos incorrectos invalidan el desafío. Un OTP correcto se consume
en la misma transacción que crea la contraseña y emite el JWT. Los bloqueos
de fila en PostgreSQL serializan envíos y verificaciones del mismo cliente.
Además, hay límites por IP de 10 solicitudes y 30 verificaciones por minuto.

## Entrega local y configuración de producción

`settings_local` activa simulación explícita. El código y destino aparecen
en la terminal del backend como `SIMULACION OTP`; no se envían mensajes reales.

Producción deshabilita simulación y envío por defecto. Para habilitar envío real:

- Configurar `CLIENT_OTP_DELIVERY_MODE=channel`.
- EMAIL: configurar `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_HOST_USER`,
  `EMAIL_HOST_PASSWORD`, `DEFAULT_FROM_EMAIL`, `EMAIL_USE_TLS` y `EMAIL_USE_SSL`
  según el proveedor SMTP (no activar TLS y SSL simultáneamente).
- WHATSAPP: configurar `CLIENT_OTP_WHATSAPP_SENDER` con la ruta Python de un
  adaptador del proveedor. El callable recibe `(phone, message)` y debe lanzar
  una excepción si el proveedor no acepta el envío. No se cambia de canal
  automáticamente si falta el proveedor preferido.

Las pruebas usan mocks, correo en memoria y simulación; no envían mensajes
reales. No guardar credenciales de proveedores en Git.

## Verificación local

```powershell
.\venv\Scripts\python.exe manage.py makemigrations --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py migrate --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py test apps.workshop --settings=ajconnect_api.settings_local
```


## Alta y bienvenida por el canal elegido

Recepción y agendamiento crean el cliente sin contraseña utilizable y programan
una única bienvenida en la misma transacción. Si el registro falla, se revierte
el trabajo; reutilizar un cliente no repite la bienvenida.

- EMAIL: las instrucciones se envían por SMTP al correo registrado.
- WHATSAPP: se envían al teléfono mediante `CLIENT_WHATSAPP_NOTIFICATION_SENDER`.
  El correo sigue siendo opcional y no se usa como reemplazo de WhatsApp.
- El adaptador de bienvenida es independiente del de códigos OTP y debe respetar
  las plantillas del proveedor. Sin proveedor configurado se registra el fallo y
  se reintenta; no se marca como enviado.
- `PUBLIC_PORTAL_URL` configura el enlace del portal. Para abrirlo desde un
  teléfono usar una URL accesible desde ese dispositivo, no localhost del PC.

Las instrucciones indican: portal público → Iniciar sesión → RUT → código por
el canal elegido → creación de contraseña en el primer ingreso. El portal
formatea el RUT automáticamente con puntos, guion y K mayúscula.

## Política temporal: correo obligatorio

Con `CLIENT_EMAIL_REQUIRED=True`, recepción y agendamiento exigen correo a clientes nuevos y aceptan teléfono vacío. OTP y bienvenida usan correo, incluso si un cliente antiguo tenía WhatsApp como canal. Los registros antiguos sin correo requieren actualizar su contacto en recepción; el portal público no cambia contactos existentes. La integración WhatsApp permanece disponible para desarrollo, pero no se usa para el acceso con esta política.

En las pruebas generales `settings_ci` desactiva esta política para cubrir ambos proveedores; la suite `test_email_policy` la activa explícitamente. No se realizó la limpieza de datos pendiente.

## Acceso actualizado: RUT y contraseña

El portal muestra RUT y contraseña desde el inicio. Una cuenta sin contraseña ingresa solo su RUT: recibe un OTP por correo y completa código y nueva contraseña. Después usa RUT y contraseña, sin reenvío de OTP. `POST /api/auth/client-login/` acepta `password` y devuelve una sesión para cuentas activadas, o confirma el envío del código para el primer ingreso. Los intentos están limitados por IP.

SQLite local y Docker usan transacciones IMMEDIATE con espera de 20 segundos para evitar escaladas de bloqueo al guardar la contraseña mientras se procesan notificaciones. El worker no ejecuta UPDATE cuando no hay trabajos vencidos. Un bloqueo residual devuelve 503 JSON recuperable en vez de una página de error. Las pruebas generales usan settings_ci y proveedores simulados.

## Datos personales protegidos

El menú muestra nombre y apellido y separa las vistas `/cliente#datos` y `/cliente#citas`. Para cambiar nombre, apellido, correo o teléfono, una sesión de cliente solicita `POST client-profile/request/` con los datos propuestos. El código se envía al correo actual, nunca al nuevo correo sin autorización. Un desafío separado de los OTP de acceso conserva los datos propuestos y un hash del código durante cinco minutos, con espera de 60 segundos entre envíos y máximo de cinco intentos. `POST client-profile/confirm/` acepta el código y aplica exclusivamente los datos almacenados del mismo cliente, de forma atómica y una sola vez. El RUT no se modifica. Se revalida que el correo y teléfono no pertenezcan a otro cliente al confirmar.
