# Meta WhatsApp: demostración

El adaptador `apps.workshop.meta_delivery` sustituye los dos hooks de Twilio:

```dotenv
CLIENT_OTP_DELIVERY_MODE=channel
CLIENT_OTP_WHATSAPP_SENDER=apps.workshop.meta_delivery.send_otp
CLIENT_WHATSAPP_NOTIFICATION_SENDER=apps.workshop.meta_delivery.send_welcome
META_WHATSAPP_ACCESS_TOKEN=token_solo_en_env
META_WHATSAPP_PHONE_NUMBER_ID=id_del_numero_emisor
META_WHATSAPP_BUSINESS_ACCOUNT_ID=id_de_la_cuenta
META_WHATSAPP_TEST_TO=56912345678
META_WHATSAPP_API_VERSION=v25.0
META_WHATSAPP_OTP_TEMPLATE=nombre_de_plantilla_authentication_aprobada
META_WHATSAPP_TEMPLATE_LANGUAGE=es
```

Esta implementación limita ambos envíos a `META_WHATSAPP_TEST_TO`, aunque otros
clientes tengan WhatsApp como canal. No está lista para destinatarios de producción.
El correo conserva su proveedor SMTP. No hay cambio automático de canal si Meta falla.

## Códigos

Se necesita una plantilla AUTHENTICATION aprobada con un parámetro de cuerpo y
botón COPY_CODE. El código se envía tanto en el cuerpo como en el parámetro del
botón URL de la API. El nombre y el idioma deben corresponder a la plantilla real.
No se envían códigos como texto libre ni mediante plantillas de pedidos.
La cuenta de prueba consultada el 2026-11-01 solo tenía plantillas de ejemplo y
rechazó crear una de autenticación: código 10, subcódigo 2388185 (sin permiso).
Por tanto el OTP real está pendiente de contar con esa plantilla y sus permisos.

## Bienvenida

Se envían las instrucciones completas generadas por `send_client_welcome` como
texto. Se requiere una ventana de atención abierta por el usuario; fuera de ella
se necesita desarrollar y configurar una plantilla de bienvenida aprobada.
Aceptar una solicitud en `/messages` no confirma entrega al teléfono. Sin webhook
de estados integrado, comprobar la recepción directamente o en las herramientas
de Meta. El token temporal puede caducar y debe renovarse desde Meta.

Para abrir el portal desde el teléfono, `PUBLIC_PORTAL_URL` debe ser una URL
accesible desde el teléfono; `localhost` apunta al propio dispositivo.

## Verificación

`python manage.py test --settings=ajconnect_api.settings_local` usa SQLite local
para las pruebas, sin conectarse al `DATABASE_URL` remoto. Los tests del adaptador
simulan HTTPS: payload OTP, bienvenida completa, restricción de destinatario,
errores sin secretos, ausencia de plantilla y respuesta sin ID de mensaje.

Las pruebas de entrega no deben imprimir tokens ni códigos en terminal, crear
clientes innecesarios ni enviar a destinatarios diferentes del teléfono de prueba.
