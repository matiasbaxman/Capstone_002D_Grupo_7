# Correcciones HU-01, HU-03 y HU-06

## Agenda

Cada bloque de una hora permite **dos citas activas**. PENDIENTE, CONFIRMADA y
ATENDIDA conservan su cupo; RECHAZADA y CANCELADA lo liberan inmediatamente.
El rechazo conserva el registro y se realiza desde `/dashboard/citas`.
`remaining_capacity` informa si queda uno o dos cupos disponibles.

La asignación usa una fila de bloqueo por horario, dos posiciones numeradas,
un índice único condicional y un CHECK que prohíbe una tercera posición.
Las reservas simultáneas se verificaron sobre PostgreSQL real y desechable.

Antes de reservar se verifica el contacto con un código de cinco minutos.
Se utiliza el contacto registrado para clientes existentes y el indicado para
clientes nuevos. No se sobrescriben contactos de terceros. El código queda
vinculado a los datos exactos del formulario; solo admite cinco intentos y un
uso. No ocupa un cupo hasta registrar la cita. Hay límites por IP/RUT y un
máximo de dos solicitudes futuras pendientes por cliente.

En desarrollo el OTP se imprime exclusivamente en el log del backend.
En producción se necesita `CLIENT_OTP_DELIVERY_MODE=channel`, SMTP o el
adaptador WhatsApp configurado. No se devuelven códigos en respuestas HTTP.

## Cotizaciones

El detalle de OT permite generar cotizaciones desde los repuestos asociados,
previsualizarlas y descargarlas como PDF, además de programar su envío por correo.
El informe técnico continúa disponible como documento separado.

- GET/POST `/api/workshop/work-orders/<id>/quotes/`.
- GET `/api/workshop/quotes/<id>/pdf/`.
- POST `/api/workshop/quotes/<id>/email/`: responde **202** con UUID de trabajo.
- GET `/api/workshop/email-deliveries/<id>/`: PENDING, PROCESSING, SENT o FAILED.

Los precios de los repuestos se consideran **netos** para cotizar. La tasa de
IVA se configura mediante `AJ_QUOTE_TAX_RATE` (predeterminado 19.00). Se usan
Decimal y redondeo de dos decimales; el documento muestra subtotal, tasa,
impuesto y total. Los importes se conservan como snapshot aunque cambie el
catálogo. Cantidades cero, importes negativos y totales incoherentes se rechazan.

Las migraciones conservan el total de cotizaciones antiguas y no inventan una
tasa histórica. Si su detalle no coincide, la exportación exige revisión;
se puede emitir una cotización nueva desde la OT sin alterar la anterior.

## Correo fuera del proceso HTTP

La solicitud HTTP escribe una outbox persistente. Un worker genera el PDF y
realiza SMTP, con tres intentos y espera creciente. El frontend distingue
programado, enviado y fallido. No informa entrega antes de que el worker confirme.

El script `start-local.ps1` inicia automáticamente el procesador de notificaciones
en segundo plano y lo detiene al cerrar el servidor. Reiniciar con ese script
permite procesar también los correos pendientes, sin abrir otra terminal.

Al registrar el ingreso, la bienvenida pendiente incorpora el código y enlace
`/seguimiento/<codigo>` de la orden. Si la bienvenida ya salió (por ejemplo,
al reservar una cita), se programa un correo de seguimiento separado, sin
depender de un PDF ni de que la orden tenga ítems. El enlace permite consultar
la atención sin iniciar sesión. Una reserva sin orden todavía no tiene código.

En Docker, `compose.dev.yaml` incluye el servicio `notifications` que espera
al backend y comparte su base de datos. Sin Docker, ejecutar en otra terminal:

```powershell
.\venv\Scripts\python.exe manage.py process_notifications --settings=ajconnect_api.settings_local
```

`--once` procesa los trabajos disponibles y termina. En producción ejecutar
este mismo comando con la configuración de producción y supervisión del proceso.
SMTP tiene timeout. Si el proceso cae después de entregar el correo pero antes
de registrar SENT, una recuperación puede duplicar el correo: SMTP no ofrece
una garantía de entrega exactamente una vez.

## Migraciones y producción

```powershell
.\venv\Scripts\python.exe manage.py migrate --settings=ajconnect_api.settings_local
```

Las migraciones 0014 y 0015 fueron aplicadas a la base SQLite local; antes se
guardó una copia en `.qa/pre-sprint-migration.sqlite3` (ignorada por Git).
Docker aplica las migraciones al iniciar el backend.

En producción usar `DEBUG=False`, una `SECRET_KEY` aleatoria propia de al menos
50 caracteres y hosts explícitos. HTTPS y cookies Secure quedan habilitados.
Si el proxy termina TLS y elimina headers entrantes, configurar
`TRUST_PROXY_SSL_HEADER=True`. No habilitar esa confianza en un proxy desconocido.

La caché de producción predeterminada es compartida en base de datos:

```text
python manage.py createcachetable
```

También se puede configurar `CACHE_BACKEND` y `CACHE_LOCATION` para una caché
compartida existente. `TRUSTED_PROXY_COUNT` es cero por defecto; configurarlo
solo para la cantidad real de proxies confiables que sanitizan cabeceras IP.
HSTS queda limitado al host; subdominios y preload requieren una decisión del
dominio de producción. Por eso `check --deploy` mantiene W005 y W021 como avisos.

## Verificación

- 128 pruebas Django aprobadas con PostgreSQL 17 desechable, incluida concurrencia.
- Flujo completo: reserva verificada → OTP/contraseña inicial → confirmación →
  recepción → insumos → tracking público → cotización → PDF → outbox → adjunto MIME.
- Tests React de reserva, seguimiento incorrecto, rechazo/reprogramación,
  previsualización/descarga PDF, sesión de clientes y primer ingreso.
- Scripts de sesión de personal, contratos HTTP y ocho pruebas de avisos.
- Check de Django, migraciones, lint y build aprobados.
- Se agregaron workflows CI para frontend y backend (PostgreSQL).

Las tres correcciones visuales solicitadas están implementadas: contraste del
botón de confirmación pública, presentación del error de tracking y barra de
recepción transparente en todos los pasos. La inspección visual directa no se
completó: el navegador integrado no accedió al servidor local y el control de
Windows se detuvo al no poder verificar con confianza la URL activa.
No se enviaron correos/SMS reales ni se certificaron credenciales de proveedores.
