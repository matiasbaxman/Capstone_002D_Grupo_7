# Chatbot A&J: contexto y límites (T-02)

`POST /api/assistant/chat/` es público. Recibe únicamente el mensaje que se
enviará a Gemini; no consulta clientes, órdenes ni inventario privado.

```json
{"message": "¿Cuál es el horario del sábado?"}
```

El mensaje debe ser un texto de 3 a 500 caracteres después de quitar espacios
al inicio y al final. Objetos, listas, números, valores nulos o mensajes vacíos
no son mensajes válidos. Los campos adicionales no pueden reemplazar la clave,
el modelo ni las instrucciones del servidor.

## Contexto oficial

`apps/assistant/prompts.py` mantiene identidad y ubicación en Quilpué, los
horarios lunes a viernes 08:30–18:30 y sábado 09:00–14:00, servicios y repuestos
multimarca. No se inventan dirección, teléfono, precios ni stock. Para stock,
cotizaciones complejas o atención presencial se orienta al taller o `/agendar`.
Las respuestas orientan; no confirman reservas ni realizan operaciones.

El prompt se envía como `system_instruction`, separado del mensaje del cliente.
La clave y el modelo se leen de `GEMINI_API_KEY` y `GEMINI_MODEL` en los settings
del backend. La prueba local utilizó `gemini-3.5-flash-lite`, configurado en el
`.env` ignorado por Git. No incluir claves en solicitudes, documentación o logs.

## Respuestas

| HTTP | Cuerpo | Significado |
|---|---|---|
| 200 | `{"reply": "...", "status": "success"}` | Respuesta generada. |
| 400 | `{"error": "...", "status": "error"}` | Mensaje vacío, tipo o longitud inválidos. |
| 429 | `{"error": "...", "status": "error"}` | Límite local excedido; incluye `Retry-After`. |
| 503 | `{"reply": "...", "status": "fallback"}` | Clave ausente, timeout, cuota, error o respuesta vacía/bloqueada. |

El fallback invita a agendar o escribir más tarde. La interfaz debe mostrar
`reply` también cuando reciba 503. JSON malformado, tipos de contenido no
admitidos y métodos distintos de POST/OPTIONS usan los errores estándar de DRF.
No se devuelve el detalle de las excepciones del SDK.

## Timeout y consumo

El timeout HTTP es de **7000 ms**, con un solo intento y hasta 512 tokens de
salida. El proveedor exige al menos 10 segundos en `X-Server-Timeout`: se fija
ese plazo del servidor por separado, conservando los 7 segundos del cliente
HTTP (no es una promesa de duración total exacta del endpoint).

## Rate limit

`AssistantChatThrottle` admite **10 POST por minuto por IP**. Las consultas
inválidas también consumen el límite; OPTIONS no lo consume. La undécima
consulta no invoca Gemini. Se reutiliza la caché Django configurada y se respeta
`REST_FRAMEWORK.NUM_PROXIES` (derivado de `TRUSTED_PROXY_COUNT`). Con valor 0,
el cliente no puede eludir el límite cambiando `X-Forwarded-For`.

Localmente se usa la caché de memoria. Para varios procesos de producción se
requiere una caché compartida operativa; la configuración actual contempla
DatabaseCache y su tabla `ajconnect_cache`. No crear esa tabla en Neon desde
el entorno local. El límite estándar de DRF es aproximado bajo concurrencia;
no sustituye protecciones de red contra abuso distribuido.

## Verificación local

```powershell
.\venv\Scripts\python.exe manage.py check --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py test apps.assistant --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py test --settings=ajconnect_api.settings_local --noinput
```

Las pruebas del asistente usan Gemini simulado, límites por IP, reloj simulado
para la ventana de un minuto y una petición del SDK real con transporte HTTP
simulado para verificar timeout/cabecera sin consumir cuota. Las consultas
reales de aceptación se realizan por separado con preguntas sin datos privados.

Referencias: [DRF throttling](https://www.django-rest-framework.org/api-guide/throttling/)
y [SDK oficial de Gemini](https://googleapis.github.io/python-genai/).
