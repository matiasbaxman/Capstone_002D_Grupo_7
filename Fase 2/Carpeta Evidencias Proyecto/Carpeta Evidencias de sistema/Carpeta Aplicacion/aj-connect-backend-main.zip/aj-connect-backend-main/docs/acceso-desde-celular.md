# Probar la versión local desde un celular

El teléfono y el computador deben estar en la misma red. Docker publica el
frontend en la IP LAN elegida y mantiene también el acceso por localhost.
El puerto 8000 del backend sigue publicado únicamente en 127.0.0.1.

Desde `aj-connect-backend`, en PowerShell:

```powershell
# Usa la IPv4 de tu adaptador con acceso a la red, no la de WSL.
$env:LAN_IP='192.168.0.12'
docker compose -f compose.dev.yaml -f compose.lan.yaml up -d
```

La IP anterior es la comprobada en este computador el 26 de octubre de 2026;
puede cambiar. Abre `http://<LAN_IP>:5173/dashboard` desde el teléfono e inicia
sesión con un usuario de la base local. El almacenamiento de sesión es propio
de cada navegador; no se copia la sesión abierta en el computador.

`compose.lan.yaml` agrega un puerto ligado a esa IP, activa `VITE_API_URL=/`
y configura el proxy de Vite hacia `http://backend:8000`. Por tanto, las
peticiones `/api` usan el mismo origen que la página, sin abrir Django a la LAN
ni habilitar CORS para cualquier origen. La configuración normal de producción
no utiliza este proxy de desarrollo.

El equipo debe mantener Docker encendido. El firewall debe permitir el acceso
de Docker en la red privada. No requiere publicar un dominio ni configurar el
router. En redes de invitados puede existir aislamiento entre dispositivos.

Para volver a permitir solo localhost, conservando la base de datos:

```powershell
docker compose -f compose.dev.yaml up -d
```

Para detener los contenedores, sin borrar datos:

```powershell
docker compose -f compose.dev.yaml stop
```

En HTTP de LAN, el frontend genera UUID con `crypto.getRandomValues` cuando
`crypto.randomUUID` no está disponible. Esto permite preparar fotos y asociar
repuestos sin depender de esa API exclusiva de contextos seguros. La cámara
usa el selector de archivos del navegador, no `getUserMedia`; su comportamiento
depende del teléfono. La subida de fotos sigue necesitando Cloudinary.

Es exclusivamente un entorno de desarrollo con DEBUG, usuarios locales y OTP
simulado; las fotos, si se configuran credenciales, sí se suben a Cloudinary.
