# API pública de servicios y agendamiento (T-03)

Las rutas son públicas y no requieren JWT. Un token JWT vencido o inválido
enviado por el navegador no impide consultar ni reservar.

## Catálogo: GET /api/services/

Retorna una lista de servicios activos con `id`, `name`, `description`,
`base_price` (decimal como cadena o null) y `estimated_duration_minutes`
(entero o null). Los servicios se crean y administran en Django Admin,
sección **Servicios**. Sin servicios registrados, la respuesta es `[]`.
No se insertan servicios ni precios de ejemplo en la base.

La duración es informativa del servicio; la cita corresponde a un bloque de
recepción de una hora según T-02, no a la duración total de una reparación.

## Disponibilidad: GET /api/appointments/?date=2030-01-07

El parámetro `date` es obligatorio y usa formato YYYY-MM-DD. La respuesta es:

```json
{
  "date": "2030-01-07",
  "timezone": "America/Santiago",
  "slot_duration_minutes": 60,
  "capacity_per_slot": 2,
  "slots": [
    {"start": "2030-01-07T09:00:00-03:00", "end": "2030-01-07T10:00:00-03:00", "remaining_capacity": 2}
  ]
}
```

`slots` contiene todos los bloques libres y futuros del día, con inicios entre
09:00 y 17:00 de lunes a viernes. Un día pasado o de fin de semana retorna
`slots: []`. Una fecha malformada retorna HTTP 400 con error en `date`.
Las citas CANCELADA y RECHAZADA liberan su cupo inmediatamente. Hay un máximo de dos citas activas por bloque. No se publican datos de otras reservas.
La disponibilidad es orientativa hasta que el POST confirma la reserva.

## Verificar el contacto antes de reservar

Enviar los datos de la solicitud a `POST /api/appointments/verify-contact/`.
Recibirás `verification_id`; el código de seis dígitos se entrega al canal
registrado del cliente existente, o al contacto indicado por un cliente nuevo.
La verificación no ocupa un cupo. Expira en cinco minutos, admite cinco intentos
y queda vinculada a los datos exactos de la solicitud. Cambiar datos requiere
solicitar otro código. Hay cooldown por RUT y límite de solicitudes por IP.

## Reserva: POST /api/appointments/

```json
{
  "rut": "22.345.678-2",
  "first_name": "Luis",
  "last_name": "Soto",
  "phone": "+56987654321",
  "email": "luis@example.test",
  "notification_channel": "EMAIL",
  "scheduled_date": "2030-01-07T10:00:00-03:00",
  "reported_symptoms": "Ruido al frenar",
  "verification_id": "<UUID recibido>",
  "code": "<código de seis dígitos>"
}
```

- Siempre se requieren `rut`, `scheduled_date`, `reported_symptoms`, `verification_id` y `code`.
- Máximo dos solicitudes PENDIENTE futuras por cliente. Confirmar una desde administración permite nuevas solicitudes.
- La base de datos limita cada horario a dos cupos numerados. El tercero recibe 400; un bloqueo transitorio de SQLite puede responder 409 para reintentar.
- Para un cliente nuevo se requieren además nombre, apellido y teléfono
  móvil en formato +569 seguido de ocho dígitos. `notification_channel`
  acepta WHATSAPP (predeterminado) o EMAIL; EMAIL requiere correo.
- Se reutiliza el cliente por RUT normalizado, incluyendo registros legados
  con puntos y guion. No se sobrescriben perfiles existentes desde esta API.
- El cliente nuevo se crea con contraseña inutilizable; este endpoint no
  activa cuentas ni envía OTP.
- `vehicle` es un UUID opcional de un vehículo existente del mismo cliente.
  Para vehículos aún no registrados, omitirlo o enviar null.
- `service` es un ID opcional del catálogo activo; también permite null.
- El estado inicial siempre es PENDIENTE; el cliente no elige el estado.

HTTP 201 devuelve `id`, `status`, `scheduled_date`, `reported_symptoms`,
`service` (datos públicos del servicio o null) y `created_at`. No devuelve
RUT, contacto, credenciales ni identificadores del perfil del cliente.

Las validaciones del modelo y serializer de T-02 se reutilizan antes de
guardar. Una cita inválida devuelve HTTP 400 con errores por campo, por ejemplo:

```json
{"scheduled_date": ["El bloque horario ya no tiene cupos disponibles."]}
```

La creación de cliente y cita comparte una transacción. Si la reserva falla,
no queda un cliente nuevo huérfano. La restricción única de T-02 sigue
protegiendo los bloques ante reservas simultáneas.

## Verificación local

Desde la carpeta del backend, sin cambiar de rama:

```powershell
.\venv\Scripts\python.exe manage.py makemigrations --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py migrate --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py test apps.workshop --settings=ajconnect_api.settings_local
```

## Cuenta y avisos de cita

El OTP del agendamiento se identifica como código para confirmación de cita, separado del código de acceso. La cuenta autenticada lista solo las citas del cliente y sus datos personales. El frontend consulta cambios cada 15 segundos mientras está visible. Aceptar, cancelar o rechazar una cita crea un aviso SMTP en la outbox dentro de la misma transacción; el aviso conserva destinatario, estado y fecha al momento del cambio y se reintenta con el worker. Repetir el mismo estado no genera otro aviso.

Las citas y las órdenes aún no tienen una relación explícita entre sí: el portal muestra ambos registros y el estado actual, sin inferir que una orden corresponde a una cita solo por cliente o fecha. Para una línea por atención se necesita vincular la cita al check-in de forma explícita.

## Reservas con cuenta iniciada

El formulario carga los datos del cliente desde su sesión y no vuelve a solicitarlos. `POST /api/auth/client-appointments/` exige JWT de cliente, toma RUT y contacto desde la cuenta autenticada e ignora intentos de sobrescribir esa identidad. La primera cita requiere verificación de contacto; las siguientes no requieren OTP. Sin sesión, un cliente con historial debe iniciar sesión, no volver a reservar enviando solo su RUT. Se conservan capacidad por hora, validación de vehículo y límite de solicitudes pendientes. Las citas se muestran en tarjetas compactas y su detalle se abre en un diálogo modal.

## Cita vinculada a orden

La consulta por RUT devuelve citas aceptadas sin orden. En recepción, en el paso de vehículo, se elige una cita o Ingreso sin cita y se revisa la selección antes de confirmar. El backend comprueba cliente, vehículo, estado aceptado y ausencia de otra orden. Una relación OneToOne opcional en WorkOrder conserva el vínculo. La orden y el estado ATENDIDA se guardan juntos; una cita con vehículo conocido debe coincidir con el que ingresa. El portal muestra el estado de la OT dentro de la cita enlazada y no repite la orden como tarjeta separada. Las órdenes anteriores conservan sus datos sin asignarles una cita por inferencia.

## Detalle de atención unificado

Ver detalle abre `/cliente#atencion=<referencia>` sin modal. La vista reutiliza el seguimiento y reúne Pendiente, Aceptada y los estados de recepción, diagnóstico, reparación, listo para entrega y entregado. Los pasos futuros se muestran por realizar. La misma página incluye datos del vehículo, fotografías e insumos; no requiere otro enlace intermedio. Las atenciones sin cita empiezan en recepción. Una atención sin OT muestra su referencia de reserva; cuando existe OT el encabezado utiliza su folio. El tracking público expone solo estado y fechas de la cita asociada, sin contacto del cliente.
