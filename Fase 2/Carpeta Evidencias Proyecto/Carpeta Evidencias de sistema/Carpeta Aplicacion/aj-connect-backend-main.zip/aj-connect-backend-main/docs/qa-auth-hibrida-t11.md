# QA T-11 / HU-09: autenticación híbrida y sesiones

**Fecha:** 2026-11-13  
**Entorno:** SQLite local con `ajconnect_api.settings_local`; base temporal para Django tests.  
**Rama:** `test/#11-auth-hibrida` (repositorio backend).

## Cobertura y resultados

| Flujo | Escenario | Resultado |
|---|---|---|
| Personal | Login válido emite `access` y `refresh`, incluye el rol y actualiza `last_login` | Correcto |
| Personal | Endpoint administrativo sin credencial | `401` esperado |
| Personal | Mecánico solicita listado de usuarios (solo administrador) | `403` esperado |
| Personal | Mecánico consulta órdenes de trabajo con JWT válido | `200` esperado |
| Personal | Renovar JWT mediante `/api/auth/refresh/` | `200`; se emite un nuevo access token |
| Portal cliente | Primer ingreso con OTP válido crea credencial de cliente y JWT | Correcto; no crea usuario de personal |
| Portal cliente | Ingreso posterior con contraseña válida, sin emitir OTP | Correcto |
| Portal cliente | OTP erróneo, vencido, agotado o reutilizado | Rechazado; desafío invalidado cuando corresponde |
| Portal cliente | JWT de personal usado en autenticación de cliente; JWT de cliente usado en endpoints de personal | Rechazados (`401`) |
| Portal cliente | JWT de cliente vencido | Rechazado por autenticación de cliente |
| Aislamiento | Cliente A consulta sesión con vehículo/OT propios y registros de Cliente B | Solo incluye vehículo y OT de A |
| Frontend | Sesión de cliente expirada o respuesta `401` | Borra la sesión y no consulta endpoints de personal |
| Frontend | Persistencia de sesión del cliente | Guarda el acceso y caducidad separados; no persiste contraseña, RUT, OTP ni refresh de personal |

## Ejecución

- Backend: `venv\\Scripts\\python.exe manage.py test apps.authentication.tests apps.workshop.test_client_auth --settings=ajconnect_api.settings_local` — **30 pruebas OK**.
- Frontend: `npm exec vitest run src/test/clientSession.test.js` — **3 pruebas OK**.
- Verificación dirigida de los cinco escenarios nuevos/principales de JWT y aislamiento — **5 pruebas OK**.

## Incidencias y notas

- La primera ejecución encontró una expectativa incorrecta en `test_delivery_adapters_use_preferred_channels`: la configuración de pruebas fuerza `CLIENT_EMAIL_REQUIRED=True`, por lo que no se seleccionaba WhatsApp aunque el test lo esperaba. Se ajustó el test para desactivar expresamente esa política en el escenario WhatsApp. La suite volvió a pasar completa.
- El sistema de Django avisó que no existe el directorio local `staticfiles/`; no afecta estas pruebas de API.
- Las sesiones de cliente duran 60 minutos y no usan refresh token. Al caducar, el cliente debe autenticarse de nuevo mediante contraseña o el flujo OTP. La renovación automática validada corresponde al JWT del personal.
- Alcance ejecutado: suites de autenticación y OTP/sesión, más el test Vitest de sesión del cliente; no se ejecutó la suite completa del producto.
