"""Supervisa Gunicorn y la cola de correo en un único servicio de Render."""
import os
import signal
import subprocess
import sys
import time
from pathlib import Path


def main():
    os.chdir(Path(__file__).resolve().parent)
    os.environ['DJANGO_SETTINGS_MODULE'] = 'ajconnect_api.settings'
    stopping = False
    children = []

    def stop(signum, frame):
        nonlocal stopping
        stopping = True

    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, stop)
    try:
        children.append(subprocess.Popen([
            sys.executable, '-m', 'gunicorn', 'ajconnect_api.wsgi:application',
            '--bind', f'0.0.0.0:{os.environ.get("PORT", "8000")}',
            '--access-logfile', '-', '--error-logfile', '-', '--graceful-timeout', '20',
        ]))
        children.append(subprocess.Popen([
            sys.executable, '-u', 'manage.py', 'process_notifications',
            '--settings=ajconnect_api.settings',
        ]))
        while not stopping:
            if any(child.poll() is not None for child in children):
                print('Un proceso del backend terminó; se detendrá el servicio para reiniciarlo.', flush=True)
                return 1
            time.sleep(0.5)
        return 0
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
        deadline = time.monotonic() + 25
        for child in children:
            try:
                child.wait(timeout=max(0, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()


if __name__ == '__main__':
    sys.exit(main())
