from hashlib import sha256

from django.core.files.storage import FileSystemStorage
from django.utils.deconstruct import deconstructible

from ajconnect_api.image_uploads import upload_image


@deconstructible
class CatalogImageStorage(FileSystemStorage):
    """Guarda imágenes publicadas en Cloudinary y resuelve las rutas locales anteriores."""

    def _save(self, name, content):
        digest = sha256()
        for chunk in content.chunks():
            digest.update(chunk)
        return upload_image(content, folder='aj_connect/catalog', public_id=digest.hexdigest())['url']

    def url(self, name):
        if name.startswith('https://'):
            return name
        return super().url(name)
