import uuid
from django.db import models
from django.db.models.functions import Lower, Trim
from django.db.models.lookups import Exact
from .storage import CatalogImageStorage


UNIDENTIFIED_BRAND = 'Marca por identificar'


class ItemBrand(models.Model):
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'item_brands'
        ordering = ['name', 'pk']
        verbose_name = 'Marca de Insumo'
        verbose_name_plural = 'Marcas de Insumos'
        constraints = [
            models.UniqueConstraint(Lower(Trim('name')), name='item_brand_name_unique'),
            models.CheckConstraint(condition=~Exact(Trim('name'), models.Value('')), name='item_brand_name_required'),
        ]

    def __str__(self):
        return self.name


class ItemCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'item_categories'
        verbose_name = 'Categoría de Insumo'
        verbose_name_plural = 'Categorías de Insumos'

    def __str__(self):
        return self.name


class InventoryItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    category = models.ForeignKey(ItemCategory, on_delete=models.PROTECT, related_name='items')
    brand = models.ForeignKey(ItemBrand, on_delete=models.PROTECT, related_name='items')
    sku = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True, null=True)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    current_stock = models.IntegerField(default=0)
    minimum_stock = models.IntegerField(default=5)
    is_published = models.BooleanField(default=False)
    public_title = models.CharField(max_length=150, blank=True, null=True)
    public_description = models.TextField(blank=True, null=True)
    public_price = models.DecimalField(max_digits=10, decimal_places=0, blank=True, null=True)
    public_image = models.ImageField(
        upload_to='catalog/', storage=CatalogImageStorage(), max_length=500, blank=True, null=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'inventory_items'
        indexes = [
            models.Index(fields=['category'], name='idx_inv_items_cat'),
            models.Index(fields=['sku'], name='idx_inv_sku'),
        ]
        verbose_name = 'Insumo de Inventario'
        verbose_name_plural = 'Insumos de Inventario'

    def __str__(self):
        return f"[{self.sku}] {self.name} (Stock: {self.current_stock})"

    @property
    def brand_name(self):
        name = self.brand.name
        return '' if name == UNIDENTIFIED_BRAND else name

    @property
    def is_low_stock(self):
        return self.current_stock <= self.minimum_stock
