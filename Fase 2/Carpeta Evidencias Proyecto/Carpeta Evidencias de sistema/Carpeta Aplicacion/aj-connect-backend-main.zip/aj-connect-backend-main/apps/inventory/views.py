import json

from django.db import transaction
from django.db.models import Count
from rest_framework import filters, generics, permissions, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.pagination import PageNumberPagination
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from .models import ItemBrand, ItemCategory, InventoryItem, UNIDENTIFIED_BRAND
from .permissions import CategoryPermissions, InventoryItemPermissions
from .serializers import (
    CatalogFieldsSerializer, InventoryItemSerializer, ItemBrandSerializer, ItemCategorySerializer, PublicCatalogSerializer,
)


class CategoryPagination(PageNumberPagination):
    page_size = 20


class CategoryOrdering(filters.OrderingFilter):
    def get_ordering(self, request, queryset, view):
        ordering = super().get_ordering(request, queryset, view) or ['name']
        return [*ordering, 'id']


class ItemCategoryViewSet(viewsets.ModelViewSet):
    pagination_class = CategoryPagination
    filter_backends = [filters.SearchFilter, CategoryOrdering]
    search_fields = ['name']
    ordering_fields = ['name', 'item_count', 'is_active']
    ordering = ['name']

    def get_queryset(self):
        queryset = super().get_queryset()
        # Filters affect the list only, never lookup for edits or archival.
        if self.action == 'list':
            status = self.request.query_params.get('status', '')
            if status not in ('', 'active', 'archived'):
                raise ValidationError({'status': 'Estado inválido.'})
            if status:
                queryset = queryset.filter(is_active=status == 'active')
        return queryset

    queryset = ItemCategory.objects.annotate(item_count=Count('items')).order_by('name')
    http_method_names = ['get', 'post', 'patch', 'head', 'options']
    serializer_class = ItemCategorySerializer
    permission_classes = [permissions.IsAuthenticated, CategoryPermissions]


class ItemBrandListCreateView(generics.ListCreateAPIView):
    queryset = ItemBrand.objects.all()
    serializer_class = ItemBrandSerializer
    permission_classes = [permissions.IsAuthenticated, InventoryItemPermissions]
    pagination_class = None

    def get_queryset(self):
        queryset = super().get_queryset()
        if self.request.query_params.get('include_archived') != 'true':
            queryset = queryset.filter(is_active=True)
        if self.request.query_params.get('include_unidentified') == 'true':
            return queryset.annotate(item_count=Count('items')).exclude(name=UNIDENTIFIED_BRAND, item_count=0)
        return queryset.exclude(name=UNIDENTIFIED_BRAND)


class ItemBrandDetailView(generics.RetrieveUpdateAPIView):
    queryset = ItemBrand.objects.exclude(name=UNIDENTIFIED_BRAND).annotate(item_count=Count('items'))
    serializer_class = ItemBrandSerializer
    permission_classes = [permissions.IsAuthenticated, InventoryItemPermissions]
    http_method_names = ['get', 'patch', 'head', 'options']


class InventoryItemViewSet(viewsets.ModelViewSet):
    queryset = InventoryItem.objects.select_related('category', 'brand').order_by('name')
    serializer_class = InventoryItemSerializer
    permission_classes = [permissions.IsAuthenticated, InventoryItemPermissions]

    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['sku', 'name', 'category__name', 'brand__name']
    ordering_fields = ['name', 'current_stock', 'unit_price', 'created_at']

    def get_queryset(self):
        queryset = super().get_queryset()
        if self.action == 'list' and (brand := self.request.query_params.get('brand')):
            field = serializers.IntegerField(min_value=1, max_value=2**63 - 1)
            try:
                brand_id = field.run_validation(brand)
            except ValidationError as error:
                raise ValidationError({'brand': 'Selecciona una marca válida.'}) from error
            return queryset.filter(brand_id=brand_id)
        return queryset

    @action(detail=False, methods=['post'], url_path='bulk-publish')
    def bulk_publish(self, request):
        entries = request.data
        if (request.content_type or '').startswith('multipart/form-data'):
            try:
                entries = json.loads(request.data.get('items', ''))
            except (ValueError, TypeError):
                raise ValidationError({'items': 'Envía la selección como un arreglo JSON.'})
        elif isinstance(entries, dict):
            entries = entries.get('items')

        if not isinstance(entries, list) or not entries:
            raise ValidationError({'items': 'Selecciona al menos un insumo.'})

        updates = {}
        uuid_field = serializers.UUIDField()
        for entry in entries:
            if not isinstance(entry, dict) or 'id' not in entry:
                raise ValidationError({'items': 'Cada insumo debe incluir un ID válido.'})
            item_id = uuid_field.run_validation(entry['id'])
            if item_id in updates:
                raise ValidationError({'items': 'Cada insumo debe aparecer una sola vez.'})
            fields = dict(entry)
            del fields['id']
            if not fields.keys() <= set(CatalogFieldsSerializer.Meta.fields):
                raise ValidationError({'items': 'La selección contiene campos ajenos a la ficha comercial.'})
            image = request.FILES.get(f'image_{item_id}')
            if image is not None:
                fields['public_image'] = image
            updates[item_id] = fields

        with transaction.atomic():
            items = {
                item.id: item
                for item in self.get_queryset().filter(pk__in=updates).order_by('pk').select_for_update(of=('self',))
            }
            if items.keys() != updates.keys():
                raise ValidationError({'items': 'Uno o más insumos ya no existen.'})
            validated = []
            for item_id, fields in updates.items():
                item = items[item_id]
                serializer = CatalogFieldsSerializer(item, data=fields, partial=True)
                if not serializer.is_valid():
                    field, errors = next(iter(serializer.errors.items()))
                    raise ValidationError({'detail': f'Ficha de {item.sku} ({field}): {errors[0]}'})
                validated.append(serializer)
            for serializer in validated:
                # Actualiza solo los datos comerciales para conservar cambios de inventario ajenos al catálogo.
                item = serializer.instance
                for field, value in serializer.validated_data.items():
                    setattr(item, field, value)
                item.is_published = True
                item.save(update_fields=[*serializer.validated_data, 'is_published', 'updated_at'])

        return Response(self.get_serializer(items.values(), many=True).data)


class PublicCatalogView(generics.ListAPIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    serializer_class = PublicCatalogSerializer
    pagination_class = None
    queryset = InventoryItem.objects.filter(is_published=True).select_related('category', 'brand').order_by('name', 'pk')
