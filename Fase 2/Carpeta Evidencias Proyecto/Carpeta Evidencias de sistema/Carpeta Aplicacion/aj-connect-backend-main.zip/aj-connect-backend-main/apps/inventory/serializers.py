from django.db import IntegrityError, transaction
from django.db.models import Value
from django.db.models.functions import Lower, Trim
from rest_framework import serializers
from .models import ItemBrand, ItemCategory, InventoryItem, UNIDENTIFIED_BRAND


def brands_with_name(name):
    return ItemBrand.objects.alias(normalized_name=Lower(Trim('name'))).filter(normalized_name=Lower(Value(name)))


class ItemBrandSerializer(serializers.ModelSerializer):
    name = serializers.CharField(max_length=100, error_messages={
        'required': 'Ingresa un nombre para la marca.',
        'blank': 'Ingresa un nombre para la marca.',
    })
    item_count = serializers.IntegerField(read_only=True)
    is_active = serializers.BooleanField(default=True)
    is_unidentified = serializers.SerializerMethodField()

    class Meta:
        model = ItemBrand
        fields = ['id', 'name', 'item_count', 'is_active', 'is_unidentified']

    def get_is_unidentified(self, brand):
        return brand.name == UNIDENTIFIED_BRAND

    def validate_name(self, value):
        name = ' '.join(value.split())
        if name.casefold() == UNIDENTIFIED_BRAND.casefold():
            raise serializers.ValidationError('Ese nombre está reservado para insumos pendientes de identificar.')
        return name

    def create(self, validated_data):
        brand, created = brands_with_name(validated_data['name']).get_or_create(defaults=validated_data)
        if not created:
            raise serializers.ValidationError({'name': ['Ya existe una marca con ese nombre.']})
        brand.item_count = 0
        return brand

    def update(self, instance, validated_data):
        for field, value in validated_data.items():
            setattr(instance, field, value)
        try:
            with transaction.atomic():
                instance.save(update_fields=list(validated_data))
        except IntegrityError:
            if 'name' in validated_data and brands_with_name(instance.name).exclude(pk=instance.pk).exists():
                raise serializers.ValidationError({'name': ['Ya existe una marca con ese nombre.']})
            raise
        return instance


class ItemCategorySerializer(serializers.ModelSerializer):
    item_count = serializers.IntegerField(read_only=True, default=0)
    def validate_name(self, value):
        name = ' '.join(value.split())
        if not name:
            raise serializers.ValidationError('Ingresa un nombre para la categoría.')
        existing = ItemCategory.objects.filter(name__iexact=name)
        if self.instance:
            existing = existing.exclude(pk=self.instance.pk)
        if existing.exists():
            raise serializers.ValidationError('Ya existe una categoría con ese nombre.')
        return name

    class Meta:
        model = ItemCategory
        fields = ['id', 'name', 'is_active', 'item_count', 'created_at']


class CatalogFieldsSerializer(serializers.ModelSerializer):
    public_price = serializers.DecimalField(
        max_digits=10, decimal_places=0, min_value=0, required=False, allow_null=True,
    )

    class Meta:
        model = InventoryItem
        fields = ['public_title', 'public_description', 'public_price', 'public_image']

    def validate_public_image(self, image):
        if image is None:
            return image
        if image.size > 5 * 1024 * 1024:
            raise serializers.ValidationError('La imagen debe pesar como máximo 5 MB.')
        if image.image.format not in ('JPEG', 'PNG', 'WEBP'):
            raise serializers.ValidationError('Sube una imagen JPG, PNG o WebP.')
        return image


class InventoryItemSerializer(CatalogFieldsSerializer):
    # Campo booleano calculado para que el front reciba la alerta directamente
    is_low_stock = serializers.BooleanField(read_only=True)
    
    # Detalle de la categoría legible (nombre) además del ID
    category_name = serializers.CharField(source='category.name', read_only=True)
    brand = serializers.PrimaryKeyRelatedField(
        queryset=ItemBrand.objects.exclude(name=UNIDENTIFIED_BRAND), required=False,
        error_messages={'does_not_exist': 'Selecciona una marca disponible.'},
    )
    brand_name = serializers.CharField(max_length=100, label='Marca', required=False, error_messages={
        'required': 'Ingresa la marca del insumo.',
        'blank': 'Ingresa la marca del insumo.',
    })

    class Meta:
        model = InventoryItem
        fields = [
            'id',
            'sku',
            'name',
            'description',
            'category',
            'category_name',
            'brand',
            'brand_name',
            'unit_price',
            'current_stock',
            'minimum_stock',
            'is_published',
            *CatalogFieldsSerializer.Meta.fields,
            'is_low_stock',
            'created_at',
            'updated_at',
        ]

    def validate_category(self, value):
        # Existing assignments survive archival, including edits to the item.
        if not value.is_active and (not self.instance or self.instance.category_id != value.pk):
            raise serializers.ValidationError('Esta categoría está archivada. Selecciona una categoría activa.')
        return value

    def validate_brand_name(self, value):
        name = ' '.join(value.split())
        if not name or name.casefold() == UNIDENTIFIED_BRAND.casefold():
            raise serializers.ValidationError('Ingresa una marca identificada para este insumo.')
        return name

    def validate(self, attrs):
        if 'brand' in attrs and 'brand_name' in attrs:
            raise serializers.ValidationError({'brand': 'Indica la marca una sola vez.'})
        if (self.instance is None or not self.partial) and not {'brand', 'brand_name'}.intersection(attrs):
            raise serializers.ValidationError({'brand_name': 'Ingresa la marca del insumo.'})
        return attrs

    def _set_brand(self, validated_data, current_brand_id=None):
        if 'brand' in validated_data:
            field = 'brand'
            brand = ItemBrand.objects.select_for_update().filter(pk=validated_data['brand'].pk).first()
            if brand is None:
                raise serializers.ValidationError({field: 'Selecciona una marca disponible.'})
        elif 'brand_name' in validated_data:
            field = 'brand_name'
            name = validated_data.pop('brand_name')
            brand, _ = brands_with_name(name).select_for_update().get_or_create(defaults={'name': name})
        else:
            return
        if not brand.is_active and brand.pk != current_brand_id:
            raise serializers.ValidationError({field: 'Esta marca está archivada. Selecciona una marca activa.'})
        validated_data['brand'] = brand

    @transaction.atomic
    def create(self, validated_data):
        self._set_brand(validated_data)
        return super().create(validated_data)

    @transaction.atomic
    def update(self, instance, validated_data):
        self._set_brand(validated_data, current_brand_id=instance.brand_id)
        return super().update(instance, validated_data)

    # Validaciones de negocio: precios y stock no negativos
    def validate_current_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock actual no puede ser negativo.")
        return value

    def validate_unit_price(self, value):
        if value < 0:
            raise serializers.ValidationError("El precio unitario no puede ser negativo.")
        return value


class PublicCatalogSerializer(serializers.ModelSerializer):
    title = serializers.SerializerMethodField()
    description = serializers.CharField(source='public_description', read_only=True)
    price = serializers.SerializerMethodField()
    image_url = serializers.ImageField(source='public_image', read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)
    brand_name = serializers.CharField(read_only=True)
    in_stock = serializers.SerializerMethodField()
    stock_status = serializers.SerializerMethodField()

    class Meta:
        model = InventoryItem
        fields = ['id', 'sku', 'title', 'description', 'price', 'image_url', 'category_name', 'brand_name', 'in_stock', 'stock_status']

    def get_title(self, item):
        return (item.public_title or '').strip() or item.name

    def get_price(self, item):
        price = item.public_price if item.public_price is not None else item.unit_price
        return str(price)

    def get_in_stock(self, item):
        return item.current_stock > 0

    def get_stock_status(self, item):
        if not self.get_in_stock(item):
            return 'out_of_stock'
        return 'low_stock' if item.is_low_stock else 'available'
