from django import forms
from django.contrib import admin
from django.db.models import Q
from .models import InventoryItem, ItemBrand, ItemCategory, UNIDENTIFIED_BRAND


class ItemBrandAdminForm(forms.ModelForm):
    def clean_name(self):
        name = ' '.join(self.cleaned_data['name'].split())
        if name.casefold() == UNIDENTIFIED_BRAND.casefold():
            raise forms.ValidationError('Ingresa una marca identificada.')
        return name


@admin.register(ItemBrand)
class ItemBrandAdmin(admin.ModelAdmin):
    form = ItemBrandAdminForm
    list_display = ('name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)

    def get_queryset(self, request):
        return super().get_queryset(request).exclude(name=UNIDENTIFIED_BRAND)


@admin.register(ItemCategory)
class ItemCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'created_at')
    search_fields = ('name',)


class InventoryItemAdminForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'brand' in self.fields:
            self.fields['brand'].queryset = ItemBrand.objects.exclude(name=UNIDENTIFIED_BRAND).filter(
                Q(is_active=True) | Q(pk=self.instance.brand_id),
            )


@admin.register(InventoryItem)
class InventoryItemAdmin(admin.ModelAdmin):
    form = InventoryItemAdminForm
    list_display = ('sku', 'name', 'brand', 'category', 'current_stock', 'minimum_stock', 'unit_price', 'is_low_stock')
    list_filter = ('category', 'brand')
    search_fields = ('sku', 'name', 'brand__name')
