import json
from io import BytesIO, StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

from cloudinary.exceptions import GeneralError
from django.contrib.auth.models import User
from django.core.management import call_command
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import override_settings
from PIL import Image
from rest_framework.test import APITestCase
from apps.authentication.models import UserProfile, Role, UserRole
from .models import InventoryItem, ItemBrand, ItemCategory, UNIDENTIFIED_BRAND


class CategoryTests(APITestCase):
    url = '/api/inventory/categories/'

    def setUp(self):
        self.admin = User.objects.create_user('admin', is_superuser=True)

    def test_normalization_and_duplicates(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post(self.url, {'name': '  Aceites   motor  '})
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data['name'], 'Aceites motor')
        self.assertEqual(self.client.post(self.url, {'name': 'aceites motor'}).status_code, 400)
        self.assertEqual(self.client.post(self.url, {'name': '   '}).status_code, 400)
        self.assertEqual(ItemCategory.objects.count(), 1)

    def test_role_permissions(self):
        self.assertEqual(self.client.get(self.url).status_code, 401)
        for role in ('ADMIN', 'RECEPCIONISTA', 'MECANICO', 'CLIENTE'):
            user = User.objects.create_user(role)
            UserProfile.objects.create(user=user)
            UserRole.objects.create(user=user, role=Role.objects.get(code=role))
            self.client.force_authenticate(user)
            self.assertEqual(self.client.get(self.url).status_code, 403 if role == 'CLIENTE' else 200)
            self.assertEqual(self.client.post(self.url, {'name': role}).status_code, 201 if role in ('ADMIN', 'RECEPCIONISTA') else 403)

    def test_archival_preserves_items_and_blocks_new_assignments(self):
        from .models import InventoryItem
        self.client.force_authenticate(self.admin)
        category = ItemCategory.objects.create(name='Aceites')
        other = ItemCategory.objects.create(name='Filtros')
        brand = ItemBrand.objects.create(name='Marca de prueba')
        item = InventoryItem.objects.create(category=category, brand=brand, sku='A1', name='Aceite', unit_price=100, current_stock=3)
        second = InventoryItem.objects.create(category=other, brand=brand, sku='B1', name='Filtro', unit_price=100)
        detail = f'{self.url}{category.pk}/'
        response = self.client.patch(detail, {'is_active': False})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['item_count'], 1)
        item.refresh_from_db()
        self.assertEqual(item.category_id, category.pk)
        self.assertEqual(self.client.post('/api/inventory/items/', {'sku':'C1', 'name':'Nuevo', 'brand_name':brand.name, 'category':category.pk, 'unit_price':100}).status_code, 400)
        self.assertEqual(self.client.patch(f'/api/inventory/items/{second.pk}/', {'category':category.pk}).status_code, 400)
        self.assertEqual(self.client.patch(f'/api/inventory/items/{item.pk}/', {'category':category.pk, 'name':'Aceite editado'}).status_code, 200)
        self.assertEqual(self.client.delete(detail).status_code, 405)
        self.assertEqual(self.client.patch(detail, {'is_active': True}).status_code, 200)
        self.assertEqual(self.client.patch(f'/api/inventory/items/{second.pk}/', {'category':category.pk}).status_code, 200)

    def test_edit_duplicates_and_mechanic_cannot_archive(self):
        category = ItemCategory.objects.create(name='Aceites')
        ItemCategory.objects.create(name='Filtros')
        self.client.force_authenticate(self.admin)
        detail = f'{self.url}{category.pk}/'
        self.assertEqual(self.client.patch(detail, {'name':' filtros '}).status_code, 400)
        self.assertEqual(self.client.patch(detail, {'name':'Aceites motor'}).status_code, 200)
        mechanic = User.objects.create_user('mechanic')
        UserProfile.objects.create(user=mechanic)
        UserRole.objects.create(user=mechanic, role=Role.objects.get(code='MECANICO'))
        self.client.force_authenticate(mechanic)
        self.assertEqual(self.client.patch(detail, {'is_active':False}).status_code, 403)

    def test_pagination_search_status_and_ordering(self):
        self.client.force_authenticate(self.admin)
        for index in range(25):
            ItemCategory.objects.create(name=f'Cat {index:02}', is_active=index != 24)
        first = ItemCategory.objects.get(name='Cat 00')
        InventoryItem.objects.create(category=first, brand=ItemBrand.objects.create(name='Marca de prueba'), sku='TEST', name='Test', unit_price=0)
        response = self.client.get(self.url)
        self.assertEqual(response.data['count'], 25)
        self.assertEqual(len(response.data['results']), 20)
        second = self.client.get(self.url, {'page':2})
        self.assertEqual(len(second.data['results']), 5)
        self.assertFalse(set(row['id'] for row in response.data['results']) & set(row['id'] for row in second.data['results']))
        filtered = self.client.get(self.url, {'search':'Cat 24', 'status':'archived'})
        self.assertEqual(filtered.data['count'], 1)
        self.assertEqual(self.client.get(self.url, {'status':'active'}).data['count'], 24)
        ordered = self.client.get(self.url, {'ordering':'-item_count'})
        self.assertEqual(ordered.data['results'][0]['id'], first.pk)
        self.assertEqual(self.client.get(self.url, {'page':99}).status_code, 404)
        self.assertEqual(self.client.get(self.url, {'status':'invalid'}).status_code, 400)


class PublicCatalogTests(APITestCase):
    public_url = '/api/inventory/public-catalog/'
    bulk_url = '/api/inventory/items/bulk-publish/'

    def setUp(self):
        credentials = SimpleNamespace(cloud_name='demo', api_key='test', api_secret='test')
        self.enterContext(patch('ajconnect_api.image_uploads.cloudinary.config', return_value=credentials))
        self.upload = self.enterContext(patch('ajconnect_api.image_uploads.uploader.upload', side_effect=self.cloud_upload))
        self.admin = User.objects.create_user('catalog-admin', is_superuser=True)
        category = ItemCategory.objects.create(name='Lubricantes')
        brand = ItemBrand.objects.create(name='Marca de prueba')
        self.published = InventoryItem.objects.create(
            category=category, brand=brand, sku='TEST-PUBLIC', name='Aceite', unit_price=15000,
            current_stock=2, is_published=True, description='Descripción interna',
        )
        self.hidden = InventoryItem.objects.create(
            category=category, brand=brand, sku='TEST-HIDDEN', name='Filtro', unit_price=7500,
        )

    def image(self, filename):
        contents = BytesIO()
        Image.new('RGB', (4, 4)).save(contents, format='PNG')
        return SimpleUploadedFile(filename, contents.getvalue(), content_type='image/png')

    @staticmethod
    def cloud_upload(file, *, folder, public_id, **options):
        identifier = f'{folder}/{public_id}'
        return {'secure_url': f'https://res.cloudinary.com/demo/image/upload/v1/{identifier}.png', 'public_id': identifier}

    def test_public_response_contains_only_published_commercial_fields(self):
        response = self.client.get(self.public_url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), [{
            'id': str(self.published.pk), 'sku': 'TEST-PUBLIC', 'title': 'Aceite',
            'description': None, 'price': '15000.00', 'image_url': None,
            'category_name': 'Lubricantes', 'brand_name': 'Marca de prueba', 'in_stock': True, 'stock_status': 'low_stock',
        }])
        self.assertEqual(self.client.post(self.public_url, {}, format='json').status_code, 405)

    def test_brand_is_required_and_reuses_normalized_names(self):
        self.client.force_authenticate(self.admin)
        url = '/api/inventory/items/'
        payload = {'sku': 'TEST-BRAND', 'name': 'Insumo', 'category': self.published.category_id, 'unit_price': 1000}
        for field in ({}, {'brand_name': '  '}, {'brand_name': UNIDENTIFIED_BRAND}):
            response = self.client.post(url, {**payload, **field}, format='json')
            self.assertEqual(response.status_code, 400, response.data)
            self.assertIn('brand_name', response.data)
        response = self.client.post(url, {**payload, 'brand_name': '  MARCA   de PRUEBA '}, format='json')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(response.data['brand'], self.published.brand_id)
        self.assertEqual(response.data['brand_name'], 'Marca de prueba')
        self.assertEqual(ItemBrand.objects.count(), 1)

        detail = f"{url}{response.data['id']}/"
        updated = self.client.patch(detail, {'brand_name': 'Marca nueva'}, format='json')
        self.assertEqual(updated.status_code, 200, updated.data)
        self.assertEqual(updated.data['brand_name'], 'Marca nueva')
        match = self.client.get(url, {'search': 'Marca nueva'})
        self.assertEqual([row['id'] for row in match.data], [response.data['id']])
        self.assertEqual(ItemBrand.objects.count(), 2)

    def test_legacy_brand_is_omitted_from_brand_choices_and_public_catalog(self):
        pending = ItemBrand.objects.create(name=UNIDENTIFIED_BRAND)
        InventoryItem.objects.filter(pk=self.published.pk).update(brand=pending)
        result = self.client.get(self.public_url)
        self.assertEqual(result.data[0]['brand_name'], '')
        self.client.force_authenticate(self.admin)
        self.assertNotIn(pending.pk, [row['id'] for row in self.client.get('/api/inventory/brands/').data])
        self.assertEqual(self.client.patch(f'/api/inventory/items/{self.published.pk}/', {'public_title': 'Aceite referencial'}).status_code, 200)

    def test_brand_summary_and_inventory_filter_include_unidentified_items(self):
        brands_url = '/api/inventory/brands/'
        items_url = '/api/inventory/items/'
        pending = ItemBrand.objects.create(name=UNIDENTIFIED_BRAND)
        self.assertEqual(self.client.get(brands_url, {'include_unidentified': 'true'}).status_code, 401)
        self.client.force_authenticate(self.admin)

        summary = self.client.get(brands_url, {'include_unidentified': 'true'}).data
        self.assertEqual({row['id']: row['item_count'] for row in summary}, {self.published.brand_id: 2})

        InventoryItem.objects.filter(pk=self.hidden.pk).update(brand=pending)
        summary = self.client.get(brands_url, {'include_unidentified': 'true'}).data
        self.assertEqual({row['id']: row['item_count'] for row in summary}, {self.published.brand_id: 1, pending.pk: 1})
        for brand_id, sku in ((self.published.brand_id, self.published.sku), (pending.pk, self.hidden.sku)):
            result = self.client.get(items_url, {'brand': brand_id})
            self.assertEqual([row['sku'] for row in result.data], [sku])
        self.assertEqual(self.client.get(items_url, {'brand': pending.pk, 'search': 'Aceite'}).data, [])
        self.assertEqual(self.client.get(items_url, {'brand': 'invalida'}).status_code, 400)

    def test_brand_creation_permissions_and_duplicate_names(self):
        url = '/api/inventory/brands/'
        mechanic = User.objects.create_user('mechanic')
        UserRole.objects.create(user=mechanic, role=Role.objects.get(code='MECANICO'))
        self.client.force_authenticate(mechanic)
        self.assertEqual(self.client.get(url).status_code, 200)
        self.assertEqual(self.client.post(url, {'name': 'Marca nueva'}).status_code, 403)

        receptionist = User.objects.create_user('receptionist')
        UserRole.objects.create(user=receptionist, role=Role.objects.get(code='RECEPCIONISTA'))
        self.client.force_authenticate(receptionist)
        response = self.client.post(url, {'name': '  Marca   nueva '})
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(response.data['name'], 'Marca nueva')
        self.assertEqual(response.data['item_count'], 0)
        for name in ('mARCA nueva', '  ', UNIDENTIFIED_BRAND):
            result = self.client.post(url, {'name': name})
            self.assertEqual(result.status_code, 400, result.data)
            self.assertIn('name', result.data)
        self.assertIn(response.data['id'], [row['id'] for row in self.client.get(url).data])

    def test_brand_rename_and_archive_keep_existing_assignments(self):
        self.client.force_authenticate(self.admin)
        brands_url = '/api/inventory/brands/'
        items_url = '/api/inventory/items/'
        assigned_brand = self.published.brand_id
        detail = f'{brands_url}{assigned_brand}/'
        other = ItemBrand.objects.create(name='Otra marca')
        pending = ItemBrand.objects.create(name=UNIDENTIFIED_BRAND)
        self.hidden.brand = other
        self.hidden.save(update_fields=['brand'])

        self.assertEqual(self.client.patch(detail, {'name': 'OTRA MARCA'}).status_code, 400)
        renamed = self.client.patch(detail, {'name': ' Marca   actualizada '})
        self.assertEqual(renamed.data['name'], 'Marca actualizada')
        self.assertEqual(renamed.data['item_count'], 1)
        self.assertEqual(self.client.get(self.public_url).data[0]['brand_name'], 'Marca actualizada')

        archived = self.client.patch(detail, {'is_active': False}, format='json')
        self.assertEqual(archived.status_code, 200)
        self.assertFalse(archived.data['is_active'])
        self.assertNotIn(assigned_brand, [row['id'] for row in self.client.get(brands_url).data])
        self.assertIn(assigned_brand, [row['id'] for row in self.client.get(brands_url, {'include_archived': 'true'}).data])
        self.assertEqual(self.client.patch(f'{brands_url}{pending.pk}/', {'is_active': False}, format='json').status_code, 404)
        self.assertEqual(self.client.delete(detail).status_code, 405)

        payload = {'sku': 'NEW-BRAND-TEST', 'name': 'Repuesto', 'category': self.published.category_id, 'unit_price': 100}
        self.assertEqual(self.client.post(items_url, {**payload, 'brand': assigned_brand}).status_code, 400)
        self.assertEqual(self.client.post(items_url, {**payload, 'brand_name': 'marca actualizada'}).status_code, 400)
        self.assertEqual(self.client.patch(f'{items_url}{self.hidden.pk}/', {'brand': assigned_brand}).status_code, 400)
        existing = self.client.patch(f'{items_url}{self.published.pk}/', {'brand': assigned_brand, 'current_stock': 10})
        self.assertEqual(existing.status_code, 200, existing.data)
        self.assertEqual(existing.data['brand'], assigned_brand)

        self.assertEqual(self.client.patch(detail, {'is_active': True}, format='json').status_code, 200)
        created = self.client.post(items_url, {**payload, 'brand': assigned_brand})
        self.assertEqual(created.status_code, 201, created.data)
        self.assertEqual(created.data['brand'], assigned_brand)

    def test_public_stock_status_uses_the_items_configured_minimum(self):
        for minimum, stock, expected in (
            (3, 0, 'out_of_stock'),
            (3, 1, 'low_stock'),
            (3, 3, 'low_stock'),
            (3, 4, 'available'),
            (7, 4, 'low_stock'),
            (0, 1, 'available'),
        ):
            with self.subTest(minimum=minimum, stock=stock):
                InventoryItem.objects.filter(pk=self.published.pk).update(
                    minimum_stock=minimum, current_stock=stock,
                )
                response = self.client.get(self.public_url)
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.json()[0]['stock_status'], expected)

    def test_patch_upload_zero_price_and_hide(self):
        self.client.force_authenticate(self.admin)
        url = f'/api/inventory/items/{self.published.pk}/'
        response = self.client.patch(url, {
            'public_title': 'Aceite comercial', 'public_price': 0,
            'public_image': self.image('foto-edicion.png'),
        })
        self.assertEqual(response.status_code, 200, response.data)
        public = self.client.get(self.public_url).json()[0]
        self.assertEqual(public['title'], 'Aceite comercial')
        self.assertEqual(public['price'], '0')
        self.assertTrue(public['image_url'].startswith('https://res.cloudinary.com/demo/image/upload/v1/aj_connect/catalog/'))
        self.assertEqual(self.upload.call_args.kwargs['resource_type'], 'image')
        self.published.refresh_from_db()
        self.assertEqual(self.published.public_image.name, public['image_url'])
        self.assertEqual(public['image_url'], response.data['public_image'])
        self.assertEqual(self.client.patch(url, {'public_price': ''}).status_code, 200)
        self.assertEqual(self.client.get(self.public_url).json()[0]['price'], '15000.00')
        self.assertEqual(self.client.patch(url, {'public_image': None}, format='json').status_code, 200)
        self.assertIsNone(self.client.get(self.public_url).json()[0]['image_url'])
        self.assertEqual(self.client.patch(url, {'is_published': False}, format='json').status_code, 200)
        self.assertEqual(self.client.get(self.public_url).json(), [])

    def test_bulk_multipart_publishes_all_selected_and_saves_their_fields(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post(self.bulk_url, {
            'items': json.dumps([
                {'id': str(self.hidden.pk), 'public_title': 'Filtro web', 'public_price': 8000},
                {'id': str(self.published.pk), 'public_description': 'Ficha revisada'},
            ]),
            f'image_{self.hidden.pk}': self.image('foto-lote.png'),
        })
        self.assertEqual(response.status_code, 200, response.data)
        self.client.force_authenticate(user=None)
        rows = {row['sku']: row for row in self.client.get(self.public_url).json()}
        self.assertEqual(rows['TEST-HIDDEN']['title'], 'Filtro web')
        self.assertEqual(rows['TEST-HIDDEN']['price'], '8000')
        self.assertFalse(rows['TEST-HIDDEN']['in_stock'])
        self.assertEqual(rows['TEST-HIDDEN']['image_url'], self.cloud_upload(None, **self.upload.call_args.kwargs)['secure_url'])
        self.assertEqual(rows['TEST-PUBLIC']['description'], 'Ficha revisada')

    def test_failed_image_upload_keeps_the_existing_catalog_photo(self):
        self.upload.side_effect = GeneralError('Cloudinary unavailable')
        InventoryItem.objects.filter(pk=self.published.pk).update(public_image='catalog/foto-anterior.png')
        self.client.force_authenticate(self.admin)
        response = self.client.patch(f'/api/inventory/items/{self.published.pk}/', {
            'public_title': 'Edición fallida', 'public_image': self.image('foto-nueva.png'),
        })
        self.assertEqual(response.status_code, 503, response.data)
        self.published.refresh_from_db()
        self.assertEqual(self.published.public_image.name, 'catalog/foto-anterior.png')
        self.assertIsNone(self.published.public_title)

    def test_migrates_existing_catalog_images_and_leaves_original_files(self):
        name = 'catalog/foto-anterior.png'
        InventoryItem.objects.filter(pk=self.published.pk).update(public_image=name)
        with TemporaryDirectory() as root, override_settings(MEDIA_ROOT=root, MEDIA_URL='/api/media/'):
            source = Path(root) / name
            source.parent.mkdir()
            contents = self.image('foto-anterior.png').read()
            source.write_bytes(contents)
            self.assertTrue(self.client.get(self.public_url).data[0]['image_url'].endswith(f'/api/media/{name}'))

            call_command('upload_legacy_images', stdout=StringIO())
            self.upload.assert_not_called()
            call_command('upload_legacy_images', apply=True, stdout=StringIO())
            self.assertEqual(source.read_bytes(), contents)
            self.assertTrue(self.client.get(self.public_url).data[0]['image_url'].startswith('https://res.cloudinary.com/'))

            call_command('upload_legacy_images', apply=True, stdout=StringIO())
            self.upload.assert_called_once()

    def test_invalid_bulk_entry_keeps_entire_selection_unchanged(self):
        self.client.force_authenticate(self.admin)
        for invalid in ({'id': str(self.published.pk), 'public_price': -1}, {'id': 'bad-id'}, {'id': str(self.hidden.pk)}):
            with self.subTest(invalid=invalid):
                response = self.client.post(self.bulk_url, [
                    {'id': str(self.hidden.pk), 'public_title': 'Cambiar ficha'},
                    invalid,
                ], format='json')
                self.assertEqual(response.status_code, 400, response.data)
                self.hidden.refresh_from_db()
                self.assertFalse(self.hidden.is_published)
                self.assertIsNone(self.hidden.public_title)

    def test_bulk_publish_requires_inventory_write_permissions(self):
        payload = [{'id': str(self.hidden.pk)}]
        self.assertEqual(self.client.post(self.bulk_url, payload, format='json').status_code, 401)
        for code, expected in [('CLIENTE', 403), ('MECANICO', 403), ('RECEPCIONISTA', 200)]:
            with self.subTest(role=code):
                user = User.objects.create_user(code)
                UserProfile.objects.create(user=user)
                UserRole.objects.create(user=user, role=Role.objects.get(code=code))
                self.client.force_authenticate(user)
                self.assertEqual(self.client.post(self.bulk_url, payload, format='json').status_code, expected)
