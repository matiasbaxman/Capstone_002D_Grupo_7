from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ItemBrandDetailView, ItemBrandListCreateView, ItemCategoryViewSet, InventoryItemViewSet, PublicCatalogView

router = DefaultRouter()
router.register(r'categories', ItemCategoryViewSet, basename='category')
router.register(r'items', InventoryItemViewSet, basename='inventory-item')

urlpatterns = [
    path('brands/', ItemBrandListCreateView.as_view(), name='item-brands'),
    path('brands/<int:pk>/', ItemBrandDetailView.as_view(), name='item-brand-detail'),
    path('public-catalog/', PublicCatalogView.as_view(), name='public-catalog'),
    path('', include(router.urls)),
]
