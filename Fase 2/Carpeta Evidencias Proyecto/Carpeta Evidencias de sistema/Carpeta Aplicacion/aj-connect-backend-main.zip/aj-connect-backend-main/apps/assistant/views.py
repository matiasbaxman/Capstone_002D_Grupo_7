from django.conf import settings
from google import genai
from google.genai import types
from rest_framework import permissions, status
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .prompts import SYSTEM_PROMPT
from .throttles import AssistantChatThrottle


FALLBACK_REPLY = (
    'El asistente no está disponible temporalmente. '
    'Intenta nuevamente en unos minutos. '
    'También puedes reservar en /agendar o visitar el taller sin reserva.'
)


class AssistantChatView(APIView):
    # HU-02: el chatbot público también admite visitantes sin sesión.
    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    parser_classes = [JSONParser]
    http_method_names = ['post', 'options']
    throttle_classes = [AssistantChatThrottle]

    def handle_exception(self, exc):
        response = super().handle_exception(exc)
        if response.status_code == status.HTTP_429_TOO_MANY_REQUESTS:
            response.data = {
                'error': 'Has alcanzado el límite de consultas. Intenta nuevamente en un minuto.',
                'status': 'error',
            }
        return response

    def post(self, request):
        data = request.data
        message = data.get('message') if isinstance(data, dict) else None
        if not isinstance(message, str) or not message.strip():
            return Response(
                {'error': "El campo 'message' es obligatorio.", 'status': 'error'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        message = message.strip()
        if not 3 <= len(message) <= 500:
            return Response(
                {'error': 'El mensaje debe tener entre 3 y 500 caracteres.', 'status': 'error'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        fallback = {
            'reply': FALLBACK_REPLY,
            'status': 'fallback',
        }
        if not settings.GEMINI_API_KEY:
            return Response(fallback, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        try:
            with genai.Client(
                api_key=settings.GEMINI_API_KEY,
                http_options=types.HttpOptions(
                    timeout=7000,
                    # Gemini exige >=10 s en el servidor; el cliente HTTP sigue
                    # limitado a 7 s y no reintenta si ese plazo se agota.
                    headers={'X-Server-Timeout': '10'},
                    retry_options=types.HttpRetryOptions(attempts=1),
                ),
            ) as client:
                result = client.models.generate_content(
                    model=settings.GEMINI_MODEL,
                    contents=message,
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_PROMPT,
                        max_output_tokens=512,
                    ),
                )
                reply = result.text
            if not isinstance(reply, str) or not reply.strip():
                return Response(fallback, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        except Exception:
            # Los errores del proveedor pueden contener credenciales o datos privados.
            return Response(fallback, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        return Response({'reply': reply, 'status': 'success'}, status=status.HTTP_200_OK)
