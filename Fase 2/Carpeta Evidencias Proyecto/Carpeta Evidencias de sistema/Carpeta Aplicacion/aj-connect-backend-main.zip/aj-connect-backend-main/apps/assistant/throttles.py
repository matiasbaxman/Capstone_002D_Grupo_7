from rest_framework.throttling import SimpleRateThrottle


class AssistantChatThrottle(SimpleRateThrottle):
    scope = 'assistant_chat'
    rate = '10/min'

    def get_cache_key(self, request, view):
        if request.method != 'POST':
            return None
        # Respeta NUM_PROXIES, igual que los demás límites públicos del proyecto.
        return self.cache_format % {'scope': self.scope, 'ident': self.get_ident(request)}
