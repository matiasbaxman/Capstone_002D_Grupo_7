import re
from unittest.mock import patch
from django.test import TestCase, override_settings
from django.core import mail
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APIClient
from apps.authentication.client_tokens import ClientAccessToken
from .models import Client, NotificationChannel, ClientProfileChange

@override_settings(EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class ClientProfileTests(TestCase):
    def setUp(self):
        from django.core.cache import cache
        cache.clear()
        channel, _ = NotificationChannel.objects.get_or_create(code='EMAIL', defaults={'name':'Correo'})
        self.client_record = Client.objects.create(rut='123456785', first_name='Ana', last_name='Perez', phone='', email='old@example.test', password_hash='!', notification_channel=channel)
        self.api = APIClient()
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(self.client_record)))
        self.payload = {'first_name':'Ana María', 'last_name':'Perez', 'email':'new@example.test', 'phone':''}

    def request_code(self):
        response = self.api.post('/api/auth/client-profile/request/', self.payload, format='json')
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(mail.outbox[-1].to, ['old@example.test'])
        return re.search(r'\b[0-9]{6}\b', mail.outbox[-1].body).group()

    def test_changes_require_code_and_apply_only_stored_payload_once(self):
        code = self.request_code()
        self.client_record.refresh_from_db()
        self.assertEqual(self.client_record.email, 'old@example.test')
        change = ClientProfileChange.objects.get()
        self.assertNotEqual(change.code_hash, code)
        response = self.api.post('/api/auth/client-profile/confirm/', {'code': code, 'email':'attacker@example.test'}, format='json')
        self.assertEqual(response.status_code, 200)
        self.client_record.refresh_from_db()
        self.assertEqual(self.client_record.email, 'new@example.test')
        self.assertEqual(self.client_record.rut, '123456785')
        self.assertEqual(self.api.post('/api/auth/client-profile/confirm/', {'code':code}, format='json').status_code, 400)

    def test_wrong_codes_and_expiry_do_not_modify_profile(self):
        code = self.request_code()
        wrong = '000000' if code != '000000' else '111111'
        for _ in range(5):
            self.assertEqual(self.api.post('/api/auth/client-profile/confirm/', {'code':wrong}, format='json').status_code, 400)
        self.assertEqual(self.api.post('/api/auth/client-profile/confirm/', {'code':code}, format='json').status_code, 400)
        self.client_record.refresh_from_db()
        self.assertEqual(self.client_record.email, 'old@example.test')
        ClientProfileChange.objects.update(attempts=0, expires_at=timezone.now()-timedelta(seconds=1))
        self.assertEqual(self.api.post('/api/auth/client-profile/confirm/', {'code':code}, format='json').status_code, 400)

    def test_session_required_and_another_client_cannot_use_code(self):
        code = self.request_code()
        self.api.credentials()
        self.assertEqual(self.api.post('/api/auth/client-profile/request/', self.payload, format='json').status_code, 401)
        other = Client.objects.create(rut='223456782', first_name='Otro', last_name='Cliente', phone='', email='other@example.test', password_hash='!', notification_channel=self.client_record.notification_channel)
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(other)))
        self.assertEqual(self.api.post('/api/auth/client-profile/confirm/', {'code':code}, format='json').status_code, 400)

    def test_send_failure_rolls_back_challenge_and_cooldown_limits_resend(self):
        with patch('apps.workshop.client_profile_views.send_mail', side_effect=RuntimeError('SMTP')):
            self.assertEqual(self.api.post('/api/auth/client-profile/request/', self.payload, format='json').status_code, 503)
        self.assertFalse(ClientProfileChange.objects.exists())
        self.request_code()
        self.assertEqual(self.api.post('/api/auth/client-profile/request/', self.payload, format='json').status_code, 429)
