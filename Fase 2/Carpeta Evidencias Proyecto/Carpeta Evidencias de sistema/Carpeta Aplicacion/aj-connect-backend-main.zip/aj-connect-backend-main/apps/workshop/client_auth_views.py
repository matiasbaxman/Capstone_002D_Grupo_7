import logging
import hashlib
import secrets
from collections.abc import Mapping
from datetime import timedelta

from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.db import OperationalError, transaction
from django.db.models import Value
from django.db.models.functions import Replace, Upper
from django.utils import timezone
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.throttling import SimpleRateThrottle
from rest_framework.views import APIView

from apps.authentication.client_tokens import ClientAccessToken, ClientJWTAuthentication
from .client_auth_serializers import ClientOTPRequestSerializer, ClientOTPVerifySerializer
from .client_otp_delivery import deliver_client_otp
from .models import Client, ClientOTP

logger = logging.getLogger(__name__)
OTP_LIFETIME = timedelta(minutes=5)
RESEND_DELAY = timedelta(seconds=60)
MAX_ATTEMPTS = 5
CODE_SENT = {'detail': 'Enviamos un código por tu canal registrado. Si ya solicitaste uno, utiliza ese código.'}
INVALID_CREDENTIALS = {'detail': 'Usuario y contraseña incorrectos.'}
INVALID_CODE = {'code': ['El código es incorrecto, expiró o ya fue utilizado.']}


def find_client(rut):
    expression = Upper(Replace(Replace(Replace('rut', Value('.'), Value('')), Value('-'), Value('')), Value(' '), Value('')))
    matches = list(Client.objects.annotate(rut_key=expression).filter(rut_key=rut)[:2])
    return matches[0] if len(matches) == 1 else None


def client_session_result(client, first_login=False):
    token = ClientAccessToken.for_client(client)
    return {
        'access': str(token), 'token_type': 'Bearer',
        'expires_in': int(token.lifetime.total_seconds()), 'first_login': first_login,
        'client': {'id': str(client.pk), 'first_name': client.first_name, 'last_name': client.last_name},
    }


class OTPRequestThrottle(SimpleRateThrottle):
    scope = 'client_otp_request'
    rate = '10/min'

    def get_cache_key(self, request, view):
        return self.cache_format % {'scope': self.scope, 'ident': self.get_ident(request)}


class OTPVerifyThrottle(OTPRequestThrottle):
    scope = 'client_otp_verify'
    rate = '30/min'


class PublicClientAuthView(APIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]

    def handle_exception(self, exc):
        if isinstance(exc, OperationalError) and 'locked' in str(exc).lower():
            return Response({'detail': 'El sistema está ocupado. Intenta nuevamente en unos segundos.'},
                            status=503, headers={'Retry-After': '3'})
        return super().handle_exception(exc)

    def finalize_response(self, request, response, *args, **kwargs):
        response = super().finalize_response(request, response, *args, **kwargs)
        response['Cache-Control'] = 'no-store'
        return response


class ClientOTPRequestView(PublicClientAuthView):
    throttle_classes = [OTPRequestThrottle]

    def post(self, request):
        serializer = ClientOTPRequestSerializer(data=request.data)
        password_login = isinstance(request.data, Mapping) and request.data.get('password', '') != ''
        if not serializer.is_valid(raise_exception=not password_login):
            return Response(INVALID_CREDENTIALS, status=401)
        rut = serializer.validated_data['rut']
        client = find_client(rut)
        if password_login:
            password = serializer.validated_data['password']
            if client is None or not client.has_usable_password():
                # Iguala el trabajo de verificación en cuentas ausentes o sin activar.
                make_password(password)
            elif client.check_password(password):
                return Response(client_session_result(client))
            return Response(INVALID_CREDENTIALS, status=401)
        if client is None or client.has_usable_password():
            return Response(INVALID_CREDENTIALS, status=401)
        cooldown_key = 'client-otp-cooldown:' + hashlib.sha256(rut.encode()).hexdigest()
        # El cooldown evita reenvíos al mismo cliente.
        if not cache.add(cooldown_key, True, int(RESEND_DELAY.total_seconds())):
            return Response(CODE_SENT)
        try:
            with transaction.atomic():
                # El bloqueo del padre serializa primer envío, reenvío y uso.
                client = Client.objects.select_for_update().select_related('notification_channel').get(pk=client.pk)
                otp = ClientOTP.objects.filter(client=client).first()
                now = timezone.now()
                if otp and now < otp.last_sent_at + RESEND_DELAY:
                    return Response(CODE_SENT)
                code = f'{secrets.randbelow(1_000_000):06d}'
                ClientOTP.objects.update_or_create(client=client, defaults={
                    'code_hash': make_password(code), 'expires_at': now + OTP_LIFETIME,
                    'last_sent_at': now, 'attempts': 0, 'consumed_at': None, 'verified_at': None,
                })
                deliver_client_otp(client, code)
        except Exception:
            cache.delete(cooldown_key)
            # El rollback conserva el desafío previo si el envío falla. No se
            # registran excepciones de proveedores que pudieran incluir el OTP.
            logger.error('No se pudo emitir el OTP de cliente.')
            return Response({'detail': 'No se pudo enviar el código. Intenta nuevamente más tarde.'}, status=503)
        return Response(CODE_SENT)


class ClientOTPVerifyView(PublicClientAuthView):
    throttle_classes = [OTPVerifyThrottle]

    def post(self, request):
        serializer = ClientOTPVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        client = find_client(data['rut'])
        if client is None:
            return Response(INVALID_CODE, status=400)
        with transaction.atomic():
            client = Client.objects.select_for_update().get(pk=client.pk)
            otp = ClientOTP.objects.select_for_update().filter(client=client).first()
            now = timezone.now()
            if otp is None or otp.consumed_at is not None:
                return Response(INVALID_CODE, status=400)
            if otp.expires_at <= now or otp.attempts >= MAX_ATTEMPTS:
                otp.consumed_at = now
                otp.save(update_fields=['consumed_at'])
                return Response(INVALID_CODE, status=400)
            if not check_password(data['code'], otp.code_hash):
                otp.attempts += 1
                if otp.attempts >= MAX_ATTEMPTS:
                    otp.consumed_at = now
                otp.save(update_fields=['attempts', 'consumed_at'])
                return Response(INVALID_CODE, status=400)
            first_login = not client.has_usable_password()
            if first_login:
                password = data.get('password')
                if not password:
                    return Response({'password': ['Crea tu contraseña para completar el primer ingreso.']}, status=400)
                try:
                    # El modelo de usuario de Django aporta nombres de campos traducidos.
                    validation_user = get_user_model()(username=client.rut, first_name=client.first_name,
                                                       last_name=client.last_name, email=client.email or '')
                    validate_password(password, user=validation_user)
                except ValidationError as error:
                    return Response({'password': error.messages}, status=400)
                client.set_password(password)
                client.save(update_fields=['password_hash', 'updated_at'])
            elif 'password' in data:
                return Response({'password': ['La contraseña ya está configurada. Omite este campo.']}, status=400)
            otp.consumed_at = now
            otp.verified_at = now
            otp.save(update_fields=['consumed_at', 'verified_at'])
            # Codificar dentro de la transacción evita consumir el OTP si falla
            # la emisión de la credencial.
            result = client_session_result(client, first_login)
        return Response(result)


class ClientSessionView(APIView):
    authentication_classes = [ClientJWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from .models import WorkOrder
        client = request.user
        vehicles = client.vehicles.select_related('model__brand').order_by('plate')
        appointments = client.appointments.filter(client=client).order_by('-scheduled_date')
        orders = WorkOrder.objects.filter(vehicle__client=client).select_related('status', 'vehicle').order_by('-created_at')
        response = Response({
            'client': {'id': str(client.pk), 'first_name': client.first_name, 'last_name': client.last_name, 'rut': client.rut, 'email': client.email, 'phone': client.phone},
            'vehicles': [
                {'id': str(vehicle.pk), 'plate': vehicle.plate, 'year': vehicle.year,
                 'color': vehicle.color, 'brand': vehicle.model.brand.name,
                 'model': vehicle.model.name}
                for vehicle in vehicles
            ],
            'appointments': list(appointments.values('id', 'status', 'scheduled_date', 'reported_symptoms', 'work_order__tracking_code', 'work_order__folio_number', 'work_order__status__name')),
            'orders': [{'folio_number': order.folio_number, 'tracking_code': order.tracking_code, 'status': order.status.name, 'created_at': order.created_at, 'plate': order.vehicle.plate, 'appointment_id': str(order.appointment_id) if order.appointment_id else None} for order in orders],
        })
        response['Cache-Control'] = 'no-store'
        return response
