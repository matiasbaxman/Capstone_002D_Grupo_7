from hashlib import sha256
from pathlib import Path

from django.core.exceptions import SuspiciousFileOperation
from django.core.files.storage import FileSystemStorage
from django.core.management.base import BaseCommand, CommandError
from PIL import Image

from ajconnect_api.image_uploads import ImageUploadError
from apps.inventory.models import InventoryItem
from apps.workshop.models import WorkOrderPhoto
from apps.workshop.services import upload_checkin_photo


class Command(BaseCommand):
    help = 'Migra a Cloudinary las imágenes anteriores que todavía están en el disco del backend.'

    def add_arguments(self, parser):
        parser.add_argument('--apply', action='store_true', help='Sube las imágenes y actualiza sus referencias.')

    def handle(self, *args, **options):
        source = FileSystemStorage()
        root = Path(source.location).resolve()
        apply = options['apply']
        migrated = missing = changed = 0

        catalog = InventoryItem.objects.exclude(
            public_image__isnull=True,
        ).exclude(public_image='').exclude(public_image__startswith='https://').exclude(
            public_image__startswith='http://',
        ).values_list('pk', 'public_image')
        checkins = WorkOrderPhoto.objects.filter(public_id__startswith='local/checkins/').values_list('pk', 'public_id', 'checkin_id')
        pending = [(catalog, self.upload_catalog_image), (checkins, self.upload_checkin_image)]
        for queryset, upload in pending:
            for record in list(queryset):
                pk, reference = record[:2]
                name = reference.removeprefix('local/')
                try:
                    path = Path(source.path(name)).resolve()
                    available = path.is_relative_to(root) and path.is_file()
                except (OSError, SuspiciousFileOperation):
                    available = False
                if not available:
                    self.stderr.write(f'Archivo local no disponible para el registro {pk}.')
                    missing += 1
                    continue
                if apply:
                    try:
                        with source.open(name, 'rb') as file:
                            with Image.open(file) as image:
                                image.verify()
                            updated = upload(record, file)
                    except (OSError, ImageUploadError) as exc:
                        raise CommandError(f'La subida del registro {pk} falló. Puedes ejecutar el comando de nuevo.') from exc
                    if not updated:
                        changed += 1
                        continue
                migrated += 1

        action = 'migradas' if apply else 'disponibles para migrar'
        self.stdout.write(f'Imágenes {action}: {migrated}. Archivos faltantes: {missing}. Cambios simultáneos: {changed}.')

    @staticmethod
    def upload_catalog_image(record, file):
        pk, previous = record
        field = InventoryItem._meta.get_field('public_image')
        url = field.storage.save(previous, file, max_length=field.max_length)
        return InventoryItem.objects.filter(pk=pk, public_image=previous).update(public_image=url)

    @staticmethod
    def upload_checkin_image(record, file):
        pk, previous, checkin_id = record
        reference_hash = sha256(f'{pk}:{previous}'.encode()).hexdigest()[:32]
        uploaded = upload_checkin_photo(file, checkin_id, public_id=f'legacy-{reference_hash}')
        return WorkOrderPhoto.objects.filter(pk=pk, public_id=previous).update(
            photo_cloudinary_url=uploaded['url'], public_id=uploaded['public_id'],
        )
