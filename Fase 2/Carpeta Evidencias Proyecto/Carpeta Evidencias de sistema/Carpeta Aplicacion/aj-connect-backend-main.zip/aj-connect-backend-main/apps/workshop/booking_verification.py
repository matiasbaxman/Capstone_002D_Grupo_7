"""Verificación del contacto antes de ocupar un cupo público."""
import hashlib
import json
import secrets
from datetime import timedelta
from types import SimpleNamespace

from django.contrib.auth.hashers import make_password, check_password
from django.core.cache import cache
from django.db import transaction
from django.utils import timezone
from rest_framework import permissions, serializers
from rest_framework.response import Response
from rest_framework.throttling import SimpleRateThrottle
from rest_framework.views import APIView

from .client_otp_delivery import deliver_client_otp
from .models import BookingVerification
from .serializers import PublicAppointmentCreateSerializer


def payload_hash(data):
    payload = {key: str(value.pk) if hasattr(value, 'pk') else value.isoformat() if hasattr(value, 'isoformat') else value for key, value in data.items()}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


class BookingThrottle(SimpleRateThrottle):
    scope = 'public_booking'
    rate = '20/hour'

    def get_cache_key(self, request, view):
        return self.cache_format % {'scope': self.scope, 'ident': self.get_ident(request)}


class BookingVerificationView(APIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    throttle_classes = [BookingThrottle]

    def post(self, request):
        serializer = PublicAppointmentCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        if serializer.existing_client and serializer.existing_client.appointments.exists():
            return Response({'detail': 'Inicia sesión para agendar tu siguiente cita sin otro código.'}, status=403)
        data = serializer.validated_data
        key = 'booking-otp:' + hashlib.sha256(data['rut'].encode()).hexdigest()
        if not cache.add(key, True, 60):
            return Response({'detail': 'Espera un minuto antes de solicitar otro código.'}, status=429)
        client = serializer.existing_client
        recipient = client or SimpleNamespace(
            email=data.get('email'), phone=data.get('phone'),
            notification_channel=SimpleNamespace(code=data['notification_channel']),
        )
        code = f'{secrets.randbelow(1_000_000):06d}'
        try:
            with transaction.atomic():
                challenge = BookingVerification.objects.create(
                    rut=data['rut'], payload_hash=payload_hash(data), code_hash=make_password(code),
                    expires_at=timezone.now() + timedelta(minutes=5),
                )
                deliver_client_otp(recipient, code, purpose="appointment")
        except Exception:
            cache.delete(key)
            return Response({'detail': 'No pudimos enviar el código. Intenta nuevamente más tarde.'}, status=503)
        response = Response({'verification_id': str(challenge.pk), 'detail': 'Enviamos un código al canal del cliente. Para clientes registrados usamos su contacto registrado.'})
        response['Cache-Control'] = 'no-store'
        return response


def verify_booking(request_data, validated_data):
    """Debe llamarse en la misma transacción que persiste la cita."""
    identifier = serializers.UUIDField().run_validation(request_data.get('verification_id'))
    code = serializers.RegexField(r'^\d{6}$').run_validation(request_data.get('code'))
    challenge = BookingVerification.objects.select_for_update().filter(pk=identifier).first()
    if not challenge or challenge.consumed_at or challenge.expires_at <= timezone.now() or challenge.attempts >= 5:
        return None, {'code': ['El código es incorrecto, expiró o ya fue utilizado.']}
    challenge.attempts += 1
    challenge.save(update_fields=['attempts'])
    if challenge.rut != validated_data['rut'] or challenge.payload_hash != payload_hash(validated_data) or not check_password(code, challenge.code_hash):
        return None, {'code': ['El código no corresponde a esta solicitud. Revisa tus datos y solicita otro código.']}
    return challenge, None
