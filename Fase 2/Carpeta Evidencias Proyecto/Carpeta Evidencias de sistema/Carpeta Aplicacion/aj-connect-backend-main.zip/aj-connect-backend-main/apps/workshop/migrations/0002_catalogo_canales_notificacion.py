from django.db import migrations

CANCALES = [
    ('WHATSAPP', 'WhatsApp'),
    ('EMAIL', 'Correo Electrónico'),
]


def crear_canales(apps, schema_editor):
    canal_model = apps.get_model('workshop', 'NotificationChannel')
    for code, name in CANCALES:
        canal_model.objects.get_or_create(
            code=code,
            defaults={'name': name},
        )


def eliminar_canales(apps, schema_editor):
    canal_model = apps.get_model('workshop', 'NotificationChannel')
    canal_model.objects.filter(code__in=[code for code, _ in CANCALES]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('workshop', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(crear_canales, eliminar_canales),
    ]