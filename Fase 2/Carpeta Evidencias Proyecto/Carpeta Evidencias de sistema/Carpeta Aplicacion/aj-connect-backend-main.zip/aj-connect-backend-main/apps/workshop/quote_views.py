from collections.abc import Mapping
from decimal import Decimal
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Prefetch, prefetch_related_objects
from django.shortcuts import get_object_or_404
from rest_framework import permissions, serializers
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import WorkOrder, Quote, QuoteItem, EmailDelivery, Service
from .quote_totals import calculate_totals
from .serializers import PublicServiceSerializer
from .views import WorkshopStaffPermission


QUOTE_ITEMS = Prefetch('items', queryset=QuoteItem.objects.select_related('item'))


def quote_services():
    return Service.objects.filter(is_active=True, base_price__isnull=False)


def booked_quote_service(order):
    service = order.appointment.service if order.appointment_id else None
    return service if service and service.is_active and service.base_price is not None else None


class QuoteServiceOptionsView(APIView):
    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        order = get_object_or_404(WorkOrder.objects.select_related('appointment__service'), pk=pk)
        booked = booked_quote_service(order)
        return Response({
            'services': PublicServiceSerializer(quote_services(), many=True).data,
            'default_service_id': booked.pk if booked else None,
        })


class QuoteCreateSerializer(serializers.Serializer):
    service = serializers.PrimaryKeyRelatedField(queryset=quote_services(), required=False, allow_null=True)
    service_description = serializers.CharField(max_length=96, required=False, allow_blank=True)

    def validate(self, attrs):
        if isinstance(self.initial_data, Mapping) and set(self.initial_data) - set(self.fields):
            raise serializers.ValidationError({'detail': 'Los precios se calculan desde el taller.'})
        order = self.context['order']
        service = attrs['service'] if 'service' in attrs else booked_quote_service(order)
        if attrs.get('service_description') and not service:
            raise serializers.ValidationError({'service_description': 'Selecciona un servicio para agregar su descripción.'})
        attrs['service'] = service
        return attrs


class QuoteItemSerializer(serializers.ModelSerializer):
    item_name = serializers.CharField(source='item.name', read_only=True)
    subtotal = serializers.DecimalField(max_digits=None, decimal_places=2, read_only=True)

    class Meta:
        model = QuoteItem
        fields = ['id', 'item_name', 'brand_name', 'quantity', 'unit_price', 'subtotal']
        read_only_fields = fields


class QuoteSerializer(serializers.ModelSerializer):
    items = QuoteItemSerializer(many=True, read_only=True)

    class Meta:
        model = Quote
        fields = [
            'id', 'work_order', 'created_at', 'subtotal_amount', 'tax_rate',
            'tax_amount', 'total_amount', 'is_approved', 'items', 'service_name', 'service_amount',
        ]
        read_only_fields = fields


class WorkOrderQuotesView(APIView):
    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        order = get_object_or_404(WorkOrder, pk=pk)
        quotes = order.quotes.order_by('-created_at', '-pk').prefetch_related(QUOTE_ITEMS)
        return Response(QuoteSerializer(quotes, many=True).data)

    @transaction.atomic
    def post(self, request, pk):
        order = get_object_or_404(WorkOrder.objects.select_for_update().select_related('vehicle'), pk=pk)
        serializer = QuoteCreateSerializer(data=request.data, context={'order': order})
        serializer.is_valid(raise_exception=True)
        service = serializer.validated_data['service']
        description = serializer.validated_data.get('service_description', '')
        items = list(order.items.select_related('item__brand').all())
        if not items and not service:
            raise serializers.ValidationError({'detail': 'Selecciona un servicio o agrega repuestos antes de generar la cotización.'})
        service_amount = service.base_price if service else None
        service_name = service.name if service else ''
        if description:
            service_name = f'{service_name} · {description}'
        tax_rate = Decimal(settings.AJ_QUOTE_TAX_RATE)
        quote = Quote(
            work_order=order, client_id=order.vehicle.client_id, tax_rate=tax_rate,
            service_name=service_name, service_amount=service_amount,
            **calculate_totals(items, tax_rate, service_amount),
        )
        try:
            quote.full_clean()
            quote.save()
        except ValidationError as error:
            raise serializers.ValidationError(error.message_dict) from error
        for line in items:
            item = QuoteItem(
                quote=quote, item=line.item, brand_name=line.item.brand_name,
                quantity=line.quantity, unit_price=line.unit_price,
            )
            try:
                item.full_clean()
                item.save()
            except ValidationError as error:
                raise serializers.ValidationError(error.message_dict) from error
        try:
            quote.full_clean()
        except ValidationError as error:
            raise serializers.ValidationError(error.message_dict) from error
        prefetch_related_objects([quote], QUOTE_ITEMS)
        return Response(QuoteSerializer(quote).data, status=201)


class EmailDeliveryView(APIView):
    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        job = get_object_or_404(EmailDelivery, pk=pk)
        return Response({'id': str(job.pk), 'status': job.status, 'attempts': job.attempts, 'detail': job.last_error})
