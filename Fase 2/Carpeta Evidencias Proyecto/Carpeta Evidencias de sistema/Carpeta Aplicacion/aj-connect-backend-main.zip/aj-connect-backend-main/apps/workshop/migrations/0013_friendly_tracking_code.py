from django.db import migrations, models
import apps.workshop.models


def populate_codes(historical_apps, schema_editor):
    Order = historical_apps.get_model('workshop', 'WorkOrder')
    used = set()
    for order in Order.objects.using(schema_editor.connection.alias).all().iterator():
        code = apps.workshop.models.generate_tracking_code()
        while code in used:
            code = apps.workshop.models.generate_tracking_code()
        used.add(code)
        order.tracking_code = code
        order.save(update_fields=['tracking_code'], using=schema_editor.connection.alias)


class Migration(migrations.Migration):
    dependencies = [('workshop', '0012_additional_checkin_equipment')]
    operations = [
        migrations.AddField(model_name='workorder', name='tracking_code', field=models.CharField(max_length=14, null=True, editable=False)),
        migrations.RunPython(populate_codes, migrations.RunPython.noop),
        migrations.AlterField(model_name='workorder', name='tracking_code', field=models.CharField(max_length=14, unique=True, default=apps.workshop.models.generate_tracking_code, editable=False)),
    ]
