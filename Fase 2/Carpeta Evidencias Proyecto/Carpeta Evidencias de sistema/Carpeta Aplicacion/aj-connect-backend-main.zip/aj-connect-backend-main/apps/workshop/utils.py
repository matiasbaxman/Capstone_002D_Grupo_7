import re

from rest_framework import serializers


def normalized_rut(value):
    """Valida un RUT chileno y lo devuelve limpio (sin puntos ni guion)."""
    if not re.fullmatch(r'[0-9kK.\-\s]+', value):
        raise serializers.ValidationError({'rut': 'Ingresa un RUT válido.'})
    clean = re.sub(r'[.\-\s]', '', value).upper()
    if not re.fullmatch(r'[1-9][0-9]{6,7}[0-9K]', clean):
        raise serializers.ValidationError({'rut': 'Ingresa un RUT válido.'})
    total = sum(int(digit) * (2 + index % 6) for index, digit in enumerate(reversed(clean[:-1])))
    result = 11 - total % 11
    expected = '0' if result == 11 else 'K' if result == 10 else str(result)
    if clean[-1] != expected:
        raise serializers.ValidationError({'rut': 'El dígito verificador no es válido.'})
    return clean
