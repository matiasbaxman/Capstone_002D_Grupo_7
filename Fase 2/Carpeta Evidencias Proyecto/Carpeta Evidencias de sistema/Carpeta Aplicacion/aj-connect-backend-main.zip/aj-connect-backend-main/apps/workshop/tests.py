from django.contrib.auth.models import User
from django.core import mail
from django.test import TestCase, override_settings
from rest_framework.test import APIClient
from apps.authentication.models import Role, UserRole
from .email_queue import process_next
from .models import (
    Client,
    EmailDelivery,
    NotificationChannel,
    Vehicle,
    VehicleBrand,
    VehicleModel,
    WorkOrder,
    WorkOrderCheckIn,
    WorkOrderStatus,
    WorkOrderStatusHistory,
)


class ClientLookupTests(TestCase):
    def setUp(self):
        self.api = APIClient()
        self.user = User.objects.create_superuser('lookup-admin', 'admin@example.test', 'test-only')
        self.api.force_authenticate(self.user)
        self.channel, _ = NotificationChannel.objects.get_or_create(
            code='WHATSAPP', defaults={'name': 'WhatsApp'}
        )

    def test_new_client_does_not_create_record(self):
        response = self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'})
        self.assertEqual(response.status_code, 200)
        self.assertIsNone(response.data['client'])
        self.assertEqual(Client.objects.count(), 0)

    def test_formatted_client_is_found_without_credentials(self):
        client = Client.objects.create(rut='12.345.678-5', first_name='Ana', last_name='PÃ©rez', phone='+56912345678', password_hash='must-not-be-exposed', notification_channel=self.channel)
        response = self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['client']['id'], str(client.id))
        self.assertNotIn('password_hash', response.data['client'])

    def test_invalid_rut_and_permissions(self):
        self.assertEqual(self.api.post('/api/workshop/clients/lookup/', {'rut': '123456784'}).status_code, 400)
        regular = User.objects.create_user('no-role', password='test-only')
        self.api.force_authenticate(regular)
        self.assertEqual(self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'}).status_code, 403)
        self.api.force_authenticate(None)
        self.assertEqual(self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'}).status_code, 401)

    def test_history_without_orders(self):
        Client.objects.create(rut='123456785', first_name='Ana', last_name='Perez', phone='+56912345678', password_hash='test', notification_channel=self.channel)
        response = self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'})
        self.assertEqual(response.data['client']['history'], {'attentionCount': 0, 'lastAttentionAt': None})
        self.assertEqual(response.data['vehicles'], [])

    def test_history_counts_only_this_clients_orders_across_vehicles(self):
        from datetime import timedelta
        from django.utils import timezone

        client = Client.objects.create(rut='123456785', first_name='Ana', last_name='Perez', phone='+56912345678', password_hash='test', notification_channel=self.channel)
        other = Client.objects.create(rut='223456782', first_name='Otro', last_name='Cliente', phone='+56987654321', password_hash='test', notification_channel=self.channel)
        brand = VehicleBrand.objects.create(name='History brand')
        model = VehicleModel.objects.create(name='History model', brand=brand)
        status, _ = WorkOrderStatus.objects.get_or_create(code='RECEPCIONADO', defaults={'name': 'Recepcionado', 'sequence_order': 1})
        latest = timezone.now() - timedelta(days=1)
        for index, owner in enumerate([client, client, other]):
            vehicle = Vehicle.objects.create(client=owner, model=model, plate=f'AB123{index}', year=2021)
            order = WorkOrder.objects.create(vehicle=vehicle, status=status, folio_number=9000 + index)
            WorkOrder.objects.filter(pk=order.pk).update(created_at=latest - timedelta(days=1 - index))
        response = self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'})
        self.assertEqual(response.data['client']['history']['attentionCount'], 2)
        self.assertEqual(response.data['client']['history']['lastAttentionAt'], latest)
        self.assertEqual({vehicle['plate'] for vehicle in response.data['vehicles']}, {'AB1230', 'AB1231'})

    def test_duplicate_normalized_rut_is_not_selected_arbitrarily(self):
        for rut, phone in [('123456785', '+56912345678'), ('12.345.678-5', '+56987654321')]:
            Client.objects.create(rut=rut, first_name='Ana', last_name='PÃ©rez', phone=phone, password_hash='test', notification_channel=self.channel)
        self.assertEqual(self.api.post('/api/workshop/clients/lookup/', {'rut': '123456785'}).status_code, 409)


class WorkOrderQueryTests(TestCase):
    """Endpoints de consulta y actualizaciÃ³n de Ã³rdenes de trabajo."""

    def setUp(self):
        self.api = APIClient()
        self.admin = User.objects.create_superuser('ot-admin', 'admin@example.test', 'test-only')
        self.api.force_authenticate(self.admin)
        self.mechanic = User.objects.create_user('ot-mecanico', password='test-only')
        whatsapp = NotificationChannel.objects.get_or_create(code='WHATSAPP', defaults={'name': 'WhatsApp'})[0]
        email = NotificationChannel.objects.get_or_create(code='EMAIL', defaults={'name': 'Correo'})[0]
        cliente = Client.objects.create(
            rut='123456785', first_name='Ana', last_name='PÃ©rez',
            phone='+56912345678', email='ana@example.cl',
            password_hash='test', notification_channel=whatsapp,
        )
        brand, _ = VehicleBrand.objects.get_or_create(name='Toyota')
        modelo, _ = VehicleModel.objects.get_or_create(name='Yaris', brand=brand)
        vehiculo = Vehicle.objects.create(client=cliente, plate='AA1111', model=modelo, year=2021)
        self.recepcionado, _ = WorkOrderStatus.objects.get_or_create(
            code='RECEPCIONADO', defaults={'name': 'Recepcionado', 'sequence_order': 1}
        )
        self.en_reparacion, _ = WorkOrderStatus.objects.get_or_create(
            code='EN_REPARACION', defaults={'name': 'En reparaciÃ³n', 'sequence_order': 2}
        )
        self.ot = WorkOrder.objects.create(
            folio_number=2001, tracking_token='token-ot-2001',
            vehicle=vehiculo, status=self.recepcionado,
        )
        WorkOrderCheckIn.objects.create(
            work_order=self.ot, receptionist=self.admin,
            initial_odometer=12000, fuel_level='1/2',
        )
        self.ruta = f'/api/workshop/work-orders/{self.ot.id}/'

    def test_lista_devuelve_campos_resumidos(self):
        respuesta = self.api.get('/api/workshop/work-orders/')
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(len(respuesta.data), 1)
        item = respuesta.data[0]
        self.assertEqual(item['folio_number'], 2001)
        self.assertEqual(item['plate'], 'AA1111')
        self.assertEqual(item['client_name'], 'Ana PÃ©rez')
        self.assertEqual(item['status_code'], 'RECEPCIONADO')
        self.assertIsNone(item['assigned_mechanic'])
        self.assertEqual(item['mecanico_nombre'], 'Sin asignar')

    def test_filtros_del_listado(self):
        casos = [
            ({'status': 'recepcionado'}, 1),
            ({'status': 'en_reparacion'}, 0),
            ({'status': 'NO_EXISTE'}, 0),
            ({'search': '2001'}, 1),
            ({'search': 'PÃ©rez'}, 1),
            ({'plate': 'AA-1111'}, 1),
            ({'plate': 'AA1111'}, 1),
            ({'unassigned': 'true'}, 1),
            ({'mechanic': self.mechanic.pk}, 0),
        ]
        for params, esperado in casos:
            with self.subTest(params=params):
                respuesta = self.api.get('/api/workshop/work-orders/', params)
                self.assertEqual(respuesta.status_code, 200)
                self.assertEqual(len(respuesta.data), esperado)

    def test_detalle_incluye_cliente_vehiculo_checkin(self):
        respuesta = self.api.get(self.ruta)
        self.assertEqual(respuesta.status_code, 200)
        detalle = respuesta.data
        self.assertEqual(detalle['client']['rut'], '123456785')
        self.assertEqual(detalle['vehicle']['plate'], 'AA1111')
        self.assertEqual(detalle['checkin']['initial_odometer'], 12000)
        self.assertEqual(detalle['checkin']['photos'], [])
        self.assertIsNone(detalle['checkin']['bodywork_details'])
        self.assertEqual(detalle['status_history'], [])
        self.assertEqual(detalle['mecanico_nombre'], 'Sin asignar')

    def test_patch_asigna_mecanico(self):
        respuesta = self.api.patch(self.ruta, {'assigned_mechanic_id': self.mechanic.pk}, format='json')
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.data['assigned_mechanic'], 'ot-mecanico')
        # Sin nombre completo se expone el nombre de usuario.
        self.assertEqual(respuesta.data['mecanico_nombre'], 'ot-mecanico')
        self.ot.refresh_from_db()
        self.assertEqual(self.ot.assigned_mechanic_id, self.mechanic.pk)

    def test_patch_estado_registra_historial_con_usuario_y_fecha(self):
        respuesta = self.api.patch(
            self.ruta,
            {'status_id': self.en_reparacion.pk, 'notes': 'Comienza el trabajo.'},
            format='json',
        )
        self.assertEqual(respuesta.status_code, 200)
        historial = respuesta.data['status_history']
        self.assertEqual(len(historial), 1)
        self.assertEqual(historial[0]['from_status_code'], 'RECEPCIONADO')
        self.assertEqual(historial[0]['to_status_code'], 'EN_REPARACION')
        self.assertEqual(historial[0]['changed_by'], 'ot-admin')
        self.assertEqual(historial[0]['notes'], 'Comienza el trabajo.')
        self.assertIsNotNone(historial[0]['changed_at'])

    def test_patch_mismo_estado_no_crea_historial_duplicado(self):
        self.api.patch(self.ruta, {'status_id': self.en_reparacion.pk}, format='json')
        respuesta = self.api.patch(self.ruta, {'status_id': self.en_reparacion.pk}, format='json')
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(len(respuesta.data['status_history']), 1)

    @override_settings(
        EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
        CLIENT_EMAIL_REQUIRED=True,
        PUBLIC_PORTAL_URL='https://example.test',
    )
    def test_listo_para_entrega_envia_un_correo_por_transicion(self):
        listo = WorkOrderStatus.objects.get(code='LISTO')
        entregado = WorkOrderStatus.objects.get(code='ENTREGADO')
        for _ in range(2):
            response = self.api.patch(self.ruta, {'status_id': listo.pk}, format='json')
            self.assertEqual(response.status_code, 200)

        deliveries = EmailDelivery.objects.filter(kind='work_order', target_id=self.ot.pk)
        ready_delivery = deliveries.get()
        self.assertEqual(ready_delivery.payload['status_code'], 'LISTO')
        self.assertEqual(ready_delivery.status, 'PENDING')

        WorkOrder.objects.filter(pk=self.ot.pk).update(status=entregado)
        self.assertTrue(process_next())
        ready_message, = mail.outbox
        self.assertIn('listo para entrega', ready_message.subject)
        self.assertEqual(ready_message.to, ['ana@example.cl'])
        self.assertIn('coordinar su retiro', ready_message.body)
        self.assertIn(f'https://example.test/seguimiento/{self.ot.tracking_code}', ready_message.body)
        self.assertFalse(ready_message.attachments)
        ready_delivery.refresh_from_db()
        self.assertEqual(ready_delivery.status, 'SENT')

    def test_historial_se_revierte_si_el_registro_falla(self):
        """Si el historial no se puede escribir, el estado tampoco cambia."""
        from unittest import mock
        with mock.patch(
            'apps.workshop.views.WorkOrderStatusHistory.objects.create',
            side_effect=RuntimeError('fallo simulado de historial'),
        ):
            with self.assertRaises(RuntimeError):
                self.api.patch(self.ruta, {'status_id': self.en_reparacion.pk}, format='json')
        self.ot.refresh_from_db()
        self.assertEqual(self.ot.status_id, self.recepcionado.id)

    def test_patch_vacio_o_invalido(self):
        self.assertEqual(self.api.patch(self.ruta, {}, format='json').status_code, 400)
        self.assertEqual(self.api.patch(self.ruta, {'status_id': 999999}, format='json').status_code, 400)
        self.assertEqual(
            self.api.patch('/api/workshop/work-orders/00000000-0000-0000-0000-000000000000/',
                           {'status_id': self.en_reparacion.pk}, format='json').status_code,
            404,
        )

    def test_diagnostico_tecnico_editable_y_bloqueado_al_entregar(self):
        diagnostico = WorkOrderStatus.objects.get(code='DIAGNOSTICO')
        entregado = WorkOrderStatus.objects.get(code='ENTREGADO')

        # En fase de diagnóstico se puede redactar.
        self.assertEqual(
            self.api.patch(self.ruta, {'status_id': diagnostico.pk}, format='json').status_code, 200
        )
        guardado = self.api.patch(
            self.ruta, {'technical_diagnosis': 'Falla en el clutch y revisión de frenos.'}, format='json'
        )
        self.assertEqual(guardado.status_code, 200)
        self.assertEqual(guardado.data['technical_diagnosis'], 'Falla en el clutch y revisión de frenos.')
        self.assertEqual(
            self.api.get(self.ruta).data['technical_diagnosis'],
            'Falla en el clutch y revisión de frenos.',
        )

        # Entregar y editar en la misma llamada se rechaza sin cambiar la OT.
        bloqueo = self.api.patch(
            self.ruta,
            {'status_id': entregado.pk, 'technical_diagnosis': 'Editado al entregar'},
            format='json',
        )
        self.assertEqual(bloqueo.status_code, 400)
        self.assertIn('technical_diagnosis', bloqueo.data)
        self.ot.refresh_from_db()
        self.assertEqual(self.ot.status_id, diagnostico.pk)
        self.assertEqual(self.ot.technical_diagnosis, 'Falla en el clutch y revisión de frenos.')

        # Una vez entregada, la edición directa también se bloquea.
        self.assertEqual(
            self.api.patch(self.ruta, {'status_id': entregado.pk}, format='json').status_code, 200
        )
        bloqueo = self.api.patch(self.ruta, {'technical_diagnosis': 'Cambio de plan'}, format='json')
        self.assertEqual(bloqueo.status_code, 400)
        self.assertIn('technical_diagnosis', bloqueo.data)
        self.ot.refresh_from_db()
        self.assertEqual(self.ot.technical_diagnosis, 'Falla en el clutch y revisión de frenos.')

    def test_check_in_registra_el_ingreso_en_el_historial(self):
        respuesta = self.api.post('/api/workshop/check-in/', {
            'first_name': 'Luis', 'last_name': 'Soto', 'rut': '223456782',
            'phone': '+56987654321', 'plate': 'BB2222', 'brand': 'Toyota',
            'vehicle_model': 'Yaris', 'year': '2020', 'odometer': '5000',
            'fuel': '1/2', 'spare': 'true', 'tools': 'true',
        })
        self.assertEqual(respuesta.status_code, 201)
        ot_id = respuesta.data['work_order']['id']
        historial = WorkOrderStatusHistory.objects.filter(work_order_id=ot_id)
        self.assertEqual(historial.count(), 1)
        self.assertIsNone(historial[0].from_status)
        self.assertEqual(historial[0].to_status_id, self.recepcionado.id)
        self.assertEqual(historial[0].changed_by_id, self.admin.id)

    def test_permisos_y_autenticacion(self):
        recepcionista = User.objects.create_user('ot-recepcionista', password='test-only')
        rol = Role.objects.get_or_create(name='Recepcionista')[0]
        UserRole.objects.get_or_create(user=recepcionista, role=rol)
        self.api.force_authenticate(recepcionista)
        self.assertEqual(self.api.get('/api/workshop/work-orders/').status_code, 403)
        self.assertEqual(self.api.get(self.ruta).status_code, 403)
        self.assertEqual(
            self.api.patch(self.ruta, {'status_id': self.en_reparacion.pk}, format='json').status_code,
            403,
        )
        self.api.force_authenticate(None)
        self.assertEqual(self.api.get('/api/workshop/work-orders/').status_code, 401)
        self.assertEqual(self.api.get(self.ruta).status_code, 401)


    def test_item_retry_does_not_discount_stock_twice(self):
        import uuid
        from apps.inventory.models import InventoryItem, ItemBrand, ItemCategory
        from .models import WorkOrderItem
        category = ItemCategory.objects.create(name='Repuestos de prueba')
        item = InventoryItem.objects.create(category=category, brand=ItemBrand.objects.create(name='Marca de prueba'), sku='TEST-1', name='Filtro', unit_price=1000, current_stock=2)
        route = self.ruta + 'items/'
        payload = {'item': str(item.pk), 'quantity': 2, 'request_id': str(uuid.uuid4())}
        first = self.api.post(route, payload, format='json')
        self.assertEqual(first.status_code, 201)
        repeated = self.api.post(route, payload, format='json')
        self.assertEqual(repeated.status_code, 200)
        self.assertEqual(first.data['id'], repeated.data['id'])
        item.refresh_from_db()
        self.assertEqual(item.current_stock, 0)
        self.assertEqual(WorkOrderItem.objects.filter(work_order=self.ot).count(), 1)
        changed = self.api.post(route, {**payload, 'quantity': 1}, format='json')
        self.assertEqual(changed.status_code, 409)
        detail = self.api.get(self.ruta).data
        self.assertEqual(detail['items'][0]['current_stock'], 0)
        self.assertEqual(detail['items'][0]['quantity'], 2)
        self.assertTrue(detail['can_add_items'])
        self.assertIn(self.en_reparacion.pk, [entry['id'] for entry in detail['allowed_statuses']])
        self.assertNotIn(self.recepcionado.pk, [entry['id'] for entry in detail['allowed_statuses']])

    def test_item_invalid_quantity_never_changes_stock(self):
        import uuid
        from apps.inventory.models import InventoryItem, ItemBrand, ItemCategory
        from .models import WorkOrderItem
        category = ItemCategory.objects.create(name='Repuestos de prueba')
        item = InventoryItem.objects.create(category=category, brand=ItemBrand.objects.create(name='Marca de prueba'), sku='TEST-2', name='Filtro', unit_price=1000, current_stock=2)
        for quantity in [0, -1, 3]:
            response = self.api.post(self.ruta + 'items/', {'item': str(item.pk), 'quantity': quantity, 'request_id': str(uuid.uuid4())}, format='json')
            self.assertEqual(response.status_code, 400)
        item.refresh_from_db()
        self.assertEqual(item.current_stock, 2)
        self.assertEqual(WorkOrderItem.objects.filter(work_order=self.ot).count(), 0)


class CheckInNotificationChannelTests(TestCase):
    """Verifica la preferencia de canal de notificaciÃ³n en el check-in."""

    def setUp(self):
        self.api = APIClient()
        self.user = User.objects.create_superuser('checkin-admin', 'admin@example.test', 'test-only')
        self.api.force_authenticate(self.user)
        self.whatsapp, _ = NotificationChannel.objects.get_or_create(code='WHATSAPP', defaults={'name': 'WhatsApp'})
        self.email, _ = NotificationChannel.objects.get_or_create(code='EMAIL', defaults={'name': 'Correo ElectrÃ³nico'})
        self.existing = Client.objects.create(
            rut='123456785',
            first_name='Ana',
            last_name='PÃ©rez',
            phone='+56912345678',
            email='ana@example.cl',
            password_hash='test',
            notification_channel=self.whatsapp,
        )
        brand, _ = VehicleBrand.objects.get_or_create(name='Toyota')
        modelo, _ = VehicleModel.objects.get_or_create(name='Yaris', brand=brand)
        self.vehicle = Vehicle.objects.create(
            client=self.existing,
            plate='AA1111',
            model=modelo,
            year=2021,
        )

    def registro(self, **extra):
        datos = {
            'odometer': '12000',
            'fuel': '1/2',
            'spare': 'true',
            'tools': 'true',
        }
        datos.update(extra)
        return self.api.post('/api/workshop/check-in/', datos)

    def test_registro_con_canal_email_persiste_el_vinculo(self):
        respuesta = self.registro(
            first_name='Luis', last_name='Soto', rut='223456782', phone='+56987654321',
            plate='BB2222', brand='Toyota', vehicle_model='Yaris', year='2020',
            email='luis@example.cl', notification_channel='EMAIL',
        )
        self.assertEqual(respuesta.status_code, 201)
        cliente = Client.objects.get(rut='223456782')
        self.assertEqual(cliente.notification_channel, self.email)

    def test_ausencia_de_canal_usa_whatsapp(self):
        respuesta = self.registro(
            first_name='Luis', last_name='Soto', rut='223456782', phone='+56987654321',
            plate='BB2222', brand='Toyota', vehicle_model='Yaris', year='2020',
        )
        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(Client.objects.get(rut='223456782').notification_channel, self.whatsapp)

    def test_condition_can_be_omitted_without_inventing_values(self):
        response = self.api.post('/api/workshop/check-in/', {
            'client_id': str(self.existing.pk), 'vehicle_id': str(self.vehicle.pk), 'plate': 'AA1111',
        })
        self.assertEqual(response.status_code, 201, response.data)
        checkin = WorkOrderCheckIn.objects.get()
        self.assertIsNone(checkin.initial_odometer)
        self.assertEqual(checkin.fuel_level, '')
        self.assertIsNone(checkin.has_spare_tire)
        self.assertIsNone(checkin.has_jack_and_tools)
        self.assertIsNone(checkin.bodywork_details)

    def test_zero_odometer_and_absent_equipment_remain_explicit(self):
        response = self.registro(client_id=self.existing.pk, vehicle_id=self.vehicle.pk, plate='AA1111', odometer='0', spare='false', tools='false')
        self.assertEqual(response.status_code, 201, response.data)
        checkin = WorkOrderCheckIn.objects.get()
        self.assertEqual(checkin.initial_odometer, 0)
        self.assertIs(checkin.has_spare_tire, False)
        self.assertIs(checkin.has_jack_and_tools, False)

    def test_invalid_provided_odometer_is_rejected(self):
        for odometer in ['-1', 'abc', '1.5']:
            response = self.registro(client_id=self.existing.pk, vehicle_id=self.vehicle.pk, plate='AA1111', odometer=odometer)
            self.assertEqual(response.status_code, 400)
        self.assertFalse(WorkOrderCheckIn.objects.exists())

    def test_additional_equipment_is_saved_and_returned(self):
        import json
        items = [{'name': 'Extintor', 'present': True}, {'name': 'Triangulos', 'present': False}, {'name': 'Botiquin', 'present': None}]
        response = self.registro(client_id=self.existing.pk, vehicle_id=self.vehicle.pk, plate='AA1111', additional_equipment=json.dumps(items))
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(WorkOrderCheckIn.objects.get().additional_equipment, items)
        self.assertEqual(response.data['additional_equipment'], items)

    def test_additional_equipment_rejects_invalid_and_duplicate_entries(self):
        import json
        invalid = [{}, [{'name': ''}], [{'name': 'Extintor', 'present': 'false'}], [{'name': 'Extintor'}, {'name': ' extintor '}], [{'name': str(i)} for i in range(21)]]
        for items in invalid:
            response = self.registro(client_id=self.existing.pk, vehicle_id=self.vehicle.pk, plate='AA1111', additional_equipment=json.dumps(items))
            self.assertEqual(response.status_code, 400, response.data)
        self.assertFalse(WorkOrderCheckIn.objects.exists())

    def test_canal_desconocido_es_rechazado(self):
        respuesta = self.registro(
            first_name='Luis', last_name='Soto', rut='223456782', phone='+56987654321',
            plate='BB2222', brand='Toyota', vehicle_model='Yaris', year='2020',
            notification_channel='SMS',
        )
        self.assertEqual(respuesta.status_code, 400)
        self.assertIn('notification_channel', respuesta.data)
        self.assertFalse(Client.objects.filter(rut='223456782').exists())

    def test_canal_email_exige_correo_valido(self):
        respuesta = self.registro(
            first_name='Luis', last_name='Soto', rut='223456782', phone='+56987654321',
            plate='BB2222', brand='Toyota', vehicle_model='Yaris', year='2020',
            email='no-es-un-correo', notification_channel='EMAIL',
        )
        self.assertEqual(respuesta.status_code, 400)
        # El campo `email` de DRF rechaza el formato antes que la regla del canal.
        self.assertIn('email', respuesta.data)
        self.assertFalse(Client.objects.filter(rut='223456782').exists())

    def test_cliente_existente_actualiza_su_canal(self):
        respuesta = self.registro(
            client_id=self.existing.pk, vehicle_id=self.vehicle.pk, plate='AA1111',
            email='ana.nueva@example.cl', notification_channel='EMAIL',
        )
        self.assertEqual(respuesta.status_code, 201)
        self.existing.refresh_from_db()
        self.assertEqual(self.existing.notification_channel, self.email)
        self.assertEqual(self.existing.email, 'ana.nueva@example.cl')

    def test_canal_acepta_minusculas(self):
        respuesta = self.registro(
            first_name='Luis', last_name='Soto', rut='223456782', phone='+56987654321',
            plate='BB2222', brand='Toyota', vehicle_model='Yaris', year='2020',
            notification_channel='whatsapp',
        )
        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(Client.objects.get(rut='223456782').notification_channel, self.whatsapp)


class CheckInMechanicAssignmentTests(TestCase):
    """La OT creada desde recepción nace con un mecánico y expone su nombre."""

    def setUp(self):
        self.api = APIClient()
        self.mechanic = User.objects.create_user(
            'mecanico-benja', password='test-only',
            first_name='Benjamín', last_name='Romero',
        )
        rol = Role.objects.get_or_create(code='MECANICO', defaults={'name': 'Mecánico'})[0]
        UserRole.objects.get_or_create(user=self.mechanic, role=rol)
        self.api.force_authenticate(self.mechanic)
        NotificationChannel.objects.get_or_create(code='WHATSAPP', defaults={'name': 'WhatsApp'})

    def registro(self, **extra):
        datos = {
            'first_name': 'Luis', 'last_name': 'Soto', 'rut': '223456782',
            'phone': '+56987654321', 'plate': 'BB2222', 'brand': 'Toyota',
            'vehicle_model': 'Yaris', 'year': '2020', 'odometer': '5000',
            'fuel': '1/2',
        }
        datos.update(extra)
        return self.api.post('/api/workshop/check-in/', datos)

    def test_check_in_asigna_al_usuario_autenticado(self):
        respuesta = self.registro()
        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.data['work_order']['assigned_mechanic_id'], self.mechanic.pk)
        self.assertEqual(respuesta.data['work_order']['mecanico_nombre'], 'Benjamín Romero')
        ot = WorkOrder.objects.get(pk=respuesta.data['work_order']['id'])
        self.assertEqual(ot.assigned_mechanic_id, self.mechanic.pk)

    def test_check_in_respeta_el_mecanico_enviado(self):
        otro = User.objects.create_user(
            'otro-mecanico', password='test-only',
            first_name='Carla', last_name='Muñoz',
        )
        respuesta = self.registro(assigned_mechanic_id=str(otro.pk))
        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.data['work_order']['assigned_mechanic_id'], otro.pk)
        self.assertEqual(respuesta.data['work_order']['mecanico_nombre'], 'Carla Muñoz')

    def test_check_in_rechaza_mecanico_inexistente(self):
        respuesta = self.registro(assigned_mechanic_id='999999')
        self.assertEqual(respuesta.status_code, 400)
        self.assertIn('assigned_mechanic_id', respuesta.data)
        self.assertFalse(WorkOrder.objects.exists())

    def test_listado_y_detalle_muestran_el_nombre_completo(self):
        respuesta = self.registro()
        ot_id = respuesta.data['work_order']['id']
        listado = self.api.get('/api/workshop/work-orders/')
        self.assertEqual(listado.status_code, 200)
        self.assertEqual(listado.data[0]['mecanico_nombre'], 'Benjamín Romero')
        detalle = self.api.get(f'/api/workshop/work-orders/{ot_id}/')
        self.assertEqual(detalle.status_code, 200)
        self.assertEqual(detalle.data['mecanico_nombre'], 'Benjamín Romero')
        self.assertEqual(detalle.data['assigned_mechanic'], 'mecanico-benja')
