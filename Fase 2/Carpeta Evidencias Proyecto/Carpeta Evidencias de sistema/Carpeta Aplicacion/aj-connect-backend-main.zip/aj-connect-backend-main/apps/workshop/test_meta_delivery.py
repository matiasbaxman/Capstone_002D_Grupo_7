import json
from unittest.mock import patch

from django.test import SimpleTestCase, override_settings

from .meta_delivery import send_otp, send_welcome


@override_settings(META_WHATSAPP_ACCESS_TOKEN='test-secret', META_WHATSAPP_PHONE_NUMBER_ID='12345',
                   META_WHATSAPP_TEST_TO='56912345678', META_WHATSAPP_API_VERSION='v25.0',
                   META_WHATSAPP_OTP_TEMPLATE='aj_connect_codigo_acceso', META_WHATSAPP_TEMPLATE_LANGUAGE='es')
class MetaDeliveryTests(SimpleTestCase):
    @patch('apps.workshop.meta_delivery.HTTPSConnection')
    def test_otp_template_preserves_leading_zero_and_copy_button(self, transport):
        response = transport.return_value.getresponse.return_value
        response.status = 200
        response.read.return_value = b'{"messages":[{"id":"wamid.test"}]}'
        self.assertTrue(send_otp('+56 9 1234 5678', 'Tu código de acceso a A&J Connect es 012345. Expira en 5 minutos. No lo compartas.'))
        request = transport.return_value.request.call_args
        payload = json.loads(request.kwargs['body'])
        self.assertEqual(payload['template']['components'][0]['parameters'][0]['text'], '012345')
        self.assertEqual(payload['template']['components'][1]['parameters'][0]['text'], '012345')
        self.assertEqual(payload['to'], '56912345678')
        transport.assert_called_with('graph.facebook.com', timeout=10)
        transport.return_value.close.assert_called_once()

    @patch('apps.workshop.meta_delivery.HTTPSConnection')
    def test_welcome_sends_full_instructions(self, transport):
        response = transport.return_value.getresponse.return_value
        response.status = 200
        response.read.return_value = b'{"messages":[{"id":"wamid.test"}]}'
        text = 'Tu cuenta está lista. Abre el portal e ingresa tu RUT.'
        self.assertTrue(send_welcome('56912345678', text))
        payload = json.loads(transport.return_value.request.call_args.kwargs['body'])
        self.assertEqual(payload['text']['body'], text)

    @patch('apps.workshop.meta_delivery.HTTPSConnection')
    def test_other_recipient_is_blocked(self, transport):
        with self.assertRaises(RuntimeError):
            send_welcome('56987654321', 'Prueba')
        transport.assert_not_called()

    @patch('apps.workshop.meta_delivery.HTTPSConnection')
    def test_error_does_not_expose_provider_details(self, transport):
        response = transport.return_value.getresponse.return_value
        response.status = 400
        response.read.return_value = b'{"error":{"code":131047,"message":"test-secret recipient OTP"}}'
        with self.assertRaisesRegex(RuntimeError, '131047') as caught:
            send_welcome('56912345678', 'Prueba')
        self.assertNotIn('test-secret', str(caught.exception))
        transport.return_value.close.assert_called_once()

    @patch('apps.workshop.meta_delivery.HTTPSConnection')
    def test_otp_requires_template_and_expected_message(self, transport):
        with self.settings(META_WHATSAPP_OTP_TEMPLATE=''):
            with self.assertRaises(RuntimeError):
                send_otp('56912345678', 'Código 123456')
        transport.assert_not_called()

    @patch('apps.workshop.meta_delivery.HTTPSConnection')
    def test_success_without_message_id_is_rejected(self, transport):
        response = transport.return_value.getresponse.return_value
        response.status = 200
        response.read.return_value = b'{}'
        with self.assertRaises(RuntimeError):
            send_welcome('56912345678', 'Prueba')
