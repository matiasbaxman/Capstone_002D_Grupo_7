import re
import uuid

from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import HttpResponse
from django.db import transaction
from django.db.models import Count, F, Max, Prefetch, Q, Value
from django.db.models.functions import Replace, Upper
from django.shortcuts import get_object_or_404
from rest_framework import permissions, serializers
from rest_framework.generics import ListAPIView, RetrieveUpdateAPIView
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.throttling import SimpleRateThrottle
from apps.authentication.permissions import is_admin, is_mecanico
from apps.inventory.models import InventoryItem
from .models import (
    Client,
    Appointment,
    NotificationChannel,
    Vehicle,
    VehicleBrand,
    VehicleModel,
    WorkOrder,
    WorkOrderCheckIn,
    WorkOrderItem,
    WorkOrderPhoto,
    WorkOrderStatus,
    WorkOrderStatusHistory,
    Quote,
)
from .serializers import (
    DEFAULT_NOTIFICATION_CHANNEL,
    CheckInCreateSerializer,
    CheckInDetailSerializer,
    WorkOrderDetailSerializer,
    WorkOrderItemSerializer,
    WorkOrderListSerializer,
    PublicWorkOrderTrackingSerializer,
    WorkOrderUpdateSerializer,
)
from .services import upload_checkin_photo
from .client_contacts import save_client_contacts
from .utils import normalized_rut
from .pdf_generator import generate_quote_pdf, generate_work_order_pdf
from .email_queue import enqueue_email, enqueue_client_welcome
from .notifications import READY_ORDER_STATUS_CODES

STATUS_RECEPCIONADO = 'RECEPCIONADO'


class WorkshopStaffPermission(permissions.BasePermission):
    """Check-In: acceso total para Mecánico y Administrador."""

    message = 'Acceso restringido. Se requiere rol de Mecánico o Administrador.'

    def has_permission(self, request, view):
        return is_admin(request.user) or is_mecanico(request.user)


class QuotePdfView(APIView):
    """GET /api/workshop/quotes/{id}/pdf/ — descarga autenticada."""

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        quote = get_object_or_404(
            Quote.objects.select_related(
                'client', 'work_order__vehicle__model__brand',
                'work_order__vehicle__client',
            ).prefetch_related('items__item'), pk=pk,
        )
        items = list(quote.items.all())
        if not items and not quote.service_name:
            return Response({'detail': 'La cotización no tiene items vinculados.'}, status=400)
        try:
            pdf = generate_quote_pdf(quote)
        except ValueError as exc:
            return Response({'detail': str(exc)}, status=400)
        except DjangoValidationError:
            return Response({'detail': 'Revisa los importes y el cliente de la cotización antes de exportar.'}, status=400)
        response = HttpResponse(pdf.getvalue(), content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="Cotizacion_AJ_{str(quote.id)[:8].upper()}.pdf"'
        return response


class WorkOrderPdfView(APIView):
    """GET /api/workshop/work-orders/{id}/pdf/ — informe técnico."""

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        work_order = get_object_or_404(
            WorkOrder.objects.select_related(
                'vehicle__client', 'vehicle__model__brand', 'checkin',
            ).prefetch_related('items__item'), pk=pk,
        )
        if not work_order.items.exists():
            return Response({'detail': 'La orden de trabajo no tiene items vinculados.'}, status=400)
        pdf = generate_work_order_pdf(work_order)
        response = HttpResponse(pdf.getvalue(), content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="Informe_Tecnico_AJ_OT_{work_order.folio_number}.pdf"'
        return response


class QuoteEmailView(APIView):
    """POST /api/workshop/quotes/{id}/email/ — envía la cotización PDF."""

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def post(self, request, pk):
        quote = get_object_or_404(Quote, pk=pk)
        if not quote.client.email or quote.client.notification_channel.code.upper() != 'EMAIL':
            return Response({'detail': 'El cliente debe tener correo y canal Email configurados.'}, status=400)
        if not quote.service_name and not quote.items.exists():
            return Response({'detail': 'La cotización no tiene items vinculados.'}, status=400)
        job = enqueue_email('quote', quote.pk)
        return Response({'id': str(job.pk), 'status': job.status, 'detail': 'Envío de cotización programado.'}, status=202)


class CheckInCreateView(APIView):
    """Registra el ingreso de un vehículo: orden de trabajo, check-in y fotos."""

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def _next_folio(self):
        last = WorkOrder.objects.aggregate(maximo=Max('folio_number'))['maximo'] or 1000
        return last + 1

    def _resolve_channel(self, code):
        """Busca el canal por código sin distinguir mayúsculas ni acentos."""
        wanted = (code or DEFAULT_NOTIFICATION_CHANNEL).strip().upper()
        channel = None
        for candidate in NotificationChannel.objects.all():
            if candidate.code.strip().upper() == wanted:
                channel = candidate
                break
        if channel:
            return channel

        # Si el catálogo no tiene el canal pedido, se crea con los valores
        # canónicos para que el registro nunca quede sin canal válido.
        return NotificationChannel.objects.create(
            code=wanted,
            name={'WHATSAPP': 'WhatsApp', 'EMAIL': 'Correo Electrónico'}.get(wanted, wanted.title()),
        )

    def _resolve_client(self, data):
        if data.get('client_id'):
            client = Client.objects.filter(pk=data['client_id']).first()
            if not client:
                raise serializers.ValidationError({'client_id': 'El cliente no existe.'})
            # Se actualiza el canal y el correo para reflejar la preferencia actual.
            updated = []
            channel = self._resolve_channel(data.get('notification_channel')) if 'notification_channel' in self.request.data else client.notification_channel
            if client.notification_channel_id != channel.id:
                client.notification_channel = channel
                updated.append('notification_channel')
            email = (data.get('email') or '').strip() or None
            if 'email' in self.request.data and client.email != email:
                client.email = email
                updated.append('email')
            if updated:
                client.save(update_fields=updated)
            return client

        channel = self._resolve_channel(data.get('notification_channel'))
        client = Client.objects.create(
            rut=data['rut'],
            first_name=data['first_name'].strip(),
            last_name=data['last_name'].strip(),
            phone=data.get('phone', '').strip(),
            email=(data.get('email') or '').strip() or None,
            # Primer ingreso al portal: OTP y creación de contraseña (T-04).
            password_hash=make_password(None),
            notification_channel=channel,
        )
        enqueue_client_welcome(client)
        return client

    def _resolve_vehicle(self, data, client):
        if data.get('vehicle_id'):
            vehicle = Vehicle.objects.filter(pk=data['vehicle_id'], client=client).first()
            if not vehicle:
                raise serializers.ValidationError(
                    {'vehicle_id': 'El vehículo no pertenece a este cliente.'}
                )
            return vehicle

        brand, _ = VehicleBrand.objects.get_or_create(name=data['brand'].strip())
        model, _ = VehicleModel.objects.get_or_create(brand=brand, name=data['vehicle_model'].strip())
        return Vehicle.objects.create(
            client=client,
            model=model,
            plate=data['plate'],
            year=data['year'],
            color=(data.get('color') or '').strip() or None,
        )

    @transaction.atomic
    def post(self, request):
        serializer = CheckInCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        with save_client_contacts():
            client = self._resolve_client(data)
        vehicle = self._resolve_vehicle(data, client)
        appointment = None
        if data.get('appointment_id'):
            appointment = Appointment.objects.select_for_update().filter(pk=data['appointment_id']).first()
            if not appointment or appointment.client_id != client.pk:
                raise serializers.ValidationError({'appointment_id': 'Selecciona una cita de este cliente.'})
            if appointment.status != 'CONFIRMADA' or WorkOrder.objects.filter(appointment=appointment).exists():
                raise serializers.ValidationError({'appointment_id': 'La cita debe estar aceptada y sin orden asociada.'})
            if appointment.vehicle_id and appointment.vehicle_id != vehicle.pk:
                raise serializers.ValidationError({'appointment_id': 'El vehículo no corresponde a la cita seleccionada.'})

        status, _ = WorkOrderStatus.objects.get_or_create(
            code=STATUS_RECEPCIONADO,
            defaults={'name': 'Recepcionado', 'sequence_order': 1},
        )

        symptoms = data.get('reported_symptoms') or (appointment.reported_symptoms if appointment else '')
        work_order = WorkOrder.objects.create(
            appointment=appointment,
            folio_number=self._next_folio(),
            vehicle=vehicle,
            client_observations=symptoms or None,
            status=status,
            # Si recepción no envía un mecánico explícito, la OT nace asignada
            # al usuario autenticado que registra el ingreso.
            assigned_mechanic=data.get('assigned_mechanic_id') or request.user,
        )

        if appointment:
            appointment.vehicle = vehicle
            appointment.status = 'ATENDIDA'
            appointment.save()

        # La OT nace en RECEPCIONADO, así que el alta queda auditada también.
        WorkOrderStatusHistory.objects.create(
            work_order=work_order,
            from_status=None,
            to_status=status,
            changed_by=request.user,
            notes='Ingreso registrado en recepción.',
        )

        checkin = WorkOrderCheckIn.objects.create(
            work_order=work_order,
            receptionist=request.user,
            initial_odometer=data['odometer'],
            fuel_level=data['fuel'],
            has_spare_tire=data['spare'],
            has_jack_and_tools=data['tools'],
            bodywork_details=(data.get('notes') or '').strip() or None,
            additional_equipment=data.get('additional_equipment', []),
        )

        for image in data.get('photos', []):
            uploaded = upload_checkin_photo(image, checkin_id=checkin.id)
            WorkOrderPhoto.objects.create(
                checkin=checkin,
                photo_cloudinary_url=uploaded['url'],
                public_id=uploaded['public_id'],
            )

        from .email_queue import enqueue_order_tracking
        enqueue_order_tracking(work_order)
        if symptoms:
            from .ai_diagnosis import save_intake_suggestion

            transaction.on_commit(
                lambda: save_intake_suggestion(work_order.pk, vehicle, checkin.initial_odometer, symptoms),
                robust=True,
            )
        payload = CheckInDetailSerializer(checkin, context={'request': request}).data
        return Response(payload, status=201)


class TrackingCodeThrottle(SimpleRateThrottle):
    scope = 'tracking_code'
    rate = '240/hour'

    def get_cache_key(self, request, view):
        if re.fullmatch(r'[0-9a-fA-F]{32}|[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', view.kwargs.get('token', '')):
            return None
        return self.cache_format % {'scope': self.scope, 'ident': self.get_ident(request)}


class PublicWorkOrderTrackingView(APIView):
    """Consulta de solo lectura por enlace público, sin autenticación JWT."""

    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    throttle_classes = [TrackingCodeThrottle]

    def get(self, request, token):
        not_found = {'detail': 'Orden de trabajo no encontrada'}
        # Acepta hex de 32 caracteres (incluidos tokens anteriores) y UUID
        # canónico de 36 caracteres. Ambos consultan el valor hex almacenado.
        is_uuid = re.fullmatch(r'[0-9a-fA-F]{32}|[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', token)
        normalized = token.replace('-', '').upper()
        if not is_uuid and not re.fullmatch(r'AJ[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{12}', normalized):
            return Response(not_found, status=404)
        queryset = WorkOrder.objects.select_related(
            'status', 'vehicle__model__brand', 'checkin',
        ).prefetch_related(
            Prefetch(
                'status_history',
                queryset=WorkOrderStatusHistory.objects.select_related(
                    'from_status', 'to_status',
                ).order_by('changed_at', 'id'),
            ),
            'checkin__photos', 'items__item',
        )
        work_order = queryset.filter(**({'tracking_token': uuid.UUID(token).hex} if is_uuid else {'tracking_code': normalized})).first()
        if work_order is None:
            return Response(not_found, status=404)
        response = Response(PublicWorkOrderTrackingSerializer(work_order).data)
        response['Cache-Control'] = 'no-store'
        return response


class WorkOrderListView(ListAPIView):
    """
    GET /api/workshop/work-orders/

    Lista las órdenes de trabajo. Filtros opcionales por query string:
    - ?status=<código>     estado exacto, insensible a mayúsculas (ej. RECEPCIONADO)
    - ?status_id=<uuid>    estado por id
    - ?mechanic=<id>       mecánico asignado
    - ?unassigned=true     solo OT sin mecánico
    - ?plate=<patente>     coincidencia parcial, ignora guiones y espacios
    - ?search=<texto>     folio, patente o nombre del cliente
    """

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]
    serializer_class = WorkOrderListSerializer

    def get_queryset(self):
        queryset = (
            WorkOrder.objects.select_related(
                'vehicle__client',
                'vehicle__model__brand',
                'assigned_mechanic',
                'status',
            )
            .order_by('-created_at')
        )
        params = self.request.query_params

        status_code = (params.get('status') or '').strip()
        if status_code:
            queryset = queryset.filter(status__code__iexact=status_code)

        status_id = params.get('status_id')
        if status_id:
            queryset = queryset.filter(status_id=status_id)

        mechanic = params.get('mechanic') or params.get('assigned_mechanic')
        if mechanic:
            queryset = queryset.filter(assigned_mechanic_id=mechanic)

        if str(params.get('unassigned', '')).lower() in ('1', 'true', 'yes'):
            queryset = queryset.filter(assigned_mechanic__isnull=True)

        plate = (params.get('plate') or '').strip().upper()
        if plate:
            clean = ''.join(char for char in plate if char.isalnum())
            if not clean:
                return queryset.none()
            queryset = queryset.filter(vehicle__plate__iregex=r'[\s\-]*'.join(clean))

        # `search` cubre folio, patente y datos del cliente en una sola pasada.
        search = (params.get('search') or '').strip()
        if search:
            condiciones = Q(
                vehicle__plate__icontains=search,
            ) | Q(
                vehicle__client__first_name__icontains=search,
            ) | Q(
                vehicle__client__last_name__icontains=search,
            ) | Q(
                vehicle__client__rut__icontains=search,
            )
            if search.isdigit():
                condiciones |= Q(folio_number=search)
            queryset = queryset.filter(condiciones)

        return queryset


class WorkOrderDetailView(RetrieveUpdateAPIView):
    """
    GET   /api/workshop/work-orders/{id}/ -> detalle completo
    PATCH /api/workshop/work-orders/{id}/ -> asignar mecánico / cambiar estado
    """

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get_queryset(self):
        return WorkOrder.objects.select_related(
            'vehicle__client',
            'vehicle__model__brand',
            'assigned_mechanic',
            'status',
        ).prefetch_related(
            'status_history__from_status',
            'status_history__to_status',
            'status_history__changed_by',
            'checkin__photos',
            'checkin__receptionist',
        )

    def get_serializer_class(self):
        if self.request.method in ('PATCH', 'PUT'):
            return WorkOrderUpdateSerializer
        return WorkOrderDetailSerializer

    @transaction.atomic
    def update(self, request, *args, **kwargs):
        work_order = get_object_or_404(self.get_queryset().select_for_update(of=('self',)), pk=kwargs['pk'])
        serializer = WorkOrderUpdateSerializer(
            work_order, data=request.data, partial=kwargs.pop('partial', True)
        )
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        previous_status = work_order.status
        new_status = data.get('status', previous_status)
        notes = data.get('notes')

        # save() y el historial comparten la transacción: si el historial falla,
        # el cambio de estado se revierte junto con él.
        work_order = serializer.save()

        if new_status.id != previous_status.id:
            WorkOrderStatusHistory.objects.create(
                work_order=work_order,
                from_status=previous_status,
                to_status=new_status,
                changed_by=request.user,
                notes=(notes or '').strip() or None,
            )
            # `get_queryset` prefetchea el historial para el GET. Esa caché no
            # conoce la fila recién insertada, así que se descarta para que el
            # PATCH devuelva el historial real y no el de la lectura previa.
            work_order._prefetched_objects_cache.pop('status_history', None)

            # La outbox comparte la transacción. Un worker envía el correo
            # cuando el commit lo vuelve visible, fuera del proceso HTTP.
            if new_status.code.upper() in READY_ORDER_STATUS_CODES | {'ENTREGADO'}:
                enqueue_email('work_order', work_order.pk, payload={
                    'status_code': new_status.code,
                    'status_name': new_status.name,
                })

        # Se devuelve el detalle completo para que el frontend no necesite un
        # GET extra tras cada PATCH.
        detalle = WorkOrderDetailSerializer(work_order, context={'request': request}).data
        return Response(detalle, status=200)


class WorkOrderItemListCreateView(APIView):
    """
    POST /api/workshop/work-orders/{id}/items/

    Vincula un insumo del inventario a la OT dentro de una transacción atómica:
    bloquea el insumo con select_for_update(), valida stock, guarda el snapshot
    del precio y descuenta las existencias con F().
    """

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    @transaction.atomic
    def post(self, request, pk):
        work_order = get_object_or_404(WorkOrder.objects.select_for_update(), pk=pk)
        request_id = serializers.UUIDField(required=False, allow_null=True).run_validation(request.data.get('request_id'))
        if request_id:
            previous = WorkOrderItem.objects.filter(work_order=work_order, request_id=request_id).first()
            if previous:
                if str(previous.item_id) != str(request.data.get('item')) or str(previous.quantity) != str(request.data.get('quantity')):
                    return Response({'detail': 'Este identificador ya fue usado para otra asociación.'}, status=409)
                return Response(WorkOrderItemSerializer(previous).data, status=200)
        serializer = WorkOrderItemSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        item_id = serializer.validated_data['item'].pk
        quantity = serializer.validated_data['quantity']

        # Lock pesimista: evita que dos OTs descuenten el mismo stock a la vez.
        inventory_item = InventoryItem.objects.select_for_update().get(pk=item_id)
        if quantity > inventory_item.current_stock:
            raise serializers.ValidationError('Stock insuficiente')

        order_item = WorkOrderItem.objects.create(
            work_order=work_order,
            item=inventory_item,
            added_by_user=request.user,
            quantity=quantity,
            request_id=request_id,
            unit_price=inventory_item.unit_price,
        )
        InventoryItem.objects.filter(pk=inventory_item.pk).update(
            current_stock=F('current_stock') - quantity
        )

        return Response(WorkOrderItemSerializer(order_item).data, status=201)


class WorkOrderItemDetailView(APIView):
    """
    DELETE /api/workshop/work-orders/{id}/items/{item_id}/

    Revierte el vínculo: devuelve la cantidad al inventario y elimina el
    registro, todo dentro de una transacción atómica.
    """

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    @transaction.atomic
    def delete(self, request, pk, item_id):
        order_item = get_object_or_404(WorkOrderItem, pk=item_id, work_order_id=pk)
        InventoryItem.objects.filter(pk=order_item.item_id).update(
            current_stock=F('current_stock') + order_item.quantity
        )
        order_item.delete()
        return Response(status=204)


class ClientLookupView(APIView):
    """
    POST /api/workshop/clients/lookup/

    Busca cliente y vehículos por RUT. 200 con `client: null` si no existe,
    409 si el RUT está duplicado en la base de datos.
    """

    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def post(self, request):
        raw = request.data.get('rut', '')
        if not isinstance(raw, str):
            raise serializers.ValidationError({'rut': 'Ingresa un RUT válido.'})
        rut = normalized_rut(raw.strip())
        # Support formatted legacy records without changing stored data.
        expression = Upper(Replace(Replace(Replace('rut', Value('.'), Value('')), Value('-'), Value('')), Value(' '), Value('')))
        matches = list(Client.objects.annotate(rut_key=expression).filter(rut_key=rut)[:2])
        if len(matches) > 1:
            return Response({'detail': 'Hay registros duplicados para este RUT. Solicita revisión a administración.'}, status=409)
        if not matches:
            return Response({'client': None, 'vehicles': []})
        client = matches[0]
        vehicles = client.vehicles.select_related('model__brand').order_by('plate')
        history = WorkOrder.objects.filter(vehicle__client=client).aggregate(
            attentionCount=Count('id'), lastAttentionAt=Max('created_at'),
        )
        return Response({
            'client': {'id': str(client.id), 'firstName': client.first_name, 'lastName': client.last_name, 'phone': client.phone, 'email': client.email or '', 'notificationChannel': client.notification_channel.code.upper(), 'history': history},
            'appointments': list(client.appointments.filter(status='CONFIRMADA', work_order__isnull=True).order_by('scheduled_date').values('id', 'scheduled_date', 'reported_symptoms', 'vehicle_id', 'service__name')),
            'vehicles': [{'id': str(vehicle.id), 'plate': vehicle.plate, 'label': f'{vehicle.model.brand.name} {vehicle.model.name}'} for vehicle in vehicles],
        })
