import base64
import json
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from django.core.exceptions import ImproperlyConfigured
from django.core.mail import EmailMessage, EmailMultiAlternatives, send_mail
from django.test import SimpleTestCase, override_settings


@override_settings(
    EMAIL_BACKEND='apps.workshop.brevo_backend.BrevoEmailBackend',
    BREVO_API_KEY='test-secret', DEFAULT_FROM_EMAIL='A&J Connect <sender@example.test>',
)
class BrevoBackendTests(SimpleTestCase):
    def setUp(self):
        patcher = patch('apps.workshop.brevo_backend.urlopen')
        self.transport = patcher.start()
        self.addCleanup(patcher.stop)
        response = self.transport.return_value.__enter__.return_value
        response.status = 201
        response.read.return_value = b'{"messageId":"accepted-test"}'

    def payload(self):
        return json.loads(self.transport.call_args.args[0].data)

    def test_plain_email_uses_authenticated_https_and_timeout(self):
        self.assertEqual(send_mail('Código de acceso', 'Tu código: 123456', None, ['client@example.test']), 1)
        request = self.transport.call_args.args[0]
        self.assertEqual(request.full_url, 'https://api.brevo.com/v3/smtp/email')
        self.assertEqual(request.get_header('Api-key'), 'test-secret')
        self.assertEqual(self.transport.call_args.kwargs['timeout'], 10)
        self.assertEqual(self.payload()['sender'], {'name': 'A&J Connect', 'email': 'sender@example.test'})
        self.assertEqual(self.payload()['textContent'], 'Tu código: 123456')

    def test_pdf_html_and_recipient_fields(self):
        message = EmailMultiAlternatives('Cotización', 'Texto', to=['Ana <ana@example.test>'],
                                        cc=['cc@example.test'], bcc=['bcc@example.test'], reply_to=['reply@example.test'])
        message.attach_alternative('<p>Cotización</p>', 'text/html')
        message.attach('cotizacion.pdf', b'%PDF-test', 'application/pdf')
        self.assertEqual(message.send(), 1)
        payload = self.payload()
        self.assertEqual(payload['htmlContent'], '<p>Cotización</p>')
        self.assertEqual(payload['to'], [{'name': 'Ana', 'email': 'ana@example.test'}])
        self.assertEqual(payload['bcc'], [{'email': 'bcc@example.test'}])
        self.assertEqual(payload['cc'], [{'email': 'cc@example.test'}])
        self.assertEqual(payload['replyTo'], {'email': 'reply@example.test'})
        self.assertEqual(base64.b64decode(payload['attachment'][0]['content']), b'%PDF-test')

    def test_missing_key_fails_without_network(self):
        with self.settings(BREVO_API_KEY=''):
            with self.assertRaises(ImproperlyConfigured):
                send_mail('Test', 'Body', None, ['client@example.test'])
        self.transport.assert_not_called()

    def test_http_errors_do_not_expose_credentials_or_response(self):
        self.transport.side_effect = HTTPError('https://api.brevo.com', 401, 'sensitive-body', {}, None)
        with self.assertRaisesRegex(RuntimeError, r'^Brevo rechazó el correo \(HTTP 401\)\.$'):
            send_mail('Test', 'Body', None, ['client@example.test'])

    def test_network_failure_is_reported(self):
        self.transport.side_effect = URLError('private details')
        with self.assertRaisesRegex(RuntimeError, '^No se pudo conectar con Brevo.$'):
            send_mail('Test', 'Body', None, ['client@example.test'])

    def test_fail_silently_returns_zero_for_rejected_email(self):
        self.transport.side_effect = TimeoutError()
        self.assertEqual(send_mail('Test', 'Body', None, ['client@example.test'], fail_silently=True), 0)

    def test_unconfirmed_delivery_is_not_counted(self):
        self.transport.return_value.__enter__.return_value.read.return_value = b'{}'
        with self.assertRaisesRegex(RuntimeError, 'identificador'):
            send_mail('Test', 'Body', None, ['client@example.test'])

    def test_empty_recipients_do_not_call_provider(self):
        self.assertEqual(EmailMessage('Test', 'Body').send(), 0)
        self.transport.assert_not_called()
