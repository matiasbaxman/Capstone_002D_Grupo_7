from django.test import TestCase, override_settings
from django.core import mail
from unittest.mock import patch
from . import test_client_onboarding as helpers
from .models import Appointment, EmailDelivery, Client
from .email_queue import process_next
from .client_otp_delivery import deliver_client_otp
from apps.authentication.client_tokens import ClientAccessToken

@override_settings(CLIENT_EMAIL_REQUIRED=True, CLIENT_OTP_DELIVERY_MODE='channel', EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class AppointmentNoticeTests(TestCase):
    setUp = helpers.ClientOnboardingTests.setUp
    data = helpers.ClientOnboardingTests.data
    booking = helpers.ClientOnboardingTests.booking

    def test_booking_uses_confirmation_subject(self):
        self.assertEqual(self.booking().status_code, 201)
        client = Client.objects.get()
        deliver_client_otp(client, '012345', purpose='appointment')
        self.assertIn('confirmación de cita', mail.outbox[-1].subject)
        self.assertNotIn('acceso', mail.outbox[-1].body)

    def test_status_change_queues_snapshot_and_sends_email_once(self):
        self.assertEqual(self.booking().status_code, 201)
        appointment = Appointment.objects.get()
        self.api.force_authenticate(self.staff)
        from .appointment_views import AppointmentAdminDetailView
        from rest_framework.test import APIRequestFactory, force_authenticate
        for status in ('CONFIRMADA', 'CONFIRMADA', 'CANCELADA'):
            request = APIRequestFactory().patch('/', {'status': status}, format='json')
            force_authenticate(request, self.staff)
            response = AppointmentAdminDetailView.as_view()(request, appointment_id=appointment.pk)
            self.assertEqual(response.status_code, 200, response.data)
        jobs = EmailDelivery.objects.filter(kind='appointment_notice').order_by('created_at')
        self.assertEqual(list(jobs.values_list('payload__status', flat=True)), ['CONFIRMADA', 'CANCELADA'])
        while process_next():
            pass
        self.assertTrue(any('aceptada' in email.subject for email in mail.outbox))
        self.assertTrue(any('cancelada' in email.subject for email in mail.outbox))

    def test_client_account_lists_only_own_appointments(self):
        self.assertEqual(self.booking().status_code, 201)
        client = Client.objects.get()
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(client)))
        response = self.api.get('/api/auth/client-session/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['appointments'][0]['status'], 'PENDIENTE')
        self.assertEqual(response.data['client']['email'], client.email)
