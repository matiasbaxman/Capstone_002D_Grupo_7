"""Cloud API de Meta, limitada al destinatario de demostración configurado."""
import json
import re
from http.client import HTTPSConnection

from django.conf import settings


def _number(value):
    value = re.sub(r'[\s()+-]', '', value.removeprefix('whatsapp:'))
    if not re.fullmatch(r'[1-9][0-9]{7,14}', value):
        raise RuntimeError('Configura un teléfono internacional válido para Meta.')
    return value


def _send(phone, content):
    if _number(phone) != _number(settings.META_WHATSAPP_TEST_TO):
        raise RuntimeError('Meta está limitado al teléfono de prueba configurado.')
    version = settings.META_WHATSAPP_API_VERSION
    phone_id = settings.META_WHATSAPP_PHONE_NUMBER_ID
    token = settings.META_WHATSAPP_ACCESS_TOKEN
    if not re.fullmatch(r'v[0-9]+\.[0-9]+', version) or not phone_id.isdigit() or not token:
        raise RuntimeError('Configura las credenciales de Meta Cloud API.')
    payload = {'messaging_product': 'whatsapp', 'to': _number(phone), **content}
    connection = HTTPSConnection('graph.facebook.com', timeout=10)
    try:
        connection.request('POST', f'/{version}/{phone_id}/messages',
                           body=json.dumps(payload).encode('utf-8'),
                           headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'})
        response = connection.getresponse()
        try:
            result = json.loads(response.read(65536))
        except (ValueError, UnicodeError):
            raise RuntimeError('Meta devolvió una respuesta inválida.') from None
        error = result.get('error') or {}
        messages = result.get('messages') or []
        if not 200 <= response.status < 300 or error or not messages or not messages[0].get('id'):
            code = error.get('code')
            safe_code = str(code) if isinstance(code, int) else 'no disponible'
            raise RuntimeError(f'Meta rechazó el envío (HTTP {response.status}, código {safe_code}).')
        return True  # Aceptación por la API; no equivale a entrega al teléfono.
    finally:
        connection.close()


def send_otp(phone, message):
    match = re.fullmatch(r'Tu código de acceso a A&J Connect es ([0-9]{6})\. Expira en 5 minutos\. No lo compartas\.', message)
    if not match or not settings.META_WHATSAPP_OTP_TEMPLATE:
        raise RuntimeError('Configura una plantilla de autenticación Meta para el código OTP.')
    code = match.group(1)
    return _send(phone, {'type': 'template', 'template': {
        'name': settings.META_WHATSAPP_OTP_TEMPLATE,
        'language': {'code': settings.META_WHATSAPP_TEMPLATE_LANGUAGE},
        'components': [
            {'type': 'body', 'parameters': [{'type': 'text', 'text': code}]},
            {'type': 'button', 'sub_type': 'url', 'index': '0',
             'parameters': [{'type': 'text', 'text': code}]},
        ],
    }})


def send_welcome(phone, message):
    # Texto completo de las instrucciones, disponible dentro de la ventana de atención.
    return _send(phone, {'type': 'text', 'text': {'preview_url': False, 'body': message}})
