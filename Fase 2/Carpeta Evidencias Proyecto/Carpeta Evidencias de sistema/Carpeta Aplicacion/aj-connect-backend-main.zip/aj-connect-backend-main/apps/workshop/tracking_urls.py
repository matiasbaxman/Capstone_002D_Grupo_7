from django.urls import path

from .views import PublicWorkOrderTrackingView

urlpatterns = [
    path('<str:token>/', PublicWorkOrderTrackingView.as_view(), name='work-order-tracking'),
]
