from types import SimpleNamespace
from unittest.mock import patch

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import SimpleTestCase

from .services import upload_checkin_photo


class CheckInPhotoTests(SimpleTestCase):
    def test_upload_uses_cloudinary_with_local_settings(self):
        credentials = SimpleNamespace(cloud_name='demo', api_key='test', api_secret='test')
        public_id = 'aj_connect/checkins/test-checkin/photo'
        url = f'https://res.cloudinary.com/demo/image/upload/{public_id}.jpg'
        photo = SimpleUploadedFile('photo.jpg', b'image-data', content_type='image/jpeg')
        photo.read()

        def fake_upload(file, **options):
            self.assertEqual(file.read(), b'image-data')
            self.assertEqual(options['folder'], 'aj_connect/checkins/test-checkin')
            self.assertEqual(options['resource_type'], 'image')
            return {'secure_url': url, 'public_id': public_id}

        with (
            patch('ajconnect_api.image_uploads.cloudinary.config', return_value=credentials),
            patch('ajconnect_api.image_uploads.uploader.upload', side_effect=fake_upload),
        ):
            result = upload_checkin_photo(photo, checkin_id='test-checkin')

        self.assertEqual(result, {'url': url, 'public_id': public_id})
