from ajconnect_api.image_uploads import upload_image


def upload_checkin_photo(file, checkin_id=None, *, public_id=None):
    folder = f'aj_connect/checkins/{checkin_id}' if checkin_id else 'aj_connect/checkins'
    return upload_image(file, folder=folder, public_id=public_id)
