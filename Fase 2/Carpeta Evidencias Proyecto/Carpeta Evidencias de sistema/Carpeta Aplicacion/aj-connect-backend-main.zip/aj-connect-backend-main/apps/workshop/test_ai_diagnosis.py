import asyncio
import json
from unittest.mock import AsyncMock, patch

from django.test import TestCase, override_settings

from . import test_client_onboarding as helpers
from .models import Appointment, Client, WorkOrder


@override_settings(GEMINI_API_KEY='test-only', GEMINI_MODEL='test-model')
class IntakeDiagnosisTests(TestCase):
    setUp = helpers.ClientOnboardingTests.setUp
    data = helpers.ClientOnboardingTests.data
    checkin = helpers.ClientOnboardingTests.checkin
    booking = helpers.ClientOnboardingTests.booking

    def test_saves_one_suggestion_and_reads_it_without_calling_gemini_again(self):
        with patch('apps.workshop.ai_diagnosis.genai.Client') as client:
            session = client.return_value.aio.__aenter__.return_value
            session.models.generate_content = AsyncMock()
            generate = session.models.generate_content
            generate.return_value.text = '["Revisar discos de freno.", "Inspeccionar bujes de suspensión."]'
            with self.captureOnCommitCallbacks(execute=True):
                response = self.checkin(odometer=85000, reported_symptoms='Vibración al frenar')

            self.assertEqual(response.status_code, 201, response.data)
            order = WorkOrder.objects.get()
            suggestion = '• Revisar discos de freno.\n• Inspeccionar bujes de suspensión.'
            self.assertEqual(order.client_observations, 'Vibración al frenar')
            self.assertEqual(order.ai_diagnostic_suggestion, suggestion)
            detail = f'work-orders/{order.pk}/'
            for path in (detail, detail, f'orders/{order.pk}/', 'work-orders/'):
                response = self.api.get(f'/api/workshop/{path}')
                self.assertEqual(response.status_code, 200)
                data = response.json()
                self.assertEqual((data[0] if isinstance(data, list) else data)['ai_diagnostic_suggestion'], suggestion)

            response = self.api.get(f'/api/tracking/{order.tracking_code}/')
            self.assertEqual(response.status_code, 200)
            self.assertNotIn('ai_diagnostic_suggestion', response.json())
            generate.assert_awaited_once()
            self.assertEqual(json.loads(generate.call_args.kwargs['contents']), {
                'marca': 'Toyota', 'modelo': 'Yaris', 'año': 2021,
                'kilometraje_km': 85000, 'sintomas': 'Vibración al frenar',
            })
            options = client.call_args.kwargs['http_options']
            self.assertEqual(options.timeout, 6000)
            self.assertEqual(options.retry_options.attempts, 1)

    def test_provider_timeout_creates_order_with_null_suggestion(self):
        with patch('apps.workshop.ai_diagnosis.TIMEOUT_SECONDS', 0.01), \
             patch('apps.workshop.ai_diagnosis.genai.Client') as client:
            generate = AsyncMock(side_effect=lambda **kwargs: None)

            async def slow_generation(**kwargs):
                await asyncio.sleep(60)

            generate.side_effect = slow_generation
            client.return_value.aio.__aenter__.return_value.models.generate_content = generate
            with self.captureOnCommitCallbacks(execute=True):
                response = self.checkin(reported_symptoms='Golpeteo al acelerar')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertIsNone(WorkOrder.objects.get().ai_diagnostic_suggestion)
        generate.assert_awaited_once()

    def test_insufficient_symptoms_skip_provider(self):
        with patch('apps.workshop.ai_diagnosis.genai.Client') as client:
            with self.captureOnCommitCallbacks(execute=True):
                response = self.checkin(reported_symptoms='--')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertIsNone(WorkOrder.objects.get().ai_diagnostic_suggestion)
        client.assert_not_called()

    def test_uses_linked_appointment_symptoms_without_retrying_the_same_appointment(self):
        self.assertEqual(self.booking(reported_symptoms='Ruido al frenar\nPatente: BC-DF-12').status_code, 201)
        appointment = Appointment.objects.get()
        appointment.status = 'CONFIRMADA'
        appointment.save(update_fields=['status'])
        linked = {'appointment_id': str(appointment.pk), 'client_id': str(Client.objects.get().pk)}
        with patch('apps.workshop.ai_diagnosis.request_causes', return_value='["Revisar pastillas."]') as request:
            with self.captureOnCommitCallbacks(execute=True):
                response = self.checkin(**linked)
            self.assertEqual(response.status_code, 201, response.data)
            with self.captureOnCommitCallbacks(execute=True):
                repeat = self.checkin(**linked)
        self.assertEqual(repeat.status_code, 400)
        request.assert_awaited_once()
        self.assertEqual(request.call_args.args[0]['sintomas'], 'Ruido al frenar')
