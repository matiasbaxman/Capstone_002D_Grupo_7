from django.urls import path

from .appointment_views import AppointmentAdminDetailView, PublicAppointmentView
from .booking_verification import BookingVerificationView

urlpatterns = [
    path('verify-contact/', BookingVerificationView.as_view(), name='booking-verify-contact'),
    path('<uuid:appointment_id>/', AppointmentAdminDetailView.as_view(), name='appointment-admin-detail'),
    path('', PublicAppointmentView.as_view(), name='public-appointments'),
]
