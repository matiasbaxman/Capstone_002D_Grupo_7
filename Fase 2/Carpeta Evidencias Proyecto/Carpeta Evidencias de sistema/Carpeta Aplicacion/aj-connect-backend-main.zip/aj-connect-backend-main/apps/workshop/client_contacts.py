from contextlib import contextmanager

from django.db import IntegrityError, transaction
from django.db.models import Case, Value, When
from django.db.models.functions import Concat, Length, Lower, NullIf, Replace, Right, Trim
from django.db.models.lookups import Exact, StartsWith
from rest_framework.exceptions import ValidationError


CONTACT_CONSTRAINTS = {
    'email': 'client_contact_email_unique',
    'phone': 'client_contact_phone_unique',
}
CONTACT_ERRORS = {
    'email': 'Usa un correo electrónico distinto para este cliente.',
    'phone': 'Usa un número de teléfono distinto para este cliente.',
}


def email_key(expression):
    return NullIf(Lower(Trim(expression)), Value(''))


def phone_key(expression):
    digits = expression
    for separator in ('+', ' ', '-', '.', '(', ')'):
        digits = Replace(digits, Value(separator), Value(''))
    return NullIf(Case(
        When(Exact(Length(digits), 11) & StartsWith(digits, Value('569')), then=Right(digits, 9)),
        When(Exact(Length(digits), 8), then=Concat(Value('9'), digits)),
        default=digits,
    ), Value(''))


def validate_client_contacts(clients, *, email=None, phone=None, client_id=None):
    if client_id is not None:
        clients = clients.exclude(pk=client_id)
    errors = {}
    for field, value, key in (('email', email, email_key), ('phone', phone, phone_key)):
        if value and clients.alias(contact_key=key(field)).filter(contact_key=key(Value(value))).exists():
            errors[field] = CONTACT_ERRORS[field]
    if errors:
        raise ValidationError(errors)


@contextmanager
def save_client_contacts():
    try:
        with transaction.atomic():
            yield
    except IntegrityError as error:
        constraint = getattr(getattr(error.__cause__, 'diag', None), 'constraint_name', None)
        for field, name in CONTACT_CONSTRAINTS.items():
            if constraint == name or name in str(error):
                raise ValidationError({field: CONTACT_ERRORS[field]}) from error
        raise
