import json
from unittest.mock import patch
from urllib.parse import parse_qs
from django.test import SimpleTestCase, override_settings
from .twilio_delivery import send_sandbox_message


@override_settings(TWILIO_ACCOUNT_SID='AC' + '1' * 32, TWILIO_AUTH_TOKEN='test-only-token', TWILIO_WHATSAPP_FROM='+14155238886', TWILIO_WHATSAPP_TEST_TO='+56912345678', TWILIO_WHATSAPP_SANDBOX=True)
class TwilioDeliveryTests(SimpleTestCase):
    @patch('apps.workshop.twilio_delivery.HTTPSConnection')
    def test_otp_and_welcome_use_whatsapp_addresses_and_timeout(self, transport):
        response = transport.return_value.getresponse.return_value
        response.status = 201
        response.read.return_value = json.dumps({'sid': 'SM-test', 'status': 'queued'}).encode()
        for text in ('Código de acceso: 012345', 'Tu cuenta está lista. Ingresa al portal.'):
            self.assertTrue(send_sandbox_message('+56912345678', text))
            call = transport.return_value.request.call_args
            data = parse_qs(call.kwargs['body'])
            self.assertEqual(data['To'], ['whatsapp:+56912345678'])
            self.assertEqual(data['Body'], [text])
        transport.assert_called_with('api.twilio.com', timeout=10)
        self.assertEqual(transport.return_value.close.call_count, 2)

    @patch('apps.workshop.twilio_delivery.HTTPSConnection')
    def test_different_recipient_is_blocked_before_network(self, transport):
        with self.assertRaises(RuntimeError):
            send_sandbox_message('+56987654321', 'Prueba')
        transport.assert_not_called()

    @patch('apps.workshop.twilio_delivery.HTTPSConnection')
    def test_provider_error_is_sanitized(self, transport):
        response = transport.return_value.getresponse.return_value
        response.status = 400
        response.read.return_value = json.dumps({'code': 63016, 'message': 'sensitive-provider-detail'}).encode()
        with self.assertRaises(RuntimeError) as caught:
            send_sandbox_message('+56912345678', '012345')
        self.assertIn('63016', str(caught.exception))
        self.assertNotIn('sensitive-provider-detail', str(caught.exception))
        transport.return_value.close.assert_called_once()

    def test_demo_must_be_explicitly_enabled(self):
        with self.settings(TWILIO_WHATSAPP_SANDBOX=False):
            with self.assertRaises(RuntimeError):
                send_sandbox_message('+56912345678', 'Prueba')
