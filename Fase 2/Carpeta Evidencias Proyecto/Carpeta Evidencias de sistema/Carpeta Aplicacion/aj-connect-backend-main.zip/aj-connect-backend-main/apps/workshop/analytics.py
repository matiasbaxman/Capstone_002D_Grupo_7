from calendar import monthrange
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Avg, Count, DecimalField, ExpressionWrapper, F, OuterRef, Subquery, Sum
from django.db.models.functions import Coalesce, Upper
from django.utils import timezone
from rest_framework import permissions, serializers
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.authentication.permissions import IsAdminRole, is_admin, is_mecanico, is_recepcionista
from apps.inventory.models import InventoryItem

from .demand_forecast import FORECAST_CACHE_TTL, get_demand_forecast_snapshot
from .models import WorkOrder, WorkOrderItem, WorkOrderStatusHistory


COMPLETED_CODES = ('ENTREGADO', 'COMPLETADO', 'FINALIZADO')
STATUS_GROUPS = {
    'pending': ('RECEPCIONADO', 'PENDIENTE'),
    'in_progress': ('DIAGNOSTICO', 'REPARACION', 'EN_REPARACION', 'EN_PROCESO',
                    'LISTO', 'LISTO_ENTREGA', 'LISTO_PARA_ENTREGA'),
    'completed': COMPLETED_CODES,
    'cancelled': ('CANCELADO', 'CANCELADA', 'ANULADO', 'ANULADA'),
}
GROUP_BY_CODE = {code: group for group, codes in STATUS_GROUPS.items() for code in codes}


class AnalyticsDateField(serializers.DateField):
    def to_internal_value(self, value):
        parsed = super().to_internal_value(value)
        if value != parsed.isoformat():
            self.fail('invalid', format='YYYY-MM-DD')
        return parsed


class AnalyticsFiltersSerializer(serializers.Serializer):
    period = serializers.ChoiceField(
        choices=('today', 'week', 'month', 'year', 'custom'), default='month',
    )
    start_date = AnalyticsDateField(required=False, input_formats=['%Y-%m-%d'])
    end_date = AnalyticsDateField(required=False, input_formats=['%Y-%m-%d'])

    def validate(self, attrs):
        period = attrs['period']
        if period == 'custom':
            missing = {field: 'Este campo es obligatorio para el período custom.'
                       for field in ('start_date', 'end_date') if field not in attrs}
            if missing:
                raise serializers.ValidationError(missing)
            if attrs['start_date'] > attrs['end_date']:
                raise serializers.ValidationError({'end_date': 'Debe ser igual o posterior a start_date.'})
            return attrs

        if 'start_date' in attrs or 'end_date' in attrs:
            raise serializers.ValidationError({'period': 'Usa custom para indicar un rango de fechas.'})

        today = timezone.localdate()
        start = end = today
        if period == 'week':
            start = today - timedelta(days=today.weekday())
            end = start + timedelta(days=6)
        elif period == 'month':
            start = today.replace(day=1)
            end = today.replace(day=monthrange(today.year, today.month)[1])
        elif period == 'year':
            start, end = date(today.year, 1, 1), date(today.year, 12, 31)
        return {**attrs, 'start_date': start, 'end_date': end}


def order_metrics(date_range):
    orders = WorkOrder.objects.annotate(
        received_at=Coalesce('checkin__created_at', 'created_at'),
        status_code=Upper('status__code'),
    ).filter(received_at__date__range=date_range)

    counts = dict.fromkeys(STATUS_GROUPS, 0)
    for row in orders.order_by().values('status_code').annotate(total=Count('pk')):
        group = GROUP_BY_CODE.get(row['status_code'], 'other')
        counts[group] = counts.get(group, 0) + row['total']

    delivered_at = WorkOrderStatusHistory.objects.filter(
        work_order_id=OuterRef('pk'),
    ).alias(target_code=Upper('to_status__code')).filter(
        target_code__in=COMPLETED_CODES,
    ).order_by('-changed_at').values('changed_at')[:1]
    # Las entregas del flujo actual pueden tener historial y closed_at vacío.
    average = orders.filter(status_code__in=COMPLETED_CODES).annotate(
        finished_at=Coalesce('closed_at', Subquery(delivered_at)),
    ).filter(finished_at__gte=F('received_at')).aggregate(
        duration=Avg(F('finished_at') - F('received_at')),
    )['duration']

    return {
        'orders_by_status': counts,
        'total_orders': sum(counts.values()),
        'average_service_time_hours': round(average.total_seconds() / 3600, 2) if average is not None else None,
    }


def supplies_summary(date_range, *, include_costs=True):
    items = WorkOrderItem.objects.filter(created_at__date__range=date_range)
    top = items.values('item_id', 'item__name').annotate(units=Sum('quantity'))
    if include_costs:
        line_cost = ExpressionWrapper(
            F('quantity') * F('unit_price'),
            output_field=DecimalField(max_digits=30, decimal_places=2),
        )
        top = top.annotate(cost=Sum(line_cost))

    parts = []
    for row in top.order_by('-units', 'item__name', 'item_id')[:10]:
        part = {'name': row['item__name'], 'quantity': row['units']}
        if include_costs:
            part['total_cost'] = float(row['cost'].quantize(Decimal('0.01')))
        parts.append(part)

    return {
        'total_items_consumed': items.aggregate(units=Sum('quantity', default=0))['units'],
        'top_consumed_parts': parts,
    }


class WorkshopAnalyticsView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]

    def get(self, request):
        filters = AnalyticsFiltersSerializer(data=request.query_params)
        filters.is_valid(raise_exception=True)
        values = filters.validated_data
        date_range = (values['start_date'], values['end_date'])
        return Response({
            'status': 'success',
            'filters': filters.data,
            'metrics': {**order_metrics(date_range), 'supplies_summary': supplies_summary(date_range)},
        })


class WorkshopOverviewView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        admin = is_admin(request.user)
        can_see_orders = admin or is_mecanico(request.user)
        can_see_supplies = admin or is_recepcionista(request.user)
        if not (can_see_orders or can_see_supplies):
            raise PermissionDenied('Se requiere un rol del taller para consultar el resumen.')

        filters = AnalyticsFiltersSerializer(data=request.query_params)
        filters.is_valid(raise_exception=True)
        values = filters.validated_data
        date_range = (values['start_date'], values['end_date'])
        metrics = order_metrics(date_range) if can_see_orders else {}
        if can_see_supplies:
            supplies = supplies_summary(date_range, include_costs=admin)
            supplies['low_stock_count'] = InventoryItem.objects.filter(current_stock__lte=F('minimum_stock')).count()
            metrics['supplies_summary'] = supplies

        return Response({'status': 'success', 'filters': filters.data, 'metrics': metrics})


class DemandForecastView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]

    def _response(self, data, *, generate_if_missing, refresh_if_expired):
        filters = AnalyticsFiltersSerializer(data=data)
        filters.is_valid(raise_exception=True)
        values = filters.validated_data
        snapshot, regenerated = get_demand_forecast_snapshot(
            values['period'], values['start_date'], values['end_date'],
            generate_if_missing=generate_if_missing,
            refresh_if_expired=refresh_if_expired,
        )
        expires_at = (
            snapshot.generated_at + FORECAST_CACHE_TTL
            if snapshot and snapshot.forecast.get('has_sufficient_history') else None
        )
        can_generate = expires_at is None or timezone.now() >= expires_at
        return Response({
            'status': 'success',
            'filters': filters.data,
            'has_forecast': snapshot is not None,
            'demand_forecast': snapshot.forecast if snapshot else None,
            'generated_at': snapshot.generated_at if snapshot else None,
            'expires_at': expires_at,
            'can_generate': can_generate,
            'cached': snapshot is not None and not regenerated,
        })

    def get(self, request):
        # Una recarga muestra el snapshot existente; solo renueva uno vencido.
        refresh_expired = request.query_params.get('refresh_expired', 'true').lower() != 'false'
        return self._response(
            request.query_params, generate_if_missing=False,
            refresh_if_expired=refresh_expired,
        )

    def post(self, request):
        # El botón crea el primer snapshot. Uno vigente siempre se reutiliza.
        return self._response(
            request.data, generate_if_missing=True,
            refresh_if_expired=True,
        )
