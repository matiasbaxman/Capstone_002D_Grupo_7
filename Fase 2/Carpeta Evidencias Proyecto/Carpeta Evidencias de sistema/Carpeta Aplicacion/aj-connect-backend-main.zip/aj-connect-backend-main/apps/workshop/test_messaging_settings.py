import json
import os
import subprocess
import sys

from django.test import SimpleTestCase


class MessagingSettingsTests(SimpleTestCase):
    def configuration(self, module, **overrides):
        env = os.environ.copy()
        for key in ('CLIENT_OTP_DELIVERY_MODE', 'EMAIL_BACKEND', 'EMAIL_PROVIDER', 'BREVO_API_KEY'):
            env.pop(key, None)
        env.update(overrides, DJANGO_SETTINGS_MODULE=module)
        # No leer credenciales locales ni realizar conexiones a proveedores.
        script = (
            'import dotenv; dotenv.load_dotenv = lambda *a, **k: None; '
            f'import importlib,json; s=importlib.import_module({module!r}); '
            'print(json.dumps([s.CLIENT_OTP_DELIVERY_MODE,s.CLIENT_OTP_ALLOW_SIMULATION,s.EMAIL_BACKEND]))'
        )
        result = subprocess.run([sys.executable, '-c', script], env=env, text=True, capture_output=True, check=True, timeout=20)
        return json.loads(result.stdout)

    def test_development_defaults_keep_simulation(self):
        self.assertEqual(self.configuration('ajconnect_api.settings_docker'), ['simulation', True, 'django.core.mail.backends.console.EmailBackend'])
        self.assertEqual(self.configuration('ajconnect_api.settings_local')[:2], ['simulation', True])

    def test_explicit_channel_enables_real_delivery_without_simulation(self):
        for module in ('ajconnect_api.settings_local', 'ajconnect_api.settings_docker'):
            self.assertEqual(self.configuration(module, CLIENT_OTP_DELIVERY_MODE='channel'), ['channel', False, 'django.core.mail.backends.smtp.EmailBackend'])

    def test_email_backend_override_is_respected(self):
        self.assertEqual(self.configuration('ajconnect_api.settings_docker', EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')[2], 'django.core.mail.backends.locmem.EmailBackend')

    def test_brevo_is_selected_in_local_and_docker(self):
        for module in ('ajconnect_api.settings_local', 'ajconnect_api.settings_docker'):
            self.assertEqual(self.configuration(module, EMAIL_PROVIDER='brevo', CLIENT_OTP_DELIVERY_MODE='channel')[2],
                             'apps.workshop.brevo_backend.BrevoEmailBackend')

    def test_tests_can_override_brevo_backend(self):
        self.assertEqual(self.configuration('ajconnect_api.settings_docker', EMAIL_PROVIDER='brevo',
                                           EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')[2],
                         'django.core.mail.backends.locmem.EmailBackend')
