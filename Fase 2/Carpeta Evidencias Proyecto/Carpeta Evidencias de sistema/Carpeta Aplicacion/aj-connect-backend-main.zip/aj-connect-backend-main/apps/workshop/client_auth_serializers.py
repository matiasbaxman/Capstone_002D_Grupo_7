from rest_framework import serializers

from .utils import normalized_rut


class ClientOTPRequestSerializer(serializers.Serializer):
    rut = serializers.CharField(max_length=20)
    password = serializers.CharField(required=False, allow_blank=True, write_only=True,
                                     trim_whitespace=False, max_length=128)

    def validate_rut(self, value):
        try:
            return normalized_rut(value)
        except serializers.ValidationError as error:
            raise serializers.ValidationError(error.detail['rut']) from error


class ClientOTPVerifySerializer(ClientOTPRequestSerializer):
    code = serializers.RegexField(r'^[0-9]{6}$', min_length=6, max_length=6)
    password = serializers.CharField(
        required=False, write_only=True, trim_whitespace=False, max_length=128,
    )
