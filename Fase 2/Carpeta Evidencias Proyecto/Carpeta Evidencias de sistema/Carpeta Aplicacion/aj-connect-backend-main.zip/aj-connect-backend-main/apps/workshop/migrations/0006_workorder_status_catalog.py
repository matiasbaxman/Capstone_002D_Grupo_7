from django.db import migrations


def seed_statuses(apps, schema_editor):
    status = apps.get_model('workshop', 'WorkOrderStatus')
    # Codes documented in the supplied database schema; preserve existing rows.
    entries = [('RECEPCIONADO', 'Recepcionado'), ('DIAGNOSTICO', 'Diagnóstico'),
               ('REPARACION', 'En reparación'), ('LISTO', 'Listo para entrega'),
               ('ENTREGADO', 'Entregado')]
    for sequence, (code, name) in enumerate(entries, start=1):
        status.objects.using(schema_editor.connection.alias).get_or_create(
            code=code, defaults={'name': name, 'sequence_order': sequence})


class Migration(migrations.Migration):
    dependencies = [('workshop', '0005_workorderitem_request_id_and_more')]
    operations = [migrations.RunPython(seed_statuses, migrations.RunPython.noop)]
