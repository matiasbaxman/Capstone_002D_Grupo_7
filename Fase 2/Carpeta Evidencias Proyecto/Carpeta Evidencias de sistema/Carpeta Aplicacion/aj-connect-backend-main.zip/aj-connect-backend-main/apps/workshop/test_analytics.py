import json
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import AccessToken

from apps.authentication.client_tokens import ClientAccessToken
from apps.authentication.models import Role, UserRole
from apps.inventory.models import InventoryItem, ItemBrand, ItemCategory

from .models import (
    Client, DemandForecastSnapshot, NotificationChannel, Vehicle, VehicleBrand, VehicleModel, WorkOrder,
    WorkOrderCheckIn, WorkOrderItem, WorkOrderStatus, WorkOrderStatusHistory,
)


@override_settings(GEMINI_API_KEY='forecast-test-key', GEMINI_MODEL='forecast-test-model')
class WorkshopAnalyticsTests(TestCase):
    period = {'period': 'custom', 'start_date': '2026-11-01', 'end_date': '2026-11-30'}

    @classmethod
    def setUpTestData(cls):
        user_model = get_user_model()
        cls.admin = user_model.objects.create_user('analytics-admin')
        cls.mechanic = user_model.objects.create_user('analytics-mechanic', is_staff=True)
        for user, code, name in ((cls.admin, 'ANALYTICS_ADMIN', 'Administrador'),
                                 (cls.mechanic, 'ANALYTICS_MECHANIC', 'Mecánico')):
            UserRole.objects.create(user=user, role=Role.objects.create(code=code, name=name))
        cls.receptionist = user_model.objects.create_user('analytics-receptionist')
        cls.both_roles = user_model.objects.create_user('analytics-both-roles')
        reception_role = Role.objects.create(code='ANALYTICS_RECEPTION', name='Recepcionista')
        UserRole.objects.create(user=cls.receptionist, role=reception_role)
        UserRole.objects.create(user=cls.both_roles, role=reception_role)
        UserRole.objects.create(user=cls.both_roles, role=cls.mechanic.user_roles.get().role)
        cls.no_role = user_model.objects.create_user('analytics-no-role')

        channel, _ = NotificationChannel.objects.get_or_create(code='EMAIL', defaults={'name': 'Correo'})
        cls.customer = Client.objects.create(
            rut='123456785', first_name='Cliente', last_name='Prueba', phone='+56911111111',
            password_hash='!', notification_channel=channel,
        )
        brand = VehicleBrand.objects.create(name='Marca de prueba')
        model = VehicleModel.objects.create(name='Modelo de prueba', brand=brand)
        cls.vehicle = Vehicle.objects.create(client=cls.customer, model=model, plate='ABCD12', year=2020)
        cls.statuses = {}
        for code in ('RECEPCIONADO', 'DIAGNOSTICO', 'LISTO', 'ENTREGADO', 'CANCELADO'):
            cls.statuses[code], _ = WorkOrderStatus.objects.get_or_create(
                code=code, defaults={'name': code, 'sequence_order': 10},
            )

        start = timezone.make_aware(datetime(2026, 11, 1))
        end = timezone.make_aware(datetime(2026, 11, 30, 23, 59, 59))
        cls.midmonth = timezone.make_aware(datetime(2026, 11, 15, 10))
        cls.pending = cls.make_order(1, 'RECEPCIONADO', start)
        cls.make_order(2, 'DIAGNOSTICO', cls.midmonth)
        cls.make_order(3, 'LISTO', start - timedelta(days=1), checked_in=end)
        cls.make_order(4, 'ENTREGADO', cls.midmonth - timedelta(hours=2),
                       checked_in=cls.midmonth, closed=cls.midmonth + timedelta(hours=3))
        from_history = cls.make_order(5, 'ENTREGADO', cls.midmonth)
        history = WorkOrderStatusHistory.objects.create(
            work_order=from_history, to_status=cls.statuses['ENTREGADO'],
        )
        WorkOrderStatusHistory.objects.filter(pk=history.pk).update(
            changed_at=cls.midmonth + timedelta(hours=6),
        )
        cls.make_order(6, 'ENTREGADO', cls.midmonth)  # Sin hora de cierre utilizable.
        cls.make_order(7, 'ENTREGADO', cls.midmonth, closed=cls.midmonth - timedelta(hours=1))
        cls.make_order(8, 'CANCELADO', cls.midmonth, closed=cls.midmonth + timedelta(hours=20))
        older = cls.make_order(9, 'RECEPCIONADO', start - timedelta(seconds=1))
        cls.make_order(10, 'RECEPCIONADO', end + timedelta(seconds=1))

        cls.category = ItemCategory.objects.create(name='Insumos de prueba')
        cls.brand = ItemBrand.objects.create(name='Marca de prueba')
        oil = InventoryItem.objects.create(category=cls.category, brand=cls.brand, sku='OIL', name='Aceite', unit_price=9999)
        filter_item = InventoryItem.objects.create(category=cls.category, brand=cls.brand, sku='FILTER', name='Filtro', unit_price=7000)
        cls.consume(cls.pending, oil, 2, '7999.95', start)
        cls.consume(older, oil, 3, '8000.25', cls.midmonth)
        cls.consume(cls.pending, filter_item, 1, '7000.00', end)
        cls.consume(cls.pending, filter_item, 50, '7000.00', end + timedelta(seconds=1))

    @classmethod
    def make_order(cls, folio, code, received, *, checked_in=None, closed=None):
        order = WorkOrder.objects.create(
            folio_number=folio, vehicle=cls.vehicle, status=cls.statuses[code], closed_at=closed,
        )
        WorkOrder.objects.filter(pk=order.pk).update(created_at=received)
        if checked_in is not None:
            checkin = WorkOrderCheckIn.objects.create(work_order=order)
            WorkOrderCheckIn.objects.filter(pk=checkin.pk).update(created_at=checked_in)
        return order

    @staticmethod
    def consume(order, item, quantity, price, when):
        line = WorkOrderItem.objects.create(
            work_order=order, item=item, quantity=quantity, unit_price=Decimal(price),
        )
        WorkOrderItem.objects.filter(pk=line.pk).update(created_at=when)

    def setUp(self):
        self.api = APIClient()
        self.url = reverse('workshop-analytics')
        self.forecast_url = reverse('workshop-demand-forecast')
        clock = patch('apps.workshop.demand_forecast.timezone.now',
                      return_value=datetime(2026, 12, 1, 15, tzinfo=UTC))
        self.clock = clock.start()
        self.addCleanup(clock.stop)
        provider = patch('apps.workshop.demand_forecast.genai.Client')
        self.gemini = provider.start()
        self.addCleanup(provider.stop)
        self.generate = self.gemini.return_value.__enter__.return_value.models.generate_content
        self.generate.return_value.text = '{}'

    def use_admin_token(self):
        self.api.credentials(HTTP_AUTHORIZATION=f'Bearer {AccessToken.for_user(self.admin)}')

    def test_missing_or_invalid_authentication_returns_401_and_mechanic_403(self):
        self.api.credentials()
        self.assertEqual(self.api.get(self.url, self.period).status_code, 401)

        mechanic_token = AccessToken.for_user(self.mechanic)
        self.api.credentials(HTTP_AUTHORIZATION=f'Bearer {mechanic_token}')
        self.assertEqual(self.api.get(self.url, self.period).status_code, 403)

        client_token = ClientAccessToken.for_client(self.customer)
        self.api.credentials(HTTP_AUTHORIZATION=f'Bearer {client_token}')
        self.assertEqual(self.api.get(self.url, self.period).status_code, 401)

        expired_token = AccessToken.for_user(self.admin)
        expired_token.set_exp(lifetime=timedelta(seconds=-1))
        self.api.credentials(HTTP_AUTHORIZATION=f'Bearer {expired_token}')
        self.assertEqual(self.api.get(self.url, self.period).status_code, 401)

    def test_overview_returns_only_the_sections_and_fields_granted_by_roles(self):
        overview = reverse('workshop-overview')
        self.assertEqual(self.api.get(overview, self.period).status_code, 401)
        self.api.force_authenticate(self.no_role)
        self.assertEqual(self.api.get(overview, self.period).status_code, 403)

        order_fields = {'orders_by_status', 'total_orders', 'average_service_time_hours'}
        for user, expected_fields in (
            (self.mechanic, order_fields),
            (self.receptionist, {'supplies_summary'}),
            (self.both_roles, order_fields | {'supplies_summary'}),
            (self.admin, order_fields | {'supplies_summary'}),
        ):
            with self.subTest(user=user.username):
                self.api.force_authenticate(user)
                response = self.api.get(overview, self.period)
                self.assertEqual(response.status_code, 200, response.data)
                metrics = response.json()['metrics']
                self.assertEqual(set(metrics), expected_fields)
                if 'total_orders' in metrics:
                    self.assertEqual(metrics['total_orders'], 8)
                if 'supplies_summary' in metrics:
                    supplies = metrics['supplies_summary']
                    self.assertEqual(supplies['total_items_consumed'], 6)
                    self.assertEqual(supplies['low_stock_count'], 2)
                    expected_part = {'name': 'Aceite', 'quantity': 5}
                    if user == self.admin:
                        expected_part['total_cost'] = 40000.65
                    self.assertEqual(supplies['top_consumed_parts'][0], expected_part)

    def test_only_admin_can_read_or_generate_a_forecast(self):
        self.assertEqual(self.api.get(self.forecast_url, self.period).status_code, 401)
        for user in (self.mechanic, self.receptionist, self.both_roles, self.no_role):
            with self.subTest(user=user.username):
                self.api.force_authenticate(user)
                self.assertEqual(self.api.get(self.forecast_url, self.period).status_code, 403)
                self.assertEqual(self.api.post(self.forecast_url, self.period, format='json').status_code, 403)
        self.gemini.assert_not_called()

    def test_admin_gets_status_counts_durations_and_costs(self):
        self.use_admin_token()
        response = self.api.get(self.url, self.period)
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.json(), {
            'status': 'success',
            'filters': self.period,
            'metrics': {
                'orders_by_status': {'pending': 1, 'in_progress': 2, 'completed': 4, 'cancelled': 1},
                'total_orders': 8,
                'average_service_time_hours': 4.5,
                'supplies_summary': {
                    'total_items_consumed': 6,
                    'top_consumed_parts': [
                        {'name': 'Aceite', 'quantity': 5, 'total_cost': 40000.65},
                        {'name': 'Filtro', 'quantity': 1, 'total_cost': 7000},
                    ],
                },
            },
        })
        self.gemini.assert_not_called()

    def test_calendar_periods_and_default_month(self):
        self.use_admin_token()
        cases = (
            ({}, 'month', '2026-11-01', '2026-11-30'),
            ({'period': 'today'}, 'today', '2026-11-18', '2026-11-18'),
            ({'period': 'week'}, 'week', '2026-11-16', '2026-11-22'),
            ({'period': 'year'}, 'year', '2026-01-01', '2026-12-31'),
        )
        with patch('apps.workshop.analytics.timezone.now', return_value=timezone.make_aware(datetime(2026, 11, 18, 12))):
            for query, period, start, end in cases:
                with self.subTest(period=period):
                    response = self.api.get(self.url, query)
                    self.assertEqual(response.status_code, 200, response.data)
                    self.assertEqual(response.json()['filters'], {
                        'period': period, 'start_date': start, 'end_date': end,
                    })

    def test_invalid_filters_return_400(self):
        self.use_admin_token()
        for query in ({'period': 'quarter'}, {'period': 'custom'},
                      {**self.period, 'start_date': '2026-11-31'},
                      {**self.period, 'start_date': '2026-11-1'},
                      {**self.period, 'start_date': '2026-12-01'},
                      {**self.period, 'period': 'month'}):
            with self.subTest(query=query):
                self.assertEqual(self.api.get(self.url, query).status_code, 400)

    def test_empty_period_returns_zero_counts_and_null_average(self):
        self.use_admin_token()
        response = self.api.get(self.url, {**self.period, 'end_date': '2026-11-01'})
        self.assertEqual(response.status_code, 200, response.data)
        metrics = response.json()['metrics']
        self.assertEqual(metrics['total_orders'], 1)
        self.assertIsNone(metrics['average_service_time_hours'])

        response = self.api.get(self.url, {**self.period, 'start_date': '2026-11-02', 'end_date': '2026-11-02'})
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.json()['metrics'], {
            'orders_by_status': {'pending': 0, 'in_progress': 0, 'completed': 0, 'cancelled': 0},
            'total_orders': 0,
            'average_service_time_hours': None,
            'supplies_summary': {'total_items_consumed': 0, 'top_consumed_parts': []},
        })

    def test_top_ten_keeps_total_units_and_separate_skus(self):
        self.use_admin_token()
        for i in range(11):
            part = InventoryItem.objects.create(category=self.category, brand=self.brand, sku=f'PART-{i}', name='Bujía', unit_price=10)
            self.consume(self.pending, part, 1, '10.00', self.midmonth)
        response = self.api.get(self.url, self.period)
        self.assertEqual(response.status_code, 200, response.data)
        summary = response.json()['metrics']['supplies_summary']
        self.assertEqual(summary['total_items_consumed'], 17)
        self.assertEqual(len(summary['top_consumed_parts']), 10)
        self.assertEqual(summary['top_consumed_parts'][0]['name'], 'Aceite')
        self.assertEqual(summary['top_consumed_parts'][1:9], [
            {'name': 'Bujía', 'quantity': 1, 'total_cost': 10},
        ] * 8)

    def add_forecast_history(self):
        oil = InventoryItem.objects.get(sku='OIL')
        filter_item = InventoryItem.objects.get(sku='FILTER')
        self.consume(self.pending, oil, 4, '8000.00', self.midmonth + timedelta(days=3))
        self.consume(self.pending, filter_item, 2, '7000.00', self.midmonth + timedelta(days=7))

    def test_forecast_uses_validated_gemini_json_and_aggregated_context(self):
        self.use_admin_token()
        self.add_forecast_history()
        self.generate.return_value.text = json.dumps({'predictions': [
            {'part_id': 2, 'estimated_demand': 3, 'stock_alert': 'low'},
            {'part_id': 1, 'estimated_demand': 9, 'stock_alert': 'high'},
        ]})

        response = self.api.post(self.forecast_url, self.period, format='json')

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['demand_forecast'], {
            'has_sufficient_history': True,
            'source': 'gemini_ai',
            'predictions': [
                {'part_name': 'Aceite', 'estimated_demand': 9,
                 'recommendation': 'Priorizar la revisión de stock por la demanda estimada.'},
                {'part_name': 'Filtro', 'estimated_demand': 3,
                 'recommendation': 'Mantener seguimiento del consumo.'},
            ],
        })
        self.generate.assert_called_once()
        call = self.generate.call_args.kwargs
        self.assertEqual(call['model'], 'forecast-test-model')
        self.assertEqual(call['config'].response_mime_type, 'application/json')
        self.assertEqual(json.loads(call['contents']), {
            'observed_days': 30, 'recent_days': 28, 'forecast_days': 30,
            'parts': [
                {'part_id': 1, 'name': 'Aceite', 'total_units': 9, 'recent_units': 7},
                {'part_id': 2, 'name': 'Filtro', 'total_units': 3, 'recent_units': 3},
            ],
        })
        options = self.gemini.call_args.kwargs['http_options']
        self.assertEqual(options.timeout, 7000)
        self.assertEqual(options.headers['X-Server-Timeout'], '10')
        self.assertEqual(options.retry_options.attempts, 1)

    def test_timeout_returns_moving_average_with_inactive_days(self):
        self.use_admin_token()
        self.add_forecast_history()
        self.generate.side_effect = TimeoutError('Gemini agotó el tiempo de espera')

        response = self.api.post(self.forecast_url, self.period, format='json')

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['demand_forecast'], {
            'has_sufficient_history': True,
            'source': 'statistical_fallback',
            'predictions': [
                {'part_name': 'Aceite', 'estimated_demand': 8,
                 'recommendation': 'Revisar disponibilidad antes de reponer.'},
                {'part_name': 'Filtro', 'estimated_demand': 4,
                 'recommendation': 'Revisar disponibilidad antes de reponer.'},
            ],
        })
        self.generate.assert_called_once()

    def test_invalid_provider_output_uses_fallback(self):
        self.use_admin_token()
        self.add_forecast_history()
        first = {'part_id': 1, 'estimated_demand': 9, 'stock_alert': 'high'}
        second = {'part_id': 2, 'estimated_demand': 3, 'stock_alert': 'low'}
        invalid_outputs = (
            'respuesta no JSON',
            json.dumps({'predictions': [first]}),
            json.dumps({'predictions': [first, first]}),
            json.dumps({'predictions': [{**first, 'estimated_demand': True}, second]}),
            json.dumps({'predictions': [{**first, 'estimated_demand': -1}, second]}),
            json.dumps({'predictions': [first, {**second, 'part_id': 99}]}),
            json.dumps({'predictions': [first, {**second, 'stock_alert': 'unknown'}]}),
        )
        for output in invalid_outputs:
            with self.subTest(output=output):
                DemandForecastSnapshot.objects.all().delete()
                self.generate.reset_mock()
                self.generate.return_value.text = output
                response = self.api.post(self.forecast_url, self.period, format='json')
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.json()['demand_forecast']['source'], 'statistical_fallback')
                self.generate.assert_called_once()

    def test_short_history_skips_gemini_even_with_five_records(self):
        self.use_admin_token()
        oil = InventoryItem.objects.get(sku='OIL')
        for _ in range(5):
            self.consume(self.pending, oil, 1, '8000.00', self.midmonth)

        response = self.api.post(
            self.forecast_url,
            {**self.period, 'start_date': '2026-11-14', 'end_date': '2026-11-20'},
            format='json',
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['demand_forecast'], {
            'has_sufficient_history': False,
            'message': 'Se necesitan al menos 5 registros de consumo en órdenes de trabajo que abarquen 14 días.',
            'predictions': [],
        })
        self.assertTrue(response.json()['can_generate'])
        self.assertIsNone(response.json()['expires_at'])
        self.gemini.assert_not_called()

    def test_weekly_projection_retries_incomplete_snapshot_and_uses_recent_history(self):
        self.use_admin_token()
        self.clock.return_value = datetime(2026, 11, 17, 15, tzinfo=UTC)
        period = {'period': 'week'}
        response = self.api.post(self.forecast_url, period, format='json')
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()['demand_forecast']['has_sufficient_history'])
        self.assertTrue(response.json()['can_generate'])
        self.gemini.assert_not_called()

        oil = InventoryItem.objects.get(sku='OIL')
        for days_ago in (3, 7, 15):
            self.consume(self.pending, oil, 2, '8000.00', self.midmonth - timedelta(days=days_ago))
        cached = self.api.get(self.forecast_url, period).json()
        self.assertFalse(cached['demand_forecast']['has_sufficient_history'])
        self.assertTrue(cached['can_generate'])
        self.gemini.assert_not_called()
        self.generate.return_value.text = json.dumps({'predictions': [
            {'part_id': 1, 'estimated_demand': 6, 'stock_alert': 'low'},
        ]})

        response = self.api.post(self.forecast_url, period, format='json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['demand_forecast']['source'], 'gemini_ai')
        self.assertFalse(response.json()['can_generate'])
        context = json.loads(self.generate.call_args.kwargs['contents'])
        self.assertEqual(context['forecast_days'], 7)
        self.assertEqual(context['parts'][0]['total_units'], 11)

    def test_forecast_is_created_by_post_and_reused_until_expiry(self):
        self.use_admin_token()
        self.add_forecast_history()

        response = self.api.get(self.forecast_url, self.period)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'status': 'success', 'filters': self.period,
            'has_forecast': False, 'demand_forecast': None,
            'generated_at': None, 'expires_at': None,
            'can_generate': True, 'cached': False,
        })
        self.gemini.assert_not_called()
        self.assertFalse(DemandForecastSnapshot.objects.exists())

        response = self.api.post(self.forecast_url, self.period, format='json')
        self.assertEqual(response.status_code, 200)
        created = response.json()
        self.assertTrue(created['has_forecast'])
        self.assertFalse(created['cached'])
        self.assertFalse(created['can_generate'])
        self.generate.assert_called_once()

        cached = {**created, 'cached': True}
        self.assertEqual(self.api.get(self.forecast_url, self.period).json(), cached)
        self.assertEqual(self.api.post(self.forecast_url, self.period, format='json').json(), cached)
        self.generate.assert_called_once()

        self.clock.return_value += timedelta(days=7)
        query = {**self.period, 'refresh_expired': 'false'}
        self.assertEqual(self.api.get(self.forecast_url, query).json(), {**cached, 'can_generate': True})
        self.generate.assert_called_once()

        response = self.api.get(self.forecast_url, self.period)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()['cached'])
        self.assertFalse(response.json()['can_generate'])
        self.assertNotEqual(response.json()['generated_at'], created['generated_at'])
        self.assertEqual(self.generate.call_count, 2)
        self.assertEqual(DemandForecastSnapshot.objects.count(), 1)
