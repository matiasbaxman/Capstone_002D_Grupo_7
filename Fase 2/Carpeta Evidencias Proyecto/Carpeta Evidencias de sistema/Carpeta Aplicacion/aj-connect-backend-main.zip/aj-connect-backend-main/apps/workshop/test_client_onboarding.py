from datetime import datetime
from unittest.mock import patch
from zoneinfo import ZoneInfo

from django.contrib.auth.models import User
from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from rest_framework.exceptions import ValidationError
from rest_framework.test import APIClient

from .email_queue import enqueue_client_welcome, process_next
from .models import Appointment, Client, EmailDelivery
from .serializers import PublicAppointmentCreateSerializer


@override_settings(EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend', PUBLIC_PORTAL_URL='https://aj.example.test')
class ClientOnboardingTests(TestCase):
    def setUp(self):
        cache.clear()
        self.api = APIClient()
        self.staff = User.objects.create_superuser('onboarding-qa', 'staff@example.test', 'StaffSeguro!2026')

    def data(self, channel='EMAIL', **changes):
        data = {'rut': '123456785', 'first_name': 'Ana', 'last_name': 'Prueba', 'phone': '+56912345678', 'notification_channel': channel}
        if channel == 'EMAIL':
            data['email'] = 'ana@example.test'
        data.update(changes)
        return data

    def checkin(self, channel='EMAIL', **changes):
        self.api.force_authenticate(self.staff)
        payload = {**self.data(channel), 'plate': 'BCDF12', 'brand': 'Toyota', 'vehicle_model': 'Yaris', 'year': 2021, **changes}
        return self.api.post('/api/workshop/check-in/', payload, format='json')

    def booking(self, channel='EMAIL', **changes):
        self.api.force_authenticate(None)
        payload = {'email': 'ana@example.test', **self.data(channel), 'scheduled_date': datetime(2030, 1, 7, 10, tzinfo=ZoneInfo('America/Santiago')).isoformat(), 'reported_symptoms': 'Revisar frenos', **changes}
        with patch('apps.workshop.booking_verification.deliver_client_otp') as delivery:
            verified = self.api.post('/api/appointments/verify-contact/', payload, format='json')
        self.assertEqual(verified.status_code, 200, verified.data)
        if not Client.objects.exists():
            self.assertFalse(EmailDelivery.objects.exists())
        code = delivery.call_args.args[1]
        return self.api.post('/api/appointments/', {**payload, 'verification_id': verified.data['verification_id'], 'code': code}, format='json')

    def assert_welcome(self, channel):
        client = Client.objects.get()
        self.assertFalse(client.has_usable_password())
        job = EmailDelivery.objects.get(kind='welcome', target_id=client.pk)
        self.assertEqual(job.status, 'PENDING')
        if channel == 'EMAIL':
            self.assertEqual(len(mail.outbox), 0)
            with patch('django.utils.module_loading.import_string') as unused:
                self.assertTrue(process_next())
            unused.assert_not_called()
            self.assertEqual(mail.outbox[0].to, ['ana@example.test'])
            body = mail.outbox[0].body
        else:
            with self.settings(CLIENT_OTP_DELIVERY_MODE='channel', CLIENT_WHATSAPP_NOTIFICATION_SENDER='qa_provider.send'):
                with patch('django.utils.module_loading.import_string') as adapter:
                    adapter.return_value.return_value = True
                    self.assertTrue(process_next())
                    adapter.assert_called_once_with('qa_provider.send')
                    self.assertEqual(adapter.return_value.call_args.args[0], client.phone)
                    body = adapter.return_value.call_args.args[1]
            self.assertEqual(len(mail.outbox), 0)
            self.assertIn('WhatsApp', body)
        job.refresh_from_db()
        self.assertEqual(job.status, 'SENT')
        for text in ('https://aj.example.test/', 'Iniciar sesión', 'RUT', 'seis dígitos', 'primer ingreso', 'sin contraseña predeterminada'):
            self.assertIn(text, body)

    def test_reception_creates_account_and_emails_instructions(self):
        response = self.checkin()
        self.assertEqual(response.status_code, 201, response.data)
        self.assert_welcome('EMAIL')

    def test_welcome_includes_public_tracking_without_login(self):
        self.assertEqual(self.checkin().status_code, 201)
        from .models import WorkOrder
        order = WorkOrder.objects.get()
        self.assertTrue(process_next())
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn(order.tracking_code, mail.outbox[0].body)
        self.assertIn(f'https://aj.example.test/seguimiento/{order.tracking_code}', mail.outbox[0].body)
        self.assertIn('sin iniciar sesión', mail.outbox[0].body)

    def test_existing_client_gets_tracking_after_welcome_was_sent(self):
        self.assertEqual(self.booking().status_code, 201)
        self.assertTrue(process_next())
        client = Client.objects.get()
        self.assertEqual(self.checkin(client_id=str(client.pk)).status_code, 201)
        from .models import WorkOrder
        order = WorkOrder.objects.get()
        self.assertTrue(process_next())
        self.assertEqual(len(mail.outbox), 2)
        self.assertIn(f'/seguimiento/{order.tracking_code}', mail.outbox[-1].body)

    def test_two_orders_before_worker_keep_both_tracking_links(self):
        self.assertEqual(self.checkin().status_code, 201)
        client = Client.objects.get()
        from .models import WorkOrder
        first = WorkOrder.objects.get()
        self.assertEqual(self.checkin(client_id=str(client.pk), vehicle_id=str(first.vehicle_id)).status_code, 201)
        while process_next():
            pass
        self.assertEqual(len(mail.outbox), 2)
        for order in WorkOrder.objects.all():
            self.assertTrue(any(f'/seguimiento/{order.tracking_code}' in email.body for email in mail.outbox))

    def test_reception_uses_whatsapp_without_requiring_email(self):
        response = self.checkin('WHATSAPP')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertFalse(Client.objects.get().email)
        self.assert_welcome('WHATSAPP')

    def test_public_booking_creates_account_and_emails_instructions(self):
        response = self.booking()
        self.assertEqual(response.status_code, 201, response.data)
        self.assert_welcome('EMAIL')

    def test_public_booking_can_use_whatsapp_with_email_registered(self):
        response = self.booking('WHATSAPP')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(Client.objects.get().email, 'ana@example.test')
        self.assert_welcome('WHATSAPP')

    def test_booking_then_reception_reuses_account_without_duplicate_welcome(self):
        self.assertEqual(self.booking().status_code, 201)
        client = Client.objects.get()
        response = self.checkin(client_id=str(client.pk))
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(Client.objects.count(), 1)
        self.assertEqual(EmailDelivery.objects.filter(kind='welcome').count(), 1)
        job = enqueue_client_welcome(client)
        self.assertEqual(enqueue_client_welcome(client).pk, job.pk)
        self.assertEqual(EmailDelivery.objects.filter(kind='welcome').count(), 1)

    def test_failed_reception_rolls_back_account_and_welcome(self):
        with patch('apps.workshop.views.CheckInCreateView._resolve_vehicle', side_effect=ValidationError({'vehicle': 'Error de prueba'})):
            self.assertEqual(self.checkin().status_code, 400)
        self.assertFalse(Client.objects.exists())
        self.assertFalse(EmailDelivery.objects.exists())
        self.assertEqual(len(mail.outbox), 0)

    def test_full_slot_rolls_back_new_account_and_welcome(self):
        self.assertEqual(self.booking().status_code, 201)
        existing = Appointment.objects.get()
        payload = {
            **self.data(rut='223456782'), 'phone': '+56987654321', 'email': 'otra@example.test',
            'scheduled_date': existing.scheduled_date.isoformat(), 'reported_symptoms': 'Otra reserva',
        }
        serializer = PublicAppointmentCreateSerializer(data=payload)
        self.assertTrue(serializer.is_valid(), serializer.errors)
        Appointment.objects.create(client=existing.client, scheduled_date=existing.scheduled_date, reported_symptoms='Segundo cupo')
        with self.assertRaises(ValidationError):
            serializer.save()
        self.assertEqual(Client.objects.count(), 1)
        self.assertEqual(EmailDelivery.objects.filter(kind='welcome').count(), 1)

    def test_missing_whatsapp_provider_retries_without_falling_back_to_email(self):
        self.assertEqual(self.checkin('WHATSAPP', email='ana@example.test').status_code, 201)
        with self.settings(CLIENT_OTP_DELIVERY_MODE='channel', CLIENT_WHATSAPP_NOTIFICATION_SENDER=''):
            with self.assertLogs('apps.workshop.notifications', level='ERROR'):
                self.assertTrue(process_next())
        job = EmailDelivery.objects.get()
        self.assertEqual(job.status, 'PENDING')
        self.assertEqual(job.attempts, 1)
        self.assertEqual(len(mail.outbox), 0)

    def test_reception_preserves_existing_channel_and_email_when_not_supplied(self):
        self.assertEqual(self.booking().status_code, 201)
        client = Client.objects.get()
        self.api.force_authenticate(self.staff)
        lookup = self.api.post('/api/workshop/clients/lookup/', {'rut': client.rut}, format='json')
        self.assertEqual(lookup.data['client']['notificationChannel'], 'EMAIL')
        response = self.api.post('/api/workshop/check-in/', {'client_id': str(client.pk), 'plate': 'BCDF12', 'brand': 'Toyota', 'vehicle_model': 'Yaris', 'year': 2021}, format='json')
        self.assertEqual(response.status_code, 201, response.data)
        client.refresh_from_db()
        self.assertEqual(client.notification_channel.code, 'EMAIL')
        self.assertEqual(client.email, 'ana@example.test')
        self.assertEqual(EmailDelivery.objects.filter(kind='welcome').count(), 1)
