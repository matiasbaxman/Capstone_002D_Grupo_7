"""Backend Django de correo transaccional por HTTPS, sin SMTP."""
import base64
import json
from email.utils import parseaddr
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.core.mail.backends.base import BaseEmailBackend


def address(value):
    name, email = parseaddr(value)
    if not email:
        raise ValueError('El correo necesita una dirección válida.')
    return {'email': email, **({'name': name} if name else {})}


class BrevoEmailBackend(BaseEmailBackend):
    def send_messages(self, email_messages):
        sent = 0
        for message in email_messages or []:
            if not message.recipients():
                continue
            try:
                self._send(message)
            except Exception:
                if not self.fail_silently:
                    raise
            else:
                sent += 1
        return sent

    def _send(self, message):
        if not settings.BREVO_API_KEY:
            raise ImproperlyConfigured('Configura BREVO_API_KEY para enviar correos con Brevo.')
        # Valida encabezados con las mismas reglas del correo estándar de Django.
        message.message()
        payload = {'sender': address(message.from_email), 'subject': message.subject}
        for field in ('to', 'cc', 'bcc'):
            if getattr(message, field):
                payload[field] = [address(value) for value in getattr(message, field)]
        if message.reply_to:
            payload['replyTo'] = address(message.reply_to[0])
        payload['htmlContent' if message.content_subtype == 'html' else 'textContent'] = message.body
        for alternative in getattr(message, 'alternatives', []):
            if alternative.mimetype == 'text/html':
                payload['htmlContent'] = alternative.content
        attachments = []
        for attachment in message.attachments:
            if not hasattr(attachment, 'filename'):
                raise ValueError('Brevo requiere adjuntos con nombre, contenido y tipo MIME.')
            content = attachment.content
            if isinstance(content, str):
                content = content.encode('utf-8')
            attachments.append({'name': attachment.filename, 'content': base64.b64encode(content).decode('ascii')})
        if attachments:
            payload['attachment'] = attachments
        request = Request(
            'https://api.brevo.com/v3/smtp/email', method='POST',
            data=json.dumps(payload).encode('utf-8'),
            headers={'api-key': settings.BREVO_API_KEY, 'Content-Type': 'application/json', 'Accept': 'application/json'},
        )
        try:
            with urlopen(request, timeout=settings.EMAIL_TIMEOUT) as response:
                if response.status != 201:
                    raise RuntimeError('Brevo no confirmó la aceptación del correo.')
                result = json.loads(response.read())
        except HTTPError as error:
            # No registrar respuesta, request ni credenciales del proveedor.
            raise RuntimeError(f'Brevo rechazó el correo (HTTP {error.code}).') from None
        except (URLError, TimeoutError):
            raise RuntimeError('No se pudo conectar con Brevo.') from None
        if not result.get('messageId'):
            raise RuntimeError('Brevo no devolvió un identificador de mensaje.')
