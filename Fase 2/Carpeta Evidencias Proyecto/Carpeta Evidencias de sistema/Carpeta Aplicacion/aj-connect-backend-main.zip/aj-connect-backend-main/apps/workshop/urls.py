from django.urls import path
from .analytics import DemandForecastView, WorkshopAnalyticsView, WorkshopOverviewView
from .views import (
    CheckInCreateView,
    ClientLookupView,
    WorkOrderDetailView,
    WorkOrderItemDetailView,
    WorkOrderItemListCreateView,
    WorkOrderListView,
    QuotePdfView,
    WorkOrderPdfView,
    QuoteEmailView,
)
from .quote_views import WorkOrderQuotesView, EmailDeliveryView, QuoteServiceOptionsView

urlpatterns = [
    path('analytics/', WorkshopAnalyticsView.as_view(), name='workshop-analytics'),
    path('overview/', WorkshopOverviewView.as_view(), name='workshop-overview'),
    path('demand-forecast/', DemandForecastView.as_view(), name='workshop-demand-forecast'),
    path('work-orders/<uuid:pk>/quotes/', WorkOrderQuotesView.as_view(), name='work-order-quotes'),
    path('work-orders/<uuid:pk>/quote-services/', QuoteServiceOptionsView.as_view(), name='quote-service-options'),
    path('email-deliveries/<uuid:pk>/', EmailDeliveryView.as_view(), name='email-delivery'),
    path('clients/lookup/', ClientLookupView.as_view(), name='client-lookup'),
    path('check-in/', CheckInCreateView.as_view(), name='check-in-create'),
    path('work-orders/', WorkOrderListView.as_view(), name='work-order-list'),
    path('work-orders/<uuid:pk>/', WorkOrderDetailView.as_view(), name='work-order-detail'),
    path('orders/<uuid:pk>/', WorkOrderDetailView.as_view(http_method_names=['get', 'head', 'options']),
         name='work-order-detail-read'),
    path('work-orders/<uuid:pk>/pdf/', WorkOrderPdfView.as_view(), name='work-order-pdf'),
    path('quotes/<uuid:pk>/pdf/', QuotePdfView.as_view(), name='quote-pdf'),
    path('quotes/<uuid:pk>/email/', QuoteEmailView.as_view(), name='quote-email'),
    path(
        'work-orders/<uuid:pk>/items/',
        WorkOrderItemListCreateView.as_view(),
        name='work-order-items',
    ),
    path(
        'work-orders/<uuid:pk>/items/<uuid:item_id>/',
        WorkOrderItemDetailView.as_view(),
        name='work-order-item-detail',
    ),
]
