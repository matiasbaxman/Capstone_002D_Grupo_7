import time
from django.core.management.base import BaseCommand
from django.db import close_old_connections
from django.utils import autoreload
from apps.workshop.email_queue import process_next


class Command(BaseCommand):
    help = 'Procesa correos y bienvenidas por el canal elegido; ejecutar como worker separado.'

    def add_arguments(self, parser):
        mode = parser.add_mutually_exclusive_group()
        mode.add_argument('--once', action='store_true', help='Procesar los trabajos disponibles y terminar.')
        mode.add_argument('--reload', action='store_true', help='Recargar al cambiar el código en desarrollo.')

    def handle(self, *args, **options):
        if options['reload']:
            autoreload.run_with_reloader(self.process_jobs, once=False)
        else:
            self.process_jobs(once=options['once'])

    def process_jobs(self, *, once):
        while True:
            close_old_connections()
            processed = process_next()
            if not processed:
                if once:
                    return
                time.sleep(1)
