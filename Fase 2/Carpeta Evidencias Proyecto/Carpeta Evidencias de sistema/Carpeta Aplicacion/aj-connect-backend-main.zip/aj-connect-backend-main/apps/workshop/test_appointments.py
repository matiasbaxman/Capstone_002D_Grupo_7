from datetime import datetime, timezone as dt_timezone
from unittest.mock import patch
from zoneinfo import ZoneInfo

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.utils import timezone
from rest_framework.exceptions import ValidationError as APIValidationError

from .models import Appointment, Client, NotificationChannel, Vehicle, VehicleBrand, VehicleModel
from .serializers import AppointmentSerializer


class AppointmentTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        channel, _ = NotificationChannel.objects.get_or_create(
            code='EMAIL', defaults={'name': 'Correo'},
        )
        cls.client_record = Client.objects.create(
            rut='123456785', first_name='Ana', last_name='Pérez', phone='+56912345678',
            password_hash='!sin-acceso-web', notification_channel=channel,
        )
        cls.other_client = Client.objects.create(
            rut='223456782', first_name='Luis', last_name='Soto', phone='+56987654321',
            password_hash='!sin-acceso-web', notification_channel=channel,
        )
        brand = VehicleBrand.objects.create(name='Toyota')
        model = VehicleModel.objects.create(brand=brand, name='Yaris')
        cls.vehicle = Vehicle.objects.create(
            client=cls.client_record, model=model, plate='ABCD12', year=2021,
        )

    def setUp(self):
        self.clock = patch('apps.workshop.models.timezone.now', return_value=self.date(hour=8))
        self.now = self.clock.start()
        self.addCleanup(self.clock.stop)

    @staticmethod
    def date(day=7, hour=10, minute=0):
        # 7 de enero de 2030 es lunes. Horarios siempre en Santiago.
        return datetime(2030, 1, day, hour, minute, tzinfo=ZoneInfo('America/Santiago'))

    def values(self, **overrides):
        values = {
            'client': self.client_record, 'vehicle': self.vehicle,
            'scheduled_date': self.date(), 'reported_symptoms': 'Ruido en los frenos',
        }
        values.update(overrides)
        return values

    def payload(self, **overrides):
        values = {
            'client': str(self.client_record.pk), 'vehicle': str(self.vehicle.pk),
            'scheduled_date': self.date().isoformat(), 'reported_symptoms': 'Ruido en los frenos',
        }
        values.update(overrides)
        return values

    def test_valid_appointment_is_saved_with_timestamps(self):
        appointment = Appointment.objects.create(**self.values())
        appointment.refresh_from_db()
        self.assertEqual(appointment.client, self.client_record)
        self.assertEqual(appointment.vehicle, self.vehicle)
        self.assertEqual(appointment.status, Appointment.Status.PENDIENTE)
        self.assertEqual(appointment.scheduled_date, self.date())
        self.assertIsNotNone(appointment.created_at)
        self.assertIsNotNone(appointment.updated_at)

    def test_vehicle_is_optional(self):
        appointment = Appointment.objects.create(**self.values(vehicle=None))
        self.assertIsNone(appointment.vehicle_id)

    def test_past_and_current_time_are_rejected_by_clean_and_save(self):
        for scheduled in (self.date(day=4), self.date(hour=8)):
            for operation in ('full_clean', 'save'):
                with self.subTest(scheduled=scheduled, operation=operation):
                    appointment = Appointment(**self.values(scheduled_date=scheduled))
                    with self.assertRaises(ValidationError) as error:
                        getattr(appointment, operation)()
                    self.assertIn('scheduled_date', error.exception.message_dict)
        self.assertEqual(Appointment.objects.count(), 0)

    def test_business_hours_weekends_and_unaligned_slots_are_rejected(self):
        for scheduled in (
            self.date(day=8, hour=8), self.date(hour=18), self.date(hour=19),
            self.date(day=12), self.date(day=13), self.date(minute=30),
            self.date().replace(second=1), self.date().replace(microsecond=1),
        ):
            with self.subTest(scheduled=scheduled), self.assertRaises(ValidationError) as error:
                Appointment.objects.create(**self.values(scheduled_date=scheduled))
            self.assertIn('scheduled_date', error.exception.message_dict)

    def test_opening_and_last_slot_are_valid(self):
        for hour in (9, 17):
            Appointment.objects.create(**self.values(scheduled_date=self.date(hour=hour)))
        self.assertEqual(Appointment.objects.count(), 2)

    def test_naive_date_is_rejected(self):
        appointment = Appointment(**self.values(scheduled_date=self.date().replace(tzinfo=None)))
        with self.assertRaises(ValidationError) as error:
            appointment.clean()
        self.assertIn('scheduled_date', error.exception.message_dict)

    def test_schedule_uses_santiago_even_with_another_active_timezone(self):
        with timezone.override('UTC'):
            appointment = Appointment.objects.create(**self.values(
                scheduled_date=self.date(hour=9).astimezone(dt_timezone.utc),
            ))
        self.assertEqual(appointment.scheduled_date, self.date(hour=9))

    def test_occupied_slot_is_rejected_for_all_non_cancelled_statuses(self):
        for status in (Appointment.Status.PENDIENTE, Appointment.Status.CONFIRMADA, Appointment.Status.ATENDIDA):
            with self.subTest(status=status):
                appointment = Appointment.objects.create(**self.values(status=status))
                Appointment.objects.create(**self.values(status=status))
                with self.assertRaises(ValidationError) as error:
                    Appointment.objects.create(**self.values(client=self.other_client, vehicle=None))
                self.assertIn('scheduled_date', error.exception.message_dict)
                Appointment.objects.all().delete()

    def test_adjacent_slots_do_not_overlap(self):
        Appointment.objects.create(**self.values())
        Appointment.objects.create(**self.values(scheduled_date=self.date(hour=11)))
        self.assertEqual(Appointment.objects.count(), 2)

    def test_cancellation_releases_slot_and_reactivation_checks_capacity(self):
        cancelled = Appointment.objects.create(**self.values())
        cancelled.status = Appointment.Status.CANCELADA
        cancelled.save()
        Appointment.objects.create(**self.values())
        Appointment.objects.create(**self.values())
        cancelled.status = Appointment.Status.CONFIRMADA
        with self.assertRaises(ValidationError):
            cancelled.save()

    def test_database_constraint_blocks_duplicates_even_without_model_validation(self):
        Appointment.objects.create(**self.values())
        with self.assertRaises(IntegrityError), transaction.atomic():
            Appointment.objects.bulk_create([Appointment(**self.values())])
        Appointment.objects.bulk_create([
            Appointment(**self.values(status=Appointment.Status.CANCELADA)),
        ])
        self.assertEqual(Appointment.objects.count(), 2)

    def test_existing_appointment_does_not_conflict_with_itself(self):
        appointment = Appointment.objects.create(**self.values())
        appointment.status = Appointment.Status.CONFIRMADA
        appointment.save()
        self.assertEqual(Appointment.objects.count(), 1)

    def test_vehicle_must_belong_to_client(self):
        with self.assertRaises(ValidationError) as error:
            Appointment.objects.create(**self.values(client=self.other_client))
        self.assertIn('vehicle', error.exception.message_dict)

    def test_client_and_status_are_validated_and_symptoms_are_optional(self):
        for overrides, field in (({'client': None}, 'client'), ({'status': 'INVALIDO'}, 'status')):
            with self.subTest(field=field), self.assertRaises(ValidationError) as error:
                Appointment.objects.create(**self.values(**overrides))
            self.assertIn(field, error.exception.message_dict)
        appointment = Appointment.objects.create(**self.values(reported_symptoms=''))
        self.assertEqual(appointment.reported_symptoms, '')

    def test_historical_appointment_can_be_closed_but_not_rescheduled_to_past(self):
        appointment = Appointment.objects.create(**self.values())
        self.now.return_value = self.date(day=8, hour=8)
        appointment.status = Appointment.Status.ATENDIDA
        appointment.save()
        appointment.refresh_from_db()
        self.assertEqual(appointment.status, Appointment.Status.ATENDIDA)
        appointment.scheduled_date = self.date(hour=11)
        with self.assertRaises(ValidationError):
            appointment.save()

    def test_serializer_creates_valid_appointment_without_vehicle(self):
        payload = self.payload()
        payload.pop('vehicle')
        serializer = AppointmentSerializer(data=payload)
        self.assertTrue(serializer.is_valid(), serializer.errors)
        appointment = serializer.save()
        self.assertIsNone(appointment.vehicle_id)

    def test_serializer_rejects_past_outside_hours_and_full_slots(self):
        Appointment.objects.create(**self.values())
        Appointment.objects.create(**self.values())
        for scheduled in (self.date(day=4), self.date(hour=18), self.date(day=12), self.date(minute=30), self.date()):
            serializer = AppointmentSerializer(data=self.payload(scheduled_date=scheduled.isoformat()))
            with self.subTest(scheduled=scheduled):
                self.assertFalse(serializer.is_valid())
                self.assertIn('scheduled_date', serializer.errors)

    def test_serializer_rejects_wrong_vehicle_owner_and_invalid_status(self):
        for overrides, field in (({'client': str(self.other_client.pk)}, 'vehicle'),
                                 ({'status': 'INVALIDO'}, 'status')):
            serializer = AppointmentSerializer(data=self.payload(**overrides))
            self.assertFalse(serializer.is_valid())
            self.assertIn(field, serializer.errors)

    def test_partial_update_uses_existing_values_without_mutating_on_validation(self):
        appointment = Appointment.objects.create(**self.values())
        serializer = AppointmentSerializer(appointment, data={'status': 'CONFIRMADA'}, partial=True)
        self.assertTrue(serializer.is_valid(), serializer.errors)
        self.assertEqual(appointment.status, Appointment.Status.PENDIENTE)
        serializer.save()
        appointment.refresh_from_db()
        self.assertEqual(appointment.status, Appointment.Status.CONFIRMADA)

    def test_serializer_rechecks_availability_when_saved(self):
        serializer = AppointmentSerializer(data=self.payload())
        self.assertTrue(serializer.is_valid(), serializer.errors)
        Appointment.objects.create(**self.values())
        Appointment.objects.create(**self.values())
        with self.assertRaises(APIValidationError) as error:
            serializer.save()
        self.assertIn('scheduled_date', error.exception.detail)
        self.assertEqual(Appointment.objects.count(), 2)

    def test_partial_update_rejects_conflicting_reschedule_without_mutation(self):
        appointment = Appointment.objects.create(**self.values())
        Appointment.objects.create(**self.values(scheduled_date=self.date(hour=11)))
        Appointment.objects.create(**self.values(scheduled_date=self.date(hour=11)))
        serializer = AppointmentSerializer(appointment, data={
            'scheduled_date': self.date(hour=11).isoformat(),
        }, partial=True)
        self.assertFalse(serializer.is_valid())
        self.assertEqual(appointment.scheduled_date, self.date())

    def test_serializer_converts_database_reservation_race_to_field_error(self):
        serializer = AppointmentSerializer(data=self.payload())
        self.assertTrue(serializer.is_valid(), serializer.errors)
        Appointment.objects.create(**self.values())
        Appointment.objects.create(**self.values())
        # Simula una reserva que entra después de full_clean y antes del INSERT.
        with patch.object(Appointment, 'full_clean'):
            with self.assertRaises(APIValidationError) as error:
                serializer.save()
        self.assertIn('scheduled_date', error.exception.detail)
        self.assertEqual(Appointment.objects.count(), 2)
