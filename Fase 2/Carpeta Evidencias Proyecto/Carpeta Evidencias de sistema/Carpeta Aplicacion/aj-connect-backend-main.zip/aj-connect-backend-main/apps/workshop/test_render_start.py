import subprocess
from unittest.mock import Mock, patch

from django.test import SimpleTestCase

import start_render


class RenderStartTests(SimpleTestCase):
    @patch('start_render.os.chdir')
    @patch('start_render.signal.signal')
    @patch('start_render.subprocess.Popen')
    def test_worker_exit_stops_web_and_fails_service(self, popen, signals, chdir):
        web, worker = Mock(), Mock()
        web.poll.return_value = None
        worker.poll.return_value = 1
        popen.side_effect = [web, worker]
        with patch.dict('os.environ', {'PORT': '10000'}):
            self.assertEqual(start_render.main(), 1)
        self.assertIn('0.0.0.0:10000', popen.call_args_list[0].args[0])
        self.assertIn('process_notifications', popen.call_args_list[1].args[0])
        web.terminate.assert_called_once()
        web.wait.assert_called_once()
        worker.terminate.assert_not_called()

    @patch('start_render.os.chdir')
    @patch('start_render.signal.signal')
    @patch('start_render.subprocess.Popen')
    def test_second_process_start_failure_stops_first(self, popen, signals, chdir):
        web = Mock()
        web.poll.return_value = None
        web.wait.side_effect = [subprocess.TimeoutExpired('gunicorn', 25), 0]
        popen.side_effect = [web, OSError('unable to start')]
        with self.assertRaises(OSError):
            start_render.main()
        web.terminate.assert_called_once()
        web.kill.assert_called_once()
