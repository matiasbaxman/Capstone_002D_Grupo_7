import uuid
import secrets
from datetime import datetime
from decimal import Decimal
from django.contrib.auth.hashers import check_password, identify_hasher, make_password
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models, transaction
from django.conf import settings
from django.utils import timezone

from apps.inventory.models import InventoryItem
from .client_contacts import CONTACT_CONSTRAINTS, email_key, phone_key


def generate_tracking_token():
    """UUIDv4 hexadecimal; conserva el formato de los enlaces existentes."""
    return uuid.uuid4().hex


def generate_tracking_code():
    alphabet = '23456789ABCDEFGHJKMNPQRSTUVWXYZ'
    return 'AJ' + ''.join(secrets.choice(alphabet) for _ in range(12))


# =============================================================================
# 1. CLIENTES Y CANALES DE NOTIFICACIÓN
# =============================================================================

class NotificationChannel(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'notification_channels'
        verbose_name = 'Canal de Notificación'
        verbose_name_plural = 'Canales de Notificación'

    def __str__(self):
        return self.name


class Client(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    rut = models.CharField(max_length=12, unique=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField(max_length=255, null=True, blank=True)
    password_hash = models.CharField(max_length=255)
    notification_channel = models.ForeignKey(
        NotificationChannel,
        on_delete=models.PROTECT,
        related_name='clients',
        db_column='notification_channel_id'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'clients'
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'
        ordering = ['last_name', 'first_name']
        constraints = [
            models.UniqueConstraint(email_key('email'), name=CONTACT_CONSTRAINTS['email']),
            models.UniqueConstraint(phone_key('phone'), name=CONTACT_CONSTRAINTS['phone']),
        ]

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.rut})"

    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    def set_password(self, raw_password):
        self.password_hash = make_password(raw_password)

    def set_unusable_password(self):
        self.password_hash = make_password(None)

    def has_usable_password(self):
        try:
            identify_hasher(self.password_hash)
        except ValueError:
            return False
        return True

    def check_password(self, raw_password):
        return check_password(raw_password, self.password_hash)


class ClientOTP(models.Model):
    """Un solo desafío vigente por cliente; nunca guarda el código en claro."""

    client = models.OneToOneField(Client, on_delete=models.CASCADE, related_name='otp')
    code_hash = models.CharField(max_length=128)
    expires_at = models.DateTimeField()
    last_sent_at = models.DateTimeField()
    attempts = models.PositiveSmallIntegerField(default=0)
    consumed_at = models.DateTimeField(null=True, blank=True)
    verified_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'client_otps'


# =============================================================================
# 2. MARCAS, MODELOS Y VEHÍCULOS (3FN)
# =============================================================================

class VehicleBrand(models.Model):
    name = models.CharField(max_length=50, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'vehicle_brands'
        verbose_name = 'Marca de Vehículo'
        verbose_name_plural = 'Marcas de Vehículos'

    def __str__(self):
        return self.name


class VehicleModel(models.Model):
    brand = models.ForeignKey(
        VehicleBrand,
        on_delete=models.CASCADE,
        related_name='models',
        db_column='brand_id'
    )
    name = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'vehicle_models'
        verbose_name = 'Modelo de Vehículo'
        verbose_name_plural = 'Modelos de Vehículos'
        unique_together = ('brand', 'name')

    def __str__(self):
        return f"{self.brand.name} {self.name}"


class Vehicle(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='vehicles',
        db_column='client_id'
    )
    model = models.ForeignKey(
        VehicleModel,
        on_delete=models.PROTECT,
        related_name='vehicles',
        db_column='model_id'
    )
    plate = models.CharField(max_length=10, unique=True)
    year = models.IntegerField()
    color = models.CharField(max_length=30, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'vehicles'
        verbose_name = 'Vehículo'
        verbose_name_plural = 'Vehículos'
        ordering = ['plate']

    def __str__(self):
        return f"{self.plate} - {self.model}"


class Service(models.Model):
    name = models.CharField(max_length=150, unique=True)
    description = models.TextField(blank=True)
    base_price = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        validators=[MinValueValidator(Decimal('0'))],
    )
    estimated_duration_minutes = models.PositiveIntegerField(
        null=True, blank=True, validators=[MinValueValidator(1)],
    )
    is_active = models.BooleanField(default=True)
    is_bookable = models.BooleanField(default=True, verbose_name='Disponible en la reserva pública')

    class Meta:
        db_table = 'services'
        ordering = ['name', 'id']
        verbose_name = 'Servicio'
        verbose_name_plural = 'Servicios'
        constraints = [
            models.CheckConstraint(condition=models.Q(base_price__gte=0) | models.Q(base_price__isnull=True), name='service_nonnegative_price'),
            models.CheckConstraint(condition=models.Q(estimated_duration_minutes__gte=1) | models.Q(estimated_duration_minutes__isnull=True), name='service_positive_duration'),
        ]

    def __str__(self):
        return self.name


class AppointmentSlot(models.Model):
    """Fila de bloqueo para serializar la asignación de los dos cupos."""

    scheduled_date = models.DateTimeField(primary_key=True)


class Appointment(models.Model):
    """Dos citas por hora; rechazar o cancelar libera el cupo inmediatamente."""

    OPENING_HOUR = 9
    CLOSING_HOUR = 18
    SLOT_MINUTES = 60
    CAPACITY = 2
    INACTIVE_STATUSES = ('CANCELADA', 'RECHAZADA')

    class Status(models.TextChoices):
        PENDIENTE = 'PENDIENTE', 'Pendiente'
        CONFIRMADA = 'CONFIRMADA', 'Confirmada'
        CANCELADA = 'CANCELADA', 'Cancelada'
        RECHAZADA = 'RECHAZADA', 'Rechazada'
        ATENDIDA = 'ATENDIDA', 'Atendida'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(Client, on_delete=models.PROTECT, related_name='appointments')
    vehicle = models.ForeignKey(
        Vehicle, on_delete=models.PROTECT, related_name='appointments', null=True, blank=True,
    )
    service = models.ForeignKey(
        Service, on_delete=models.PROTECT, related_name='appointments', null=True, blank=True,
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDIENTE)
    scheduled_date = models.DateTimeField(db_index=True)
    slot_number = models.PositiveSmallIntegerField(default=1, editable=False)
    reported_symptoms = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'appointments'
        ordering = ['scheduled_date', 'created_at']
        verbose_name = 'Cita'
        verbose_name_plural = 'Citas'
        constraints = [
            models.UniqueConstraint(
                fields=['scheduled_date', 'slot_number'],
                condition=~models.Q(status__in=['CANCELADA', 'RECHAZADA']),
                name='unique_active_appointment_capacity',
                violation_error_message='El bloque horario ya no tiene cupos disponibles.',
            ),
            models.CheckConstraint(condition=models.Q(slot_number__gte=1, slot_number__lte=2), name='appointment_slot_one_or_two'),
        ]

    def clean(self):
        super().clean()
        errors = {}
        if self.client_id and self.vehicle_id:
            owner_id = Vehicle.objects.filter(pk=self.vehicle_id).values_list('client_id', flat=True).first()
            if owner_id is not None and owner_id != self.client_id:
                errors['vehicle'] = 'El vehículo no pertenece al cliente de la cita.'

        scheduled = self.scheduled_date
        if isinstance(scheduled, datetime):
            if timezone.is_naive(scheduled):
                errors['scheduled_date'] = 'La fecha debe incluir una zona horaria.'
            else:
                # Las reglas usan America/Santiago (TIME_ZONE), aunque una
                # petición haya activado otra zona horaria para presentación.
                local = timezone.localtime(scheduled, timezone.get_default_timezone())
                previous = None
                if not self._state.adding:
                    previous = type(self).objects.filter(pk=self.pk).values_list('scheduled_date', flat=True).first()
                # Permite cancelar o marcar como atendida una cita histórica;
                # solo una reserva nueva o reprogramación debe ser futura.
                if scheduled <= timezone.now() and scheduled != previous:
                    errors['scheduled_date'] = 'No se puede agendar una cita en el pasado.'
                elif local.weekday() >= 5 or not self.OPENING_HOUR <= local.hour < self.CLOSING_HOUR:
                    errors['scheduled_date'] = 'El taller atiende de lunes a viernes de 09:00 a 18:00.'
                elif local.minute or local.second or local.microsecond:
                    errors['scheduled_date'] = 'Selecciona un bloque de una hora, con inicio en hora exacta.'
                elif self.status not in self.INACTIVE_STATUSES:
                    occupied = type(self).objects.filter(scheduled_date=scheduled).exclude(
                        status__in=self.INACTIVE_STATUSES,
                    ).exclude(pk=self.pk)
                    used = set(occupied.values_list('slot_number', flat=True))
                    if len(used) >= self.CAPACITY:
                        errors['scheduled_date'] = 'El bloque horario ya no tiene cupos disponibles.'
                    else:
                        self.slot_number = next(n for n in range(1, self.CAPACITY + 1) if n not in used)
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        with transaction.atomic():
            # PostgreSQL serializa las reservas del mismo horario. El índice
            # compuesto y el CHECK mantienen el máximo incluso con bulk_create.
            slot, _ = AppointmentSlot.objects.get_or_create(scheduled_date=self.scheduled_date)
            AppointmentSlot.objects.select_for_update().get(pk=slot.pk)
            self.full_clean()
            if kwargs.get('update_fields'):
                kwargs['update_fields'] = set(kwargs['update_fields']) | {'slot_number'}
            return super().save(*args, **kwargs)

    def __str__(self):
        return f'Cita {self.scheduled_date} ({self.status})'


# =============================================================================
# 3. ÓRDENES DE TRABAJO, CHECK-IN Y FOTOS
# =============================================================================

class WorkOrderStatus(models.Model):
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=50)
    sequence_order = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'work_order_statuses'
        verbose_name = 'Estado de OT'
        verbose_name_plural = 'Estados de OT'

    def __str__(self):
        return self.name


class WorkOrder(models.Model):
    appointment = models.OneToOneField(Appointment, on_delete=models.PROTECT, null=True, blank=True, related_name='work_order')
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    folio_number = models.IntegerField(unique=True, editable=False)
    tracking_code = models.CharField(max_length=14, unique=True, default=generate_tracking_code, editable=False)
    # unique=True crea el índice único en BD; no hace falta un segundo índice.
    tracking_token = models.CharField(
        max_length=32, default=generate_tracking_token, unique=True, editable=False,
    )
    vehicle = models.ForeignKey(
        Vehicle,
        on_delete=models.PROTECT,
        related_name='work_orders',
        db_column='vehicle_id'
    )
    assigned_mechanic = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_work_orders',
        db_column='assigned_mechanic_id'
    )
    status = models.ForeignKey(
        WorkOrderStatus,
        on_delete=models.PROTECT,
        related_name='work_orders',
        db_column='status_id'
    )
    client_observations = models.TextField(null=True, blank=True)
    technical_diagnosis = models.TextField(null=True, blank=True)
    ai_diagnostic_suggestion = models.TextField(blank=True, null=True)
    estimated_delivery_date = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'work_orders'
        verbose_name = 'Orden de Trabajo'
        verbose_name_plural = 'Órdenes de Trabajo'

    def __str__(self):
        return f"OT #{self.folio_number} - {self.vehicle.plate}"


class WorkOrderCheckIn(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_order = models.OneToOneField(
        WorkOrder,
        on_delete=models.CASCADE,
        related_name='checkin',
        db_column='work_order_id'
    )
    receptionist = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='receptionist_checkins',
        db_column='receptionist_id'
    )
    initial_odometer = models.PositiveIntegerField(null=True, blank=True)
    fuel_level = models.CharField(max_length=20, blank=True, default='')
    has_spare_tire = models.BooleanField(null=True, blank=True, default=None)
    has_jack_and_tools = models.BooleanField(null=True, blank=True, default=None)
    bodywork_details = models.TextField(null=True, blank=True)
    additional_equipment = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'work_order_checkins'
        verbose_name = 'Check-In Vehicular'
        verbose_name_plural = 'Check-Ins Vehiculares'

    def __str__(self):
        return f"Check-In OT #{self.work_order.folio_number} ({self.work_order.vehicle.plate})"


class WorkOrderStatusHistory(models.Model):
    """
    Auditoría de cambios de estado de una orden de trabajo.

    Se escribe dentro de la misma transacción que actualiza
    `WorkOrder.status`, para que el historial nunca quede desalineado con el
    estado actual. `changed_by` usa SET_NULL: si el usuario se elimina, el
    registro histórico se conserva.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_order = models.ForeignKey(
        WorkOrder,
        on_delete=models.CASCADE,
        related_name='status_history',
        db_column='work_order_id'
    )
    from_status = models.ForeignKey(
        WorkOrderStatus,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='+',
        db_column='from_status_id'
    )
    to_status = models.ForeignKey(
        WorkOrderStatus,
        on_delete=models.PROTECT,
        related_name='+',
        db_column='to_status_id'
    )
    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='work_order_status_changes',
        db_column='changed_by_id'
    )
    notes = models.TextField(null=True, blank=True)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'work_order_status_history'
        verbose_name = 'Cambio de Estado de OT'
        verbose_name_plural = 'Cambios de Estado de OT'
        ordering = ['-changed_at']

    def __str__(self):
        return f"OT #{self.work_order.folio_number}: {self.from_status} -> {self.to_status}"


class WorkOrderPhoto(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    checkin = models.ForeignKey(
        WorkOrderCheckIn,
        on_delete=models.CASCADE,
        related_name='photos',
        db_column='checkin_id'
    )
    photo_cloudinary_url = models.TextField()
    public_id = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'work_order_photos'
        verbose_name = 'Foto de Check-In'
        verbose_name_plural = 'Fotos de Check-In'

    def __str__(self):
        return f"Foto {self.public_id} - CheckIn {self.checkin_id}"


# =============================================================================
# 4. INSUMOS VINCULADOS A ÓRDENES DE TRABAJO
# =============================================================================

class WorkOrderItem(models.Model):
    """
    Insumo del inventario vinculado a una orden de trabajo.

    `unit_price` es un snapshot del precio al momento de asociar el insumo, para
    que el costo histórico de la OT no cambie si el catálogo se actualiza.
    El descuento y la reposición de stock se hacen dentro de una transacción
    atómica en las vistas.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_order = models.ForeignKey(
        WorkOrder,
        on_delete=models.CASCADE,
        related_name='items',
        db_column='work_order_id',
    )
    item = models.ForeignKey(
        InventoryItem,
        on_delete=models.PROTECT,
        related_name='order_items',
        db_column='item_id',
    )
    added_by_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='added_work_order_items',
        db_column='added_by_user_id',
    )
    quantity = models.PositiveIntegerField()
    request_id = models.UUIDField(null=True, blank=True, editable=False)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'work_order_items'
        verbose_name = 'Insumo de Orden de Trabajo'
        verbose_name_plural = 'Insumos de Órdenes de Trabajo'
        ordering = ['created_at']
        constraints = [models.UniqueConstraint(fields=['work_order', 'request_id'], name='unique_order_item_request')]

    def __str__(self):
        return f"OT #{self.work_order.folio_number} - {self.item.name} x{self.quantity}"

    @property
    def subtotal(self):
        return self.unit_price * self.quantity


class Quote(models.Model):
    """Cotización asociada a un cliente y opcionalmente a una OT."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_order = models.ForeignKey(
        WorkOrder, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='quotes', db_column='work_order_id',
    )
    client = models.ForeignKey(
        Client, on_delete=models.PROTECT, related_name='quotes', db_column='client_id',
    )
    subtotal_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    service_name = models.CharField(max_length=250, blank=True, default='')
    service_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(0)])
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    is_approved = models.BooleanField(default=False)
    pdf_cloudinary_url = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'quotes'
        ordering = ['-created_at']
        constraints = [
            models.CheckConstraint(condition=models.Q(total_amount__gte=0, subtotal_amount__gte=0, tax_amount__gte=0), name='quote_nonnegative_amounts'),
            models.CheckConstraint(condition=models.Q(tax_rate__gte=0, tax_rate__lte=100), name='quote_valid_tax_rate'),
            models.CheckConstraint(condition=models.Q(total_amount=models.F('subtotal_amount') + models.F('tax_amount')), name='quote_total_consistent'),
            models.CheckConstraint(
                condition=models.Q(service_name='', service_amount__isnull=True)
                | (~models.Q(service_name='') & models.Q(service_amount__isnull=False, service_amount__gte=0)),
                name='quote_service_snapshot_consistent',
            ),
        ]

    def clean(self):
        super().clean()
        if self.work_order_id and self.client_id != self.work_order.vehicle.client_id:
            raise ValidationError({'client': 'El cliente debe ser el propietario del vehículo de la OT.'})
        if self.pk and not self._state.adding:
            from .quote_totals import calculate_totals
            totals = calculate_totals(self.items.all(), self.tax_rate, self.service_amount)
            if any(getattr(self, key) != value for key, value in totals.items()):
                raise ValidationError({'total_amount': 'Los importes no coinciden con el detalle y la tasa de impuesto.'})


class QuoteItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    quote = models.ForeignKey(
        Quote, on_delete=models.CASCADE, related_name='items', db_column='quote_id',
    )
    item = models.ForeignKey(
        InventoryItem, on_delete=models.PROTECT, related_name='quote_items', db_column='item_id',
    )
    brand_name = models.CharField(max_length=100, blank=True, default='')
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'quote_items'
        ordering = ['created_at']
        constraints = [models.CheckConstraint(condition=models.Q(quantity__gte=1, unit_price__gte=0), name='quote_item_positive_values')]

    @property
    def subtotal(self):
        return self.unit_price * self.quantity


class BookingVerification(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    rut = models.CharField(max_length=12, db_index=True)
    payload_hash = models.CharField(max_length=64)
    code_hash = models.CharField(max_length=128)
    expires_at = models.DateTimeField()
    attempts = models.PositiveSmallIntegerField(default=0)
    consumed_at = models.DateTimeField(null=True, blank=True)


class EmailDelivery(models.Model):
    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Pendiente'
        PROCESSING = 'PROCESSING', 'En proceso'
        SENT = 'SENT', 'Enviado'
        FAILED = 'FAILED', 'Fallido'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    payload = models.JSONField(default=dict, blank=True)
    kind = models.CharField(max_length=20, choices=[('appointment_notice', 'Estado de cita'), ('quote', 'Cotización'), ('work_order', 'Orden'), ('welcome', 'Bienvenida por canal elegido')])
    target_id = models.UUIDField()
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING)
    attempts = models.PositiveSmallIntegerField(default=0)
    available_at = models.DateTimeField(default=timezone.now, db_index=True)
    locked_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['kind', 'target_id'], condition=models.Q(kind='welcome'), name='unique_client_welcome_notification')]


class ClientProfileChange(models.Model):
    client = models.OneToOneField(Client, on_delete=models.CASCADE)
    payload = models.JSONField(default=dict)
    email_at_request = models.EmailField()
    code_hash = models.CharField(max_length=128)
    expires_at = models.DateTimeField()
    last_sent_at = models.DateTimeField()
    attempts = models.PositiveSmallIntegerField(default=0)
    consumed_at = models.DateTimeField(null=True, blank=True)


class DemandForecastSnapshot(models.Model):
    """Última proyección por tipo de período y rango consultado."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    period = models.CharField(max_length=10)
    start_date = models.DateField()
    end_date = models.DateField()
    forecast = models.JSONField(default=dict)
    generated_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        db_table = 'demand_forecast_snapshots'
        constraints = [models.UniqueConstraint(
            fields=['period', 'start_date', 'end_date'],
            name='unique_demand_forecast_period_range',
        )]
