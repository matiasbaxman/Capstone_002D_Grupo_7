from django.db import migrations, models
from django.db.models import Case, Count, Value, When
from django.db.models.functions import Concat, Length, Lower, NullIf, Replace, Right, Trim
from django.db.models.lookups import Exact, StartsWith


EMAIL_KEY = NullIf(Lower(Trim('email')), Value(''))
digits = 'phone'
for separator in ('+', ' ', '-', '.', '(', ')'):
    digits = Replace(digits, Value(separator), Value(''))
PHONE_KEY = NullIf(Case(
    When(Exact(Length(digits), 11) & StartsWith(digits, Value('569')), then=Right(digits, 9)),
    When(Exact(Length(digits), 8), then=Concat(Value('9'), digits)),
    default=digits,
), Value(''))


def check_existing_contacts(apps, schema_editor):
    clients = apps.get_model('workshop', 'Client').objects.using(schema_editor.connection.alias)
    duplicates = {}
    for field, key in (('email', EMAIL_KEY), ('phone', PHONE_KEY)):
        count = clients.order_by().annotate(contact=key).filter(contact__isnull=False).values('contact').annotate(
            total=Count('pk'),
        ).filter(total__gt=1).count()
        if count:
            duplicates[field] = count
    if duplicates:
        raise RuntimeError(f'Hay contactos duplicados en clientes ({duplicates}). Corrige los duplicados antes de migrar.')


class Migration(migrations.Migration):
    dependencies = [('workshop', '0023_quote_services')]
    operations = [
        migrations.RunPython(check_existing_contacts, migrations.RunPython.noop),
        migrations.AddConstraint(
            model_name='client',
            constraint=models.UniqueConstraint(EMAIL_KEY, name='client_contact_email_unique'),
        ),
        migrations.AddConstraint(
            model_name='client',
            constraint=models.UniqueConstraint(PHONE_KEY, name='client_contact_phone_unique'),
        ),
    ]
