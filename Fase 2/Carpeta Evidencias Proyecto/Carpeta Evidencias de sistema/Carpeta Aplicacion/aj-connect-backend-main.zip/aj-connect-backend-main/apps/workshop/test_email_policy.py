from types import SimpleNamespace
from unittest.mock import patch

from django.test import TestCase, override_settings

from .client_otp_delivery import deliver_client_otp
from .models import Client
from . import test_client_onboarding as onboarding_helpers


@override_settings(CLIENT_EMAIL_REQUIRED=True, CLIENT_OTP_DELIVERY_MODE='channel',
                   EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class EmailPolicyTests(TestCase):
    setUp = onboarding_helpers.ClientOnboardingTests.setUp
    data = onboarding_helpers.ClientOnboardingTests.data
    checkin = onboarding_helpers.ClientOnboardingTests.checkin
    booking = onboarding_helpers.ClientOnboardingTests.booking

    def test_reception_requires_email_even_when_whatsapp_is_requested(self):
        response = self.checkin('WHATSAPP')
        self.assertEqual(response.status_code, 400)
        self.assertIn('email', response.data)
        self.assertFalse(Client.objects.exists())

    def test_reception_accepts_empty_phone_and_uses_email(self):
        response = self.checkin('WHATSAPP', email='ana@example.test', phone='')
        self.assertEqual(response.status_code, 201, response.data)
        client = Client.objects.get()
        self.assertEqual(client.notification_channel.code, 'EMAIL')
        self.assertEqual(client.phone, '')

    def test_booking_uses_email_even_when_whatsapp_is_requested(self):
        response = self.booking('WHATSAPP')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(Client.objects.get().notification_channel.code, 'EMAIL')

    @patch('apps.workshop.client_otp_delivery.send_mail', return_value=1)
    @patch('apps.workshop.client_otp_delivery.import_string')
    def test_existing_whatsapp_client_receives_otp_by_email(self, provider, email):
        client = SimpleNamespace(email='ana@example.test', phone='+56912345678',
                                 notification_channel=SimpleNamespace(code='WHATSAPP'))
        deliver_client_otp(client, '012345')
        self.assertEqual(email.call_args.args[3], ['ana@example.test'])
        provider.assert_not_called()
