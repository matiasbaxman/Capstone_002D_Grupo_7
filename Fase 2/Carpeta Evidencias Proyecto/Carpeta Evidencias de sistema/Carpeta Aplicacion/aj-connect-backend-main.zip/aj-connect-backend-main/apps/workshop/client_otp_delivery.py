import logging

from django.conf import settings
from django.core.mail import send_mail
from django.utils.module_loading import import_string

logger = logging.getLogger(__name__)


def deliver_client_otp(client, code, *, purpose="access"):
    """Solo la simulación local imprime el código; envío real según canal."""
    channel = 'EMAIL' if settings.CLIENT_EMAIL_REQUIRED else client.notification_channel.code.strip().upper()
    recipient = client.email if channel == 'EMAIL' else client.phone
    if channel not in ('EMAIL', 'WHATSAPP') or not recipient:
        raise RuntimeError('Canal o destinatario no configurado.')
    mode = settings.CLIENT_OTP_DELIVERY_MODE
    if mode == 'simulation' and settings.CLIENT_OTP_ALLOW_SIMULATION:
        logger.warning('SIMULACION OTP: canal=%s destino=%s codigo=%s', channel, recipient, code)
        return
    if mode != 'channel':
        raise RuntimeError('El envío de OTP no está habilitado.')
    message = f'Tu código de acceso a A&J Connect es {code}. Expira en 5 minutos. No lo compartas.'
    subject = 'Código de acceso A&J Connect'
    if purpose == 'appointment':
        subject = 'Código para confirmación de cita A&J Connect'
        message = f'Tu código para confirmar tu cita en A&J Connect es {code}. Expira en 5 minutos. No lo compartas.'
    if channel == 'EMAIL':
        sent = send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [recipient])
        if sent != 1:
            raise RuntimeError('No se pudo entregar el correo OTP.')
    else:
        if not settings.CLIENT_OTP_WHATSAPP_SENDER:
            raise RuntimeError('El proveedor WhatsApp no está configurado.')
        # Adaptador propio del proveedor: sender(phone, message), debe lanzar
        # una excepción si la entrega no puede aceptarse.
        import_string(settings.CLIENT_OTP_WHATSAPP_SENDER)(recipient, message)
