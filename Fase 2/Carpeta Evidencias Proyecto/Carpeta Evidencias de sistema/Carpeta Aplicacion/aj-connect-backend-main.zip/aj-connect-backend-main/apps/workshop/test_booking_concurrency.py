from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from threading import Barrier
from unittest import skipUnless
from zoneinfo import ZoneInfo

from django.core.exceptions import ValidationError
from django.db import connection, close_old_connections
from django.test import TransactionTestCase
from .models import Appointment, Client, NotificationChannel


@skipUnless(connection.vendor == 'postgresql', 'Bloqueos de fila verificados en PostgreSQL; SQLite no ofrece select_for_update.')
class BookingConcurrencyTests(TransactionTestCase):
    def test_two_simultaneous_requests_for_last_place_create_only_one(self):
        channel, _ = NotificationChannel.objects.get_or_create(code='EMAIL', defaults={'name': 'Email'})
        client = Client.objects.create(rut='123456785', first_name='QA', last_name='Concurrency', phone='+56912345678', notification_channel=channel, password_hash='!qa')
        scheduled = datetime(2030, 1, 7, 10, tzinfo=ZoneInfo('America/Santiago'))
        Appointment.objects.create(client=client, scheduled_date=scheduled, reported_symptoms='Primer cupo')
        barrier = Barrier(2)

        def reserve():
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                Appointment.objects.create(client_id=client.pk, scheduled_date=scheduled, reported_symptoms='Reserva simultánea')
                return 'created'
            except ValidationError:
                return 'full'
            finally:
                connection.close()

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: reserve(), range(2)))
        self.assertCountEqual(results, ['created', 'full'])
        self.assertEqual(Appointment.objects.filter(scheduled_date=scheduled).count(), 2)
        self.assertEqual(set(Appointment.objects.values_list('slot_number', flat=True)), {1, 2})
