from django.test import TestCase, override_settings
from django.db import IntegrityError, transaction
from apps.authentication.client_tokens import ClientAccessToken
from . import test_client_onboarding as helpers
from .models import Client, Appointment, WorkOrder, Vehicle, VehicleBrand, VehicleModel

@override_settings(CLIENT_EMAIL_REQUIRED=True, EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class AppointmentLinkTests(TestCase):
    setUp = helpers.ClientOnboardingTests.setUp
    data = helpers.ClientOnboardingTests.data
    booking = helpers.ClientOnboardingTests.booking
    checkin = helpers.ClientOnboardingTests.checkin

    def accepted(self):
        self.assertEqual(self.booking().status_code,201)
        appointment=Appointment.objects.get(); appointment.status='CONFIRMADA'; appointment.save()
        return appointment, Client.objects.get()

    def test_link_is_atomic_and_portal_has_one_attention(self):
        appointment, client=self.accepted()
        self.api.force_authenticate(self.staff)
        lookup_url = '/api/workshop/clients/lookup/'
        available = self.api.post(lookup_url, {'rut': client.rut}, format='json')
        self.assertEqual(available.status_code, 200, available.data)
        self.assertEqual([row['id'] for row in available.json()['appointments']], [str(appointment.pk)])

        response=self.checkin(client_id=str(client.pk), appointment_id=str(appointment.pk))
        self.assertEqual(response.status_code,201,response.data)
        order=WorkOrder.objects.get(); appointment.refresh_from_db()
        self.assertEqual(order.appointment_id,appointment.pk)
        self.assertEqual(appointment.status,'ATENDIDA')
        self.assertEqual(appointment.vehicle_id,order.vehicle_id)
        available = self.api.post(lookup_url, {'rut': client.rut}, format='json')
        self.assertEqual(available.status_code, 200, available.data)
        self.assertEqual(available.json()['appointments'], [])
        self.api.force_authenticate(None)
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(client)))
        account=self.api.get('/api/auth/client-session/').data
        self.assertEqual(account['orders'][0]['appointment_id'],str(appointment.pk))
        self.assertEqual(account['appointments'][0]['work_order__tracking_code'],order.tracking_code)
        self.assertEqual(self.api.get('/api/auth/client-session/').status_code,200)
        self.api.force_authenticate(self.staff)
        response=self.checkin(client_id=str(client.pk), appointment_id=str(appointment.pk), plate='BCDF13')
        self.assertEqual(response.status_code,400)
        self.assertIn('appointment_id', response.data)
        self.assertEqual(WorkOrder.objects.count(),1)
        self.assertEqual(Vehicle.objects.count(),1)
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                WorkOrder.objects.create(appointment=appointment,vehicle=order.vehicle,status=order.status,assigned_mechanic=self.staff,folio_number=99999)

    def test_unconfirmed_or_other_client_cannot_be_linked(self):
        appointment, client=self.accepted()
        appointment.status='PENDIENTE'; appointment.save()
        response=self.checkin(client_id=str(client.pk),appointment_id=str(appointment.pk))
        self.assertEqual(response.status_code,400)
        self.assertFalse(WorkOrder.objects.exists())
        self.assertFalse(Vehicle.objects.exists())
        appointment.status='CONFIRMADA';appointment.save()
        response=self.checkin(rut='223456782',email='other@example.test',appointment_id=str(appointment.pk))
        self.assertEqual(response.status_code,400)
        self.assertEqual(Client.objects.count(),1)

    def test_wrong_vehicle_rejected_and_unlinked_order_still_allowed(self):
        appointment,client=self.accepted()
        brand=VehicleBrand.objects.create(name='Marca QA')
        model=VehicleModel.objects.create(brand=brand,name='Modelo QA')
        vehicle=Vehicle.objects.create(client=client,model=model,plate='BCDF14',year=2020)
        appointment.vehicle=vehicle;appointment.save()
        response=self.checkin(client_id=str(client.pk),appointment_id=str(appointment.pk))
        self.assertEqual(response.status_code,400)
        self.assertEqual(Vehicle.objects.count(),1)
        self.assertFalse(WorkOrder.objects.exists())
        response=self.checkin(client_id=str(client.pk))
        self.assertEqual(response.status_code,201,response.data)
        self.assertIsNone(WorkOrder.objects.get().appointment_id)
