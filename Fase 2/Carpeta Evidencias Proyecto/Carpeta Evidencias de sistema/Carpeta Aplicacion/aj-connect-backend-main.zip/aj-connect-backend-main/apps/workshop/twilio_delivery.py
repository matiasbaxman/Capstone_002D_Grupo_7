"""Mensajes de demostración al teléfono unido al Sandbox de Twilio."""
import base64
import json
import re
from http.client import HTTPSConnection
from urllib.parse import urlencode

from django.conf import settings


def whatsapp_address(value):
    number = re.sub(r'[\s()-]', '', value.removeprefix('whatsapp:'))
    if not re.fullmatch(r'\+[1-9][0-9]{7,14}', number):
        raise ValueError('Usa un teléfono internacional con + y código de país.')
    return 'whatsapp:' + number


def send_sandbox_message(phone, message):
    if not settings.TWILIO_WHATSAPP_SANDBOX:
        raise RuntimeError('Este adaptador requiere el modo Sandbox de demostración.')
    sid = settings.TWILIO_ACCOUNT_SID.strip()
    token = settings.TWILIO_AUTH_TOKEN.strip()
    if not re.fullmatch(r'AC[0-9a-fA-F]{32}', sid) or not token:
        raise RuntimeError('Configura Account SID y Auth Token de Twilio.')
    destination = whatsapp_address(phone)
    if destination != whatsapp_address(settings.TWILIO_WHATSAPP_TEST_TO):
        raise RuntimeError('El Sandbox está limitado al teléfono de prueba configurado.')
    sender = whatsapp_address(settings.TWILIO_WHATSAPP_FROM)
    body = urlencode({'From': sender, 'To': destination, 'Body': message})
    authorization = base64.b64encode(f'{sid}:{token}'.encode()).decode()
    connection = HTTPSConnection('api.twilio.com', timeout=10)
    try:
        connection.request('POST', f'/2010-04-01/Accounts/{sid}/Messages.json', body=body,
                           headers={'Authorization': f'Basic {authorization}', 'Content-Type': 'application/x-www-form-urlencoded'})
        response = connection.getresponse()
        payload = json.loads(response.read(65536))
        if not 200 <= response.status < 300 or payload.get('status') in {'failed', 'undelivered'} or not payload.get('sid'):
            code = payload.get('code') or payload.get('error_code')
            # No registrar texto, destinatarios, credenciales ni la respuesta completa.
            safe_code = str(code) if isinstance(code, int) else 'no disponible'
            raise RuntimeError(f'Twilio rechazó el envío (HTTP {response.status}, código {safe_code}).')
        return True  # Aceptado por Twilio; no confirma lectura o entrega final.
    finally:
        connection.close()
