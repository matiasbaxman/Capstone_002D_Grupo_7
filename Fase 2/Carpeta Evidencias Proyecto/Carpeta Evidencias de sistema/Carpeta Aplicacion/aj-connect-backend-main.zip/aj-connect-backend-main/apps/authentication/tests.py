from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.test import APIClient

from .models import Role


class UserAndTokenTests(TestCase):
    def setUp(self):
        self.api = APIClient()
        self.admin = User.objects.create_superuser('auth-admin', 'admin@example.test', 'test-only')

    def test_login_entrega_roles_y_ultimo_acceso(self):
        respuesta = self.api.post(
            '/api/auth/login/',
            {'username': 'auth-admin', 'password': 'test-only'},
            format='json',
        )
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn('Administrador', respuesta.data['roles'])
        self.assertEqual(respuesta.data['role'], 'Administrador')
        self.assertTrue(respuesta.data['is_superuser'])
        self.assertEqual(respuesta.data['roles_detail'][-1]['code'], 'ADMIN')
        self.assertIsNotNone(User.objects.get(username='auth-admin').last_login)

    def test_jwt_autentica_personal_y_aplica_permisos_por_rol(self):
        mecanico_role = Role.objects.get_or_create(code='MECANICO', defaults={'name': 'Mecánico'})[0]
        mechanic = User.objects.create_user('auth-mechanic', password='test-only')
        mechanic.user_roles.create(role=mecanico_role)

        # Las rutas privadas rechazan la ausencia de token y el rol limitado.
        self.assertEqual(self.api.get('/api/auth/users/').status_code, 401)
        login = self.api.post(
            '/api/auth/login/',
            {'username': 'auth-mechanic', 'password': 'test-only'},
            format='json',
        )
        self.assertEqual(login.status_code, 200, login.data)
        self.assertTrue(login.data.get('access'))
        self.assertTrue(login.data.get('refresh'))
        self.assertIn('Mecánico', login.data['roles'])

        self.api.credentials(HTTP_AUTHORIZATION=f"Bearer {login.data['access']}")
        self.assertEqual(self.api.get('/api/auth/users/').status_code, 403)
        self.assertEqual(self.api.get('/api/workshop/work-orders/').status_code, 200)

        refreshed = self.api.post('/api/auth/refresh/', {'refresh': login.data['refresh']}, format='json')
        self.assertEqual(refreshed.status_code, 200, refreshed.data)
        self.assertTrue(refreshed.data.get('access'))
        self.assertNotEqual(refreshed.data['access'], login.data['access'])

    def test_listado_expone_rol_de_superusuario(self):
        self.api.force_authenticate(self.admin)
        respuesta = self.api.get('/api/auth/users/')
        self.assertEqual(respuesta.status_code, 200)
        entry = next(item for item in respuesta.data if item['username'] == 'auth-admin')
        self.assertIn('Administrador', entry['roles'])
        self.assertEqual(entry['full_name'], 'auth-admin')
        self.assertEqual(entry['roles_detail'][-1]['code'], 'ADMIN')

    def test_crear_usuario_asigna_los_roles_del_payload(self):
        rol = Role.objects.get_or_create(code='MECANICO', defaults={'name': 'Mecánico'})[0]
        self.api.force_authenticate(self.admin)
        respuesta = self.api.post(
            '/api/auth/users/',
            {
                'username': 'nuevo-mecanico',
                'password': 'secret123',
                'first_name': 'Carla',
                'last_name': 'Muñoz',
                'roles': [str(rol.pk)],
            },
            format='json',
        )
        self.assertEqual(respuesta.status_code, 201)
        self.assertIn('Mecánico', respuesta.data['roles'])
        usuario = User.objects.get(username='nuevo-mecanico')
        self.assertTrue(usuario.check_password('secret123'))
        self.assertTrue(usuario.user_roles.filter(role=rol).exists())

    def test_editar_empleado_reemplaza_roles_y_conserva_la_contrasena_omitida(self):
        mecanico = Role.objects.get_or_create(code='MECANICO', defaults={'name': 'Mecánico'})[0]
        recepcionista = Role.objects.get_or_create(code='RECEPCIONISTA', defaults={'name': 'Recepcionista'})[0]
        usuario = User.objects.create_user('empleado', email='empleado@example.test', password='test-only')
        usuario.user_roles.create(role=mecanico)
        self.api.force_authenticate(self.admin)
        url = f'/api/auth/users/{usuario.pk}/'

        response = self.api.patch(url, {
            'username': usuario.username, 'email': usuario.email, 'first_name': 'Carla',
            'rut': '12.345.678-5', 'roles': [recepcionista.pk],
        }, format='json')
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data['first_name'], 'Carla')
        self.assertEqual(response.data['rut'], '12.345.678-5')
        self.assertNotIn('password', response.data)
        response = self.api.patch(url, {'is_active': False}, format='json')
        self.assertEqual(response.status_code, 200, response.data)

        usuario.refresh_from_db()
        self.assertFalse(usuario.is_active)
        self.assertTrue(usuario.check_password('test-only'))
        self.assertFalse(usuario.user_roles.filter(role=mecanico).exists())
        self.assertTrue(usuario.user_roles.filter(role=recepcionista).exists())

    def test_editar_empleado_protege_las_cuentas_y_el_acceso_propio(self):
        administrator = User.objects.create_user('role-admin')
        admin_role = Role.objects.get(code='ADMIN')
        administrator.user_roles.create(role=admin_role)
        mechanic = User.objects.create_user('role-mechanic')
        mechanic.user_roles.create(role=Role.objects.get(code='MECANICO'))
        self.api.force_authenticate(mechanic)
        self.assertEqual(self.api.patch(f'/api/auth/users/{mechanic.pk}/', {}, format='json').status_code, 403)

        self.api.force_authenticate(administrator)
        self.assertEqual(self.api.patch(f'/api/auth/users/{self.admin.pk}/', {}, format='json').status_code, 403)
        own_url = f'/api/auth/users/{administrator.pk}/'
        self.assertEqual(self.api.patch(own_url, {'is_active': False}, format='json').status_code, 400)
        self.assertEqual(self.api.patch(own_url, {'roles': []}, format='json').status_code, 400)
        administrator.refresh_from_db()
        self.assertTrue(administrator.is_active)
        self.assertTrue(administrator.user_roles.filter(role=admin_role).exists())

    def test_usuario_duplicado_devuelve_400(self):
        User.objects.create_user('repetido', password='test-only')
        self.api.force_authenticate(self.admin)
        respuesta = self.api.post(
            '/api/auth/users/',
            {'username': 'repetido', 'password': 'secret123'},
            format='json',
        )
        self.assertEqual(respuesta.status_code, 400)
        self.assertIn('username', respuesta.data)
        self.assertEqual(User.objects.count(), 2)
