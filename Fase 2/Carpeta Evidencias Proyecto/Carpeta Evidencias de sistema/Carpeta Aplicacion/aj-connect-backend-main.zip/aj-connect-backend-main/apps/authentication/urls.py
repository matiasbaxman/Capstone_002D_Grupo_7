from apps.workshop.appointment_views import ClientAppointmentCreateView
from apps.workshop.client_profile_views import ClientProfileView, ClientProfileConfirmView
from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from apps.workshop.client_auth_views import ClientOTPRequestView, ClientOTPVerifyView, ClientSessionView
from .views import (
    CustomTokenObtainPairView,
    UserListCreateView,
    UserUpdateView,
    RoleListView,
)

app_name = 'authentication'

urlpatterns = [
    path('client-appointments/', ClientAppointmentCreateView.as_view()),
    path('client-profile/request/', ClientProfileView.as_view()),
    path('client-profile/confirm/', ClientProfileConfirmView.as_view()),
    path('client-session/', ClientSessionView.as_view(), name='client_session'),
    path('client-login/', ClientOTPRequestView.as_view(), name='client_login'),
    path('client-otp/', ClientOTPVerifyView.as_view(), name='client_otp'),
    path('login/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('users/', UserListCreateView.as_view(), name='user_list_create'),
    path('users/<int:pk>/', UserUpdateView.as_view(), name='user_update'),
    path('roles/', RoleListView.as_view(), name='role_list'),
]
