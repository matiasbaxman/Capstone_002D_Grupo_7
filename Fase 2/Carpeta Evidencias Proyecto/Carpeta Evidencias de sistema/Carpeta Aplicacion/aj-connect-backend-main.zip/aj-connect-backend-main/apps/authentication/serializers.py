from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth.models import User
from django.db import transaction
from .models import Role, UserRole, UserProfile
from .permissions import ROLE_ADMIN, normalize_role, user_role_names


def effective_roles(user):
    """
    Nombres y códigos de rol del usuario.

    El superusuario siempre se complementa con el rol Administrador/ADMIN,
    aunque no tenga una fila en `user_roles`.
    """
    roles = user_role_names(user)
    codes = list(user.user_roles.values_list('role__code', flat=True)) if hasattr(user, 'user_roles') else []
    if getattr(user, 'is_superuser', False) and not any(normalize_role(r) == ROLE_ADMIN for r in roles):
        roles = [*roles, 'Administrador']
        codes = [*codes, 'ADMIN']
    return roles, codes


def effective_roles_detail(user):
    """Detalle de los roles del usuario (incluye el rol sintético de superusuario)."""
    details = [
        {'id': ur.role.id, 'code': ur.role.code, 'name': ur.role.name}
        for ur in (user.user_roles.all() if hasattr(user, 'user_roles') else [])
    ]
    if getattr(user, 'is_superuser', False) and not any(normalize_role(d['name']) == ROLE_ADMIN for d in details):
        details.append({'id': None, 'code': 'ADMIN', 'name': 'Administrador'})
    return details


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'code', 'name', 'description', 'created_at']


class UserListSerializer(serializers.ModelSerializer):
    rut = serializers.CharField(source='profile.rut', read_only=True, default='')
    phone = serializers.CharField(source='profile.phone', read_only=True, default='')
    roles = serializers.SerializerMethodField()
    roles_detail = serializers.SerializerMethodField()
    full_name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'first_name',
            'last_name',
            'full_name',
            'email',
            'rut',
            'phone',
            'roles',
            'roles_detail',
            'is_active',
            'is_superuser',
            'last_login',
            'date_joined',
        ]

    def get_full_name(self, obj):
        name = f"{obj.first_name} {obj.last_name}".strip()
        return name if name else obj.username

    def get_roles(self, obj):
        # Nombres reales del rol, tal como están guardados en la base de datos.
        roles, _ = effective_roles(obj)
        return roles

    def get_roles_detail(self, obj):
        return effective_roles_detail(obj)


class UserCreateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, min_length=6)
    rut = serializers.CharField(required=False, allow_blank=True, default='')
    phone = serializers.CharField(required=False, allow_blank=True, default='')
    roles = serializers.ListField(
        child=serializers.CharField(),
        required=False,
        default=list
    )

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'first_name',
            'last_name',
            'email',
            'password',
            'rut',
            'phone',
            'roles',
        ]

    def validate_username(self, value):
        matches = User.objects.filter(username__iexact=value)
        if self.instance:
            matches = matches.exclude(pk=self.instance.pk)
        if matches.exists():
            raise serializers.ValidationError("Este nombre de usuario ya está registrado.")
        return value

    def validate_email(self, value):
        matches = User.objects.filter(email__iexact=value)
        if self.instance:
            matches = matches.exclude(pk=self.instance.pk)
        if value and matches.exists():
            raise serializers.ValidationError("Este correo electrónico ya está registrado.")
        return value

    def validate_rut(self, value):
        val = value.strip() if value else ''
        matches = UserProfile.objects.filter(rut=val)
        if self.instance:
            matches = matches.exclude(user=self.instance)
        if val and matches.exists():
            raise serializers.ValidationError("Ya existe un usuario con este RUT.")
        return val

    def _get_role_items(self):
        """Roles enviados en el payload: admite `roles`, `role_ids` o `role`."""
        for container in (getattr(self, 'initial_data', None), getattr(self, 'validated_data', {})):
            if not container:
                continue
            role_items = container.get('roles') or container.get('role_ids') or container.get('role') or []
            if role_items:
                return role_items if isinstance(role_items, (list, tuple)) else [role_items]
        return []

    @staticmethod
    def _sync_roles(user, role_items):
        """Reemplaza los roles del usuario por los enviados en el payload."""
        roles_list = []
        for item in role_items:
            if item is None:
                continue
            if isinstance(item, int) or (isinstance(item, str) and str(item).strip().lstrip('-').isdigit()):
                role = Role.objects.filter(id=int(item)).first()
            else:
                role = Role.objects.filter(code__iexact=str(item).strip()).first()
            if role:
                roles_list.append(role)
            else:
                raise serializers.ValidationError({'roles': 'Selecciona roles válidos del catálogo.'})
        UserRole.objects.filter(user=user).delete()
        if roles_list:
            UserRole.objects.bulk_create([UserRole(user=user, role=r) for r in dict.fromkeys(roles_list)])

    @transaction.atomic
    def create(self, validated_data):
        rut = validated_data.pop('rut', '').strip() or None
        phone = validated_data.pop('phone', '').strip() or None
        password = validated_data.pop('password')

        role_items = self._get_role_items()

        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=password,
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
        )

        UserProfile.objects.create(
            user=user,
            rut=rut,
            phone=phone,
        )

        self._sync_roles(user, role_items)

        return user

    @transaction.atomic
    def update(self, instance, validated_data):
        role_items = self._get_role_items()
        if 'password' in validated_data:
            password = validated_data.pop('password')
            if password:
                instance.set_password(password)

        for attr in ['username', 'email', 'first_name', 'last_name', 'is_active']:
            if attr in validated_data:
                setattr(instance, attr, validated_data[attr])

        instance.save()

        if 'rut' in validated_data or 'phone' in validated_data:
            profile, _ = UserProfile.objects.get_or_create(user=instance)
            if 'rut' in validated_data:
                profile.rut = validated_data.get('rut', '').strip() or None
            if 'phone' in validated_data:
                profile.phone = validated_data.get('phone', '').strip() or None
            profile.save()

        if any(key in self.initial_data for key in ('roles', 'role_ids', 'role')):
            self._sync_roles(instance, role_items)

        return instance

    def to_representation(self, instance):
        return UserListSerializer(instance, context=self.context).data


class UserUpdateSerializer(UserCreateSerializer):
    class Meta(UserCreateSerializer.Meta):
        fields = [*UserCreateSerializer.Meta.fields, 'is_active']


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Inyectar atributos útiles en el payload del JWT
        token['username'] = user.username
        token['email'] = user.email

        roles, codes = effective_roles(user)
        token['roles'] = roles
        token['role_codes'] = codes
        token['is_superuser'] = bool(getattr(user, 'is_superuser', False))

        # Mantener retrocompatibilidad para clientes que leen claim 'role' singular
        if roles:
            token['role'] = roles[0]
        if codes:
            token['role_code'] = codes[0]

        return token

    def validate(self, attrs):
        # `super().validate()` autentica y, con UPDATE_LAST_LOGIN activo,
        # ya deja registrado el último acceso del usuario.
        data = super().validate(attrs)

        roles, codes = effective_roles(self.user)
        data['roles'] = roles
        data['roles_detail'] = effective_roles_detail(self.user)
        data['role_codes'] = codes
        data['is_superuser'] = bool(getattr(self.user, 'is_superuser', False))
        if roles:
            data['role'] = roles[0]
        data['username'] = self.user.username
        data['email'] = self.user.email

        return data
