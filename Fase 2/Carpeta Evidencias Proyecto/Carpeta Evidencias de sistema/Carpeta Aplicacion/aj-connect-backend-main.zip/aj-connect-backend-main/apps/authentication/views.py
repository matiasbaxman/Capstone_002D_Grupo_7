from rest_framework import generics, permissions
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth.models import User
from django.db import transaction
from .models import Role
from .serializers import (
    CustomTokenObtainPairSerializer,
    RoleSerializer,
    UserCreateSerializer,
    UserListSerializer,
    UserUpdateSerializer,
)
from .permissions import IsAdminRole, is_admin


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class UserListCreateView(generics.ListCreateAPIView):
    """
    GET /api/auth/users/ : Retorna el listado de empleados registrados con sus perfiles y roles.
    POST /api/auth/users/ : Registra un nuevo empleado con transacción atómica.
    """
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]

    def get_queryset(self):
        return (
            User.objects.select_related('profile')
            .prefetch_related('user_roles__role')
            .all()
            .order_by('-date_joined')
        )

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserCreateSerializer
        return UserListSerializer


class UserUpdateView(generics.UpdateAPIView):
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]
    serializer_class = UserUpdateSerializer
    queryset = User.objects.select_for_update()
    http_method_names = ['patch', 'options']

    @transaction.atomic
    def patch(self, request, *args, **kwargs):
        return super().patch(request, *args, **kwargs)

    def get_object(self):
        employee = super().get_object()
        if employee.is_superuser and not self.request.user.is_superuser:
            raise PermissionDenied('Solo un superusuario puede editar esta cuenta.')
        return employee

    def perform_update(self, serializer):
        employee = serializer.save()
        if employee.pk == self.request.user.pk:
            if not employee.is_active:
                raise ValidationError({'is_active': 'No puedes desactivar tu propia cuenta.'})
            if not is_admin(employee):
                raise ValidationError({'roles': 'No puedes quitar el rol de administrador de tu propia cuenta.'})


class RoleListView(generics.ListAPIView):
    """
    GET /api/auth/roles/ : Retorna el catálogo de roles disponibles.
    """
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]
    queryset = Role.objects.all().order_by('name')
    serializer_class = RoleSerializer
