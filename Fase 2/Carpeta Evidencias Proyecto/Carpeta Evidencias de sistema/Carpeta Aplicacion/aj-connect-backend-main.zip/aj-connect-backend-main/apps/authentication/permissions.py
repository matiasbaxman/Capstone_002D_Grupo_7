from rest_framework.permissions import BasePermission


def normalize_role(value):
    """Compara nombres de rol sin distinguir mayúsculas, minúsculas ni tildes."""
    import unicodedata

    text = str(value or '')
    text = ''.join(
        char for char in unicodedata.normalize('NFD', text) if unicodedata.category(char) != 'Mn'
    )
    return text.strip().upper()

# Los nombres canónicos de rol. La comparación en la base de datos siempre es
# `__iexact` para que funcione igual en SQLite local y en PostgreSQL (Neon),
# sin importar acentos, mayúsculas ni minúsculas.
ROLE_ADMIN = 'administrador'
ROLE_MECANICO = 'mecanico'
ROLE_RECEPCIONISTA = 'recepcionista'


def _has_role(user, role_name):
    """True si el usuario tiene un rol con ese nombre (insensible a formato)."""
    if not user or not user.is_authenticated:
        return False
    if not hasattr(user, 'user_roles'):
        return False
    return any(normalize_role(name) == normalize_role(role_name) for name in user.user_roles.values_list('role__name', flat=True))


def is_admin(user):
    return bool(getattr(user, 'is_superuser', False)) or _has_role(user, ROLE_ADMIN)


def is_mecanico(user):
    return _has_role(user, ROLE_MECANICO)


def is_recepcionista(user):
    return _has_role(user, ROLE_RECEPCIONISTA)


def user_role_names(user):
    """Nombres de rol del usuario, para respuestas del serializer."""
    if not user or not user.is_authenticated or not hasattr(user, 'user_roles'):
        return []
    return list(user.user_roles.values_list('role__name', flat=True))


class IsAdminRole(BasePermission):
    """
    Acceso total solo para superusuarios o usuarios con rol Administrador.
    Usado por los endpoints que no existían antes de la matriz de permisos.
    """
    message = 'Acceso restringido. Se requiere rol de Administrador.'

    def has_permission(self, request, view):
        return is_admin(request.user)
