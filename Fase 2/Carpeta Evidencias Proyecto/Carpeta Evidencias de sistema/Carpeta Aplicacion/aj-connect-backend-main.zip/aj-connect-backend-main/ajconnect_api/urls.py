from django.contrib import admin
from django.urls import path, include
from apps.workshop.appointment_views import PublicServiceListView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/', include('apps.authentication.urls')),
    path('api/assistant/', include('apps.assistant.urls')),
    path('api/workshop/', include('apps.workshop.urls')),
    path('api/tracking/', include('apps.workshop.tracking_urls')),
    path('api/appointments/', include('apps.workshop.appointment_urls')),
    path('api/services/', PublicServiceListView.as_view(), name='public-services'),
    path('api/inventory/', include('apps.inventory.urls')),
]

if settings.DEBUG and settings.MEDIA_ROOT:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
