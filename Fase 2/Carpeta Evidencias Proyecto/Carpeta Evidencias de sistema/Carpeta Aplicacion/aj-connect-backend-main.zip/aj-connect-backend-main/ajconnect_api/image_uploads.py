import logging
from pathlib import Path

import cloudinary
from cloudinary import uploader
from cloudinary.exceptions import Error as CloudinaryError
from rest_framework.exceptions import APIException


logger = logging.getLogger(__name__)


class ImageUploadError(APIException):
    status_code = 503
    default_detail = 'No se pudo subir la imagen. Intenta nuevamente.'
    default_code = 'image_upload_unavailable'


def upload_image(file, *, folder, public_id=None):
    config = cloudinary.config()
    if not (config.cloud_name and config.api_key and config.api_secret):
        logger.error('Faltan credenciales de Cloudinary para la subida de imágenes.')
        raise ImageUploadError('El almacenamiento de imágenes no está configurado.')

    try:
        file.seek(0)
        result = uploader.upload(
            file,
            resource_type='image',
            folder=folder,
            public_id=public_id,
            filename=f'image{Path(file.name).suffix.lower()}',
            overwrite=False,
            timeout=20,
            transformation=[
                {'quality': 'auto', 'fetch_format': 'auto'},
                {'width': 1920, 'crop': 'limit'},
            ],
        )
        url, identifier = result['secure_url'], result['public_id']
        if not isinstance(url, str) or not url.startswith('https://') or len(url) > 500 or not identifier:
            raise ValueError('La respuesta no contiene una referencia de imagen válida.')
    except (CloudinaryError, OSError, KeyError, TypeError, ValueError) as exc:
        logger.error('Falló la subida de una imagen a Cloudinary (%s).', type(exc).__name__)
        raise ImageUploadError() from exc
    return {'url': url, 'public_id': identifier}
