"""Solo para pruebas CI con PostgreSQL desechable, nunca el DATABASE_URL real."""
import os
import dj_database_url
from .settings_local import *  # noqa: F403

if os.getenv('CI_DATABASE_URL'):
    DATABASES = {'default': dj_database_url.parse(os.environ['CI_DATABASE_URL'], conn_max_age=0)}

# Las suites generales cubren ambos canales; las de política activan el modo correo.
CLIENT_EMAIL_REQUIRED = False
