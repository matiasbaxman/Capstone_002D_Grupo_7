# A&J Connect — Backend API

API Django + Django REST Framework para A&J Automotriz. Incluye autenticación
del personal, inventario, clientes, vehículos, citas, recepción y órdenes de
trabajo. También contiene autenticación OTP de clientes, seguimiento público,
cotizaciones PDF y notificaciones, integradas al frontend. Consulta
[las correcciones del Sprint](docs/sprint-correcciones.md) para migraciones,
verificación de reservas y el worker de correo.

## Desarrollo con Docker

Requisitos: Docker Desktop con el motor Linux iniciado y Docker Compose 2.24 o
superior. Ambos repositorios deben estar como carpetas hermanas:

```text
ajconnect/
├── aj-connect-backend/
└── aj-connect-frontend/
```

Desde este repositorio:

```powershell
docker compose -f compose.dev.yaml up --build -d
docker compose -f compose.dev.yaml exec backend python manage.py createsuperuser
docker compose -f compose.dev.yaml logs -f
```

El primer arranque descarga imágenes e instala dependencias. El backend aplica
migraciones antes de servir; el frontend espera a que esté disponible.

- Sitio: http://127.0.0.1:5173
- Panel del taller: http://127.0.0.1:5173/dashboard
- Administrador Django: http://127.0.0.1:8000/admin/
- API: `http://127.0.0.1:8000/api/...` (no hay una vista índice global).

Inicia sesión con el superusuario. Carga servicios activos desde el administrador
Django para probar reservas. Las migraciones crean los catálogos de roles,
canales y estados; no crean empleados ni datos de demostración.

### Datos, edición y servicios externos

El código se monta desde Windows y ambos servidores recargan los cambios.
SQLite se guarda en el volumen `backend_data`, separado de tu `db.sqlite3`
local. Las dependencias Node se guardan en `frontend_modules`.

```powershell
# Detener y eliminar contenedores conservando los datos:
docker compose -f compose.dev.yaml down

# Revisar el estado:
docker compose -f compose.dev.yaml ps

# Después de cambios de dependencias o Dockerfile:
docker compose -f compose.dev.yaml up --build -d
```

`down -v` elimina también la base de datos de desarrollo y el volumen Node.
Si creas migraciones Python, reinicia el backend para aplicarlas:
`docker compose -f compose.dev.yaml restart backend`.

El archivo `.env` es opcional. Para subir fotos, créalo sin sobrescribir uno
existente y completa las tres credenciales de Cloudinary:

```powershell
Copy-Item .env.example .env
```

Las fotos sí se suben a Cloudinary real. En Docker los correos se imprimen en
los logs y los OTP utilizan simulación local. Este montaje usa SQLite aunque
exista un `DATABASE_URL` remoto en `.env`. Los puertos se publican únicamente
en `127.0.0.1`. Es un entorno de desarrollo, con DEBUG y clave local pública.

### Comprobaciones en Docker

```powershell
docker compose -f compose.dev.yaml exec backend python manage.py check
docker compose -f compose.dev.yaml exec backend python manage.py makemigrations --check --dry-run
docker compose -f compose.dev.yaml exec backend python manage.py test apps.authentication apps.inventory apps.workshop
docker compose -f compose.dev.yaml exec frontend npm run lint
docker compose -f compose.dev.yaml exec frontend npm run build
docker compose -f compose.dev.yaml exec frontend node scripts/test-session.mjs
docker compose -f compose.dev.yaml exec frontend node scripts/test-workshop.mjs
```

## Desarrollo sin Docker en Windows

Para probar desde el teléfono en la misma red, consulta
[Acceso local desde celular](docs/acceso-desde-celular.md).

El contenedor utiliza Python 3.13. Para trabajar directamente en Windows:

```powershell
python -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe manage.py migrate --settings=ajconnect_api.settings_local
.\venv\Scripts\python.exe manage.py createsuperuser --settings=ajconnect_api.settings_local
powershell -ExecutionPolicy Bypass -File .\start-local.ps1
```

`settings_local` usa `db.sqlite3`, OTP simulado y Cloudinary real si hay fotos.
A diferencia de `settings_docker`, conserva el backend SMTP de la configuración
principal. El frontend se levanta en otra terminal siguiendo su README.

## Organización y permisos

| Carpeta | Responsabilidad |
| --- | --- |
| `ajconnect_api/` | Configuración, URLs, WSGI y ASGI |
| `apps/authentication/` | Personal, perfiles, roles y JWT |
| `apps/inventory/` | Categorías, insumos y existencias |
| `apps/workshop/` | Clientes, vehículos, servicios, citas, OT, fotos y PDF |
| `docs/` | Contratos y plan de revisión |

Administración gestiona personal; administración y recepción modifican
inventario y citas. Mecánicos consultan inventario y, junto con administración,
acceden a recepción y órdenes. Los clientes usan una entidad y JWT separados.

## Producción y PR

La configuración principal utiliza PostgreSQL mediante `DATABASE_URL`;
configura también `SECRET_KEY`, `ALLOWED_HOSTS`, `CORS_ALLOWED_ORIGINS` y los
servicios externos correspondientes. Usa un servidor WSGI de producción;
`runserver` y `settings_docker` son exclusivos de desarrollo.

Consulta [docs/pulido-y-pr.md](docs/pulido-y-pr.md) para el alcance y las
comprobaciones previas al PR. Las funciones OTP están documentadas en
[docs/autenticacion-clientes.md](docs/autenticacion-clientes.md).
