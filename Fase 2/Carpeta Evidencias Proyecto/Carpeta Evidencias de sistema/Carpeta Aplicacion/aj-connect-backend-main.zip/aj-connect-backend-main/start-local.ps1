$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
$notificationWorker = $null
try {
    & .\venv\Scripts\python.exe manage.py migrate --settings=ajconnect_api.settings_local
    if ($LASTEXITCODE -ne 0) { throw 'No se pudieron aplicar las migraciones locales.' }
    $notificationWorker = Start-Process -FilePath "$PSScriptRoot\venv\Scripts\python.exe" -ArgumentList @('manage.py', 'process_notifications', '--reload', '--settings=ajconnect_api.settings_local') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru
    Write-Host 'Procesador de correos iniciado automáticamente.'
    & .\venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000 --settings=ajconnect_api.settings_local
} finally {
    if ($notificationWorker -and -not $notificationWorker.HasExited) {
        & taskkill.exe /PID $notificationWorker.Id /T /F | Out-Null
    }
    Pop-Location
}
