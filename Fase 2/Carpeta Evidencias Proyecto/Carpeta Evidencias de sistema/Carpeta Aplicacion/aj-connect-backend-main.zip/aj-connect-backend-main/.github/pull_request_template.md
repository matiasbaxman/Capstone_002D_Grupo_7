## Problema y resultado

Describe el problema concreto y el comportamiento resultante.

## Validación

- [ ] `python manage.py check --settings=ajconnect_api.settings_local`
- [ ] `python manage.py makemigrations --check --dry-run --settings=ajconnect_api.settings_local`
- [ ] `python manage.py test apps.authentication apps.inventory apps.workshop --settings=ajconnect_api.settings_local`
- [ ] Permisos, errores y contratos de API afectados revisados.

## Dependencias y límites

Enlaza el PR del frontend si corresponde e indica el orden de integración.
Documenta migraciones, variables nuevas y comprobaciones pendientes.
