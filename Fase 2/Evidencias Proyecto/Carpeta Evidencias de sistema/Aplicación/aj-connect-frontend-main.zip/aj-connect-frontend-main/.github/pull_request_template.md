## Problema y resultado

Describe el problema concreto y el comportamiento resultante.

## Validación

- [ ] `npm run lint`
- [ ] `npm run build`
- [ ] `node scripts/test-session.mjs`
- [ ] `node scripts/test-workshop.mjs`
- [ ] `node scripts/test-toasts.mjs` si cambian los avisos o sus temporizadores.
- [ ] Recorrido manual de las pantallas afectadas y sus permisos.

## Dependencias y límites

Enlaza el PR del backend si corresponde e indica el orden de integración.
Documenta comprobaciones pendientes, cambios visuales y riesgos relevantes.
