import { beforeEach, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import Tracking from '../pages/Tracking.jsx';
const transport = vi.hoisted(() => ({ get: vi.fn() }));
vi.mock('axios', () => ({ default: { create: () => transport, isCancel: () => false } }));
vi.mock('../api/axiosConfig.js', () => ({ BACKEND_URL: 'http://qa.test' }));
beforeEach(() => vi.resetAllMocks());
it('muestra cita, estados de orden, fotos e insumos en el mismo detalle', async () => {
  transport.get.mockResolvedValue({ data: { folio_number:1001,status:'Diagnóstico',status_history:[],appointment:{status:'ATENDIDA'},vehicle:{plate:'ABCD12'},photos:[],items:[] } });
  render(<Tracking token="AJ222222222222" attention={{id:'appointment:qa', status:'ATENDIDA', reported_symptoms:'Revisar frenos', work_order__folio_number:1001}} />);
  expect(await screen.findByRole('heading',{name:'Detalle de atención N.° 1001'})).toBeVisible();
  expect(await screen.findByText('Diagnóstico · Estado actual')).toBeVisible();
  expect(screen.getByText('Pendiente')).toBeVisible();
  expect(screen.getByText('Aceptada')).toBeVisible();
  expect(screen.getByRole('heading',{name:'Fotografías de ingreso'})).toBeVisible();
  expect(screen.getByRole('heading',{name:'Repuestos asociados'})).toBeVisible();
  expect(screen.queryByText('Ver avance, fotografías e insumos →')).not.toBeInTheDocument();
});
it('permite revisar la atención antes de que exista una orden', () => {
  render(<Tracking attention={{id:'appointment:12345678',status:'PENDIENTE',reported_symptoms:'Revisar frenos'}} />);
  expect(screen.getByRole('heading',{name:'Detalle de atención N.° 12345678'})).toBeVisible();
  expect(screen.getByText('Pendiente · Estado actual')).toBeVisible();
  expect(transport.get).not.toHaveBeenCalled();
});
