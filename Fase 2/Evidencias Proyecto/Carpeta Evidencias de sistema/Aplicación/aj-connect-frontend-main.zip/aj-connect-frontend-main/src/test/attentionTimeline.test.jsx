import { expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import AttentionTimeline from '../components/AttentionTimeline.jsx';
it('conecta cita y estados de OT marcando únicamente el avance alcanzado', () => {
  render(<AttentionTimeline appointment={{status:'ATENDIDA'}} order={{status:'En reparación',status_history:[]}} />);
  expect(screen.getByText('Pendiente')).toBeVisible();
  expect(screen.getByText('Aceptada')).toBeVisible();
  expect(screen.getByText('Recepcionado')).toBeVisible();
  expect(screen.getByText('En reparación · Estado actual').closest('li')).toHaveAttribute('aria-current','step');
  expect(screen.getByText('Entregado').closest('li')).toHaveClass('attention-step-pending');
});
it('una atención pendiente no muestra aceptación ni recepción completadas', () => {
  render(<AttentionTimeline appointment={{status:'PENDIENTE'}} />);
  expect(screen.getByText('Pendiente · Estado actual')).toBeVisible();
  expect(screen.getByText('Aceptada').closest('li')).toHaveClass('attention-step-pending');
});
it('un ingreso sin cita empieza directamente en recepción', () => {
  render(<AttentionTimeline order={{status:'Recepcionado',status_history:[]}} />);
  expect(screen.queryByText('Aceptada')).not.toBeInTheDocument();
  expect(screen.getByText('Recepcionado · Estado actual')).toBeVisible();
});
