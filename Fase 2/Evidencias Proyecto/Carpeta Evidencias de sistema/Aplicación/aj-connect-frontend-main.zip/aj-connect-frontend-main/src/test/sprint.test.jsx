import { beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ToastProvider from '../components/notifications/ToastProvider.jsx';
import BookingPage from '../pages/BookingPage.jsx';
import Tracking from '../pages/Tracking.jsx';
import AppointmentsAdmin from '../pages/AppointmentsAdmin.jsx';
import QuotePanel from '../components/QuotePanel.jsx';
import * as appointments from '../api/appointments.js';
import * as workshop from '../api/workshop.js';
import axios from 'axios';

vi.mock('../api/appointments.js', () => ({ getPublicServices: vi.fn(), getAppointmentAvailability: vi.fn(), requestBookingVerification: vi.fn(), createPublicAppointment: vi.fn(), listAppointments: vi.fn(), updateAppointment: vi.fn() }));
vi.mock('../api/workshop.js', () => ({ listQuotes: vi.fn(), createQuote: vi.fn(), getQuotePdf: vi.fn(), getWorkOrderPdf: vi.fn(), emailQuote: vi.fn(), getEmailDelivery: vi.fn() }));
vi.mock('../api/axiosConfig.js', () => ({ BACKEND_URL: 'http://qa.test', default: {} }));
vi.mock('axios', () => ({ default: { create: () => ({ get: (...args) => publicGet(...args) }), isCancel: () => false } }));
const publicGet = vi.hoisted(() => vi.fn());
const slot = { start: '2030-01-07T10:00:00-03:00', end: '2030-01-07T11:00:00-03:00', remaining_capacity: 2 };
const quote = { id: '12345678-1234-4567-8123-123456789012', created_at: '2030-01-07T10:00:00Z', subtotal_amount: '20000', tax_rate: '19', tax_amount: '3800', total_amount: '23800' };
beforeEach(() => { vi.clearAllMocks(); appointments.getPublicServices.mockResolvedValue([]); appointments.getAppointmentAvailability.mockResolvedValue({ slots: [slot] }); workshop.listQuotes.mockResolvedValue([]); });

describe('Sprint: recorridos React', () => {
  it('reserva por pasos, verifica contacto y muestra una confirmación legible', async () => {
    const user = userEvent.setup();
    appointments.requestBookingVerification.mockResolvedValue({ verification_id: 'verification-qa', detail: 'Código enviado al contacto registrado.' });
    appointments.createPublicAppointment.mockResolvedValue({ id: 'booking-qa', status: 'PENDIENTE' });
    render(<BookingPage />);
    await user.click(await screen.findByRole('button', { name: /Evaluación general/ }));
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    await user.type(screen.getByLabelText('Fecha'), '2030-01-07');
    await user.click(await screen.findByRole('button', { name: /10:00/ }));
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    await user.type(screen.getByLabelText('RUT'), '123456785');
    await user.type(screen.getByLabelText('Correo electrónico (obligatorio)'), 'ana@example.test');
    await user.type(screen.getByLabelText('Nombre'), 'Ana');
    await user.type(screen.getByLabelText('Apellido'), 'Perez');
    await user.type(screen.getByLabelText('¿Qué problema o servicio requiere tu vehículo?'), 'Ruido al frenar');
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    await user.click(screen.getByRole('button', { name: /Enviar código de verificación/ }));
    expect(appointments.createPublicAppointment).not.toHaveBeenCalled();
    await user.type(await screen.findByLabelText('Código de seis dígitos'), '012345');
    await user.click(screen.getByRole('button', { name: 'Confirmar agendamiento' }));
    expect(await screen.findByText('¡Gracias, Ana!')).toBeVisible();
    expect(appointments.createPublicAppointment).toHaveBeenCalledWith(expect.objectContaining({ verification_id: 'verification-qa', code: '012345', scheduled_date: slot.start, notification_channel: 'EMAIL', email: 'ana@example.test' }));
    expect(screen.getByRole('link', { name: 'Volver al inicio' })).toHaveClass('booking-home-button');
  });

  it('presenta acciones claras cuando el código de tracking no existe', async () => {
    publicGet.mockRejectedValue({ response: { status: 404 } });
    render(<Tracking token="AJ222222222222" />);
    expect(await screen.findByRole('heading', { name: 'No pudimos consultar tu orden' })).toBeVisible();
    expect(screen.getByRole('button', { name: 'Intentar de nuevo' })).toBeVisible();
    expect(screen.getByRole('link', { name: 'Ingresar otro código' })).toHaveAttribute('href', '/seguimiento');
    expect(axios.isCancel({})).toBe(false);
  });

  it('rechaza citas desde administración y valida una fecha vacía sin lanzar excepción', async () => {
    const user = userEvent.setup();
    const row = { id: 'booking-qa', status: 'PENDIENTE', scheduled_date: slot.start, client: { first_name: 'Ana' } };
    appointments.listAppointments.mockResolvedValue([row]);
    appointments.updateAppointment.mockResolvedValue({ ...row, status: 'RECHAZADA' });
    render(<ToastProvider><AppointmentsAdmin /></ToastProvider>);
    await user.click(await screen.findByRole('button', { name: 'Reprogramar' }));
    const dateInput = screen.getByLabelText('Nueva fecha y hora');
    await user.clear(dateInput);
    await user.click(screen.getByRole('button', { name: 'Guardar horario' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Selecciona una fecha y hora válida.');
    expect(appointments.updateAppointment).not.toHaveBeenCalled();
    await user.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Cancelar' }));
    await user.click(screen.getByRole('button', { name: 'Rechazar' }));
    appointments.listAppointments.mockResolvedValue([{ ...row, status: 'RECHAZADA' }]);
    await user.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Rechazar cita' }));
    await waitFor(() => expect(appointments.updateAppointment).toHaveBeenCalledWith('booking-qa', { status: 'RECHAZADA' }));
    expect(await screen.findByText('Rechazada', { selector: 'span' })).toBeVisible();
  });

  it('genera una cotización, usa su endpoint PDF y libera el blob al cerrar', async () => {
    const user = userEvent.setup();
    workshop.createQuote.mockResolvedValue(quote);
    workshop.getQuotePdf.mockResolvedValue(new Blob(['%PDF-QA'], { type: 'application/pdf' }));
    render(<QuotePanel order={{ id: 'ot-qa', folio: 1001, parts: [{ id: 'part' }] }} />);
    await user.click(screen.getByRole('button', { name: 'Generar cotización' }));
    await user.click(await screen.findByRole('button', { name: 'Ver cotización PDF' }));
    expect(await screen.findByRole('link', { name: 'Descargar PDF' })).toHaveAttribute('download', 'Cotizacion_AJ_12345678.pdf');
    expect(workshop.getQuotePdf).toHaveBeenCalledWith(quote.id, expect.any(AbortSignal));
    expect(workshop.getWorkOrderPdf).not.toHaveBeenCalled();
    await user.click(screen.getByRole('button', { name: 'Cerrar vista previa' }));
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:qa-document');
  });
});
