import { beforeEach, expect, it, vi } from 'vitest';
import { act, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ClientPortal from '../pages/ClientPortal.jsx';
import * as auth from '../api/clientAuth.js';

vi.mock('../api/clientAuth.js', () => ({ clearClientSession: vi.fn(), getClientSession: () => null, requestClientCode: vi.fn(), verifyClientCode: vi.fn(), getClientAccount: vi.fn(), requestProfileChange: vi.fn(), confirmProfileChange: vi.fn() }));
beforeEach(() => vi.resetAllMocks());

it('formatea el RUT al escribir y no solicita código si la cuenta no existe', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockRejectedValue({ response: { status: 404, data: { detail: 'No encontramos una cuenta con este RUT.' } } });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '223456782');
  expect(screen.getByLabelText('RUT')).toHaveValue('22.345.678-2');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(await screen.findByRole('alert')).toHaveTextContent('No encontramos una cuenta');
  expect(auth.requestClientCode).toHaveBeenCalledWith('223456782', '');
  expect(screen.queryByLabelText('Código de seis dígitos')).not.toBeInTheDocument();
  expect(screen.getByRole('link', { name: 'Agendar una cita' })).toHaveAttribute('href', '/agendar');
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
});

it('normaliza el dígito K, limpia el desafío al cambiar el RUT y conserva el formato al pegar', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({});
  render(<ClientPortal />);
  await user.click(screen.getByLabelText('RUT'));
  await user.paste('21.865.259-k');
  expect(screen.getByLabelText('RUT')).toHaveValue('21.865.259-K');
  await user.clear(screen.getByLabelText('RUT'));
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(await screen.findByLabelText('Código de seis dígitos')).toBeVisible();
  await user.click(screen.getByRole('button', { name: 'Cerrar verificación' }));
  await user.clear(screen.getByLabelText('RUT'));
  expect(screen.queryByLabelText('Código de seis dígitos')).not.toBeInTheDocument();
});

it('completa el primer ingreso y limpia los datos del desafío al cerrar sesión', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({});
  auth.verifyClientCode.mockResolvedValueOnce({ access: 'client-access', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana' }, orders: [] });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  await user.type(await screen.findByLabelText('Código de seis dígitos'), '012345');
  expect(screen.getByRole('dialog')).toBeVisible();
  expect(screen.queryByLabelText('Crea tu contraseña de primer ingreso')).not.toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Continuar' }));
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  await user.type(await screen.findByLabelText('Crea tu contraseña de primer ingreso'), 'MotorSeguro!2026');
  await user.type(screen.getByLabelText('Confirma tu contraseña'), 'MotorSeguro!2026');
  await user.click(screen.getByRole('button', { name: 'Crear contraseña e ingresar' }));
  expect(await screen.findByText('Hola, Ana.')).toBeVisible();
  expect(auth.verifyClientCode).toHaveBeenLastCalledWith({ rut: '123456785', code: '012345', password: 'MotorSeguro!2026' });
  await user.click(screen.getByRole('button', { name: 'Cerrar sesión' }));
  expect(screen.queryByLabelText('Crea tu contraseña de primer ingreso')).not.toBeInTheDocument();
  expect(screen.getByRole('button', { name: 'Ingresar' })).toBeVisible();
});

it('entra con RUT y contraseña sin pedir un nuevo código', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({ access: 'client-access', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana' }, orders: [] });
  render(<ClientPortal />);
  expect(screen.getByLabelText('Contraseña')).toBeVisible();
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.type(screen.getByLabelText('Contraseña'), 'MotorSeguro!2026');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(await screen.findByText('Hola, Ana.')).toBeVisible();
  expect(auth.requestClientCode).toHaveBeenCalledWith('123456785', 'MotorSeguro!2026');
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
});

it('conserva la ventana al reenviar y vuelve al código si el servidor lo rechaza', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({});
  auth.verifyClientCode.mockRejectedValue({ response: { status: 400, data: { code: ['El código expiró.'] } } });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  await user.type(await screen.findByLabelText('Código de seis dígitos'), '012345');
  await user.click(screen.getByRole('button', { name: 'Solicitar otro código' }));
  expect(auth.requestClientCode).toHaveBeenCalledTimes(2);
  expect(screen.getByLabelText('Código de seis dígitos')).toHaveValue('');
  await user.type(screen.getByLabelText('Código de seis dígitos'), '123456');
  await user.click(screen.getByRole('button', { name: 'Continuar' }));
  await user.type(screen.getByLabelText('Crea tu contraseña de primer ingreso'), 'MotorSeguro!2026');
  await user.type(screen.getByLabelText('Confirma tu contraseña'), 'OtraClave!2026');
  await user.click(screen.getByRole('button', { name: 'Crear contraseña e ingresar' }));
  expect(screen.getByRole('alert')).toHaveTextContent('no coinciden');
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
  await user.clear(screen.getByLabelText('Confirma tu contraseña'));
  await user.type(screen.getByLabelText('Confirma tu contraseña'), 'MotorSeguro!2026');
  await user.click(screen.getByRole('button', { name: 'Crear contraseña e ingresar' }));
  expect(await screen.findByRole('dialog')).toHaveTextContent('El código expiró.');
  await user.keyboard('{Escape}');
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  expect(screen.getByRole('button', { name: 'Ingresar' })).toBeVisible();
});

it('muestra un mensaje recuperable en vez del HTML de un error del servidor', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockRejectedValue({ response: { status: 500, data: '<html>OperationalError database is locked</html>' } });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(await screen.findByRole('alert')).toHaveTextContent('No pudimos completar el ingreso');
  expect(screen.queryByText(/OperationalError/)).not.toBeInTheDocument();
});

it('separa los datos personales de las citas al cambiar de apartado', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({ access: 'client-access', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana', last_name: 'Perez', rut: '123456785', email: 'ana@example.test', phone: '' }, orders: [], appointments: [] });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(await screen.findByRole('heading', { name: 'Atenciones' })).toBeVisible();
  expect(screen.queryByRole('heading', { name: 'Datos personales' })).not.toBeInTheDocument();
  act(() => { window.location.hash = '#datos'; window.dispatchEvent(new Event('hashchange')); });
  expect(await screen.findByRole('heading', { name: 'Datos personales' })).toBeVisible();
  expect(screen.queryByRole('heading', { name: 'Atenciones' })).not.toBeInTheDocument();
  act(() => { window.location.hash = '#citas'; window.dispatchEvent(new Event('hashchange')); });
});
