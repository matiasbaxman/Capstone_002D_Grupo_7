import { beforeEach, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import BookingPage from '../pages/BookingPage.jsx';
import * as auth from '../api/clientAuth.js';
import * as api from '../api/appointments.js';
vi.mock('../api/clientAuth.js', () => ({ getClientSession: vi.fn(), getClientAccount: vi.fn() }));
vi.mock('../api/appointments.js', () => ({ createPublicAppointment: vi.fn(), getAppointmentAvailability: vi.fn(), getPublicServices: vi.fn(), requestBookingVerification: vi.fn() }));
beforeEach(() => {
  vi.resetAllMocks();
  auth.getClientSession.mockReturnValue({access:'client'});
  api.getPublicServices.mockResolvedValue([]);
  api.getAppointmentAvailability.mockResolvedValue({slots:[{ start:'2030-01-07T10:00:00-03:00', remaining_capacity:2 }]});
  api.requestBookingVerification.mockResolvedValue({verification_id:'verify'});
  api.createPublicAppointment.mockResolvedValue({id:'booking',status:'PENDIENTE'});
});
async function complete(appointments) {
  auth.getClientAccount.mockResolvedValue({client:{rut:'123456785',first_name:'Ana',last_name:'Perez',email:'ana@example.test',phone:''},appointments});
  const user = userEvent.setup();render(<BookingPage />);
  await user.click(await screen.findByRole('button',{name:/Evaluación general/}));
  await user.click(screen.getByRole('button',{name:/Continuar/}));
  await user.type(screen.getByLabelText('Fecha'),'2030-01-07');
  await user.click(await screen.findByRole('button',{name:/10:00/}));
  await user.click(screen.getByRole('button',{name:/Continuar/}));
  expect(screen.queryByLabelText('RUT')).not.toBeInTheDocument();
  expect(screen.getByText('Ana Perez')).toBeVisible();
  await user.type(screen.getByLabelText('¿Qué problema o servicio requiere tu vehículo?'),'Revisar frenos');
  await user.click(screen.getByRole('button',{name:/Continuar/}));
  return user;
}
it('usa datos de sesión y confirma una siguiente cita sin código',async () => {
  const user = await complete([{id:'previous'}]);
  await user.click(screen.getByRole('button',{name:'Confirmar agendamiento'}));
  expect(await screen.findByText('¡Gracias, Ana!')).toBeVisible();
  expect(api.requestBookingVerification).not.toHaveBeenCalled();
  expect(api.createPublicAppointment).toHaveBeenCalledWith(expect.objectContaining({rut:'123456785',email:'ana@example.test'}));
});
it('conserva el código para la primera cita aunque haya sesión',async () => {
  const user = await complete([]);
  await user.click(screen.getByRole('button',{name:'Enviar código de verificación'}));
  expect(await screen.findByLabelText('Código de seis dígitos')).toBeVisible();
  expect(api.createPublicAppointment).not.toHaveBeenCalled();
});

it('permite cerrar, reabrir y reenviar el código sin perder la reserva', async () => {
  const user = await complete([]);
  await user.click(screen.getByRole('button', { name: 'Enviar código de verificación' }));
  expect(await screen.findByRole('dialog')).toBeVisible();
  await user.keyboard('{Escape}');
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Ingresar código de verificación' }));
  await user.click(screen.getByRole('button', { name: 'Solicitar otro código' }));
  expect(api.requestBookingVerification).toHaveBeenCalledTimes(2);
  api.createPublicAppointment.mockRejectedValueOnce({ response: { data: { code: ['Código incorrecto.'] } } });
  await user.type(screen.getByLabelText('Código de seis dígitos'), '123456');
  await user.click(screen.getByRole('button', { name: 'Confirmar agendamiento' }));
  expect(await screen.findByRole('alert')).toHaveTextContent('Código incorrecto.');
  expect(screen.getByRole('dialog')).toBeVisible();
  await user.click(screen.getByRole('button', { name: 'Confirmar agendamiento' }));
  expect(await screen.findByText('¡Gracias, Ana!')).toBeVisible();
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
});
