import { beforeEach, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import ClientMenu from '../components/ClientMenu.jsx';
import * as auth from '../api/clientAuth.js';
vi.mock('../api/clientAuth.js', () => ({ clearClientSession: vi.fn(), getClientSession: vi.fn(), getClientAccount: vi.fn() }));
beforeEach(() => vi.resetAllMocks());
it('muestra iniciar sesión cuando no hay acceso de cliente', () => {
  auth.getClientSession.mockReturnValue(null);
  render(<ClientMenu />);
  expect(screen.getByRole('link', { name: 'Iniciar sesión' })).toBeVisible();
});
it('muestra nombre y opciones de cuenta cuando la sesión está activa', async () => {
  auth.getClientSession.mockReturnValue({ access: 'client', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana', last_name: 'Perez' } });
  render(<ClientMenu />);
  expect(await screen.findByText('Ana Perez ▾')).toBeVisible();
  expect(screen.queryByRole('link', { name: 'Iniciar sesión' })).not.toBeInTheDocument();
  expect(screen.getByText('Datos personales')).toHaveAttribute('href', '/cliente#datos');
  expect(screen.getByText('Atenciones')).toHaveAttribute('href', '/cliente#atenciones');
  expect(screen.getByText('Cerrar sesión')).toBeInTheDocument();
});
