import { StrictMode } from 'react';
import { expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import AppointmentCards from '../components/AppointmentCards.jsx';
import { unifiedAttentions } from '../utils/attentions.js';
it('enlaza cada tarjeta al detalle completo sin modal intermedio', () => {
  render(<StrictMode><AppointmentCards appointments={[{ id:'1',status:'PENDIENTE',scheduled_date:'2030-01-07T10:00:00-03:00',reported_symptoms:'Frenos delanteros' }, { id:'2',status:'CONFIRMADA',scheduled_date:'2030-01-08T11:00:00-03:00',reported_symptoms:'Cambio aceite' }]} /></StrictMode>);
  expect(screen.queryByText('Frenos delanteros')).not.toBeInTheDocument();
  expect(screen.getByRole('link', { name:/Cita aceptada/ })).toHaveAttribute('href','/cliente#atencion=appointment%3A2');
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
});

it('unifica una cita y su orden y conserva una atención sin cita', () => {
  const rows = unifiedAttentions([{id:'cita',status:'ATENDIDA',scheduled_date:'2030-01-07T10:00:00Z'}], [{appointment_id:'cita',tracking_code:'tracking1',folio_number:1001,status:'Recepcionado'},{appointment_id:null,tracking_code:'tracking2',folio_number:1002,status:'En trabajo'}]);
  expect(rows).toHaveLength(2);
  expect(rows.filter(item => item.work_order__tracking_code === 'tracking1')).toHaveLength(1);
  expect(rows.find(item => item.work_order__tracking_code === 'tracking2').withoutAppointment).toBe(true);
});
