import { beforeEach, describe, expect, it, vi } from 'vitest';
import { clearClientSession, getClientAccount, getClientSession, verifyClientCode, requestClientCode } from '../api/clientAuth.js';

const transport = vi.hoisted(() => ({ post: vi.fn(), get: vi.fn() }));
vi.mock('axios', () => ({ default: { create: () => transport } }));
vi.mock('../api/axiosConfig.js', () => ({ BACKEND_URL: 'http://qa.test' }));
beforeEach(() => { vi.clearAllMocks(); });
describe('Sesión del cliente independiente del personal', () => {
  it('persiste solo el acceso y su caducidad, sin contraseña ni refresh de empleados', async () => {
    sessionStorage.setItem('access', 'staff-access');
    transport.post.mockResolvedValue({ data: { access: 'client-access', expires_in: 3600 } });
    await verifyClientCode({ rut: '123456785', code: '012345', password: 'InitialPassword!2026' });
    expect(getClientSession().access).toBe('client-access');
    expect(sessionStorage.getItem('access')).toBe('staff-access');
    expect(sessionStorage.getItem('ajconnect:client-session')).not.toMatch(/password|refresh|123456785|012345/);
    clearClientSession();
    expect(sessionStorage.getItem('access')).toBe('staff-access');
    expect(getClientSession()).toBeNull();
  });
  it('elimina una sesión expirada o rechazada y no llama endpoints de personal', async () => {
    sessionStorage.setItem('ajconnect:client-session', JSON.stringify({ access: 'expired', expiresAt: Date.now() - 1 }));
    await expect(getClientAccount()).rejects.toThrow('Tu sesión terminó');
    expect(transport.get).not.toHaveBeenCalled();
    sessionStorage.setItem('ajconnect:client-session', JSON.stringify({ access: 'client-access', expiresAt: Date.now() + 60000 }));
    transport.get.mockRejectedValue({ response: { status: 401 } });
    await expect(getClientAccount()).rejects.toEqual({ response: { status: 401 } });
    expect(getClientSession()).toBeNull();
    expect(transport.get.mock.calls[0][0]).toBe('/client-session/');
  });
});

it('persiste la sesión del acceso por contraseña sin guardar la contraseña', async () => {
  transport.post.mockResolvedValue({ data: { access: 'password-access', expires_in: 3600 } });
  await requestClientCode('123456785', 'MotorSeguro!2026');
  expect(transport.post).toHaveBeenLastCalledWith('/client-login/', { rut: '123456785', password: 'MotorSeguro!2026' });
  expect(getClientSession().access).toBe('password-access');
  expect(sessionStorage.getItem('ajconnect:client-session')).not.toContain('MotorSeguro!2026');
});
