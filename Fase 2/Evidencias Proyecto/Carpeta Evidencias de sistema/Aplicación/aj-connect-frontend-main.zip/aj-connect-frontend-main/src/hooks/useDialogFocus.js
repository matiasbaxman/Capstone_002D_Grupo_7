import { useEffect } from 'react';

export function useDialogFocus(dialog) {
  useEffect(() => {
    const root = document.getElementById('root');
    const inert = root?.inert;
    const overflow = document.body.style.overflow;
    const focus = document.activeElement;
    if (root) root.inert = true;
    document.body.style.overflow = 'hidden';
    (dialog.current?.querySelector('input:not(:disabled)') || dialog.current?.querySelector('button:not(:disabled)') || dialog.current)?.focus();
    function trap(event) {
      if (event.key !== 'Tab') return;
      const controls = [...dialog.current.querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href]')];
      const first = controls[0];
      const last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
    document.addEventListener('keydown', trap);
    return () => {
      if (root) root.inert = inert;
      document.body.style.overflow = overflow;
      document.removeEventListener('keydown', trap);
      if (focus?.isConnected) focus.focus();
    };
  }, [dialog]);
}


