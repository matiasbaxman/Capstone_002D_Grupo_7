import { createCheckIn, lookupClient } from './api/workshop.js';
import CheckIn from './pages/CheckIn.jsx';
import WorkOrders from './pages/WorkOrders.jsx';
import ConfirmDialog from './components/ConfirmDialog.jsx';
import LoginEntrance from './components/LoginEntrance.jsx';
import { useToast, notificationMessages } from './components/notifications/useToast.js';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { flushSync } from 'react-dom';
import Inventario from './pages/Inventario.jsx';
import Users from './pages/Users.jsx';
import Categories from './pages/Categories.jsx';
import Login from './components/Login.jsx';
import PublicHome, { PublicLayout } from './pages/PublicHome.jsx';
import Tracking from './pages/Tracking.jsx';
import ClientPortal from './pages/ClientPortal.jsx';
import BookingPage from './pages/BookingPage.jsx';
import AdminLayout from './layouts/AdminLayout.jsx';
import AdminHome from './pages/AdminHome.jsx';
import MyAccount from './pages/MyAccount.jsx';
import AppointmentsAdmin from './pages/AppointmentsAdmin.jsx';
import { clearSession, getSession, hasRole, saveSession, SESSION_EVENT } from './api/session.js';
import { sessionIdentity } from './utils/sessionIdentity.js';

export default function App() {
  const toast = useToast();
  const [entering, setEntering] = useState(false);
  const [logoutRequested, setLogoutRequested] = useState(false);
  const finishEntrance = useCallback(() => {
    setEntering(false);
    toast.success(notificationMessages.loginSuccess, { icon: 'login' });
  }, [toast]);
  const [token, setToken] = useState(() => getSession()?.access);
  const [path, setPath] = useState(() => window.location.pathname.replace(/\/+$/, '') || '/');
  const [locationSearch, setLocationSearch] = useState(window.location.search);

  function navigate(destination) {
    if (destination === window.location.pathname + window.location.search) return;
    const update = () => {
      window.history.pushState({}, '', destination);
      flushSync(() => { setPath(window.location.pathname); setLocationSearch(window.location.search); });
      window.scrollTo(0, 0);
    };
    const administrative = path.startsWith('/dashboard') && destination.startsWith('/dashboard');
    if (administrative && document.startViewTransition && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      // Disable the fallback before React mounts the incoming page, so the
      // browser snapshot does not capture a second entrance animation.
      document.documentElement.classList.add('admin-route-transition');
      const inventoryTransition = path.startsWith('/dashboard/inventario') || destination.startsWith('/dashboard/inventario');
      document.documentElement.classList.toggle('admin-inventory-transition', inventoryTransition);
      const transition = document.startViewTransition(update);
      transition.finished.catch(() => {}).finally(() => {
        document.documentElement.classList.remove('admin-route-transition');
        document.documentElement.classList.remove('admin-inventory-transition');
      });
    } else update();
  }
  useEffect(() => {
    const updatePath = () => { setPath(window.location.pathname.replace(/\/+$/, '') || '/'); setLocationSearch(window.location.search); };
    window.addEventListener('popstate', updatePath);
    return () => window.removeEventListener('popstate', updatePath);
  }, []);
  // Redirecciones de rutas heredadas (/admin y /inventario) a la nueva estructura /dashboard
  const legacyTarget =
    path === '/inventario' ? '/dashboard/inventario'
      : path === '/admin/usuarios' ? '/dashboard/users'
        : path.startsWith('/admin') ? '/dashboard' + path.slice('/admin'.length)
          : '';

  useEffect(() => {
    if (legacyTarget) window.location.replace(legacyTarget);
  }, [legacyTarget]);
  useEffect(() => {
    let timer;
    function syncSession() {
      clearTimeout(timer);
      const session = getSession();
      setToken(session?.access);
      if (session) timer = setTimeout(clearSession, Math.min(session.expiresAt - Date.now(), 2147483647));
    }
    syncSession();
    window.addEventListener(SESSION_EVENT, syncSession);
    window.addEventListener('storage', syncSession);
    return () => {
      clearTimeout(timer);
      window.removeEventListener(SESSION_EVENT, syncSession);
      window.removeEventListener('storage', syncSession);
    };
  }, []);

  function handleLoginSuccess(session, remember) {
    const update = () => flushSync(() => {
      setEntering(true);
      saveSession(session, remember);
      setToken(getSession()?.access);
    });
    if (document.startViewTransition && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.documentElement.classList.add('login-auth-transition');
      const transition = document.startViewTransition(update);
      transition.finished.catch(() => {}).finally(() => {
        document.documentElement.classList.remove('login-auth-transition');
      });
    } else update();
  }

  function handleLogout() {
    const update = () => flushSync(() => {
      setLogoutRequested(false);
      clearSession();
      window.history.replaceState({}, '', '/dashboard');
      setPath('/dashboard');
      setLocationSearch('');
    });
    if (document.startViewTransition && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.documentElement.classList.add('login-auth-transition');
      const transition = document.startViewTransition(update);
      transition.finished.catch(() => {}).finally(() => {
        document.documentElement.classList.remove('login-auth-transition');
        toast.success(notificationMessages.logoutSuccess, { icon: 'logout' });
      });
    } else {
      update();
      toast.success(notificationMessages.logoutSuccess, { icon: 'logout' });
    }
  }

  const isDashboardHome = path === '/dashboard';
  const isInventory = path === '/dashboard/inventario';
  const isCategories = path === '/dashboard/inventario/categorias';
  const isCheckIn = path === '/dashboard/check-in';
  const isOrders = path === '/dashboard/ordenes' || /^\/dashboard\/ordenes\/[^/]+$/.test(path);
  const isAccount = path === '/dashboard/cuenta';
  const isPersonnel = path === '/dashboard/users' || path === '/dashboard/personal';
  const isAppointments = path === '/dashboard/citas';
  const privateRoute = isDashboardHome || isInventory || isCategories || isCheckIn || isAccount || isPersonnel || isOrders || isAppointments;

  const identity = useMemo(() => (token ? sessionIdentity(token) : null), [token]);
  const isSuperUser = Boolean(identity?.isSuperUser);
  const isAdmin = isSuperUser || hasRole(identity?.roles, 'Administrador') || Boolean(identity?.isAdmin);
  const isMecanico = hasRole(identity?.roles, 'Mecanico') || Boolean(identity?.isMecanico);
  const isRecepcionista = hasRole(identity?.roles, 'Recepcionista') || Boolean(identity?.isRecepcionista);

  const canAccessInventory = isAdmin || isMecanico || isRecepcionista;
  const canAccessCheckIn = isAdmin || isMecanico;
  const canAccessPersonnel = isAdmin;

  const deniedPath = token && (
    (isPersonnel && !canAccessPersonnel) ||
    (isAppointments && !isAdmin && !isRecepcionista) ||
    ((isCheckIn || isOrders) && !canAccessCheckIn) ||
    ((isInventory || isCategories) && !canAccessInventory)
  ) ? '/dashboard' : '';

  useEffect(() => {
    if (!deniedPath) return;
    window.history.replaceState({}, '', deniedPath);
    flushSync(() => { setPath(deniedPath); setLocationSearch(''); });
  }, [deniedPath]);

  if (legacyTarget) return null;
  if (['/', '/privacidad', '/condiciones', '/almacenamiento', '/contacto'].includes(path)) return <PublicHome path={path} />;
  if (['/seguimiento', '/tracking'].includes(path) || /^\/(?:seguimiento|tracking)\/[^/]+$/.test(path)) return <PublicLayout><Tracking token={path.split('/')[2] || ''} /></PublicLayout>;
  if (path === '/cliente') return <PublicLayout><ClientPortal /></PublicLayout>;
  if (path === '/agendar') return <PublicLayout><BookingPage /></PublicLayout>;
  if (!privateRoute) {
    return (
      <main className="min-h-screen bg-slate-950 px-6 py-24 text-center text-white">
        <h1 className="text-3xl font-bold">Página no encontrada</h1>
        <a href="/" className="mt-6 inline-block text-emerald-400 underline">Volver al inicio</a>
      </main>
    );
  }
  if (!token) return <Login onLoginSuccess={handleLoginSuccess} />;

  return (
    <>
    <div className={entering ? "login-dashboard-pending" : undefined} inert={entering ? true : undefined}>
    <AdminLayout path={path} token={token} onNavigate={navigate} onLogout={() => setLogoutRequested(true)}>
      {isOrders ? <WorkOrders key={path} orderId={path.split('/')[3]} onNavigate={navigate} />
        : isAppointments ? <AppointmentsAdmin />
        : isCheckIn ? <CheckIn lookupClient={lookupClient} onSubmit={createCheckIn} />
        : isCategories ? <Categories onNavigate={navigate} />
          : isInventory ? <Inventario key={locationSearch} onNavigate={navigate} initialCategory={new URLSearchParams(locationSearch).get('category') || ''} isMecanico={isMecanico && !isAdmin} />
            : isAccount ? <MyAccount token={token} />
              : isPersonnel ? <Users />
                : <AdminHome onNavigate={navigate} />}
    </AdminLayout>
    </div>
    {entering && <LoginEntrance onComplete={finishEntrance} />}
    {logoutRequested && <ConfirmDialog title="¿Cerrar sesión?" confirmLabel="Cerrar sesión" variant="danger" onCancel={() => setLogoutRequested(false)} onConfirm={handleLogout}>Tendrás que iniciar sesión nuevamente para volver a entrar.</ConfirmDialog>}
    </>
  );
}
