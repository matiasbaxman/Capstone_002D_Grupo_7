import axios from 'axios';
import { clearSession, getSession, updateSession } from './session.js';

const raw = (import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000').replace(/\/+$/, '');
export const BACKEND_URL = raw.endsWith('/api') ? raw.slice(0, -4) : raw;
const api = axios.create({ baseURL: `${BACKEND_URL}/api`, timeout: 15000 });
let refreshing;

api.interceptors.request.use((config) => {
  if (config.skipAuth) return config;
  const session = getSession();
  if (session) config.headers.Authorization = `Bearer ${session.access}`;
  else {
    clearSession();
    throw new Error('Tu sesión terminó. Inicia sesión nuevamente.');
  }
  return config;
});
api.interceptors.response.use((response) => response, async (error) => {
  const config = error.config;
  if (error.response?.status !== 401 || !config) throw error;
  if (config.skipAuth) throw error;
  if (config._retried) { clearSession(); throw error; }
  config._retried = true;
  const session = getSession();
  if (!session) { clearSession(); throw error; }
  // Otra petición puede haber renovado el token antes de que llegue este 401.
  if (config.headers.Authorization !== `Bearer ${session.access}`) return api(config);
  if (!refreshing) {
    refreshing = axios.post(`${BACKEND_URL}/api/auth/refresh/`, { refresh: session.refresh }, { timeout: 15000 })
      .then(({ data }) => updateSession(data, session.revision))
      .catch((refreshError) => {
        if ([400, 401, 403].includes(refreshError.response?.status)) clearSession();
        throw refreshError;
      })
      .finally(() => { refreshing = undefined; });
  }
  await refreshing;
  return api(config);
});
export default api;
