import { getClientSession } from './clientAuth.js';
import axios from 'axios';
import api, { BACKEND_URL } from './axiosConfig.js';

const publicApi = axios.create({ baseURL: `${BACKEND_URL}/api`, timeout: 15000 });

export async function getPublicServices() {
  const { data } = await publicApi.get('/services/');
  return Array.isArray(data) ? data : data.results || [];
}

export async function getAppointmentAvailability(date) {
  const { data } = await publicApi.get('/appointments/', { params: { date } });
  return data;
}

export async function createPublicAppointment(payload) {
  const session = getClientSession();
  const { data } = session
    ? await publicApi.post('/auth/client-appointments/', payload, { headers: { Authorization: `Bearer ${session.access}` } })
    : await publicApi.post('/appointments/', payload);
  return data;
}

export async function requestBookingVerification(payload) {
  const { data } = await publicApi.post('/appointments/verify-contact/', payload);
  return data;
}

// Endpoints de gestión para el panel administrativo.
export async function listAppointments(params = {}) {
  const { data } = await api.get('/appointments/', { params });
  return Array.isArray(data) ? data : data.results || [];
}

export async function updateAppointment(id, payload) {
  const { data } = await api.patch(`/appointments/${id}/`, payload);
  return data;
}
