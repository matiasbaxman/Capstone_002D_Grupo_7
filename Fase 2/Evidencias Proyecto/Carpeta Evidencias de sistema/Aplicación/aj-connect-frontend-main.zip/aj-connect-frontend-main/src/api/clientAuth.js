import axios from 'axios';
import { BACKEND_URL } from './axiosConfig.js';

const api = axios.create({ baseURL: `${BACKEND_URL}/api/auth`, timeout: 15000 });
const KEY = 'ajconnect:client-session';
export function clearClientSession() { const hadSession = sessionStorage.getItem(KEY); sessionStorage.removeItem(KEY); if (hadSession) window.dispatchEvent(new Event('aj-client-session')); }
export function getClientSession() {
  try {
    const session = JSON.parse(sessionStorage.getItem(KEY));
    if (session?.access && session.expiresAt > Date.now()) return session;
  } catch { /* almacenamiento inválido o no disponible */ }
  clearClientSession();
  return null;
}
function saveClientSession(data) {
  const session = { access: data.access, expiresAt: Date.now() + data.expires_in * 1000 };
  sessionStorage.setItem(KEY, JSON.stringify(session));
  window.dispatchEvent(new Event('aj-client-session'));
  return session;
}
export async function requestClientCode(rut, password = '') {
  const { data } = await api.post('/client-login/', { rut, password });
  return data.access ? saveClientSession(data) : data;
}
export async function verifyClientCode(payload) {
  const { data } = await api.post('/client-otp/', payload);
  return saveClientSession(data);
}
export async function getClientAccount(signal) {
  const session = getClientSession();
  if (!session) throw new Error('Tu sesión terminó. Inicia sesión nuevamente.');
  try {
    const { data } = await api.get('/client-session/', { headers: { Authorization: `Bearer ${session.access}` }, signal });
    return data;
  } catch (error) {
    if (error.response?.status === 401) clearClientSession();
    throw error;
  }
}

export async function requestProfileChange(payload) {
  const { data } = await api.post('/client-profile/request/', payload, { headers: { Authorization: `Bearer ${getClientSession()?.access}` } });
  return data;
}
export async function confirmProfileChange(code) {
  const { data } = await api.post('/client-profile/confirm/', { code }, { headers: { Authorization: `Bearer ${getClientSession()?.access}` } });
  window.dispatchEvent(new Event('aj-client-session'));
  return data;
}
