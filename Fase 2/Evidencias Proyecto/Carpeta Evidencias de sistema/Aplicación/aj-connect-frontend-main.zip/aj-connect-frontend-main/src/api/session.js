const KEYS = ['access', 'refresh', 'session_expires_at'];
export const SESSION_EVENT = 'ajconnect:session';
let revision = 0;

export function tokenExpiry(token) {
  try { return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).exp * 1000; }
  catch { return 0; }
}
function activeStore() {
  return sessionStorage.getItem('access') ? sessionStorage : localStorage;
}
export function clearSession() {
  revision += 1;
  for (const store of [sessionStorage, localStorage]) {
    for (const key of KEYS) store.removeItem(key);
    store.removeItem('access_token');
  }
  window.dispatchEvent(new Event(SESSION_EVENT));
}
export function getSession() {
  const store = activeStore();
  const access = store.getItem('access');
  const refresh = store.getItem('refresh');
  const expiresAt = Number(store.getItem('session_expires_at')) || tokenExpiry(refresh);
  if (!access || !refresh || !expiresAt || expiresAt <= Date.now()) return null;
  return { access, refresh, expiresAt, remember: store === localStorage, revision };
}
export function saveSession(tokens, remember = false) {
  clearSession();
  const store = remember ? localStorage : sessionStorage;
  store.setItem('access', tokens.access);
  store.setItem('refresh', tokens.refresh);
  store.setItem('session_expires_at', String(tokenExpiry(tokens.refresh)));
  window.dispatchEvent(new Event(SESSION_EVENT));
}
export function updateSession(tokens, expectedRevision) {
  const session = getSession();
  if (!session || revision !== expectedRevision) throw new Error('La sesión terminó.');
  const store = activeStore();
  store.setItem('access', tokens.access);
  if (tokens.refresh) store.setItem('refresh', tokens.refresh);
  window.dispatchEvent(new Event(SESSION_EVENT));
}

const normalize = (str) => (str || '').toString().toUpperCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

export const hasRole = (roles, target) => {
  if (!roles || !target) return false;
  const targetNorm = normalize(target);
  return roles.some((r) => {
    const val = typeof r === 'string' ? r : r?.name || r?.code;
    return val && normalize(val) === targetNorm;
  });
};
