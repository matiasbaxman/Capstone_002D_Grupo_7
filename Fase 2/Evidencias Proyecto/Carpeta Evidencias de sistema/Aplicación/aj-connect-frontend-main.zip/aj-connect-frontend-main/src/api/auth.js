import api from './axiosConfig.js';

export async function login(username, password) {
  const { data } = await api.post('/auth/login/', { username, password }, { skipAuth: true });
  return data;
}