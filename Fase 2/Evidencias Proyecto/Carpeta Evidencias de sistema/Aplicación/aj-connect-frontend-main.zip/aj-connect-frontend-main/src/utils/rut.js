/**
 * Utilidades para formateo de RUT chileno, teléfonos, fechas y generación automática de credenciales.
 */

/**
 * Limpia el RUT dejando únicamente dígitos y la letra K/k.
 */
export function cleanRut(rut) {
  if (!rut) return '';
  return rut.toString().replace(/[^0-9kK]/g, '');
}

/**
 * Retorna el RUT sin puntos y con guion (ej: "12345678-9" o "21965259-K").
 */
export function cleanRutWithDash(rut) {
  const cleaned = cleanRut(rut);
  if (!cleaned) return '';
  if (cleaned.length === 1) return cleaned.toUpperCase();

  const body = cleaned.slice(0, -1);
  const dv = cleaned.slice(-1).toUpperCase();
  return `${body}-${dv}`;
}

/**
 * Formatea un RUT chileno con puntos y guion estándar (ej: "12.345.678-9" o "21.965.259-K").
 */
export function formatRut(rut) {
  const cleaned = cleanRut(rut);
  if (!cleaned) return '';
  if (cleaned.length === 1) return cleaned.toUpperCase();

  const body = cleaned.slice(0, -1);
  const dv = cleaned.slice(-1).toUpperCase();

  // Puntos de miles en el cuerpo
  const formattedBody = body.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${formattedBody}-${dv}`;
}

/**
 * Formatea un número telefónico chileno con el prefijo internacional y espacios:
 * +56 9 1234 5678
 */
export function formatPhone(phone) {
  if (!phone) return '';
  const digits = phone.toString().replace(/\D/g, '');
  if (!digits) return phone;

  // 11 dígitos con código país 569XXXXXXXX
  if (digits.length === 11 && digits.startsWith('569')) {
    const body = digits.slice(3);
    return `+56 9 ${body.slice(0, 4)} ${body.slice(4)}`;
  }

  // 9 dígitos con el 9 móvil chileno 9XXXXXXXX
  if (digits.length === 9 && digits.startsWith('9')) {
    const body = digits.slice(1);
    return `+56 9 ${body.slice(0, 4)} ${body.slice(4)}`;
  }

  // 8 dígitos correspondientes al cuerpo móvil XXXXXXXX
  if (digits.length === 8) {
    return `+56 9 ${digits.slice(0, 4)} ${digits.slice(4)}`;
  }

  // 10 dígitos con código país 56XXXXXXXX
  if (digits.length === 10 && digits.startsWith('56')) {
    const body = digits.slice(2);
    return `+56 9 ${body.slice(0, 4)} ${body.slice(4)}`;
  }

  return phone;
}

/**
 * Formatea la fecha de último inicio de sesión en estándar legible para Chile:
 * DD/MM/AAAA HH:mm
 */
export function formatLastLogin(dateStr) {
  if (!dateStr) return null;
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return null;

    const formatter = new Intl.DateTimeFormat('es-CL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: 'America/Santiago',
    });
    const parts = formatter.formatToParts(date);
    const getPart = (type) => parts.find((p) => p.type === type)?.value || '';

    const day = getPart('day');
    const month = getPart('month');
    const year = getPart('year');
    const hour = getPart('hour');
    const minute = getPart('minute');

    return `${day}/${month}/${year} ${hour}:${minute}`;
  } catch {
    return null;
  }
}

/**
 * Genera el username con la inicial del primer nombre + primer apellido,
 * en minúsculas y sin acentos/caracteres especiales (ej: "Juan Pérez" -> "jperez").
 */
export function generateUsername(firstName, lastName) {
  const cleanFirst = (firstName || '').trim().split(/\s+/)[0] || '';
  const cleanLast = (lastName || '').trim().split(/\s+/)[0] || '';

  const initial = cleanFirst
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase()
    .slice(0, 1);

  const last = cleanLast
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase();

  if (!initial && !last) return '';
  return `${initial}${last}`;
}

/**
 * Genera la contraseña por defecto:
 * inicial del nombre + inicial del apellido + RUT sin puntos y con guion (ej: "jp12345678-9").
 */
export function generateDefaultPassword(firstName, lastName, rut) {
  const initFirst = (firstName || '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase()
    .slice(0, 1);

  const initLast = (lastName || '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase()
    .slice(0, 1);

  const rutFormatted = cleanRutWithDash(rut);
  if (!initFirst && !initLast && !rutFormatted) return '';
  return `${initFirst}${initLast}${rutFormatted}`;
}
