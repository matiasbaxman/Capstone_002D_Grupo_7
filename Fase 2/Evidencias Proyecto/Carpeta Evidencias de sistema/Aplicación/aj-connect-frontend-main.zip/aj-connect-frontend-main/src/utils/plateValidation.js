// Conventional Chilean automobile formats. Special plates require separate support.
export function normalizePlate(value) {
  return value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
}
export function validPlate(value) {
  return /^(?:[A-Z]{2}\d{4}|[A-Z]{4}\d{2})$/.test(normalizePlate(value));
}
export function formatPlate(value) {
  const plate = normalizePlate(value);
  if (/^[A-Z]{2}\d/.test(plate)) return plate.length > 2 ? `${plate.slice(0, 2)}-${plate.slice(2)}` : plate;
  return plate.match(/.{1,2}/g)?.join('-') || '';
}
