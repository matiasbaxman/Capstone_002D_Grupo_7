export function normalizeRut(value) {
  return value.toUpperCase().replace(/[^0-9K]/g, '').slice(0, 9);
}
export function formatRut(value) {
  const clean = normalizeRut(value);
  if (clean.length < 2) return clean;
  return `${clean.slice(0, -1).replace(/\B(?=(\d{3})+(?!\d))/g, '.')}-${clean.slice(-1)}`;
}
export function validRut(value) {
  const clean = normalizeRut(value);
  if (!/^\d{7,8}[0-9K]$/.test(clean) || /^0+/.test(clean)) return false;
  const body = clean.slice(0, -1);
  let sum = 0;
  let factor = 2;
  for (let i = body.length - 1; i >= 0; i--) {
    sum += Number(body[i]) * factor;
    factor = factor === 7 ? 2 : factor + 1;
  }
  const result = 11 - sum % 11;
  const digit = result === 11 ? '0' : result === 10 ? 'K' : String(result);
  return digit === clean.slice(-1);
}
