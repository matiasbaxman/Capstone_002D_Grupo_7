export function formatDateTime(value) {
  return value && !Number.isNaN(new Date(value).getTime())
    ? new Date(value).toLocaleString('es-CL', { dateStyle: 'medium', timeStyle: 'short' })
    : 'No indicada';
}

export function formatMoney(value) {
  return Number(value).toLocaleString('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 });
}

export function formatKm(value) {
  if (value === null || value === undefined || value === '') return 'No registrado';
  return `${Number(value).toLocaleString('es-CL')} km`;
}
