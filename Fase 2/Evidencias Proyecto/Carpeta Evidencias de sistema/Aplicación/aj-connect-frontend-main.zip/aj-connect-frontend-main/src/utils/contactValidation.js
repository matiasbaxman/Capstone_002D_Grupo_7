// Form-format validation only; mailbox ownership is verified by the backend flow.
export function validContactEmail(value) {
  const email = value.trim();
  if (email.length > 254 || !/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+$/.test(email)) return false;
  const [local, domain] = email.split('@');
  if (local.length > 64 || local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;
  const labels = domain.split('.');
  return labels.length >= 2 && labels.every((label) => label.length <= 63 && /^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(label)) && /^[a-zA-Z]{2,63}$/.test(labels.at(-1));
}
export function mobileDigits(value) {
  const digits = value.replace(/\D/g, '');
  if (digits.startsWith('569') && digits.length === 11) return digits.slice(3);
  if (digits.startsWith('9') && digits.length === 9) return digits.slice(1);
  return digits.slice(0, 8);
}
export function mobileContact(value) { return value ? `+569${value}` : ''; }
