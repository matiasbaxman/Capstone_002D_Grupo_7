export function unifiedAttentions(appointments = [], orders = []) {
  const used = new Set();
  const rows = appointments.map(item => {
    const order = orders.find(value => String(value.appointment_id) === String(item.id) || (item.work_order__tracking_code && value.tracking_code === item.work_order__tracking_code));
    if (order) used.add(order.tracking_code);
    return { ...item, id: 'appointment:' + item.id,
      work_order__tracking_code: order?.tracking_code || item.work_order__tracking_code,
      work_order__folio_number: order?.folio_number || item.work_order__folio_number,
      work_order__status__name: order?.status || item.work_order__status__name,
      plate: order?.plate,
    };
  });
  for (const order of orders) {
    if (used.has(order.tracking_code)) continue;
    if (rows.some(item => item.work_order__tracking_code === order.tracking_code)) continue;
    rows.push({ id: 'order:' + order.tracking_code, scheduled_date: order.created_at,
      status: 'ATENDIDA', withoutAppointment: true, plate: order.plate,
      reported_symptoms: 'Recepción del vehículo sin cita asociada.',
      work_order__tracking_code: order.tracking_code, work_order__folio_number: order.folio_number,
      work_order__status__name: order.status });
  }
  return rows.sort((a, b) => (Date.parse(b.scheduled_date) || 0) - (Date.parse(a.scheduled_date) || 0));
}
