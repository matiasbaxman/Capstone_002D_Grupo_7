// JWT claims are used only for display. API permissions remain server-side.
export function sessionIdentity(token) {
  try {
    const payload = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const claims = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(payload), (char) => char.charCodeAt(0))));
    const roles = Array.isArray(claims.roles) ? claims.roles : claims.role ? [claims.role] : [];
    const normalize = (str) => (str || '').toString().toUpperCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const isSuperUser = Boolean(claims.is_superuser);
    const normalizedRoles = roles.map((r) => normalize(r));
    const isAdmin = isSuperUser || normalizedRoles.some((r) => r === 'ADMINISTRADOR' || r === 'ADMIN');
    return {
      name: claims.username || 'Usuario',
      email: typeof claims.email === 'string' ? claims.email.trim() : '',
      roles,
      isAdmin,
      isSuperUser,
      isMecanico: normalizedRoles.some((r) => r === 'MECANICO' || r === 'MECÁNICO'),
      isRecepcionista: normalizedRoles.some((r) => r === 'RECEPCIONISTA'),
      role: ({ ADMIN: 'Administrador', ADMINISTRADOR: 'Administrador', MECANICO: 'Mecánico', MECÁNICO: 'Mecánico', RECEPCIONISTA: 'Recepcionista', CLIENTE: 'Cliente' })[normalizedRoles[0] || normalize(claims.role)] || 'Usuario',
    };
  } catch { return { name: 'Usuario', email: '', roles: [], isAdmin: false, isSuperUser: false, isMecanico: false, isRecepcionista: false, role: 'Usuario' }; }
}
