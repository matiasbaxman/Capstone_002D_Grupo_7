export { formatPhone } from './rut.js';
