import { useEffect, useState } from 'react';
import { createUser, parseFieldErrors, parseGeneralError } from '../api/users.js';
import {
  cleanRut,
  formatRut,
  generateUsername,
  generateDefaultPassword,
} from '../utils/rut.js';

const campoClase =
  'w-full rounded-lg border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--ink)] placeholder-[var(--muted)] outline-none transition focus:border-emerald-500';
const campoErrorClase = 'border-red-500/60 focus:border-red-500';

function Campo({ etiqueta, error, obligatorio, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-[var(--muted)]">
        {etiqueta}
        {obligatorio ? <span className="ml-1 text-[var(--accent)]">*</span> : null}
      </span>
      {children}
      {error ? (
        <span className="mt-1 block text-xs text-[var(--danger)]">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-xs text-[var(--muted)]">{hint}</span>
      ) : null}
    </label>
  );
}

export default function UserModal({ roles, onCerrar, onGuardado }) {
  const [formulario, setFormulario] = useState({
    first_name: '',
    last_name: '',
    username: '',
    email: '',
    password: '',
    rut: '',
    phone: '',
  });
  const [usernameTouched, setUsernameTouched] = useState(false);
  const [passwordTouched, setPasswordTouched] = useState(false);
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [verPassword, setVerPassword] = useState(false);

  useEffect(() => {
    function alPresionarEscape(evento) {
      if (evento.key === 'Escape' && !enviando) onCerrar();
    }
    window.addEventListener('keydown', alPresionarEscape);
    return () => window.removeEventListener('keydown', alPresionarEscape);
  }, [enviando, onCerrar]);

  function handleFirstNameChange(e) {
    const value = e.target.value;
    setFormulario((prev) => {
      const updated = { ...prev, first_name: value };
      if (!usernameTouched) {
        updated.username = generateUsername(value, updated.last_name);
      }
      if (!passwordTouched) {
        updated.password = generateDefaultPassword(value, updated.last_name, updated.rut);
      }
      return updated;
    });
    setErrores((prev) => ({
      ...prev,
      first_name: undefined,
      username: undefined,
      password: undefined,
    }));
  }

  function handleLastNameChange(e) {
    const value = e.target.value;
    setFormulario((prev) => {
      const updated = { ...prev, last_name: value };
      if (!usernameTouched) {
        updated.username = generateUsername(updated.first_name, value);
      }
      if (!passwordTouched) {
        updated.password = generateDefaultPassword(updated.first_name, value, updated.rut);
      }
      return updated;
    });
    setErrores((prev) => ({
      ...prev,
      last_name: undefined,
      username: undefined,
      password: undefined,
    }));
  }

  function handleUsernameChange(e) {
    const value = e.target.value;
    if (!value.trim()) {
      setUsernameTouched(false);
      setFormulario((prev) => ({
        ...prev,
        username: generateUsername(prev.first_name, prev.last_name),
      }));
    } else {
      setUsernameTouched(true);
      setFormulario((prev) => ({ ...prev, username: value }));
    }
    setErrores((prev) => ({ ...prev, username: undefined }));
  }

  function handlePasswordChange(e) {
    const value = e.target.value;
    if (!value) {
      setPasswordTouched(false);
      setFormulario((prev) => ({
        ...prev,
        password: generateDefaultPassword(prev.first_name, prev.last_name, prev.rut),
      }));
    } else {
      setPasswordTouched(true);
      setFormulario((prev) => ({ ...prev, password: value }));
    }
    setErrores((prev) => ({ ...prev, password: undefined }));
  }

  function handleRutChange(e) {
    let val = e.target.value;
    // Filtrar caracteres: sólo dígitos, k, K, puntos y guiones
    val = val.replace(/[^0-9kK.-]/g, '');

    const cleaned = cleanRut(val);
    // Limitar longitud a max 9 caracteres válidos de RUT chileno (8 dígitos + 1 DV)
    if (cleaned.length > 9) return;

    // Si se ingresó o pegó el RUT completo (8 o 9 caracteres) y aún no tiene formato, autoformatear
    if (cleaned.length >= 8 && (!val.includes('.') || !val.includes('-'))) {
      val = formatRut(cleaned);
    }

    setFormulario((prev) => {
      const updated = { ...prev, rut: val };
      if (!passwordTouched) {
        updated.password = generateDefaultPassword(
          updated.first_name,
          updated.last_name,
          val
        );
      }
      return updated;
    });
    setErrores((prev) => ({ ...prev, rut: undefined, password: undefined }));
  }

  function handleRutBlur() {
    setFormulario((prev) => {
      if (!prev.rut) return prev;
      const formatted = formatRut(prev.rut);
      const updated = { ...prev, rut: formatted };
      if (!passwordTouched) {
        updated.password = generateDefaultPassword(
          updated.first_name,
          updated.last_name,
          formatted
        );
      }
      return updated;
    });
  }

  function handlePhoneChange(e) {
    const rawDigits = e.target.value.replace(/\D/g, '').slice(0, 8);
    const formatted = rawDigits.length > 4 ? `${rawDigits.slice(0, 4)} ${rawDigits.slice(4)}` : rawDigits;
    setFormulario((prev) => ({ ...prev, phone: formatted }));
    setErrores((prev) => ({ ...prev, phone: undefined }));
  }

  function resetUsername() {
    setUsernameTouched(false);
    setFormulario((prev) => ({
      ...prev,
      username: generateUsername(prev.first_name, prev.last_name),
    }));
  }

  function resetPassword() {
    setPasswordTouched(false);
    setFormulario((prev) => ({
      ...prev,
      password: generateDefaultPassword(prev.first_name, prev.last_name, prev.rut),
    }));
  }

  function alternarRol(code) {
    setSelectedRoles((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
    setErrores((prev) => ({ ...prev, roles: undefined }));
  }

  function validar() {
    const nuevos = {};
    if (!formulario.first_name.trim()) nuevos.first_name = 'El nombre es obligatorio.';
    if (!formulario.last_name.trim()) nuevos.last_name = 'El apellido es obligatorio.';
    if (!formulario.username.trim()) nuevos.username = 'El nombre de usuario es obligatorio.';
    if (!formulario.email.trim()) {
      nuevos.email = 'El correo electrónico es obligatorio.';
    } else if (!/\S+@\S+\.\S+/.test(formulario.email.trim())) {
      nuevos.email = 'Ingresa un correo electrónico válido.';
    }
    if (!formulario.password) {
      nuevos.password = 'La contraseña es obligatoria.';
    } else if (formulario.password.length < 6) {
      nuevos.password = 'La contraseña debe tener al menos 6 caracteres.';
    }
    const phoneDigits = formulario.phone.replace(/\D/g, '');
    if (phoneDigits.length > 0 && phoneDigits.length < 8) {
      nuevos.phone = 'El teléfono debe tener los 8 dígitos restantes (ej: 1234 5678).';
    }
    if (selectedRoles.length === 0) {
      nuevos.roles = 'Selecciona al menos un rol para el empleado.';
    }
    return nuevos;
  }

  async function manejarEnvio(evento) {
    evento.preventDefault();
    setErrorGeneral('');

    const fallos = validar();
    if (Object.keys(fallos).length > 0) {
      setErrores(fallos);
      return;
    }

    setEnviando(true);
    try {
      const phoneDigits = formulario.phone.replace(/\D/g, '');
      const fullPhone =
        phoneDigits.length === 8
          ? `+56 9 ${phoneDigits.slice(0, 4)} ${phoneDigits.slice(4)}`
          : undefined;

      const payload = {
        first_name: formulario.first_name.trim(),
        last_name: formulario.last_name.trim(),
        username: formulario.username.trim(),
        email: formulario.email.trim(),
        password: formulario.password,
        rut: formulario.rut ? formatRut(formulario.rut) : undefined,
        phone: fullPhone,
        roles: selectedRoles.map((r) => (typeof r === 'number' ? r : (isNaN(Number(r)) ? r : Number(r)))),
      };

      await createUser(payload);
      onGuardado();
    } catch (err) {
      const data = err?.response?.data;
      const erroresCampos = parseFieldErrors(data);

      if (Object.keys(erroresCampos).length > 0) {
        setErrores(erroresCampos);
      }
      setErrorGeneral(parseGeneralError(err));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="titulo-modal-usuario"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
        onClick={enviando ? undefined : onCerrar}
      />

      <div className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[var(--line)] bg-[var(--surface)] text-[var(--ink)] shadow-2xl">
        <header className="flex items-center justify-between border-b border-[var(--line)] px-6 py-4">
          <div>
            <h2 id="titulo-modal-usuario" className="text-lg font-bold text-[var(--ink)]">
              Nuevo Empleado
            </h2>
            <p className="text-xs text-[var(--muted)]">
              Registra un nuevo miembro del equipo y asígnale sus roles de acceso.
            </p>
          </div>
          <button
            type="button"
            onClick={onCerrar}
            disabled={enviando}
            aria-label="Cerrar modal"
            className="rounded-lg p-1.5 text-[var(--muted)] transition hover:bg-[var(--hover)] hover:text-[var(--ink)]"
          >
            ✕
          </button>
        </header>

        <form onSubmit={manejarEnvio}>
          <div className="space-y-4 px-6 py-5">
            {errorGeneral ? (
              <div
                role="alert"
                className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-[var(--danger)]"
              >
                {errorGeneral}
              </div>
            ) : null}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Campo etiqueta="Nombre" error={errores.first_name} obligatorio>
                <input
                  type="text"
                  name="first_name"
                  value={formulario.first_name}
                  onChange={handleFirstNameChange}
                  disabled={enviando}
                  placeholder="Juan"
                  maxLength={150}
                  className={`${campoClase} ${errores.first_name ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo etiqueta="Apellido" error={errores.last_name} obligatorio>
                <input
                  type="text"
                  name="last_name"
                  value={formulario.last_name}
                  onChange={handleLastNameChange}
                  disabled={enviando}
                  placeholder="Pérez"
                  maxLength={150}
                  className={`${campoClase} ${errores.last_name ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo
                etiqueta="Nombre de usuario"
                error={errores.username}
                obligatorio
                hint={
                  usernameTouched ? (
                    <span className="flex items-center gap-1">
                      Personalizado ·{' '}
                      <button
                        type="button"
                        onClick={resetUsername}
                        className="text-[var(--accent)] underline hover:no-underline"
                      >
                        Restablecer sugerido
                      </button>
                    </span>
                  ) : formulario.username ? (
                    'Generado automáticamente (editable)'
                  ) : (
                    'Ej: jperez'
                  )
                }
              >
                <input
                  type="text"
                  name="username"
                  value={formulario.username}
                  onChange={handleUsernameChange}
                  disabled={enviando}
                  placeholder="jperez"
                  autoCapitalize="none"
                  spellCheck={false}
                  maxLength={150}
                  className={`${campoClase} ${errores.username ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo etiqueta="Correo electrónico" error={errores.email} obligatorio>
                <input
                  type="email"
                  name="email"
                  value={formulario.email}
                  onChange={(e) => {
                    const value = e.target.value;
                    setFormulario((prev) => ({ ...prev, email: value }));
                    setErrores((prev) => ({ ...prev, email: undefined }));
                  }}
                  disabled={enviando}
                  placeholder="jperez@ajconnect.cl"
                  className={`${campoClase} ${errores.email ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo
                etiqueta="RUT"
                error={errores.rut}
                hint="Ej: 12.345.678-9 (formateo dinámico)"
              >
                <input
                  type="text"
                  name="rut"
                  value={formulario.rut}
                  onChange={handleRutChange}
                  onBlur={handleRutBlur}
                  disabled={enviando}
                  placeholder="12.345.678-9"
                  maxLength={12}
                  className={`${campoClase} tabular-nums ${errores.rut ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo
                etiqueta="Contraseña"
                error={errores.password}
                obligatorio
                hint={
                  passwordTouched ? (
                    <span className="flex items-center gap-1">
                      Personalizada ·{' '}
                      <button
                        type="button"
                        onClick={resetPassword}
                        className="text-[var(--accent)] underline hover:no-underline"
                      >
                        Restablecer por defecto
                      </button>
                    </span>
                  ) : formulario.password ? (
                    'Por defecto: iniciales + RUT (editable)'
                  ) : (
                    'Mínimo 6 caracteres'
                  )
                }
              >
                <div className="relative">
                  <input
                    type={verPassword ? 'text' : 'password'}
                    name="password"
                    value={formulario.password}
                    onChange={handlePasswordChange}
                    disabled={enviando}
                    placeholder="••••••••"
                    className={`${campoClase} pr-14 ${errores.password ? campoErrorClase : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setVerPassword(!verPassword)}
                    aria-label={verPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
                    className="absolute inset-y-0 right-0 px-3 text-xs text-[var(--muted)] hover:text-[var(--ink)]"
                  >
                    {verPassword ? 'Ocultar' : 'Ver'}
                  </button>
                </div>
              </Campo>

              {/* Teléfono chileno con prefijo fijo +56 9 */}
              <div className="sm:col-span-2">
                <Campo
                  etiqueta="Teléfono"
                  error={errores.phone}
                  hint="Prefijo móvil chileno fijo. Ingresa los 8 dígitos restantes (ej: 1234 5678)"
                >
                  <div
                    className={`flex rounded-lg border bg-[var(--surface)] transition focus-within:border-emerald-500 ${
                      errores.phone ? campoErrorClase : 'border-[var(--line)]'
                    }`}
                  >
                    <span className="flex select-none items-center rounded-l-lg border-r border-[var(--line)] bg-[var(--chrome)] px-3 text-sm font-semibold text-[var(--muted)]">
                      +56 9
                    </span>
                    <input
                      type="tel"
                      inputMode="numeric"
                      name="phone"
                      value={formulario.phone}
                      onChange={handlePhoneChange}
                      disabled={enviando}
                      placeholder="1234 5678"
                      maxLength={9}
                      className="w-full bg-transparent px-3 py-2 text-sm tabular-nums text-[var(--ink)] placeholder-[var(--muted)] outline-none"
                    />
                  </div>
                </Campo>
              </div>
            </div>

            {/* Selector de Roles M:N */}
            <div className="pt-2">
              <span className="mb-2 block text-xs font-medium uppercase tracking-wide text-[var(--muted)]">
                Roles de acceso <span className="text-[var(--accent)]">*</span>
              </span>

              {errores.roles ? (
                <span className="mb-2 block text-xs text-[var(--danger)]">{errores.roles}</span>
              ) : null}

              {roles.length === 0 ? (
                <p className="text-xs text-[var(--muted)]">Cargando catálogo de roles…</p>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {roles.map((rol) => {
                     const rolValue = rol.id !== undefined && rol.id !== null ? rol.id : rol.code;
                     const seleccionado = selectedRoles.includes(rolValue) || selectedRoles.includes(rol.code);
                     return (
                       <label
                         key={rol.code || rol.id}
                         className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 transition ${
                           seleccionado
                             ? 'border-emerald-500/50 bg-[var(--active)] text-[var(--ink)]'
                             : 'border-[var(--line)] bg-[var(--surface)] text-[var(--muted)] hover:border-[var(--line)] hover:bg-[var(--hover)]'
                         }`}
                       >
                         <input
                           type="checkbox"
                           checked={seleccionado}
                           onChange={() => alternarRol(rolValue)}
                           disabled={enviando}
                           className="mt-0.5 rounded border-[var(--line)] text-emerald-500 focus:ring-emerald-500"
                         />
<div className="min-w-0">
                           <span className="text-sm font-semibold text-[var(--ink)]">
                             {rol.name}
                           </span>
                           {rol.description ? (
                             <p className="mt-0.5 text-xs text-[var(--muted)]">
                               {rol.description}
                             </p>
                           ) : null}
                         </div>
                      </label>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <footer className="flex justify-end gap-3 border-t border-[var(--line)] px-6 py-4">
            <button
              type="button"
              onClick={onCerrar}
              disabled={enviando}
              className="rounded-lg border border-[var(--line)] px-4 py-2 text-sm font-medium text-[var(--ink)] transition hover:bg-[var(--hover)] disabled:opacity-40"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={enviando}
              className="rounded-lg bg-[var(--button)] px-4 py-2 text-sm font-semibold text-[var(--button-text)] transition hover:bg-[var(--button-hover)] disabled:cursor-not-allowed disabled:opacity-40"
            >
              {enviando ? 'Registrando empleado…' : 'Registrar Empleado'}
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
}
