import ToastIcon from './ToastIcon.jsx';
import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { createPortal } from 'react-dom';
import { ToastContext } from './useToast.js';
import { createToastStore } from './toastStore.js';
import './Toast.css';

const types = { success: 'Listo', error: 'Error', warning: 'Atención', info: 'Información' };
const mobileQuery = '(max-width: 640px)';
const isMobile = () => window.matchMedia(mobileQuery).matches;
function subscribeMobile(listener) {
  const media = window.matchMedia(mobileQuery);
  media.addEventListener('change', listener);
  return () => media.removeEventListener('change', listener);
}

function Toast({ toast, store }) {
  const pause = (reason, paused) => store.pause(toast.id, reason, paused);
  return (
    <div className={`toast toast--${toast.type}${toast.leaving ? ' toast--leaving' : ''}`}
      onPointerEnter={(event) => { if (event.pointerType !== 'touch') pause('pointer', true); }}
      onPointerLeave={() => { pause('pointer', false); pause('press', false); }}
      onPointerDown={() => pause('press', true)}
      onPointerUp={() => pause('press', false)}
      onPointerCancel={() => pause('press', false)}
      onFocusCapture={() => pause('focus', true)}
      onBlurCapture={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) pause('focus', false); }}>
      <span className="toast-symbol"><ToastIcon name={toast.icon} type={toast.type} /></span>
      <div className="toast-copy" tabIndex={0} role={toast.type === 'error' ? 'alert' : 'status'} aria-atomic="true">
        <span className="toast-kind">{types[toast.type]}</span>
        <p className="toast-message">{toast.message}</p>
        {toast.description && <p className="toast-description">{toast.description}</p>}
      </div>
      <button className="toast-close" type="button" disabled={toast.leaving} onClick={() => store.dismiss(toast.id)} aria-label={`Cerrar mensaje: ${toast.message}`}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" /></svg>
      </button>
    </div>
  );
}

export default function ToastProvider({ children }) {
  const [store] = useState(() => createToastStore({ exitDuration: 200 }));
  const mobile = useSyncExternalStore(subscribeMobile, isMobile, () => false);
  const { visible, pending } = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);
  useEffect(() => { store.setLimit(mobile ? 1 : 3); }, [store, mobile]);
  useEffect(() => {
    const visibility = () => store.pauseAll('hidden', document.hidden);
    visibility();
    store.pauseAll('unmounted', false);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      document.removeEventListener('visibilitychange', visibility);
      store.pauseAll('unmounted', true);
    };
  }, [store]);
  const api = useMemo(() => ({
    success: (message, options) => store.notify('success', message, options),
    error: (message, options) => store.notify('error', message, options),
    warning: (message, options) => store.notify('warning', message, options),
    info: (message, options) => store.notify('info', message, options),
    dismiss: store.dismiss,
  }), [store]);
  return <ToastContext.Provider value={api}>{children}{createPortal(
    <section className="toast-region" aria-label="Mensajes del sistema">
      {visible.map((toast) => <Toast key={toast.id} toast={toast} store={store} />)}
      {pending > 0 && <p className="toast-pending">{pending} {pending === 1 ? 'mensaje pendiente' : 'mensajes pendientes'} · Cierra un aviso para ver el siguiente</p>}
    </section>, document.body,
  )}</ToastContext.Provider>;
}
