import { useEffect, useRef, useState } from 'react';
import ConfirmDialog from './ConfirmDialog.jsx';
import PdfPreview from './PdfPreview.jsx';
import QuotePanel from './QuotePanel.jsx';
import { randomId } from '../utils/randomId.js';
import { useToast, notificationMessages } from './notifications/useToast.js';
import { listItems } from '../api/inventory.js';
import { formatDateTime as date, formatKm, formatMoney as amount } from '../utils/format.js';

export default function WorkOrderDetail({ order, onBack, onOrderChange, changeStatus, addPart, updateDiagnosis, loadItems = listItems }) {
  const [copyMessage, setCopyMessage] = useState('');
  const [pdfOpen, setPdfOpen] = useState(false);
  const [nextStatus, setNextStatus] = useState('');
  const [partsOpen, setPartsOpen] = useState(false);
  const [catalog, setCatalog] = useState(null);
  const [catalogError, setCatalogError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [search, setSearch] = useState('');
  const [quantities, setQuantities] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [diagnosis, setDiagnosis] = useState(order?.diagnosis || '');
  const [diagnosisError, setDiagnosisError] = useState('');
  const mounted = useRef(true);
  const pendingRequests = useRef(new Map());
  const toast = useToast();
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  useEffect(() => {
    if (!partsOpen) return;
    let active = true;
    loadItems().then((data) => {
      if (!Array.isArray(data)) throw new Error('Invalid inventory');
      if (active) { setCatalog(data); setCatalogError(false); }
    }).catch(() => { if (active) setCatalogError(true); });
    return () => { active = false; };
  }, [partsOpen, attempt, loadItems]);
  async function saveStatus() {
    if (busy) return;
    setBusy(true); setError('');
    try {
      const statusId = order.allowedStatuses.find((status) => status.code === nextStatus)?.id;
      if (!statusId) throw new Error('Estado no disponible');
      const updated = await changeStatus(order.id, statusId);
      if (!updated?.id || !updated.status) throw new Error('Invalid order');
      if (!mounted.current) return;
      onOrderChange(updated); setNextStatus(''); toast.success(notificationMessages.orderStatusUpdated, { icon: 'save' });
    } catch { if (mounted.current) setError('No pudimos actualizar el estado. Intenta nuevamente.'); }
    finally { if (mounted.current) setBusy(false); }
  }
  async function saveDiagnosis() {
    if (busy) return;
    setBusy(true); setDiagnosisError('');
    try {
      const updated = await updateDiagnosis(order.id, diagnosis.trim());
      if (!updated?.id || !updated.status) throw new Error('Invalid order');
      if (!mounted.current) return;
      onOrderChange(updated); toast.success(notificationMessages.diagnosisUpdated, { icon: 'save' });
    } catch { if (mounted.current) setDiagnosisError('No pudimos guardar el diagnóstico. Intenta nuevamente.'); }
    finally { if (mounted.current) setBusy(false); }
  }
  async function associate(item) {
    if (busy) return;
    const quantity = Number(quantities[item.id] ?? 1);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > item.current_stock) { setError('Ingresa una cantidad entera entre 1 y el stock disponible.'); return; }
    const key = `${order.id}:${item.id}:${quantity}`;
    const requestId = pendingRequests.current.get(key) || randomId();
    pendingRequests.current.set(key, requestId);
    setBusy(true); setError('');
    try {
      const updated = await addPart(order.id, item.id, quantity, requestId);
      if (!updated?.id || !Array.isArray(updated.parts)) throw new Error('Invalid order');
      if (!mounted.current) return;
      pendingRequests.current.delete(key); onOrderChange(updated);
      const stock = updated.parts.find((part) => String(part.itemId) === String(item.id))?.currentStock;
      if (stock !== undefined) setCatalog((previous) => previous?.map((entry) => entry.id === item.id ? { ...entry, current_stock: stock } : entry));
      toast.success(notificationMessages.orderPartAdded, { icon: 'create' });
    } catch { if (mounted.current) setError('No pudimos agregar el repuesto. El stock pudo cambiar; actualiza la lista antes de reintentar.'); }
    finally { if (mounted.current) setBusy(false); }
  }
  const parts = order.parts || [];
  const items = (catalog || []).filter((item) => `${item.name} ${item.sku}`.toLowerCase().includes(search.trim().toLowerCase()));
  const allowed = order.allowedStatuses || [];
  return <section className="work-orders">
    <button className="ot-back" onClick={onBack}>← Volver a órdenes de trabajo</button>
    <header className="ot-heading"><div><h1>OT #{order.folio}</h1><p>{order.vehicle.plate} · {order.vehicle.label || 'Vehículo'} · Ingreso {date(order.createdAt)}</p></div><span className="ot-status">{order.status.name}</span></header>
    <div className="ot-grid"><div className="ot-stack">
      <QuotePanel order={order} />
      <section className="ot-card"><header><h2>Informe de la orden</h2></header><div className="ot-card-body"><p className="ot-help">Revisa o descarga el informe técnico de esta atención.</p><button type="button" className="ot-button" onClick={() => setPdfOpen(true)}>Ver informe PDF</button></div></section><section className="ot-card"><header><h2>Vehículo y cliente</h2></header><dl className="ot-card-body ot-meta">{[['Cliente', order.client.name], ['RUT', order.client.rut], ['Teléfono', order.client.phone], ['Correo electrónico', order.client.email || 'No indicado'], ['Patente', order.vehicle.plate], ['Mecánico asignado', order.mechanicName || 'Sin asignar']].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></section>
      <section className="ot-card"><header><h2>Repuestos asociados</h2><button className="ot-button primary" disabled={order.canAddParts !== true || busy} onClick={() => { setPartsOpen(true); setError(''); }}>+ Agregar repuesto</button></header><div className="ot-table-wrap"><table className="ot-table"><caption className="sr-only">Repuestos de la orden</caption><thead><tr><th>Repuesto</th><th>Cantidad</th><th>Precio unitario</th><th>Subtotal</th></tr></thead><tbody>{parts.map((part) => <tr key={part.id}><td><strong>{part.name}</strong><small>{part.sku}</small></td><td>{part.quantity}</td><td>{amount(part.unitPrice)}</td><td>{amount(part.quantity * part.unitPrice)}</td></tr>)}</tbody></table></div>{!parts.length && <p className="ot-empty">Esta orden todavía no tiene repuestos asociados.</p>}{parts.length > 0 && <p className="ot-card-body ot-help">Total de repuestos: <strong>{amount(parts.reduce((total, part) => total + part.quantity * part.unitPrice, 0))}</strong></p>}</section>
      <section className="ot-card"><header><h2>Condición de ingreso</h2></header><div className="ot-card-body">{order.checkIn ? <><dl className="ot-meta">{[['Odómetro', formatKm(order.checkIn.odometer)], ['Combustible', order.checkIn.fuel || 'No registrado'], ['Rueda de repuesto', order.checkIn.spare == null ? 'Sin revisar' : order.checkIn.spare ? 'Presente' : 'No presente'], ['Gata y herramientas', order.checkIn.tools == null ? 'Sin revisar' : order.checkIn.tools ? 'Presentes' : 'No presentes'], ...(order.checkIn.additionalEquipment || []).map(item => [item.name, item.present === null ? 'Sin revisar' : item.present ? 'Presente' : 'No presente'])].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><p className="ot-help">Observaciones de ingreso</p><p className="ot-note">{order.checkIn.notes || 'No registradas.'}</p><div className="ot-gallery">{(order.checkIn.photos || []).map((photo, index) => <a key={photo.id} href={photo.url} target="_blank" rel="noreferrer" aria-label={`Abrir fotografía de ingreso ${index + 1}`}><img src={photo.url} alt={`Condición de ingreso ${index + 1}`} loading="lazy" /></a>)}</div></> : <p className="ot-help">No hay información de ingreso disponible.</p>}</div></section>
      <section className="ot-card"><header><h2>Diagnóstico técnico</h2></header><div className="ot-card-body">{order.status.code === 'ENTREGADO' ? <p className="ot-note">{order.diagnosis || 'No se registró un diagnóstico técnico.'}</p> : order.status.code === 'RECEPCIONADO' ? <p className="ot-help">El vehículo debe estar en fase de Diagnóstico para registrar el diagnóstico técnico.</p> : <><div className="ot-diagnosis-editor"><textarea className="ot-input" rows="4" aria-label="Diagnóstico técnico" placeholder="Describe el diagnóstico entregado al cliente por el mecánico." value={diagnosis} disabled={busy} onChange={(event) => { setDiagnosis(event.target.value); setDiagnosisError(''); }} /><button className="ot-button primary" disabled={busy} onClick={saveDiagnosis}>{busy ? 'Guardando…' : 'Guardar diagnóstico'}</button></div>{diagnosisError && <p className="ot-error" role="alert">{diagnosisError}</p>}</>}</div></section>
    </div><aside className="ot-stack">
      <section className="ot-card"><header><h2>Avance de la atención</h2></header><div className="ot-card-body"><label><span className="ot-help">Actualizar estado</span><select className="ot-input" value="" disabled={busy || !allowed.length} onChange={(event) => { setNextStatus(event.target.value); setError(''); }}><option value="">{allowed.length ? 'Seleccionar nuevo estado' : 'Sin cambios disponibles'}</option>{allowed.map((status) => <option key={status.code} value={status.code}>{status.name}</option>)}</select></label><p className="ot-help">El estado registrado permite al cliente consultar el avance de su atención.</p><dl className="ot-meta"><div><dt>Entrega estimada</dt><dd>{date(order.estimatedDeliveryAt)}</dd></div><div><dt>Última actualización</dt><dd>{date(order.updatedAt)}</dd></div></dl></div></section>
      <section className="ot-card"><header><h2>Historial de estados</h2></header>{order.history?.length ? <ol className="ot-history">{order.history.map((entry) => <li key={entry.id}><strong>{entry.name}</strong><small>{date(entry.createdAt)}{entry.actor ? ` · ${entry.actor}` : ''}</small></li>)}</ol> : <p className="ot-empty">Sin movimientos registrados.</p>}</section>
      {order.trackingCode && <section className="ot-card"><header><h2>Seguimiento del cliente</h2></header><div className="ot-card-body"><p className="ot-help">Orden N.° {order.folio}</p><p><strong>{order.trackingCode.replace(/^AJ(.{4})(.{4})(.{4})$/, 'AJ-$1-$2-$3')}</strong></p><label className="ot-help" htmlFor="tracking-link">Enlace de seguimiento</label><input id="tracking-link" className="ot-input" readOnly value={`${window.location.origin}/seguimiento/${order.trackingCode.replace(/^AJ(.{4})(.{4})(.{4})$/, 'AJ-$1-$2-$3')}`} onFocus={event => event.target.select()} /><button type="button" className="ot-button" onClick={async () => { try { await navigator.clipboard.writeText(document.getElementById('tracking-link').value); setCopyMessage('Enlace copiado.'); } catch { document.getElementById('tracking-link').select(); setCopyMessage('Selecciona y copia el enlace.'); } }}>Copiar enlace</button><p className="ot-help" role="status">{copyMessage || 'Comparte este enlace solo con el cliente.'}</p></div></section>}
    </aside></div>
    {pdfOpen && <PdfPreview order={order} onClose={() => setPdfOpen(false)} />}
    {nextStatus && <ConfirmDialog title="Actualizar estado de la orden" confirmLabel="Actualizar estado" busyLabel="Actualizando…" busy={busy} error={error} onCancel={() => setNextStatus('')} onConfirm={saveStatus}><p>OT #{order.folio} pasará de <strong>{order.status.name}</strong> a <strong>{allowed.find((status) => status.code === nextStatus)?.name}</strong>.</p><p className="ot-help">Este cambio actualizará el avance de la atención.</p></ConfirmDialog>}
    {partsOpen && <ConfirmDialog title="Agregar repuestos" confirmLabel="Listo" cancelLabel="Cerrar" busy={busy} error={error} onCancel={() => setPartsOpen(false)} onConfirm={() => setPartsOpen(false)}><p>Agrega los repuestos utilizados en OT #{order.folio}. Cada asociación descontará su cantidad del inventario.</p><div className="ot-parts-search"><label><span className="sr-only">Buscar repuestos</span><input className="ot-input" placeholder="Buscar por nombre o SKU…" value={search} onChange={(event) => setSearch(event.target.value)} /></label>{catalogError ? <div role="alert"><p>No pudimos cargar el inventario.</p><button className="ot-button" disabled={busy} onClick={() => { setCatalogError(false); setCatalog(null); setAttempt((value) => value + 1); }}>Reintentar</button></div> : !catalog ? <p role="status">Cargando repuestos…</p> : <div className="ot-parts-results">{items.map((item) => <div className="ot-part-row" key={item.id}><div><strong>{item.name}</strong><small>{item.sku} · {item.current_stock} disponibles</small></div><div className="ot-part-actions"><input className="ot-input" type="number" inputMode="numeric" min="1" max={item.current_stock} step="1" aria-label={`Cantidad de ${item.name}`} value={quantities[item.id] ?? 1} disabled={busy || item.current_stock < 1} onChange={(event) => setQuantities((previous) => ({ ...previous, [item.id]: event.target.value }))} /><button className="ot-button primary" disabled={busy || item.current_stock < 1} onClick={() => associate(item)}>{item.current_stock < 1 ? 'Sin stock' : 'Agregar'}</button></div></div>)}{!items.length && <p className="ot-empty">No hay repuestos que coincidan.</p>}</div>}<button className="ot-button" disabled={busy} onClick={() => { setCatalog(null); setAttempt((value) => value + 1); }}>Actualizar disponibilidad</button></div></ConfirmDialog>}
  </section>;
}
