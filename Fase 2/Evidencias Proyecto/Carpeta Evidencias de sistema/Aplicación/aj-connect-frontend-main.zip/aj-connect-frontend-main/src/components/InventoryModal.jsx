import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useDialogFocus } from '../hooks/useDialogFocus.js';
import {
  createItem,
  erroresPorCampo,
  mensajeDeError,
  updateItem,
} from '../api/inventory.js';

const formularioVacio = {
  sku: '',
  name: '',
  description: '',
  category: '',
  unit_price: '',
  current_stock: '',
  minimum_stock: '',
};

const campoClase =
  'w-full rounded-lg border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--ink)] placeholder-[var(--muted)] outline-none transition focus:border-emerald-500';
const campoErrorClase = 'border-red-500/60 focus:border-red-500';

function Campo({ etiqueta, error, obligatorio, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-[var(--muted)]">
        {etiqueta}
        {obligatorio ? <span className="ml-1 text-[var(--accent)]">*</span> : null}
      </span>
      {children}
      {error ? (
        <span className="mt-1 block text-xs text-[var(--danger)]">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-xs text-[var(--muted)]">{hint}</span>
      ) : null}
    </label>
  );
}

export default function InventoryModal({ item, categorias, onCerrar, onGuardado }) {
  const esEdicion = Boolean(item);
  const dialog = useRef(null);
  useDialogFocus(dialog);

  const [formulario, setFormulario] = useState(
    esEdicion
      ? {
          sku: item.sku,
          name: item.name,
          description: item.description ?? '',
          category: String(item.category),
          unit_price: String(item.unit_price),
          current_stock: String(item.current_stock),
          minimum_stock: String(item.minimum_stock),
        }
      : formularioVacio,
  );
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState('');
  const [enviando, setEnviando] = useState(false);

  // Cerrar con Escape. Se deshabilita mientras se guarda para no perder el envío.
  useEffect(() => {
    function alPresionarEscape(evento) {
      if (evento.key === 'Escape' && !enviando) onCerrar();
    }

    window.addEventListener('keydown', alPresionarEscape);
    return () => window.removeEventListener('keydown', alPresionarEscape);
  }, [enviando, onCerrar]);

  function cambiarCampo(evento) {
    const { name, value } = evento.target;
    setFormulario((previo) => ({ ...previo, [name]: value }));
    setErrores((previos) => ({ ...previos, [name]: undefined }));
  }

  function validar() {
    const nuevos = {};

    if (!formulario.sku.trim()) nuevos.sku = 'El SKU es obligatorio.';
    if (!formulario.name.trim()) nuevos.name = 'El nombre es obligatorio.';
    if (!formulario.category) nuevos.category = 'Selecciona una categoría.';

    const precio = Number(formulario.unit_price);
    if (formulario.unit_price === '') nuevos.unit_price = 'El precio es obligatorio.';
    else if (!Number.isFinite(precio) || precio < 0) {
      nuevos.unit_price = 'El precio no puede ser negativo.';
    }

    const stock = Number(formulario.current_stock);
    if (formulario.current_stock === '') nuevos.current_stock = 'El stock actual es obligatorio.';
    else if (!Number.isInteger(stock) || stock < 0) {
      nuevos.current_stock = 'Debe ser un entero igual o mayor a 0.';
    }

    const minimo = Number(formulario.minimum_stock);
    if (formulario.minimum_stock === '') nuevos.minimum_stock = 'El stock mínimo es obligatorio.';
    else if (!Number.isInteger(minimo) || minimo < 0) {
      nuevos.minimum_stock = 'Debe ser un entero igual o mayor a 0.';
    }

    return nuevos;
  }

  async function alEnviar(evento) {
    evento.preventDefault();
    if (enviando) return;

    const nuevos = validar();
    setErrores(nuevos);
    if (Object.keys(nuevos).length > 0) return;

    setEnviando(true);
    setErrorGeneral('');

    const payload = {
      sku: formulario.sku.trim(),
      name: formulario.name.trim(),
      description: formulario.description.trim(),
      category: Number(formulario.category),
      unit_price: Number(formulario.unit_price),
      current_stock: Number(formulario.current_stock),
      minimum_stock: Number(formulario.minimum_stock),
    };

    try {
      if (esEdicion) {
        await updateItem(item.id, payload);
      } else {
        await createItem(payload);
      }
      onGuardado();
    } catch (err) {
      const porCampo = erroresPorCampo(err?.response?.data);
      if (Object.keys(porCampo).length > 0) {
        setErrores(porCampo);
      } else {
        setErrorGeneral(mensajeDeError(err));
      }
    } finally {
      setEnviando(false);
    }
  }

  const availableCategories = categorias.filter((category) => category.is_active !== false || category.id === item?.category);
  const sinCategorias = availableCategories.length === 0;

  return createPortal(
    <div className="admin-modal-layer fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="admin-modal-backdrop absolute inset-0 bg-slate-950/30 backdrop-blur-sm"
        onClick={enviando ? undefined : onCerrar}
      />

      <div
        ref={dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby="titulo-modal-insumo"
        className="admin-modal-panel relative w-full max-w-2xl rounded-xl border border-[var(--line)] bg-[var(--surface)] shadow-2xl"
      >
        <header className="flex items-start justify-between gap-4 border-b border-[var(--line)] px-6 py-4">
          <div>
            <h2 id="titulo-modal-insumo" className="text-lg font-bold text-[var(--ink)]">
              {esEdicion ? 'Editar insumo' : 'Nuevo insumo'}
            </h2>
            <p className="mt-0.5 text-xs text-[var(--muted)]">
              {esEdicion ? item.sku : 'Completa los datos para registrarlo en el inventario.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onCerrar}
            disabled={enviando}
            aria-label="Cerrar"
            className="rounded-lg px-2 py-1 text-xl leading-none text-[var(--muted)] transition hover:bg-[var(--hover)] hover:text-[var(--ink)] disabled:opacity-40"
          >
            &times;
          </button>
        </header>

        <form onSubmit={alEnviar} noValidate>
          <div className="max-h-[60vh] overflow-y-auto px-6 py-5">
            {errorGeneral ? (
              <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-[var(--danger)]">
                {errorGeneral}
              </div>
            ) : null}

            {sinCategorias ? (
              <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-[var(--warning)]">
                No hay categorías activas. Cierra este formulario y abre la pestaña «Categorías» para
                agregar una, o solicita ayuda a administración.
              </div>
            ) : null}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Campo etiqueta="SKU" error={errores.sku} obligatorio>
                <input
                  type="text"
                  name="sku"
                  value={formulario.sku}
                  onChange={cambiarCampo}
                  disabled={enviando}
                  placeholder="ACE-5W30-01"
                  maxLength={50}
                  className={`${campoClase} ${errores.sku ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo etiqueta="Categoría" error={errores.category} obligatorio>
                <select
                  name="category"
                  value={formulario.category}
                  onChange={cambiarCampo}
                  disabled={enviando || sinCategorias}
                  className={`${campoClase} ${errores.category ? campoErrorClase : ''} ${
                    formulario.category ? '' : 'text-[var(--muted)]'
                  }`}
                >
                  <option value="">Selecciona una categoría</option>
                  {availableCategories.map((categoria) => (
                    <option key={categoria.id} value={categoria.id} className="text-[var(--ink)]">
                      {categoria.name}{categoria.is_active === false ? ' (archivada)' : ''}
                    </option>
                  ))}
                </select>
              </Campo>

              <div className="sm:col-span-2">
                <Campo etiqueta="Nombre" error={errores.name} obligatorio>
                  <input
                    type="text"
                    name="name"
                    value={formulario.name}
                    onChange={cambiarCampo}
                    disabled={enviando}
                    placeholder="Aceite sintético 5W-30"
                    maxLength={150}
                    className={`${campoClase} ${errores.name ? campoErrorClase : ''}`}
                  />
                </Campo>
              </div>

              <div className="sm:col-span-2">
                <Campo etiqueta="Descripción" error={errores.description}>
                  <textarea
                    name="description"
                    value={formulario.description}
                    onChange={cambiarCampo}
                    disabled={enviando}
                    rows={3}
                    placeholder="Opcional"
                    className={`${campoClase} resize-y ${errores.description ? campoErrorClase : ''}`}
                  />
                </Campo>
              </div>

              <Campo etiqueta="Precio unitario" error={errores.unit_price} obligatorio>
                <input
                  type="number"
                  name="unit_price"
                  value={formulario.unit_price}
                  onChange={cambiarCampo}
                  disabled={enviando}
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  className={`${campoClase} tabular-nums ${errores.unit_price ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo etiqueta="Stock mínimo" error={errores.minimum_stock} obligatorio>
                <input
                  type="number"
                  name="minimum_stock"
                  value={formulario.minimum_stock}
                  onChange={cambiarCampo}
                  disabled={enviando}
                  min="0"
                  step="1"
                  placeholder="5"
                  className={`${campoClase} tabular-nums ${errores.minimum_stock ? campoErrorClase : ''}`}
                />
              </Campo>

              <Campo etiqueta="Stock actual" error={errores.current_stock} obligatorio>
                <input
                  type="number"
                  name="current_stock"
                  value={formulario.current_stock}
                  onChange={cambiarCampo}
                  disabled={enviando}
                  min="0"
                  step="1"
                  placeholder="0"
                  className={`${campoClase} tabular-nums ${errores.current_stock ? campoErrorClase : ''}`}
                />
              </Campo>
            </div>
          </div>

          <footer className="flex justify-end gap-3 border-t border-[var(--line)] px-6 py-4">
            <button
              type="button"
              onClick={onCerrar}
              disabled={enviando}
              className="rounded-lg border border-[var(--line)] px-4 py-2 text-sm font-medium text-[var(--ink)] transition hover:bg-[var(--hover)] disabled:opacity-40"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={enviando || sinCategorias}
              className="rounded-lg bg-[var(--button)] px-4 py-2 text-sm font-semibold text-[var(--button-text)] transition hover:bg-[var(--button-hover)] disabled:cursor-not-allowed disabled:opacity-40"
            >
              {enviando ? 'Guardando…' : esEdicion ? 'Guardar cambios' : 'Crear insumo'}
            </button>
          </footer>
        </form>
      </div>
    </div>,
    document.body,
  );
}
