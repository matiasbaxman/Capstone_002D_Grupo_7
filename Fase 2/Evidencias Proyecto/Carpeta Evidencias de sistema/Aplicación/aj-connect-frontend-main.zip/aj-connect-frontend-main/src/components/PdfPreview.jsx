import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { getWorkOrderPdf, getQuotePdf } from '../api/workshop.js';
import './PdfPreview.css';

export default function PdfPreview({ order, quote, onClose }) {
  const dialog = useRef(null);
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const quoteId = quote?.id;
  const title = quoteId ? `Cotización COT-${quoteId.slice(0, 8).toUpperCase()}` : `Informe de la orden N.° ${order.folio}`;
  const filename = quoteId ? `Cotizacion_AJ_${quoteId.slice(0, 8).toUpperCase()}.pdf` : `Informe_AJ_${order.folio}.pdf`;
  useEffect(() => { dialog.current?.showModal(); }, []);
  useEffect(() => {
    const controller = new AbortController(); let objectUrl;
    (quoteId ? getQuotePdf(quoteId, controller.signal) : getWorkOrderPdf(order.id, controller.signal)).then(blob => {
      if (controller.signal.aborted) return;
      objectUrl = URL.createObjectURL(blob); setUrl(objectUrl); setError('');
    }).catch(async err => {
      if (controller.signal.aborted) return;
      let message = 'No pudimos cargar el documento. Intenta nuevamente.';
      if (err.response?.status === 400 && err.response.data instanceof Blob) {
        try { const data = JSON.parse(await err.response.data.text()); if (data.detail) message = data.detail; } catch { /* respuesta no interpretable */ }
      }
      if (!controller.signal.aborted) setError(message);
    });
    return () => { controller.abort(); if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [order.id, quoteId, attempt]);
  return createPortal(<dialog ref={dialog} className="pdf-preview" aria-labelledby="pdf-title" onCancel={event => { event.preventDefault(); onClose(); }} onClick={event => { if (event.target === event.currentTarget) onClose(); }}><div className="pdf-panel"><header><div><h2 id="pdf-title">{title}</h2><p>Vista previa del documento</p></div><button type="button" onClick={onClose} aria-label="Cerrar vista previa">×</button></header><div className="pdf-content">{error ? <div role="alert"><p>{error}</p><button type="button" onClick={() => { setError(''); setAttempt(n => n + 1); }}>Reintentar</button></div> : url ? <><iframe title={title} src={url} /><p className="pdf-mobile-hint">Si tu dispositivo no muestra la vista previa, descarga el PDF para abrirlo.</p></> : <p role="status">Preparando documento…</p>}</div><footer>{url && <a href={url} download={filename}>Descargar PDF</a>}<button type="button" onClick={onClose}>Cerrar</button></footer></div></dialog>, document.body);
}
