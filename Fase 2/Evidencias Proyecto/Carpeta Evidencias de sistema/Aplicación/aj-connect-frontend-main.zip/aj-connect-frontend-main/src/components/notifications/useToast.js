import { createContext, useContext } from 'react';
export const ToastContext = createContext(null);
export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast requiere ToastProvider');
  return context;
}
export const notificationMessages = {
  logoutSuccess: 'Sesión cerrada correctamente.',
  loginSuccess: 'Sesión iniciada. Bienvenido a A&J Connect.',
  categoryCreated: 'Categoría creada',
  categoryUpdated: 'Cambios de la categoría guardados',
  categoryArchived: 'Categoría archivada',
  categoryRestored: 'Categoría reactivada',
  checkInCreated: 'Check-in registrado',
  itemCreated: 'Insumo creado',
  itemUpdated: 'Cambios del insumo guardados',
  appointmentUpdated: 'Cita actualizada correctamente.',
  orderStatusUpdated: 'Estado de la orden actualizado',
  diagnosisUpdated: 'Diagnóstico técnico guardado',
  orderPartAdded: 'Repuesto asociado a la orden',
};
