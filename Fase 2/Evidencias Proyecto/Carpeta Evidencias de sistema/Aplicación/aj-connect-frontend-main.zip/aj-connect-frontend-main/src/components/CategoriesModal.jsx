import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { createCategory, updateCategory, mensajeDeError } from '../api/inventory.js';
import { useDialogFocus } from '../hooks/useDialogFocus.js';

export default function CategoriesModal({ category, onClose, onSaved }) {
  const dialog = useRef(null);
  const [name, setName] = useState(category?.name || '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  useDialogFocus(dialog);
  useEffect(() => {
    const escape = (event) => { if (event.key === 'Escape' && !saving) onClose(); };
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, [onClose, saving]);
  async function submit(event) {
    event.preventDefault();
    if (saving) return;
    const normalized = name.trim().replace(/\s+/g, ' ');
    if (!normalized) { setError('Ingresa un nombre para la categoría.'); return; }
    setSaving(true); setError('');
    try {
      const saved = category ? await updateCategory(category.id, {name: normalized}) : await createCategory({name: normalized});
      onSaved(saved);
    } catch (err) { setError(mensajeDeError(err)); }
    finally { setSaving(false); }
  }
  return createPortal(
    <div className="admin-modal-layer fixed inset-0 flex items-center justify-center p-4">
      <div className="admin-modal-backdrop absolute inset-0 bg-slate-950/30 backdrop-blur-sm" onClick={saving ? undefined : onClose} />
      <section ref={dialog} role="dialog" aria-modal="true" aria-labelledby="categories-title" className="admin-modal-panel categories-panel relative w-full max-w-lg rounded-xl border border-[var(--line)] bg-[var(--surface)] shadow-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-[var(--line)] p-5"><div><h2 id="categories-title" className="text-lg font-bold">{category ? 'Editar categoría' : 'Nueva categoría'}</h2><p className="mt-1 text-sm text-[var(--muted)]">{category ? 'Los insumos conservarán esta categoría.' : 'Organiza los insumos de tu inventario.'}</p></div><button onClick={onClose} disabled={saving} aria-label="Cerrar categorías" className="px-2 text-xl disabled:opacity-40">×</button></header>
        <form onSubmit={submit} noValidate className="p-5">
          <label htmlFor="category-name" className="mb-2 block text-sm font-medium">Nombre</label>
          <input id="category-name" value={name} onChange={(event) => { setName(event.target.value); setError(''); }} disabled={saving} maxLength={100} placeholder="Ej. Aceites" aria-invalid={Boolean(error)} aria-describedby={error ? 'category-error' : undefined} className="w-full rounded-lg border border-[var(--line)] bg-[var(--chrome)] px-3 py-2 text-sm" />
          {error && <p id="category-error" role="alert" className="mt-2 text-sm text-[var(--danger)]">{error}</p>}
          <div className="mt-6 flex justify-end gap-3"><button type="button" onClick={onClose} disabled={saving} className="rounded-lg border border-[var(--line)] px-4 py-2 text-sm disabled:opacity-40">Cancelar</button><button type="submit" disabled={saving} className="rounded-lg bg-[var(--button)] px-4 py-2 text-sm font-semibold text-[var(--button-text)] disabled:opacity-40">{saving ? 'Guardando…' : category ? 'Guardar cambios' : 'Crear categoría'}</button></div>
        </form>
      </section>
    </div>, document.body,
  );
}
