import { useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import { useDialogFocus } from '../hooks/useDialogFocus.js';
import './ConfirmDialog.css';

export default function ConfirmDialog({ title, children, confirmLabel = 'Confirmar', cancelLabel = 'Cancelar', busyLabel = 'Procesando…', variant = 'default', busy = false, error = '', onCancel, onConfirm }) {
  const dialog = useRef(null);
  const id = useId();
  useDialogFocus(dialog);
  useEffect(() => {
    function escape(event) { if (event.key === 'Escape' && !busy) { event.preventDefault(); onCancel(); } }
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, [busy, onCancel]);
  return createPortal(<div className="admin-modal-layer fixed inset-0 flex items-center justify-center p-4">
    <div className="admin-modal-backdrop absolute inset-0 bg-slate-950/30 backdrop-blur-sm" onClick={busy ? undefined : onCancel} aria-hidden="true" />
    <section ref={dialog} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={`${id}-title`} aria-describedby={`${id}-description`} aria-busy={busy} className="admin-modal-panel relative w-full max-w-lg rounded-xl border border-[var(--line)] bg-[var(--surface)] p-6 text-[var(--ink)] shadow-2xl">
      <h2 id={`${id}-title`} className="text-lg font-bold">{title}</h2>
      <div id={`${id}-description`} className="mt-3 text-sm text-[var(--muted)]">{children}</div>
      {error && <p role="alert" className="mt-3 text-sm text-[var(--danger)]">{error}</p>}
      <div className="mt-6 flex flex-wrap justify-end gap-3">
        <button type="button" onClick={onCancel} disabled={busy} className="confirm-dialog-button confirm-dialog-cancel rounded-lg border border-[var(--line)] px-4 py-2 text-sm disabled:opacity-40">{cancelLabel}</button>
        <button type="button" onClick={busy ? undefined : onConfirm} disabled={busy} className={`confirm-dialog-button ${variant === 'danger' ? 'confirm-dialog-danger' : 'confirm-dialog-primary'} rounded-lg border px-4 py-2 text-sm font-semibold disabled:opacity-40 ${variant === 'danger' ? 'border-[var(--danger-line)] bg-[var(--danger-bg)] text-[var(--danger)]' : 'border-transparent bg-[var(--button)] text-[var(--button-text)]'}`}>{busy ? busyLabel : confirmLabel}</button>
      </div>
    </section>
  </div>, document.body);
}
