import { useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Mail, X } from 'lucide-react';
import { useDialogFocus } from '../hooks/useDialogFocus.js';
import './CodeVerificationDialog.css';

export default function CodeVerificationDialog({ code, onChange, onConfirm, onClose, onResend, busy, error, title = 'Revisa tu correo', description, confirmLabel = 'Continuar' }) {
  const dialog = useRef(null);
  const id = useId();
  useDialogFocus(dialog);
  useEffect(() => {
    const escape = event => { if (event.key === 'Escape' && !busy) onClose(); };
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, [busy, onClose]);
  return createPortal(<div className="code-dialog-layer">
    <div className="code-dialog-backdrop" aria-hidden="true" onClick={busy ? undefined : onClose} />
    <section className="code-dialog-panel" ref={dialog} role="dialog" aria-modal="true" aria-labelledby={`${id}-title`} aria-describedby={`${id}-description`} aria-busy={busy} tabIndex={-1}>
      <button type="button" className="code-dialog-close" aria-label="Cerrar verificación" disabled={busy} onClick={onClose}><X size={20} /></button>
      <div className="code-dialog-icon"><Mail size={27} aria-hidden="true" /></div>
      <p className="code-dialog-eyebrow">VERIFICACIÓN POR CORREO</p>
      <h2 id={`${id}-title`}>{title}</h2>
      <p id={`${id}-description`} className="code-dialog-description">{description || 'Ingresa el código de seis dígitos que enviamos a tu correo. Expira en cinco minutos.'}</p>
      <form onSubmit={event => { event.preventDefault(); if (!busy) onConfirm(); }}>
        <label htmlFor={`${id}-code`} className="code-dialog-label">Código de seis dígitos</label>
        <input id={`${id}-code`} className="code-dialog-input" type="text" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={event => onChange(event.target.value.replace(/\D/g, ''))} disabled={busy} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-error` : undefined} required />
        {error && <p id={`${id}-error`} role="alert" className="code-dialog-error">{error}</p>}
        <button className="code-dialog-submit" disabled={busy || code.length !== 6}>{busy ? 'Procesando…' : confirmLabel}</button>
      </form>
      <p className="code-dialog-help">¿No lo encuentras? Revisa también spam.</p>
      <button type="button" className="code-dialog-resend" disabled={busy} onClick={onResend}>Solicitar otro código</button>
    </section>
  </div>, document.body);
}
