import { useState } from 'react';
import '@fontsource-variable/manrope';
import './Login.css';
import { login } from '../api/auth.js';
import { saveSession } from '../api/session.js';

function EyeIcon({ visible }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" />
      <circle cx="12" cy="12" r="3" />
      {visible && <path d="m3 3 18 18" />}
    </svg>
  );
}

export default function Login({ onLoginSuccess }) {

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  const [capsLock, setCapsLock] = useState(false);
  const [remember, setRemember] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    if (loading) return;
    setError('');
    setLoading(true);
    try {
      const data = await login(username.trim(), password);
      if (onLoginSuccess) onLoginSuccess(data, remember);
      else { saveSession(data, remember); window.location.assign('/dashboard'); }
    } catch (err) {
      if (!err.response) setError('No pudimos conectar con el servidor. Intenta nuevamente en unos momentos.');
      else if ([400, 401].includes(err.response.status)) setError('El usuario o la contraseña no son correctos. Revisa tus datos e intenta nuevamente.');
      else if (err.response.status === 429) setError('Demasiados intentos. Espera un momento antes de volver a ingresar.');
      else setError('No pudimos iniciar tu sesión. Intenta nuevamente en unos momentos.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="login-page">
      <section className="login-brand" aria-label="A&J Connect">
        <a className="login-wordmark" href="/" aria-label="A&J Connect, volver al inicio">
          <span className="login-brand-initials">A&J</span>
          <span className="login-product-name">connect.</span>
        </a>
        <div className="login-brand-content">
          <h1>Tu taller.<br />Todo en orden.</h1>
          <p>Un espacio para trabajar mejor.<br />La gestión de tu taller empieza aquí.</p>
          <div className="login-line-art" aria-hidden="true"><span /><span /><span /><span /></div>
        </div>
      </section>

      <section className="login-form-panel" aria-labelledby="login-title">
        <a className="login-mobile-brand" href="/" aria-label="A&J Connect, volver al inicio"><span className="login-brand-initials">A&J</span><span className="login-product-name">connect.</span></a>
        <div className="login-form-content">
          <h2 id="login-title">Bienvenido de nuevo</h2>
          <p className="login-intro">Ingresa tus credenciales para continuar.</p>

          <form onSubmit={handleSubmit} aria-busy={loading}>
            <div className="login-field">
              <label htmlFor="login-username">Usuario</label>
              <input id="login-username" name="username" autoComplete="username" autoCapitalize="none" spellCheck={false} required value={username} onChange={(event) => setUsername(event.target.value)} disabled={loading} placeholder="Tu nombre de usuario" />
            </div>
            <div className="login-field">
              <label htmlFor="login-password">Contraseña</label>
              <div className="login-password-wrap">
                <input id="login-password" name="password" type={visible ? 'text' : 'password'} autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} onKeyDown={(event) => setCapsLock(event.getModifierState('CapsLock'))} onKeyUp={(event) => setCapsLock(event.getModifierState('CapsLock'))} onBlur={() => setCapsLock(false)} disabled={loading} placeholder="Ingresa tu contraseña" aria-describedby={capsLock ? 'login-capslock' : undefined} />
                <button type="button" className="login-eye" onClick={() => setVisible(!visible)} aria-label={visible ? 'Ocultar contraseña' : 'Mostrar contraseña'} aria-pressed={visible} disabled={loading}><EyeIcon visible={visible} /></button>
              </div>
              {capsLock && <p id="login-capslock" className="login-capslock" role="status">Las mayúsculas están activadas.</p>}
            </div>
            <label className="login-remember"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} disabled={loading} /> Mantener sesión iniciada</label>
            {error && <div className="login-error" role="alert">{error}</div>}
            <button className="login-submit" type="submit" disabled={loading}>
              {loading ? <><span className="login-spinner" aria-hidden="true" /> Ingresando…</> : <>Iniciar sesión <span aria-hidden="true">→</span></>}
            </button>
          </form>
          <a className="login-back" href="/"><span aria-hidden="true">←</span> Volver al inicio</a>
        </div>
        <span className="login-panel-caption">© {new Date().getFullYear()} A&J Automotriz. Todos los derechos reservados.</span>
      </section>
    </main>
  );
}
