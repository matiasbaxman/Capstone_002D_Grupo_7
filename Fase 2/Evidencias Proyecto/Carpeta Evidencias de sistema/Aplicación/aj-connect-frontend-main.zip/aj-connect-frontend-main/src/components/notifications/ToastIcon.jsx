const shapes = {
  success: <><circle cx="12" cy="12" r="9" /><path d="m8 12 3 3 5-6" /></>,
  error: <><circle cx="12" cy="12" r="9" /><path d="m9 9 6 6m0-6-6 6" /></>,
  warning: <><path d="m12 3 10 18H2Z" /><path d="M12 9v4m0 3v1" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v6m0-10v.5" /></>,
  login: <><path d="M14 3h6v18h-6M3 12h12m-4-4 4 4-4 4" /></>,
  logout: <><path d="M12 2v10" /><path d="M6.3 5.8a9 9 0 1 0 11.4 0" /></>,
  create: <><rect x="4" y="4" width="16" height="16" rx="4" /><path d="M12 8v8m-4-4h8" /></>,
  save: <><path d="M4 3h13l4 4v14H3V3h1Z" /><path d="M7 3v6h9V3M7 21v-7h10v7" /></>,
  checkin: <><path d="m5 10 2-6h10l2 6M5 17v3m14-3v3" /><rect x="3" y="10" width="18" height="7" rx="2" /><path d="M6 13h2m8 0h2" /></>,
  archive: <><rect x="3" y="3" width="18" height="5" rx="1" /><path d="M5 8v13h14V8m-10 4h6" /></>,
  restore: <><path d="M4 10a8 8 0 1 1 0 6m0-12v6h6" /><path d="m9 14 2 2 4-4" /></>,
};
export default function ToastIcon({ name, type }) {
  return <svg className="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{shapes[name] || shapes[type] || shapes.info}</svg>;
}
