export default function InventoryTabs({ path, onNavigate }) {
  function navigate(event, url) {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault(); onNavigate(url);
  }
  return <nav className="inventory-tabs" aria-label="Secciones de inventario">{[['/dashboard/inventario', 'Insumos'], ['/dashboard/inventario/categorias', 'Categorías']].map(([url, name]) => <a key={url} href={url} aria-current={path === url ? 'page' : undefined} onClick={(event) => navigate(event, url)}>{name}</a>)}</nav>;
}
