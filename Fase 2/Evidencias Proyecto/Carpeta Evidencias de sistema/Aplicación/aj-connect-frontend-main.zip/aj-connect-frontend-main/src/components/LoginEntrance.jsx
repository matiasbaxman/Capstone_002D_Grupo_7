import { useEffect } from 'react';
import './LoginEntrance.css';

const ENTRANCE_DURATION = 1100;

export default function LoginEntrance({ onComplete }) {
  useEffect(() => {
    // The panel mounts behind this brief entrance; this is not network progress.
    const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const timer = window.setTimeout(onComplete, motion.matches ? 0 : ENTRANCE_DURATION);
    return () => window.clearTimeout(timer);
  }, [onComplete]);

  return <div className="login-entrance" style={{ '--entrance-duration': `${ENTRANCE_DURATION}ms` }}>
    <div className="login-entrance-content" role="status" aria-live="polite">
      <div className="login-entrance-brand"><strong>A&J</strong><span>connect.</span></div>
      <svg className="login-entrance-spinner" viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <circle className="login-entrance-track" cx="24" cy="24" r="17" strokeWidth="2" />
        <g className="login-entrance-orbit" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M7 24a17 17 0 0 1 34 0" />
          <path d="m36 20 5 5 4-5" />
        </g>
      </svg>
      <p className="login-entrance-caption">Abriendo tu espacio de trabajo…</p>
    </div>
  </div>;
}
