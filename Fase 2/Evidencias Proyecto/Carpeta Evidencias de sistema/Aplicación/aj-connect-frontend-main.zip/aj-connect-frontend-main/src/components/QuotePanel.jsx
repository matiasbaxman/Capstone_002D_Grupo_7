import { useEffect, useState } from 'react';
import { createQuote, emailQuote, getEmailDelivery, listQuotes } from '../api/workshop.js';
import { formatDateTime } from '../utils/format.js';
import PdfPreview from './PdfPreview.jsx';

const errorText = err => err.response?.data ? Object.values(err.response.data).flat().join(' ') : 'No pudimos conectar. Intenta nuevamente.';
const formatMoney = value => new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 2 }).format(Number(value));
export default function QuotePanel({ order }) {
  const [quotes, setQuotes] = useState(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(null);
  const [delivery, setDelivery] = useState(null);
  useEffect(() => {
    const controller = new AbortController();
    listQuotes(order.id, controller.signal).then(rows => { if (!controller.signal.aborted) setQuotes(rows); }).catch(err => { if (!controller.signal.aborted) setError(errorText(err)); });
    return () => controller.abort();
  }, [order.id, attempt]);
  useEffect(() => {
    if (!delivery || ['SENT', 'FAILED'].includes(delivery.status)) return;
    const controller = new AbortController();
    const interval = setInterval(() => {
      getEmailDelivery(delivery.id, controller.signal).then(row => { if (!controller.signal.aborted) setDelivery(row); }).catch(err => { if (!controller.signal.aborted) setError(errorText(err)); });
    }, 3000);
    return () => { controller.abort(); clearInterval(interval); };
  }, [delivery]);
  async function generate() {
    if (busy) return;
    setBusy(true); setError('');
    try { const row = await createQuote(order.id); setQuotes(current => [row, ...(current || [])]); }
    catch (err) { setError(errorText(err)); }
    finally { setBusy(false); }
  }
  async function send(quote) {
    if (busy) return;
    setBusy(true); setError('');
    try { setDelivery(await emailQuote(quote.id)); }
    catch (err) { setError(errorText(err)); }
    finally { setBusy(false); }
  }
  return <section className="ot-card"><header><h2>Cotizaciones</h2><button className="ot-button primary" type="button" disabled={busy || !order.parts?.length} onClick={generate}>Generar cotización</button></header><div className="ot-card-body"><p className="ot-help">La cotización conserva los precios netos de los repuestos de esta orden y desglosa subtotal, IVA y total.</p>{error && <div role="alert"><p>{error}</p>{quotes === null && <button type="button" className="ot-button" onClick={() => { setError(''); setAttempt(n => n + 1); }}>Reintentar</button>}</div>}{quotes === null && !error ? <p role="status">Cargando cotizaciones…</p> : quotes?.length ? <ul className="ot-quotes">{quotes.map(quote => <li key={quote.id}><h3>COT-{quote.id.slice(0, 8).toUpperCase()}</h3><p className="ot-help">{formatDateTime(quote.created_at)}</p><dl className="ot-meta"><div><dt>Subtotal neto</dt><dd>{formatMoney(quote.subtotal_amount)}</dd></div><div><dt>IVA ({Number(quote.tax_rate)}%)</dt><dd>{formatMoney(quote.tax_amount)}</dd></div><div><dt>Total</dt><dd><strong>{formatMoney(quote.total_amount)}</strong></dd></div></dl><div className="ot-quote-actions"><button type="button" className="ot-button" onClick={() => setPreview(quote)}>Ver cotización PDF</button><button type="button" className="ot-button" disabled={busy || (delivery && !['SENT', 'FAILED'].includes(delivery.status))} onClick={() => send(quote)}>Enviar por correo</button></div></li>)}</ul> : quotes && <p>Aún no hay cotizaciones. Agrega repuestos y genera una para previsualizarla.</p>}{delivery && <p role="status" className="ot-help">{delivery.status === 'SENT' ? 'Cotización enviada por correo.' : delivery.status === 'FAILED' ? 'No se pudo enviar el correo. Revisa el contacto del cliente y la configuración SMTP.' : 'Envío programado. Te mostraremos el resultado cuando termine.'}</p>}</div>{preview && <PdfPreview order={order} quote={preview} onClose={() => setPreview(null)} />}</section>;
}
