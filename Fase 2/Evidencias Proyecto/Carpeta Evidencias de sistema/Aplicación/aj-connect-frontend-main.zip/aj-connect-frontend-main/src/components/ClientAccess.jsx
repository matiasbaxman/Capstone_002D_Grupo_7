import { useState } from 'react';
import { LockKeyhole } from 'lucide-react';
import { requestClientCode, verifyClientCode } from '../api/clientAuth.js';
import { validRut, formatRut, normalizeRut } from '../utils/rutValidation.js';
import CodeVerificationDialog from './CodeVerificationDialog.jsx';

const inputClass = 'mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3';

export default function ClientAccess({ onSession }) {
  const [rut, setRut] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [step, setStep] = useState('login');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [accountMissing, setAccountMissing] = useState(false);

  function reset() { setStep('login'); setCode(''); setPassword(''); setConfirmation(''); setError(''); }
  async function submit(event) {
    event?.preventDefault();
    if (busy) return;
    if (!validRut(rut)) { setError('Ingresa un RUT válido.'); return; }
    if (step === 'password' && password !== confirmation) { setError('Las contraseñas no coinciden.'); return; }
    setBusy(true); setError(''); setAccountMissing(false);
    try {
      if (step === 'password') {
        const session = await verifyClientCode({ rut, code, password });
        reset(); onSession(session);
      } else {
        const result = await requestClientCode(rut, step === 'login' ? password : '');
        setPassword(''); setCode('');
        if (result.access) onSession(result);
        else setStep('code');
      }
    } catch (err) {
      const data = err.response?.data;
      const messages = data && typeof data === 'object'
        ? ['detail', 'rut', 'code', 'password'].flatMap(key => data[key] || []).filter(value => typeof value === 'string') : [];
      setError(messages.join(' ') || 'No pudimos completar el ingreso. Intenta nuevamente en unos segundos.');
      if (err.response?.status === 404) { setAccountMissing(true); setStep('login'); }
      else if (data?.code) { setPassword(''); setConfirmation(''); setStep('code'); }
    } finally { setBusy(false); }
  }
  const creating = step === 'password';
  return <>
    {creating && <div className="mb-5 grid size-12 place-items-center rounded-2xl bg-emerald-50 text-emerald-800"><LockKeyhole aria-hidden="true" /></div>}
    <p className="mb-2 text-xs font-bold uppercase tracking-widest text-emerald-800">{creating ? 'Último paso · Activa tu acceso' : 'Portal de clientes'}</p>
    <h1 className="text-3xl font-bold">{creating ? 'Crea tu contraseña' : 'Iniciar sesión'}</h1>
    <p className="mt-4 text-sm leading-6 text-slate-600">{creating ? `Elige una contraseña para ingresar con tu RUT ${formatRut(rut)}. La usarás en tus próximas visitas.` : 'Ingresa con tu RUT y contraseña. Si es tu primera visita, escribe solo tu RUT y te enviaremos un código para activar tu acceso.'}</p>
    {error && step !== 'code' && <p role="alert" className="my-4 rounded-xl bg-rose-50 p-4 text-rose-800">{error}{accountMissing && <a className="mt-3 block font-semibold underline" href="/agendar">Agendar una cita</a>}</p>}
    <form onSubmit={submit} className="mt-6 grid gap-5">
      {!creating && <label>RUT<input className={inputClass} value={formatRut(rut)} onChange={event => { setRut(normalizeRut(event.target.value)); setAccountMissing(false); setError(''); }} maxLength={12} autoComplete="off" autoCapitalize="characters" spellCheck={false} placeholder="12.345.678-5" disabled={busy} required /></label>}
      <label>{creating ? 'Crea tu contraseña de primer ingreso' : 'Contraseña'}<input type="password" className={inputClass} autoComplete={creating ? 'new-password' : 'current-password'} minLength={creating ? 8 : undefined} maxLength={128} value={password} onChange={event => setPassword(event.target.value)} required={creating} disabled={busy} /></label>
      {creating && <><p className="-mt-3 text-xs text-slate-500">Usa al menos 8 caracteres. Evita tu RUT y datos fáciles de adivinar.</p><label>Confirma tu contraseña<input type="password" autoComplete="new-password" className={inputClass} value={confirmation} onChange={event => setConfirmation(event.target.value)} disabled={busy} required minLength={8} maxLength={128} /></label></>}
      <button disabled={busy} className="rounded-xl bg-emerald-900 px-5 py-3 font-semibold text-white disabled:opacity-50">{busy ? 'Procesando…' : creating ? 'Crear contraseña e ingresar' : 'Ingresar'}</button>
      {creating && <button type="button" disabled={busy} className="text-sm text-emerald-800 underline" onClick={() => { setError(''); setStep('code'); }}>Volver al código</button>}
    </form>
    {step === 'code' && <CodeVerificationDialog code={code} onChange={setCode} busy={busy} error={error} onClose={reset} onResend={() => submit()} onConfirm={() => { if (/^\d{6}$/.test(code)) { setError(''); setStep('password'); } }} />}
  </>;
}
