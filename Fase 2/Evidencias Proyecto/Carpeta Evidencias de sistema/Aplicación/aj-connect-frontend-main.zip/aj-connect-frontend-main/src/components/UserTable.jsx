import { formatRut, formatPhone, formatLastLogin } from '../utils/rut.js';

const normalizeRole = (value) =>
  (value || '').toString().toUpperCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

const ROLE_STYLES = {
  ADMINISTRADOR: {
    className: 'border-emerald-500/30 bg-emerald-500/20 text-emerald-400',
  },
  MECANICO: {
    className: 'border-cyan-500/30 bg-cyan-500/20 text-cyan-400',
  },
  RECEPCIONISTA: {
    className: 'border-amber-500/30 bg-amber-500/20 text-amber-400',
  },
  CLIENTE: {
    className: 'border-slate-500/30 bg-slate-500/20 text-slate-300',
  },
};

const SUPERUSER_STYLE = 'border-purple-500/30 bg-purple-500/20 text-purple-400';
const NO_ROLE_STYLE = 'border-gray-500/30 bg-gray-500/10 text-gray-400';

function RoleBadge({ role }) {
  const rawName = typeof role === 'string' ? role : role?.name;
  const rawCode = typeof role === 'string' ? role : role?.code;
  const name = rawName || rawCode;
  const config =
    ROLE_STYLES[normalizeRole(rawName)] ||
    ROLE_STYLES[normalizeRole(rawCode)] || {
      className: 'border-emerald-500/30 bg-emerald-500/20 text-emerald-400',
    };

  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${config.className}`}
    >
      {name}
    </span>
  );
}

export default function UserTable({ users }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-[var(--line)] bg-[var(--surface)]">
      <table className="w-full text-left text-sm">
        <thead className="border-b border-[var(--line)] bg-[var(--chrome)] text-xs text-[var(--muted)]">
          <tr>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Empleado
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Usuario
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              RUT
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Correo
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Teléfono
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Último Acceso
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Roles
            </th>
          </tr>
        </thead>

        <tbody className="divide-y divide-[var(--line)]">
          {users.length === 0 ? (
            <tr>
              <td colSpan={7} className="px-4 py-12 text-center text-[var(--muted)]">
                No hay empleados registrados que coincidan con la búsqueda.
              </td>
            </tr>
          ) : (
            users.map((user) => {
              const fullName =
                user.full_name ||
                `${user.first_name || ''} ${user.last_name || ''}`.trim() ||
                user.username;
              const initials = fullName
                .split(' ')
                .filter(Boolean)
                .slice(0, 2)
                .map((w) => w[0].toUpperCase())
                .join('');
               let userRoles = [];
               if (user.is_superuser) {
                 userRoles = [];
               } else if (Array.isArray(user.roles_detail) && user.roles_detail.length > 0) {
                 userRoles = user.roles_detail;
               } else if (Array.isArray(user.roles) && user.roles.length > 0) {
                 userRoles = user.roles;
               }
               const lastLoginFormatted = formatLastLogin(user.last_login);

               return (
                 <tr key={user.id} className="transition hover:bg-[var(--chrome)]">
                   <td className="px-4 py-3">
                     <div className="flex items-center gap-3">
                       <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--line)] text-xs font-bold text-[var(--ink)]">
                         {initials || 'U'}
                       </div>
                       <div>
                         <p className="font-medium text-[var(--ink)]">{fullName}</p>
                         <p className="text-xs text-[var(--muted)]">
                           {user.is_active ? 'Activo' : 'Inactivo'}
                         </p>
                       </div>
                     </div>
                   </td>

                   <td className="px-4 py-3 font-mono text-xs text-[var(--muted)]">
                     @{user.username}
                   </td>

                   <td className="px-4 py-3 tabular-nums font-medium text-[var(--ink)]">
                     {user.rut ? formatRut(user.rut) : <span className="text-[var(--muted)]">—</span>}
                   </td>

                   <td className="px-4 py-3 text-[var(--muted)]">
                     {user.email || <span className="text-[var(--muted)]">—</span>}
                   </td>

                   <td className="px-4 py-3 tabular-nums text-[var(--muted)]">
                     {user.phone ? formatPhone(user.phone) : <span className="text-[var(--muted)]">—</span>}
                   </td>

                   <td className="px-4 py-3 text-xs">
                     {lastLoginFormatted ? (
                       <span className="font-mono tabular-nums text-[var(--ink)]">
                         {lastLoginFormatted}
                       </span>
                     ) : (
                       <span className="inline-flex items-center rounded-md border border-[var(--line)] bg-[var(--chrome)] px-2 py-0.5 text-[11px] font-medium text-[var(--muted)]">
                         Nunca
                       </span>
                     )}
                   </td>

                   <td className="px-4 py-3">
                     <div className="flex flex-wrap items-center gap-1.5">
                       {user.is_superuser === true ? (
<span
                            className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${SUPERUSER_STYLE}`}
                          >
                            Superusuario
                          </span>
                       ) : userRoles.length > 0 ? (
                          userRoles.map((role, idx) => (
                            <RoleBadge
                              key={typeof role === 'string' ? role : role.id || role.code || idx}
                              role={role}
                            />
                          ))
                        ) : (
                          <span
                            className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${NO_ROLE_STYLE}`}
                          >
                            Sin rol asignado
                          </span>
                        )}
                      </div>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}
