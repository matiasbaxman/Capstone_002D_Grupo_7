import { useState } from 'react';
import { requestProfileChange, confirmProfileChange } from '../api/clientAuth.js';
import { formatRut } from '../utils/rutValidation.js';
export default function ClientProfile({ client, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ first_name: client.first_name, last_name: client.last_name || '', email: client.email || '', phone: client.phone || '' });
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function submit(event) {
    event.preventDefault(); if (busy) return; setBusy(true); setMessage('');
    try {
      const result = sent ? await confirmProfileChange(code) : await requestProfileChange(form);
      setMessage(result.detail);
      if (sent) { setEditing(false); setSent(false); setCode(''); onSaved(); }
      else setSent(true);
    } catch (error) {
      const data = error.response?.data;
      setMessage(data && typeof data === 'object' ? Object.values(data).flat().join(' ') : 'No pudimos guardar los cambios. Intenta nuevamente.');
    } finally { setBusy(false); }
  }
  return <section><h2 className="text-xl font-bold">Datos personales</h2>{message && <p role="status" className="my-4 rounded-xl bg-slate-100 p-4">{message}</p>}{editing ? <form onSubmit={submit} className="mt-5 grid gap-4"><p className="text-sm">Para guardar los cambios enviaremos un código a tu correo actual registrado.</p>{[['first_name', 'Nombre'], ['last_name', 'Apellido'], ['email', 'Correo electrónico'], ['phone', 'Teléfono / WhatsApp (opcional)']].map(([key, label]) => <label key={key}>{label}<input className="mt-1 w-full rounded-xl border border-slate-300 p-3" value={form[key]} type={key === 'email' ? 'email' : key === 'phone' ? 'tel' : 'text'} maxLength={key === 'email' ? 255 : key === 'phone' ? 20 : 100} required={key !== 'phone'} disabled={sent || busy} onChange={event => setForm({ ...form, [key]: event.target.value })} placeholder={key === 'phone' ? '+56912345678' : undefined} /></label>)}{sent && <label>Código de autorización<input className="mt-1 w-full rounded-xl border border-slate-300 p-3" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} required value={code} onChange={event => setCode(event.target.value.replace(/\D/g, ''))} /></label>}<button disabled={busy} className="rounded-xl bg-emerald-900 p-3 font-semibold text-white">{busy ? 'Procesando…' : sent ? 'Confirmar cambios' : 'Enviar código para guardar'}</button><button type="button" disabled={busy} onClick={() => { setEditing(false); setSent(false); setCode(''); }}>Cancelar</button></form> : <><dl className="my-5 grid gap-4 break-words">{[['Nombre', client.first_name], ['Apellido', client.last_name], ['RUT', formatRut(client.rut || '')], ['Correo', client.email], ['Teléfono', client.phone || 'No indicado']].map(([label, value]) => <div key={label}><dt className="text-sm text-slate-500">{label}</dt><dd className="break-all">{value}</dd></div>)}</dl><button className="rounded-xl border border-slate-300 px-5 py-3" onClick={() => { setForm({ first_name: client.first_name, last_name: client.last_name, email: client.email, phone: client.phone || '' }); setEditing(true); setMessage(''); }}>Modificar datos</button></>}</section>;
}
