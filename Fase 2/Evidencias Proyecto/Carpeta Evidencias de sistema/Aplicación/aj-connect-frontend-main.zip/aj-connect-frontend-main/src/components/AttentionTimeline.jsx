import { formatDateTime } from '../utils/format.js';
const stages = ['Recepcionado', 'Diagnóstico', 'En reparación', 'Listo para entrega', 'Entregado'];
const key = value => (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z]/g, '');
export default function AttentionTimeline({ appointment, order }) {
  const current = order ? stages.findIndex(label => key(label) === key(order.status)) : -1;
  const accepted = Boolean(order) || ['CONFIRMADA', 'ATENDIDA'].includes(appointment?.status);
  const ended = ['CANCELADA', 'RECHAZADA'].includes(appointment?.status);
  const rows = [];
  if (appointment) {
    rows.push({ label: 'Pendiente', done: true, date: appointment.created_at });
    rows.push({ label: ended ? (appointment.status === 'CANCELADA' ? 'Cancelada' : 'Rechazada') : 'Aceptada', done: accepted || ended, current: !order && (accepted || ended) });
    if (!accepted && !ended) rows[0].current = true;
  }
  if (!ended) stages.forEach((label, index) => {
    const event = order?.status_history?.find(item => key(item.to_status) === key(label));
    rows.push({ label, done: Boolean(order) && (index <= current || Boolean(event)), current: Boolean(order) && index === current, date: event?.changed_at });
  });
  return <section className="tracking-card">{!appointment && <p className="tracking-caption">Ingreso directo al taller, sin cita previa.</p>}<ol className="tracking-timeline">{rows.map(row => <li key={row.label} aria-current={row.current ? 'step' : undefined} className={row.done ? 'attention-step-complete' : 'attention-step-pending'}><span className="tracking-dot" /><div><strong>{row.label}{row.current ? ' · Estado actual' : ''}</strong><p>{row.date ? formatDateTime(row.date) : row.done ? 'Registrado' : 'Por realizar'}</p></div></li>)}</ol></section>;
}
