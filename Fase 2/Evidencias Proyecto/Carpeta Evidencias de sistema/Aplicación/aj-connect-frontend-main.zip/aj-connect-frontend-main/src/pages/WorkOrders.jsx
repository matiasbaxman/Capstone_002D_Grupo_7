import { useEffect, useState } from 'react';
import { listWorkOrders, getWorkOrder, updateOrderStatus, updateWorkOrder, addOrderPart } from '../api/workshop.js';
import WorkOrderDetail from '../components/WorkOrderDetail.jsx';
import { formatDateTime } from '../utils/format.js';
import './WorkOrders.css';

export function OrderUnavailable({ retry, missing = false }) {
  return <section className="ot-state" role="alert"><h2>{missing ? 'Orden no encontrada' : 'No pudimos cargar las órdenes'}</h2><p>{missing ? 'Revisa el número de la orden o vuelve al listado.' : 'El servicio de órdenes no está disponible. Intenta nuevamente más tarde.'}</p><button className="ot-button" onClick={retry}>Reintentar</button></section>;
}
export default function WorkOrders({ onNavigate, orderId, loadOrders = listWorkOrders, loadOrder = getWorkOrder }) {
  const [resource, setResource] = useState({ loading: true });
  const [attempt, setAttempt] = useState(0);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  useEffect(() => {
    let active = true;
    const request = orderId ? loadOrder(orderId) : loadOrders();
    request.then((data) => {
      if (orderId ? !data?.id : !Array.isArray(data)) throw new Error('Invalid order response');
      if (active) setResource({ loading: false, data });
    }).catch((error) => { if (active) setResource({ loading: false, error: true, missing: Boolean(orderId && error.response?.status === 404) }); });
    return () => { active = false; };
  }, [attempt, orderId, loadOrders, loadOrder]);
  function retry() { setResource({ loading: true }); setAttempt((value) => value + 1); }
  function go(event, destination) {
    if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault(); onNavigate(destination);
  }
  if (orderId && resource.data) return <WorkOrderDetail order={resource.data} onBack={() => onNavigate('/dashboard/ordenes')} onOrderChange={(data) => setResource({ loading: false, data })} changeStatus={updateOrderStatus} addPart={addOrderPart} updateDiagnosis={(id, technicalDiagnosis) => updateWorkOrder(id, { technical_diagnosis: technicalDiagnosis })} />;
  const orders = resource.data || [];
  const statuses = [...new Map(orders.map((order) => [order.status.code, order.status.name])).entries()];
  const filtered = orders.filter((order) => (!status || order.status.code === status) && `${order.folio} ${order.vehicle.plate} ${order.client.name}`.toLowerCase().includes(search.toLowerCase().trim()));
  return <section className="work-orders">
    {orderId && <button className="ot-back" onClick={() => onNavigate('/dashboard/ordenes')}>← Volver a órdenes de trabajo</button>}
    <header className="ot-heading"><div><h1>{orderId ? 'Detalle de la orden' : 'Órdenes de trabajo'}</h1><p>{orderId ? 'Consulta el ingreso, actualiza el avance y agrega repuestos.' : 'Consulta las atenciones y actualiza el avance del taller.'}</p></div><a className="ot-button primary" href="/dashboard/check-in" onClick={(event) => go(event, '/dashboard/check-in')}>+ Registrar ingreso</a></header>
    {resource.loading ? <section className="ot-state" role="status" aria-busy="true"><p>Cargando {orderId ? 'orden' : 'órdenes de trabajo'}…</p></section> : resource.error ? <OrderUnavailable retry={retry} missing={resource.missing} /> : <>
      <div className="ot-filters"><label><span className="sr-only">Buscar órdenes</span><input className="ot-input" type="text" placeholder="Buscar por OT, patente o cliente…" value={search} onChange={(event) => setSearch(event.target.value)} /></label><label><span className="sr-only">Estado de la orden</span><select className="ot-input" value={status} onChange={(event) => setStatus(event.target.value)}><option value="">Todos los estados</option>{statuses.map(([code, name]) => <option key={code} value={code}>{name}</option>)}</select></label></div>
      <div className="ot-card ot-table-wrap"><table className="ot-table"><caption className="sr-only">Órdenes de trabajo</caption><thead><tr>{['Orden', 'Vehículo', 'Cliente', 'Estado', 'Ingreso', 'Acciones'].map((title) => <th key={title}>{title}</th>)}</tr></thead><tbody>{filtered.map((order) => <tr key={order.id}><td><strong>OT #{order.folio}</strong></td><td>{order.vehicle.plate}<small>{order.vehicle.label}</small></td><td>{order.client.name}</td><td><span className="ot-status">{order.status.name}</span></td><td>{formatDateTime(order.createdAt)}</td><td><a href={`/dashboard/ordenes/${order.id}`} onClick={(event) => go(event, `/dashboard/ordenes/${order.id}`)}>Ver detalle →</a></td></tr>)}</tbody></table>{!filtered.length && <p className="ot-empty">{orders.length ? 'No hay órdenes que coincidan con tu búsqueda.' : 'Todavía no hay órdenes de trabajo. Registra el ingreso de un vehículo para comenzar.'}</p>}</div><p className="ot-help">{filtered.length} de {orders.length} órdenes</p>
    </>}
  </section>;
}
