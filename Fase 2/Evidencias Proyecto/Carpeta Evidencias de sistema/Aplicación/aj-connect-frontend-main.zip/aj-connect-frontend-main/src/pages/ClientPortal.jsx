import Tracking from './Tracking.jsx';
import { unifiedAttentions } from '../utils/attentions.js';
import AppointmentCards from '../components/AppointmentCards.jsx';
import ClientProfile from '../components/ClientProfile.jsx';
import { useEffect, useState } from 'react';
import { clearClientSession, getClientAccount, getClientSession } from '../api/clientAuth.js';
import ClientAccess from '../components/ClientAccess.jsx';

export default function ClientPortal() {
  const [detail, setDetail] = useState(() => window.location.hash.startsWith('#atencion=') ? window.location.hash.slice(10) : '');
  const [section, setSection] = useState(() => window.location.hash === '#datos' ? 'datos' : 'citas');
  useEffect(() => { const sync = () => { setSection(window.location.hash === '#datos' ? 'datos' : 'citas'); setDetail(window.location.hash.startsWith('#atencion=') ? window.location.hash.slice(10) : ''); window.scrollTo(0, 0); }; window.addEventListener('hashchange', sync); return () => window.removeEventListener('hashchange', sync); }, []);
  const [session, setSession] = useState(getClientSession);
  const [account, setAccount] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!session) return;
    const controller = new AbortController();
    const timer = setTimeout(() => { clearClientSession(); setSession(null); setAccount(null); setError('Tu sesión expiró. Ingresa nuevamente con tu RUT y contraseña.'); }, Math.max(0, session.expiresAt - Date.now()));
    getClientAccount(controller.signal).then(data => { if (!controller.signal.aborted) setAccount(data); }).catch(err => {
      if (!controller.signal.aborted) { setError(err.response?.data?.detail || 'No pudimos cargar tus órdenes.'); if (!getClientSession()) setSession(null); }
    });
    const refresh = setInterval(() => { if (!document.hidden) getClientAccount(controller.signal).then(data => { if (!controller.signal.aborted) setAccount(data); }).catch(() => {}); }, 15000);
    return () => { clearTimeout(timer); clearInterval(refresh); controller.abort(); };
  }, [session]);
  const selected = detail && account ? unifiedAttentions(account.appointments, account.orders).find(item => encodeURIComponent(item.id) === detail) : null;
  if (session && detail && account) return selected ? <Tracking key={selected.id} token={selected.work_order__tracking_code} attention={selected} /> : <main className="p-8"><h1>Atención no encontrada</h1><a href="/cliente#atenciones">Volver a mis atenciones</a></main>;
  return <main className="booking-page px-4 py-12 text-slate-900"><section className="mx-auto max-w-xl rounded-3xl bg-white p-7 sm:p-10">{session && <h1 className="text-3xl font-bold">{session ? (section === 'datos' ? 'Mi cuenta' : 'Mis atenciones') : 'Iniciar sesión'}</h1>}{error && <p role="alert" className="my-4 rounded-xl bg-rose-50 p-4 text-rose-800">{error}</p>}{session ? <><p className="my-4">{account ? `Hola, ${[account.client.first_name, account.client.last_name].filter(Boolean).join(' ')}.` : 'Cargando tu cuenta…'}</p>{section === 'datos' ? (account && <ClientProfile client={account.client} onSaved={() => getClientAccount().then(setAccount).catch(() => setError('Tus datos se guardaron. Recarga la página para verlos.'))} />) : <><section id="atenciones" className="my-6"><h2 className="font-bold">Atenciones</h2><p className="my-2 text-sm">Solicitud → Aceptación → Recepción → Trabajo en taller. El estado se actualiza automáticamente.</p><AppointmentCards appointments={account?.appointments} orders={account?.orders} />{account && !account.appointments?.length && !account.orders?.length && <p>Aún no tienes atenciones registradas.</p>}</section></>}<button type="button" className="mt-6 rounded-xl border border-slate-300 px-5 py-3" onClick={() => { clearClientSession(); setSession(null); setAccount(null); }}>Cerrar sesión</button></> : <ClientAccess onSession={setSession} />}</section></main>;
}
