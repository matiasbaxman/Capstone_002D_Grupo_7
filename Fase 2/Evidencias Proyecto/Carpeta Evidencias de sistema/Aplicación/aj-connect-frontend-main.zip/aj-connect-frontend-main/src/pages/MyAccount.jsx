import { sessionIdentity } from '../utils/sessionIdentity.js';

export default function MyAccount({ token }) {
  const user = sessionIdentity(token);
  return (
    <section>
      <header className="admin-page-heading"><div><p className="admin-eyebrow">PERFIL</p><h1>Mi cuenta</h1><p>Datos de tu cuenta de acceso.</p></div></header>
      <dl className="admin-account-card">
        <div><dt>Usuario</dt><dd>{user.name}</dd></div>
        <div><dt>Correo electrónico</dt><dd>{user.email || 'Correo no registrado'}</dd></div>
        <div><dt>Rol</dt><dd>{user.role}</dd></div>
      </dl>
    </section>
  );
}
