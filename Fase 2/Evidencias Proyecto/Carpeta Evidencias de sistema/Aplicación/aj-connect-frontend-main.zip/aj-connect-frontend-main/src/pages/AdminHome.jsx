export default function AdminHome() {
  return (
    <section className="admin-home">
      <header className="admin-page-heading">
        <div>
          <h1>Inicio</h1>
          <p>Lo esencial de tu taller, a mano.</p>
        </div>
        <span className="admin-date">
          {new Intl.DateTimeFormat('es-CL', {
            dateStyle: 'long',
            timeZone: 'America/Santiago',
          }).format(new Date())}
        </span>
      </header>
    </section>
  );
}
