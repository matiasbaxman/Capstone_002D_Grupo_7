import { useToast, notificationMessages } from '../components/notifications/useToast.js';
import { useCallback, useEffect, useState } from 'react';
import InventoryModal from '../components/InventoryModal.jsx';
import InventoryTabs from '../components/InventoryTabs.jsx';
import InventoryTable from '../components/InventoryTable.jsx';
import { listCategories, listItems, mensajeDeError } from '../api/inventory.js';

const filasSkeleton = Array.from({ length: 5 }, (_, indice) => indice);

export default function Inventario({ onNavigate, initialCategory = '', isMecanico = false }) {
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [busqueda, setBusqueda] = useState('');
  const [busquedaAplicada, setBusquedaAplicada] = useState('');
  const [ordering, setOrdering] = useState('name');
  const [categoriaFiltro, setCategoriaFiltro] = useState(initialCategory);
  const [stockFiltro, setStockFiltro] = useState('');
  const [cargando, setCargando] = useState(true);
  const [buscando, setBuscando] = useState(false);
  const [error, setError] = useState('');
  const [modalAbierto, setModalAbierto] = useState(false);

  const [itemEnEdicion, setItemEnEdicion] = useState(null);

  // Debounce del buscador para no pegarle al backend en cada tecla.
  useEffect(() => {
    const temporizador = setTimeout(() => setBusquedaAplicada(busqueda.trim()), 350);

  return () => clearTimeout(temporizador);
  }, [busqueda]);

  const aplicarItems = useCallback((data) => {
    setItems(data);
    setError('');
  }, []);

  const aplicarErrorItems = useCallback((err) => {
    setError(mensajeDeError(err));
    setItems([]);
  }, []);

  // El flag `vigente` evita que una respuesta lenta pise a una más reciente
  // cuando el usuario cambia el orden o la búsqueda varias veces seguidas.
  useEffect(() => {
    let vigente = true;

    listItems({ search: busquedaAplicada, ordering })
      .then((data) => {
        if (vigente) aplicarItems(data);
      })
      .catch((err) => {
        if (vigente) aplicarErrorItems(err);
      })
      .finally(() => {
        if (vigente) {
          setCargando(false);
          setBuscando(false);
        }
      });


  return () => {
      vigente = false;
    };
  }, [aplicarItems, aplicarErrorItems, busquedaAplicada, ordering]);

  useEffect(() => {
    let vigente = true;

    listCategories()
      .then((data) => {
        if (vigente) setCategorias(data);
      })
      .catch(() => {
        // Si no se pueden leer, el formulario muestra el aviso; la tabla sigue operativa.
      });


  return () => {
      vigente = false;
    };
  }, []);

  function refrescarItems() {
    listItems({ search: busquedaAplicada, ordering })
      .then(aplicarItems)
      .catch(aplicarErrorItems);
  }

  function cambiarBusqueda(valor) {
    setBusqueda(valor);
    setBuscando(true);
  }

  function abrirNuevo() {
    setItemEnEdicion(null);
    setModalAbierto(true);
  }

  function abrirEdicion(item) {
    setItemEnEdicion(item);
    setModalAbierto(true);
  }

  function cerrarModal() {
    setModalAbierto(false);
    setItemEnEdicion(null);
  }

  function alGuardar() {
    toast.success(itemEnEdicion ? notificationMessages.itemUpdated : notificationMessages.itemCreated, { icon: itemEnEdicion ? 'save' : 'create' });
    cerrarModal();
    refrescarItems();
  }


  const itemsFiltrados = items.filter((item) => {
    if (categoriaFiltro && String(item.category) !== categoriaFiltro) return false;
    if (stockFiltro === 'sin-stock') return Number(item.current_stock) === 0;
    if (stockFiltro === 'bajo') return Number(item.current_stock) > 0 && item.is_low_stock;
    if (stockFiltro === 'disponible') return !item.is_low_stock;
    return true;
  });
  const filtrosActivos = Boolean(categoriaFiltro || stockFiltro || busqueda);
  function limpiarFiltros() {
    setCategoriaFiltro('');
    setStockFiltro('');
    if (busqueda) cambiarBusqueda('');
  }

  return (
    <div className="text-[var(--ink)]">
      <div>
        <header className="inventory-heading">
          <div>
            <h1 className="text-3xl font-bold text-[var(--ink)]">Inventario</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              {cargando
                ? 'Cargando insumos…'
                : buscando
                  ? 'Buscando…'
                  : categoriaFiltro || stockFiltro || busquedaAplicada ? `${itemsFiltrados.length} resultado(s)` : `${items.length} insumo(s) registrado(s)`}
            </p>
          </div>

        {isMecanico !== true ? (
          <button
            type="button"
            onClick={abrirNuevo}
            className="admin-primary-action rounded-lg bg-[var(--button)] px-4 py-2 text-sm font-semibold text-[var(--button-text)] transition hover:bg-[var(--button-hover)]"
          >
            + Nuevo insumo
          </button>
        ) : null}
        </header>

        <InventoryTabs path="/dashboard/inventario" onNavigate={onNavigate} />
        <div className="inventory-filters mt-6" aria-label="Filtros de inventario"><div className="inventory-search">
          <label htmlFor="buscar-insumo" className="sr-only">
           Buscar insumos
          </label>
          <div className="relative">
            <input
              id="buscar-insumo"
              type="search"
              value={busqueda}
              onChange={(evento) => cambiarBusqueda(evento.target.value)}
              placeholder="Buscar por SKU, nombre o categoría…"
              className="w-full rounded-lg border border-[var(--line)] bg-[var(--surface)] py-2 pl-3 pr-9 text-sm text-[var(--ink)] placeholder-[var(--muted)] outline-none transition focus:border-emerald-500"
            />
            {busqueda ? (
              <button
                type="button"
                onClick={() => cambiarBusqueda('')}
                aria-label="Limpiar búsqueda"
                className="absolute inset-y-0 right-0 px-3 text-lg leading-none text-[var(--muted)] transition hover:text-[var(--ink)]"
              >
                &times;
              </button>
            ) : null}
          </div>
        </div>

          <label className="inventory-filter">
            <span className="sr-only">Categoría</span>
            <select value={categoriaFiltro} onChange={(event) => setCategoriaFiltro(event.target.value)}>
              <option value="">Todas las categorías</option>
              {categorias.map((categoria) => <option key={categoria.id} value={String(categoria.id)}>{categoria.name}{categoria.is_active === false ? ' (archivada)' : ''}</option>)}
            </select>
          </label>
          <label className="inventory-filter">
            <span className="sr-only">Estado del stock</span>
            <select value={stockFiltro} onChange={(event) => setStockFiltro(event.target.value)}>
              <option value="">Todo el stock</option>
              <option value="disponible">Stock sobre el mínimo</option>
              <option value="bajo">Stock bajo</option>
              <option value="sin-stock">Sin existencias</option>
            </select>
          </label>
          {filtrosActivos && <button className="inventory-reset" type="button" onClick={limpiarFiltros}>Limpiar filtros</button>}
        </div>
        <div className="mt-4">
          {error ? (
            <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-[var(--danger)]">
              {error}
            </div>
          ) : cargando ? (
            <div className="overflow-hidden rounded-xl border border-[var(--line)] bg-[var(--surface)]">
              {filasSkeleton.map((indice) => (
                <div
                  key={indice}
                  className="h-16 animate-pulse border-b border-[var(--line)] last:border-0"
                />
              ))}
            </div>
          ) : (
            <InventoryTable
              items={itemsFiltrados}
              ordering={ordering}
              onOrdenChange={setOrdering}
              onEditar={isMecanico ? undefined : abrirEdicion}
            />
          )}
        </div>
      </div>


      {modalAbierto ? (
        <InventoryModal
          // La key fuerza el remonte al cambiar entre alta y edición, así el
          // formulario se inicializa limpio sin usar un efecto de sincronización.
          key={itemEnEdicion?.id ?? 'nuevo'}
          item={itemEnEdicion}
          categorias={categorias}
          onCerrar={cerrarModal}
          onGuardado={alGuardar}
        />
      ) : null}
    </div>
  );
}
