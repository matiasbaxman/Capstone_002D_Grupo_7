import ClientMenu from '../components/ClientMenu.jsx';
import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight, Disc3, MapPin, Pause, Play, ScanLine, Settings2, Star, Wrench } from 'lucide-react';
import monogram from '../assets/aj-monograma.png';
import signature from '../assets/aj-firma.png';
import './PublicHome.css';

const information = {
  '/privacidad': { title: 'Privacidad y datos', description: 'Información sobre el tratamiento de datos personales.', notice: 'La política de privacidad está en preparación. Se publicará cuando el taller confirme los datos del responsable, los usos y los canales de contacto.' },
  '/condiciones': { title: 'Condiciones de reserva', description: 'Información sobre el uso del portal y las reservas.', notice: 'Las condiciones de reserva están en preparación. Se publicarán cuando el taller confirme sus condiciones de atención, cambios y cancelaciones.' },
  '/almacenamiento': { title: 'Cookies y almacenamiento', description: 'Información sobre tecnologías utilizadas en el sitio.', notice: 'La información sobre cookies y almacenamiento está en preparación. Se publicará después de revisar las tecnologías utilizadas y su finalidad.' },
  '/contacto': { title: 'Contacto', description: 'Información de contacto del taller.', notice: 'Los datos de contacto se publicarán cuando el taller los confirme.' },
};

const services = [
  { title: 'Mecánica integral', description: 'Revisión y reparación de componentes mecánicos del vehículo.', Icon: Wrench },
  { title: 'Frenos', description: 'Revisión del sistema de frenado para cuidar su funcionamiento.', Icon: Disc3 },
  { title: 'Diagnóstico', description: 'Identificación de fallas para orientar la reparación.', Icon: ScanLine },
  { title: 'Mantención', description: 'Cuidados periódicos para mantener tu vehículo en buen estado.', Icon: Settings2 },
];

// Selección manual consultada en Google Maps el 29 de octubre de 2026.
// Textos facilitados por el usuario; la reseña de Ana se muestra abreviada.
const reviews = [
  { author: 'Ana Fernandez', profileReviews: 1, date: '2025-12', edited: false, quote: "Excelente atención, vi muchos mecánicos con mii marido, pero nadie le encontraba la falla a mi baleno, hasta que llegue a Alhan, quien pudo resolver los problemas electrónico" },
  { author: 'Constanza Pérez Lillo', profileReviews: 100, date: '2026-06', edited: false, quote: "Super recomendados, solucionaron el problema de mi auto. Excelente atención", full: true },
  { author: 'Siriham Morales', profileReviews: 1, date: '2026-01', edited: false, quote: "Muchas gracias por devolverme a mi autito!!  Estuvo mucho tiempo detenido, pero gracias a ustedes al fin pude volver a manejarlo, muchas gracias por la amabilidad y la disposición para resolver tantas dudas, son unos secos !! 1000% recomendados !", full: true },
  { author: 'Barbara Fernandez', profileReviews: 1, date: '2025-10', edited: false, quote: "excelente atención y disposición, Damian mecánico incluso fue a  domicilio a ver el auto.", full: true },
  { author: 'Matias Baxman', profileReviews: 1, date: '2025-10', edited: false, quote: "Muy excelente servicio y muy amables los mecanicos, 100% recomendado!! ✨", full: true },
  { author: 'Head Pineapple', profileReviews: 1, date: '2025-12', edited: false, quote: "Son todos amables y se demoran un tiempo razonable en entregar los autos", full: true },
  { author: 'Stephanie Marchant', profileReviews: 1, date: '2025-10', edited: false, quote: "Excelente atención, honestos y por lo menos con mi auto cumplieron con el plazo de entrega.", full: true },
  { author: 'Elisabeth Zambrano', profileReviews: 4, date: '2026-08', edited: true, quote: "Excelente atención, muy profesionales para atender!", full: true },
  { author: 'Vannessa Moreno', profileReviews: 7, date: '2025-10', edited: false, quote: "Jovenes super comprometidos, dedicados, único lugar donde encontraron la panita real de mi auto. Recomendo totalmente", full: true },
  { author: 'Denisse Estay', profileReviews: 7, date: '2025-10', edited: false, quote: "Excelente atención, resolvieron mi problema en poco tiempo. Los recomiendo", full: true },
  { author: 'Claudia Hurtado Gahona', profileReviews: 2, date: '2025-10', edited: false, quote: "Muy buenos mecánicos y resuelven todas las dudas", full: true },
];

function reviewAge(date) {
  const [year, month] = date.split('-').map(Number);
  const now = new Date();
  const months = Math.max(0, (now.getFullYear() - year) * 12 + now.getMonth() + 1 - month);
  if (months < 1) return 'hace menos de un mes';
  if (months < 12) return `hace ${months} ${months === 1 ? 'mes' : 'meses'}`;
  const years = Math.floor(months / 12);
  return `hace ${years} ${years === 1 ? 'año' : 'años'}`;
}

function ReviewsSection() {
  const [position, setPosition] = useState(reviews.length);
  const [animated, setAnimated] = useState(true);
  const [playing, setPlaying] = useState(() => !window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [moving, setMoving] = useState(false);
  const carouselReviews = [...reviews, ...reviews, ...reviews];
  const currentIndex = ((position - reviews.length) % reviews.length + reviews.length) % reviews.length;
  function moveReview(direction) {
    if (moving) return;
    setAnimated(true);
    setMoving(true);
    setPosition(current => current + direction);
  }
  useEffect(() => {
    if (!playing || moving) return undefined;
    const timer = window.setTimeout(() => moveReview(-1), 7000);
    return () => window.clearTimeout(timer);
  });
  useEffect(() => {
    if (!moving) return undefined;
    const timer = window.setTimeout(() => {
      if (position < reviews.length || position >= reviews.length * 2) {
        setAnimated(false);
        setPosition(reviews.length + currentIndex);
      }
      setMoving(false);
    }, 550);
    return () => window.clearTimeout(timer);
  }, [moving, position, currentIndex]);
  function navigate(direction) {
    setPlaying(false);
    moveReview(direction);
  }
  return <section className="storefront-reviews" aria-labelledby="reviews-title">
    <div className="storefront-reviews-inner">
      <div className="storefront-reviews-heading"><h2 id="reviews-title">La experiencia de nuestros clientes</h2><p>Opiniones publicadas por clientes en Google Maps.</p></div>
      <div className="storefront-reviews-carousel" aria-label="Reseñas de clientes">
        <div className="storefront-reviews-track" style={{ transform: `translateX(calc(-${position} * var(--review-width)))`, transition: animated ? undefined : 'none' }}>
          {carouselReviews.map((review, i) => <article className="storefront-review-card" key={i} aria-hidden={i < position || i > position + 2}>
            <div className="storefront-review-author"><span>{review.author}</span><span className="storefront-review-meta">{review.profileReviews} {review.profileReviews === 1 ? 'reseña' : 'reseñas'} en Google · {review.edited ? 'Editada' : 'Publicada'} {reviewAge(review.date)} aprox.</span></div>
            <div className="storefront-review-stars" aria-label="5 de 5 estrellas">{Array.from({ length: 5 }, (_, star) => <Star key={star} size={18} fill="currentColor" aria-hidden="true" />)}</div>
            <p className="storefront-review-summary">“{review.quote}{review.full ? '' : '…'}”</p>
          </article>)}
        </div>
      </div>
      <div className="storefront-review-controls"><div className="storefront-review-buttons"><button type="button" onClick={() => navigate(-1)} aria-label="Reseña anterior"><ArrowLeft size={19} aria-hidden="true" /></button><button type="button" onClick={() => navigate(1)} aria-label="Reseña siguiente"><ArrowRight size={19} aria-hidden="true" /></button><button type="button" onClick={() => setPlaying(value => !value)} aria-label={playing ? 'Pausar rotación' : 'Reanudar rotación'}>{playing ? <Pause size={18} aria-hidden="true" /> : <Play size={18} aria-hidden="true" />}</button></div></div>
    </div>
  </section>;
}

function ServicesSection() {
  return <section className="storefront-services" id="servicios" aria-labelledby="services-title">
    <div className="storefront-services-inner">
      <div className="storefront-services-heading">
        <h2 id="services-title">Servicios principales</h2>
        <p>Conoce cómo podemos ayudarte a cuidar tu vehículo.</p>
      </div>
      <ul className="storefront-services-grid">
        {services.map(({ title, description, Icon }) => <li className="storefront-service" key={title}>
          <span className="storefront-service-icon"><Icon size={27} strokeWidth={1.6} aria-hidden="true" /></span>
          <h3>{title}</h3><p>{description}</p>
        </li>)}
      </ul>
      <div className="storefront-location">
        <div className="storefront-location-content">
          <div className="storefront-location-details"><MapPin size={22} strokeWidth={1.7} aria-hidden="true" /><div><h3>Encuéntranos en Quilpué</h3><p>Freire 1447, Quilpué</p></div></div>
          <a href="https://maps.app.goo.gl/ns8U36iTCPenTPBEA" target="_blank" rel="noopener noreferrer">Cómo llegar <ArrowUpRight size={17} aria-hidden="true" /><span className="storefront-sr-only"> (se abre en una pestaña nueva)</span></a>
        </div>
        <div className="storefront-location-map"><iframe title="Mapa de Freire 1447, Quilpué" src="https://maps.google.com/maps?q=Freire%201447%2C%20Quilpu%C3%A9%2C%20Chile&z=16&output=embed" loading="lazy" referrerPolicy="strict-origin-when-cross-origin" /></div>
      </div>
    </div>
  </section>;
}

export function PublicLayout({ children }) {
  const topbarRef = useRef(null);
  useEffect(() => {
    const topbar = topbarRef.current;
    if (!topbar) return undefined;
    const updateHeight = () => topbar.parentElement?.style.setProperty('--storefront-header-height', `${topbar.offsetHeight}px`);
    updateHeight();
    const observer = new ResizeObserver(updateHeight);
    observer.observe(topbar);
    return () => observer.disconnect();
  }, []);
  return <div className="storefront">
    <div className="storefront-topbar" ref={topbarRef}>
    <div className="storefront-notice">Servicio automotriz en Quilpué <span aria-hidden="true">·</span> Atención con reserva previa</div>
    <header className="storefront-header"><div className="storefront-header-inner">
      <a className="storefront-logo" href="/" aria-label="A&J Servicio Automotriz, inicio"><img src={monogram} alt="A&J Servicio Automotriz" /></a>
      <nav className="storefront-nav" aria-label="Navegación principal"><a href="/seguimiento">Seguimiento</a><a href="/agendar">Agendar cita</a></nav>
      <div className="storefront-account-actions" aria-label="Acceso de clientes">
        <ClientMenu />
      </div>
    </div></header>
    </div>
    {children}
    <footer className="storefront-footer"><div className="storefront-footer-inner"><div className="storefront-footer-brand"><a className="storefront-footer-logo" href="/" aria-label="A&J Servicio Automotriz, inicio"><img src={signature} alt="A&J Servicio Automotriz" /></a></div><nav className="storefront-footer-nav" aria-label="Información del sitio"><div><h2>Información</h2><a href="/privacidad">Privacidad y datos</a><a href="/condiciones">Condiciones de reserva</a></div><div><h2>Ayuda</h2><a href="/almacenamiento">Cookies y almacenamiento</a><a href="/contacto">Contacto</a></div></nav></div><div className="storefront-footer-bottom"><small>© {new Date().getFullYear()} A&J Servicio Automotriz</small><span>Quilpué, Chile</span></div></footer>
  </div>;
}

export default function PublicHome({ path = '/' }) {
  const page = information[path];
  return <PublicLayout>
    <main className={page ? 'storefront-info' : 'storefront-blank'} aria-label={page ? undefined : 'Inicio'}>{!page && <section className="storefront-social" aria-labelledby="storefront-social-title"><div className="storefront-social-copy"><h1 id="storefront-social-title">Únete a nuestra comunidad</h1><p>Descubre lo que hacemos en el taller, conoce a nuestro equipo y acompáñanos en cada trabajo.</p><a className="storefront-social-link" href="https://www.instagram.com/a.j.servicioautomotriz/" target="_blank" rel="noopener noreferrer"><span className="storefront-instagram-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></span> Síguenos en Instagram <ArrowUpRight size={16} aria-hidden="true" /><span className="storefront-sr-only"> (se abre en una pestaña nueva)</span></a></div><div className="storefront-social-mark"><div className="storefront-reel-frame"><iframe title="Reel de A&J Servicio Automotriz" src="https://www.instagram.com/reel/DYE92ErOErB/embed/" scrolling="no" allow="encrypted-media; picture-in-picture" /></div></div></section>}{!page && <><ServicesSection /><ReviewsSection /></>}{page && <div className="storefront-info-inner"><a className="storefront-info-back" href="/">← Volver al inicio</a><h1>{page.title}</h1><p className="storefront-info-description">{page.description}</p><section className="storefront-info-notice"><h2>Información en preparación</h2><p>{page.notice}</p></section></div>}</main>
  </PublicLayout>;
}
