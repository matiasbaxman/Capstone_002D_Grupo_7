import CodeVerificationDialog from '../components/CodeVerificationDialog.jsx';
import { getClientSession, getClientAccount } from '../api/clientAuth.js';
import { useEffect, useMemo, useState } from 'react';
import { createPublicAppointment, getAppointmentAvailability, getPublicServices, requestBookingVerification } from '../api/appointments.js';
import { validRut, formatRut } from '../utils/rutValidation.js';
import { validPlate, formatPlate } from '../utils/plateValidation.js';
import { validContactEmail, mobileDigits, mobileContact } from '../utils/contactValidation.js';

const steps = ['Servicio', 'Fecha y hora', 'Tus datos', 'Confirmación'];
const generalService = { id: null, name: 'Evaluación general', general: true };
const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Santiago' });
const textInput = 'w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-emerald-700 focus:ring-2 focus:ring-emerald-100';

function apiError(error) {
  const data = error.response?.data;
  if (typeof data === 'string') return data;
  if (data && typeof data === 'object') return Object.values(data).flat(Infinity).join(' ');
  return 'No pudimos conectar con el servicio. Revisa tu conexión e inténtalo nuevamente.';
}

function Field({ label, error, children }) {
  return <label className="block space-y-1.5 text-sm font-semibold text-slate-700"><span>{label}</span>{children}{error && <span className="block text-xs font-medium text-rose-700">{error}</span>}</label>;
}

export default function BookingPage() {
  const [customer, setCustomer] = useState(null);
  const [loadingAccount, setLoadingAccount] = useState(() => Boolean(getClientSession()));
  const [accountError, setAccountError] = useState(false);
  const [step, setStep] = useState(0);
  const [services, setServices] = useState([]);
  const [service, setService] = useState(null);
  const [date, setDate] = useState('');
  const [slots, setSlots] = useState([]);
  const [slot, setSlot] = useState(null);
  const [loadingServices, setLoadingServices] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [booking, setBooking] = useState(null);
  const [verification, setVerification] = useState(null);
  const [code, setCode] = useState('');
  const [codeOpen, setCodeOpen] = useState(false);
  const [form, setForm] = useState({ rut: '', first_name: '', last_name: '', phone: '', email: '', plate: '', symptoms: '', notification_channel: 'EMAIL' });

  useEffect(() => {
    if (!getClientSession()) return;
    let alive = true;
    getClientAccount().then(data => {
      if (!alive) return;
      setCustomer(data);
      setForm(current => ({ ...current, ...data.client, notification_channel: 'EMAIL' }));
    }).catch(() => { if (alive) { setAccountError(true); setError('No pudimos recuperar tus datos. Inicia sesión nuevamente antes de agendar.'); } })
      .finally(() => { if (alive) setLoadingAccount(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    let alive = true;
    getPublicServices().then((rows) => { if (alive) setServices(rows); })
      .catch((err) => { if (alive) setError(apiError(err)); })
      .finally(() => { if (alive) setLoadingServices(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!date) return undefined;
    let alive = true;
    getAppointmentAvailability(date).then((data) => { if (alive) setSlots(data.slots || []); })
      .catch((err) => { if (alive) { setSlots([]); setError(apiError(err)); } })
      .finally(() => { if (alive) setLoadingSlots(false); });
    return () => { alive = false; };
  }, [date]);

  const errors = useMemo(() => {
    const result = {};
    if (!validRut(form.rut)) result.rut = 'Ingresa un RUT válido.';
    if (!form.first_name.trim()) result.first_name = 'Ingresa tu nombre.';
    if (!form.last_name.trim()) result.last_name = 'Ingresa tu apellido.';
    if (form.phone && mobileDigits(form.phone).length !== 8) result.phone = 'Ingresa un celular chileno válido.';
    if (form.email && !validContactEmail(form.email)) result.email = 'Ingresa un correo válido.';
    if (!form.email.trim()) result.email = 'El correo es obligatorio para recibir avisos por email.';
    if (form.plate && !validPlate(form.plate)) result.plate = 'Formato esperado: AA-1234 o BBBB-12.';
    if (form.symptoms.trim().length < 5) result.symptoms = 'Describe brevemente el motivo de tu visita.';
    return result;
  }, [form]);

  function update(key, value) { setVerification(null); setCode(''); setForm((current) => ({ ...current, [key]: value })); }
  function continueStep() {
    setError('');
    if (loadingAccount || accountError) { setError('Espera a que se cargue tu cuenta o vuelve a iniciar sesión.'); return; }
    if (step === 0 && !service) return setError('Selecciona un servicio para continuar.');
    if (step === 1 && (!date || !slot)) return setError('Selecciona una fecha y un horario disponible.');
    if (step === 2 && Object.keys(errors).length) return setError('Revisa los campos indicados antes de continuar.');
    setStep((current) => Math.min(3, current + 1));
  }

  async function confirmBooking(resend = false) {
    if (submitting || loadingAccount || accountError) return;
    if (!slot || !service || Object.keys(errors).length) { setError('Revisa los datos de tu solicitud antes de confirmar.'); return; }
    setSubmitting(true); setError('');
    const symptoms = [form.symptoms.trim(), form.plate ? `Patente: ${formatPlate(form.plate)}` : ''].filter(Boolean).join('\n');
    try {
      const payload = {
        rut: form.rut, first_name: form.first_name.trim(), last_name: form.last_name.trim(),
        phone: mobileContact(mobileDigits(form.phone)), email: form.email.trim(),
        notification_channel: form.notification_channel, service: service?.id ?? null,
        scheduled_date: slot.start, reported_symptoms: symptoms,
      };
      if (customer && !getClientSession()) { setError('Tu sesión expiró. Inicia sesión nuevamente.'); return; }
      if (customer?.appointments?.length > 0) {
        setBooking(await createPublicAppointment(payload)); return;
      }
      if (!verification || resend) {
        setVerification(await requestBookingVerification(payload));
        setCode(''); setCodeOpen(true);
        return;
      }
      if (!/^\d{6}$/.test(code)) { setError('Ingresa los seis dígitos del código recibido.'); return; }
      const result = await createPublicAppointment({ ...payload, verification_id: verification.verification_id, code });
      setBooking(result);
    } catch (err) { setError(apiError(err)); }
    finally { setSubmitting(false); }
  }

  const formattedDate = date ? new Intl.DateTimeFormat('es-CL', { dateStyle: 'full', timeZone: 'America/Santiago' }).format(new Date(`${date}T12:00:00`)) : '';
  const selectedTime = slot ? new Intl.DateTimeFormat('es-CL', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Santiago' }).format(new Date(slot.start)) : '';

  if (booking) return <main className="booking-page px-4 py-10 sm:py-16"><section className="mx-auto max-w-xl rounded-3xl bg-white p-7 text-center shadow-xl shadow-slate-200/60 sm:p-12"><div className="mx-auto mb-5 grid size-16 place-items-center rounded-full bg-emerald-100 text-3xl text-emerald-800">✓</div><p className="text-sm font-bold uppercase tracking-[.2em] text-emerald-800">Agendamiento recibido</p><h1 className="mt-3 text-3xl font-bold text-slate-900">¡Gracias, {form.first_name}!</h1><p className="mt-3 text-slate-600">Tu solicitud quedó registrada. Te contactaremos para confirmar los detalles. Si es tu primer registro, recibirás las instrucciones de acceso a tu cuenta por el canal elegido.</p><div className="mt-7 rounded-2xl bg-slate-50 p-5 text-left text-sm text-slate-700"><p><b>Reserva:</b> {booking.id}</p><p className="mt-2"><b>Servicio:</b> {service?.name || 'Evaluación general'}</p><p className="mt-2"><b>Fecha:</b> {formattedDate}, {selectedTime}</p><p className="mt-2"><b>Estado:</b> {booking.status}</p></div><a href="/" className="booking-home-button mt-7 inline-flex rounded-xl bg-slate-900 px-5 py-3 font-semibold text-white">Volver al inicio</a></section></main>;

  return <main className="booking-page px-4 py-7 text-slate-900 sm:px-6 sm:py-12"><div className="mx-auto max-w-4xl"><section className="overflow-hidden rounded-3xl bg-white shadow-xl shadow-slate-200/60"><div className="bg-[#202b23] px-6 py-7 text-white sm:px-10 sm:py-9"><h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">Reserva tu hora</h1><p className="mt-2 max-w-xl text-sm text-emerald-50/75">Cuéntanos qué necesita tu vehículo. Nuestro equipo te contactará para confirmar.</p></div><div className="px-5 py-6 sm:px-10 sm:py-8"><ol className="mb-8 grid grid-cols-4 gap-2" aria-label="Progreso de reserva">{steps.map((name, index) => <li key={name} className="min-w-0"><div className={`h-1.5 rounded-full ${index <= step ? 'bg-emerald-700' : 'bg-slate-100'}`} /><p className={`mt-2 truncate text-[11px] font-semibold sm:text-sm ${index === step ? 'text-emerald-900' : 'text-slate-400'}`}><span className="mr-1">{index + 1}.</span>{name}</p></li>)}</ol>
      {error && !codeOpen && <div role="alert" className="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{error}</div>}

      {step === 0 && <section><div className="mb-5"><h2 className="text-xl font-bold">¿Qué servicio necesitas?</h2><p className="mt-1 text-sm text-slate-500">Elige el motivo principal de tu visita. Puedes agendar una evaluación general.</p></div>{loadingServices ? <p className="rounded-xl bg-slate-50 p-5 text-sm text-slate-500">Cargando servicios…</p> : services.length === 0 ? <button type="button" onClick={() => { setService(generalService); setVerification(null); setCode(''); }} aria-pressed={service?.general === true} className={`w-full rounded-2xl border p-5 text-left ${service?.general ? 'border-emerald-700 bg-emerald-50 ring-2 ring-emerald-100' : 'border-slate-200 hover:border-emerald-400 hover:bg-slate-50'}`}><span className="flex items-start justify-between gap-3"><b>Evaluación general</b><span className="grid size-5 shrink-0 place-items-center rounded-full border border-slate-300 text-xs text-white">{service?.general ? '✓' : ''}</span></span><p className="mt-1 text-sm text-slate-500">Cuéntanos qué necesita tu vehículo y te orientaremos.</p></button> : <div className="grid gap-3 sm:grid-cols-2">{services.map((item) => <button type="button" key={item.id} onClick={() => { setService(item); setVerification(null); }} aria-pressed={service?.id === item.id} className={`rounded-2xl border p-5 text-left transition ${service?.id === item.id ? 'border-emerald-700 bg-emerald-50 ring-2 ring-emerald-100' : 'border-slate-200 hover:border-emerald-400 hover:bg-slate-50'}`}><span className="flex items-start justify-between gap-3"><b className="text-base">{item.name}</b><span className="grid size-5 shrink-0 place-items-center rounded-full border border-slate-300 text-xs text-white">{service?.id === item.id ? '✓' : ''}</span></span><span className="mt-2 block min-h-10 text-sm leading-relaxed text-slate-500">{item.description || 'Servicio de atención automotriz.'}</span><span className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-xs font-semibold text-slate-600"><span>{item.estimated_duration_minutes ? `${item.estimated_duration_minutes} min aprox.` : 'Duración por evaluar'}</span>{item.base_price != null && <span>Desde ${Number(item.base_price).toLocaleString('es-CL')}</span>}</span></button>)}</div>}</section>}

      {step === 1 && <section><h2 className="text-xl font-bold">Elige fecha y hora</h2><p className="mb-5 mt-1 text-sm text-slate-500">Atendemos de lunes a viernes, entre 09:00 y 18:00.</p><Field label="Fecha"><input type="date" min={today} value={date} onChange={(event) => { setVerification(null); setCode(''); setDate(event.target.value); setLoadingSlots(Boolean(event.target.value)); setSlots([]); setSlot(null); setError(''); }} className={textInput} /></Field>{date && <div className="mt-6"><p className="mb-3 text-sm font-semibold text-slate-700">Horarios disponibles</p>{loadingSlots ? <p className="text-sm text-slate-500">Consultando disponibilidad…</p> : slots.length ? <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">{slots.map((item) => { const time = new Intl.DateTimeFormat('es-CL', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Santiago' }).format(new Date(item.start)); return <button type="button" key={item.start} onClick={() => { setSlot(item); setVerification(null); setCode(''); }} aria-pressed={slot?.start === item.start} className={`rounded-xl border px-3 py-3 text-sm font-semibold ${slot?.start === item.start ? 'border-emerald-800 bg-emerald-800 text-white' : 'border-slate-200 hover:border-emerald-700'}`}>{time}<span className="mt-1 block text-[10px] font-normal">{item.remaining_capacity} {item.remaining_capacity === 1 ? 'cupo' : 'cupos'}</span></button>; })}</div> : <p className="rounded-xl bg-amber-50 p-4 text-sm text-amber-900">No hay horas disponibles este día. Prueba con otra fecha entre semana.</p>}</div>}</section>}

      {step === 2 && <section><h2 className="text-xl font-bold">Tus datos de contacto</h2><p className="mb-5 mt-1 text-sm text-slate-500">Usaremos estos datos para registrar la solicitud y contactarte.</p>{customer ? <div className="mb-5 rounded-xl bg-emerald-50 p-4"><b>{customer.client.first_name} {customer.client.last_name}</b><p>{customer.client.email}</p><p className="text-sm">Usaremos los datos de tu cuenta. Puedes modificarlos en Datos personales.</p></div> : null}<div className="grid gap-4 sm:grid-cols-2">{!customer && <><Field label="RUT" error={form.rut && errors.rut}><input autoComplete="off" value={form.rut} onChange={(e) => update('rut', e.target.value)} onBlur={() => update('rut', formatRut(form.rut))} placeholder="12.345.678-5" className={textInput} /></Field><Field label="Teléfono / WhatsApp (opcional)" error={form.phone && errors.phone}><input inputMode="tel" value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="9 1234 5678" className={textInput} /></Field><Field label="Nombre" error={form.first_name && errors.first_name}><input autoComplete="given-name" value={form.first_name} onChange={(e) => update('first_name', e.target.value)} className={textInput} /></Field><Field label="Apellido" error={form.last_name && errors.last_name}><input autoComplete="family-name" value={form.last_name} onChange={(e) => update('last_name', e.target.value)} className={textInput} /></Field><Field label="Correo electrónico (obligatorio)" error={form.email && errors.email}><input type="email" autoComplete="email" value={form.email} onChange={(e) => update('email', e.target.value)} className={textInput} /></Field><p className="self-center text-sm text-slate-600">Los códigos y las instrucciones de ingreso se enviarán por correo. WhatsApp es opcional como dato de contacto.</p></>}<Field label="Patente (opcional)" error={form.plate && errors.plate}><input value={form.plate} onChange={(e) => update('plate', e.target.value)} onBlur={() => update('plate', formatPlate(form.plate))} placeholder="AB-CD-12" className={textInput} /></Field><div className="sm:col-span-2"><Field label="¿Qué problema o servicio requiere tu vehículo?" error={form.symptoms && errors.symptoms}><textarea rows="4" value={form.symptoms} onChange={(e) => update('symptoms', e.target.value)} placeholder="Describe los síntomas o el motivo de la visita…" className={`${textInput} resize-y`} /></Field></div></div><p className="mt-3 text-xs leading-relaxed text-slate-500">La patente se adjunta como referencia para el taller. Los datos de vehículo registrados en el sistema se completan durante la recepción.</p></section>}

      {step === 3 && <section><h2 className="text-xl font-bold">Revisa tu solicitud</h2><p className="mb-5 mt-1 text-sm text-slate-500">Confirma que los datos estén correctos antes de enviar.</p><div className="grid gap-4 sm:grid-cols-2"><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Servicio</p><p className="mt-2 font-semibold">{service?.name || 'Evaluación general'}</p>{service?.description && <p className="mt-1 text-sm text-slate-500">{service.description}</p>}</div><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Fecha y hora</p><p className="mt-2 font-semibold capitalize">{formattedDate}</p><p className="text-sm text-slate-600">{selectedTime} hrs</p></div><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Cliente</p><p className="mt-2 font-semibold">{form.first_name} {form.last_name}</p><p className="text-sm text-slate-600">RUT {form.rut}</p><p className="text-sm text-slate-600">{mobileContact(mobileDigits(form.phone))}</p>{form.email && <p className="text-sm text-slate-600">{form.email}</p>}</div><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Vehículo y motivo</p><p className="mt-2 font-semibold">{form.plate ? `Patente ${formatPlate(form.plate)}` : 'Patente no informada'}</p><p className="mt-1 whitespace-pre-line text-sm text-slate-600">{form.symptoms}</p></div></div></section>}

      {step === 3 && verification && codeOpen && <CodeVerificationDialog code={code} onChange={setCode} busy={submitting} error={error} title="Confirma tu cita" confirmLabel="Confirmar agendamiento" description="Ingresa el código que enviamos a tu correo para registrar tu solicitud. Expira en cinco minutos." onConfirm={() => confirmBooking()} onClose={() => { setCodeOpen(false); setError(''); }} onResend={() => confirmBooking(true)} />}
       <div className="mt-8 flex flex-col-reverse gap-3 border-t border-slate-100 pt-5 sm:flex-row sm:justify-between">{step > 0 ? <button type="button" disabled={submitting} onClick={() => { setError(''); setStep((s) => s - 1); }} className="rounded-xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">Volver</button> : <span />}{step < 3 ? <button type="button" disabled={loadingServices || loadingSlots} onClick={continueStep} className="rounded-xl bg-emerald-800 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-emerald-900 disabled:cursor-not-allowed disabled:opacity-50">Continuar <span aria-hidden="true">→</span></button> : <button type="button" disabled={submitting} onClick={() => verification ? setCodeOpen(true) : confirmBooking()} className="rounded-xl bg-emerald-800 px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-emerald-900 disabled:cursor-wait disabled:opacity-60">{submitting ? 'Procesando…' : verification ? 'Ingresar código de verificación' : customer?.appointments?.length > 0 ? 'Confirmar agendamiento' : 'Enviar código de verificación'}</button>}</div>
      <p className="mt-5 text-center text-xs text-slate-400">La disponibilidad se confirma nuevamente al registrar tu solicitud.</p>
    </div></section></div></main>;
}
