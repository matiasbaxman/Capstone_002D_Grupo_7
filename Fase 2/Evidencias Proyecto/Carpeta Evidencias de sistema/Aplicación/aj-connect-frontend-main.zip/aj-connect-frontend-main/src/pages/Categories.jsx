import { useToast, notificationMessages } from '../components/notifications/useToast.js';
import { useEffect, useState } from 'react';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import InventoryTabs from '../components/InventoryTabs.jsx';
import CategoriesModal from '../components/CategoriesModal.jsx';
import { listCategoryPage, updateCategory, mensajeDeError } from '../api/inventory.js';
import { getSession } from '../api/session.js';
import { sessionIdentity } from '../utils/sessionIdentity.js';


function ArchiveDialog({ category, onClose, onSaved }) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function save() {
    if (saving) return;
    setSaving(true);
    try { onSaved(await updateCategory(category.id, {is_active: !category.is_active})); }
    catch (err) { setError(mensajeDeError(err)); setSaving(false); }
  }
  return <ConfirmDialog title={`${category.is_active ? 'Archivar' : 'Reactivar'} «${category.name}»`} confirmLabel={category.is_active ? 'Archivar' : 'Reactivar'} busyLabel="Guardando…" busy={saving} error={error} onCancel={onClose} onConfirm={save}>
    {category.is_active ? 'Sus insumos se conservarán. La categoría dejará de estar disponible para nuevas asignaciones.' : 'La categoría volverá a estar disponible al crear o reclasificar insumos.'}
  </ConfirmDialog>;
}

export default function Categories({ onNavigate }) {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [count, setCount] = useState(0);
  const [ordering, setOrdering] = useState('name');
  const [query, setQuery] = useState('');
  useEffect(() => {
    const timer = setTimeout(() => { if (search.trim() !== query) { setLoading(true); setQuery(search.trim()); } }, 250);
    return () => clearTimeout(timer);
  }, [search, query]);
  const [editor, setEditor] = useState(null);
  const [archive, setArchive] = useState(null);
  const toast = useToast();
  const role = sessionIdentity(getSession()?.access).role;
  const canManage = role === 'Administrador' || role === 'Recepcionista';
  useEffect(() => {
    let active = true;
    listCategoryPage({page, search:query, status, ordering}).then((data) => { if (active) { setCategories(data.results); setCount(data.count); setError(''); } }).catch((err) => { if (active) { if (err.response?.status === 404 && page > 1) setPage(page - 1); else setError(mensajeDeError(err)); } }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [attempt, page, query, status, ordering]);
  function saved(category) {
    setLoading(true); setAttempt((value) => value + 1);
    toast.success(archive ? (category.is_active ? notificationMessages.categoryRestored : notificationMessages.categoryArchived) : editor?.category ? notificationMessages.categoryUpdated : notificationMessages.categoryCreated, { icon: archive ? (category.is_active ? 'restore' : 'archive') : editor?.category ? 'save' : 'create' });
    setEditor(null); setArchive(null);
  }
  const visible = categories;
  function sort(field) {
    setPage(1); setLoading(true);
    setOrdering(ordering === field ? `-${field}` : field);
  }
  function sortLabel(field, label) { return `${label} ${ordering === field ? '↑' : ordering === `-${field}` ? '↓' : '↕'}`; }
  function openItems(event, category) {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault(); onNavigate(`/dashboard/inventario?category=${category.id}`);
  }
  return <section>
    <header className="inventory-heading"><div><h1>Inventario</h1><p>Administra las categorías de tus insumos.</p></div>{canManage && <button className="admin-primary-action rounded-lg bg-[var(--button)] px-4 py-2 text-sm font-semibold text-[var(--button-text)]" onClick={() => setEditor({category:null})}>+ Nueva categoría</button>}</header>
    <InventoryTabs path="/dashboard/inventario/categorias" onNavigate={onNavigate} />
    <div className="inventory-filters mt-6"><label className="inventory-search"><span className="sr-only">Buscar categorías</span><input type="text" value={search} onChange={(event) => { if (page !== 1) setLoading(true); setPage(1); setSearch(event.target.value); }} placeholder="Buscar categoría…" className="w-full rounded-lg border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-sm" /></label><label className="inventory-filter"><span className="sr-only">Estado de la categoría</span><select value={status} onChange={(event) => {setPage(1);setLoading(true);setStatus(event.target.value);}}><option value="">Todos los estados</option><option value="active">Activas</option><option value="archived">Archivadas</option></select></label>{(search || status) && <button className="inventory-reset" onClick={() => {if (page !== 1 || status) setLoading(true);setPage(1);setSearch('');setStatus('');}}>Limpiar filtros</button>}</div>
    {error ? <div className="admin-alert" role="alert">{error}<button onClick={() => {setLoading(true);setAttempt(attempt+1);}}>Reintentar</button></div> : loading ? <p className="mt-5 text-sm text-[var(--muted)]">Cargando categorías…</p> : <div className="mt-4 overflow-x-auto rounded-xl border border-[var(--line)] bg-[var(--surface)]"><table className="inventory-data-table w-full text-left text-sm"><caption className="sr-only">Categorías de inventario</caption><thead className="bg-[var(--chrome)] text-xs text-[var(--muted)]"><tr><th className="px-4 py-3" scope="col" aria-sort={ordering === 'name' ? 'ascending' : ordering === '-name' ? 'descending' : 'none'}><button onClick={() => sort('name')} className="inventory-sort-button">{sortLabel('name', 'Nombre')}</button></th><th className="px-4 py-3" scope="col" aria-sort={ordering === 'item_count' ? 'ascending' : ordering === '-item_count' ? 'descending' : 'none'}><button onClick={() => sort('item_count')} className="inventory-sort-button">{sortLabel('item_count', 'Insumos asociados')}</button></th><th className="px-4 py-3" scope="col" aria-sort={ordering === 'is_active' ? 'ascending' : ordering === '-is_active' ? 'descending' : 'none'}><button onClick={() => sort('is_active')} className="inventory-sort-button">{sortLabel('is_active', 'Estado')}</button></th>{canManage && <th className="px-4 py-3 text-right" scope="col">Acciones</th>}</tr></thead><tbody className="divide-y divide-[var(--line)]">{visible.length ? visible.map((category) => <tr key={category.id} className="transition hover:bg-[var(--chrome)]"><td className="px-4 py-3 font-medium">{category.name}</td><td className="px-4 py-3 tabular-nums"><a className="category-count-link" href={`/dashboard/inventario?category=${category.id}`} onClick={(event) => openItems(event, category)} aria-label={`Ver ${category.item_count} insumos de ${category.name}`}>{category.item_count} <span aria-hidden="true">↗</span></a></td><td className="px-4 py-3"><span className={`category-status ${category.is_active ? 'is-active' : ''}`}>{category.is_active ? 'Activa' : 'Archivada'}</span></td>{canManage && <td className="px-4 py-3"><div className="flex justify-end gap-2"><button aria-label={`Editar ${category.name}`} className="category-action" onClick={() => setEditor({category})}>Editar</button><button aria-label={`${category.is_active ? 'Archivar' : 'Reactivar'} ${category.name}`} className="category-action" onClick={() => setArchive(category)}>{category.is_active ? 'Archivar' : 'Reactivar'}</button></div></td>}</tr>) : <tr><td colSpan={canManage ? 4 : 3} className="px-4 py-12 text-center text-[var(--muted)]">{search || status ? 'No hay categorías que coincidan con los filtros.' : 'Aún no hay categorías registradas.'}</td></tr>}</tbody></table></div>}
    {!loading && !error && <nav className="category-pagination" aria-label="Paginación de categorías"><span>{count ? `${(page - 1) * 20 + 1}–${Math.min(page * 20, count)} de ${count} categorías` : '0 categorías'}</span><div><button disabled={page === 1} onClick={() => {setLoading(true);setPage(page-1);}}>Anterior</button><span>Página {page} de {Math.max(1, Math.ceil(count / 20))}</span><button disabled={page * 20 >= count} onClick={() => {setLoading(true);setPage(page+1);}}>Siguiente</button></div></nav>}
    {editor && <CategoriesModal category={editor.category} onClose={() => setEditor(null)} onSaved={saved} />}
    {archive && <ArchiveDialog category={archive} onClose={() => setArchive(null)} onSaved={saved} />}
  </section>;
}



