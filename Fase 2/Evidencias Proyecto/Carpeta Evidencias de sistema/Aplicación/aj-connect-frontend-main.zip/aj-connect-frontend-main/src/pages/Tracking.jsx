import AttentionTimeline from '../components/AttentionTimeline.jsx';
import { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import { BACKEND_URL } from '../api/axiosConfig.js';
import { formatPlate } from '../utils/plateValidation.js';
import { formatDateTime } from '../utils/format.js';
import './Tracking.css';

const publicApi = axios.create({ baseURL: `${BACKEND_URL}/api`, timeout: 15000 });
const validToken = value => /^(?:[0-9a-f]{32}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})$/i.test(value) || /^AJ[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{12}$/.test(value.replaceAll('-', '').toUpperCase());

export default function Tracking({ token, attention }) {
  const [input, setInput] = useState(token);
  const [photoIndex, setPhotoIndex] = useState(null);
  const photoDialog = useRef(null);
  const photoTrigger = useRef(null);
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(token && !validToken(token) ? 'El código de seguimiento no es válido. Revisa el enlace o código recibido.' : '');
  const [loading, setLoading] = useState(Boolean(token) && validToken(token));
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    if (!token) return;
    if (!validToken(token)) return;
    let active = true;
    let controller;
    async function load() {
      if (document.hidden) return;
      controller?.abort(); controller = new AbortController();
      try {
        const { data } = await publicApi.get(`/tracking/${encodeURIComponent(token)}/`, { signal: controller.signal });
        if (active) { setOrder(data); setError(''); setLoading(false); }
      } catch (err) {
        if (!active || axios.isCancel(err)) return;
        if (err.response?.status === 429) { setError('Demasiadas consultas. Espera unos minutos antes de intentarlo nuevamente.'); }
        else if (err.response?.status === 404) { setOrder(null); setError('No encontramos una orden con este código. Revisa el enlace recibido.'); }
        else setError('No pudimos actualizar el estado. Revisa tu conexión e inténtalo nuevamente.');
        setLoading(false);
      }
    }
    load(); const interval = setInterval(load, 30000);
    const visible = () => { if (!document.hidden) load(); };
    document.addEventListener('visibilitychange', visible);
    return () => { active = false; controller?.abort(); clearInterval(interval); document.removeEventListener('visibilitychange', visible); };
  }, [token, retry]);
  useEffect(() => {
    const dialog = photoDialog.current;
    if (photoIndex !== null && dialog && !dialog.open) dialog.showModal();
    if (photoIndex === null && dialog?.open) dialog.close();
  }, [photoIndex]);
  function closePhoto() { setPhotoIndex(null); requestAnimationFrame(() => photoTrigger.current?.focus()); }
  function submit(event) {
    event.preventDefault();
    const next = input.trim();
    if (!validToken(next)) { setError('Ingresa el código completo de seguimiento.'); return; }
    window.location.assign(`/seguimiento/${encodeURIComponent(next)}`);
  }
  const appointment = order?.appointment || (attention && !attention.withoutAppointment ? attention : null);
  const number = order?.folio_number || attention?.work_order__folio_number || attention?.id?.split(':').at(-1).slice(0, 8).toUpperCase();
  return <main className="tracking"><div className="tracking-wrap"><section className="tracking-intro"><a href="/cliente#atenciones" className="tracking-back-button">← Volver a mis atenciones</a><h1>{number ? `Detalle de atención N.° ${number}` : 'Tu vehículo, paso a paso'}</h1></section>{!token && !attention && <form className="tracking-card tracking-form" onSubmit={submit}><label htmlFor="tracking-token">Código de seguimiento</label><input id="tracking-token" value={input} onChange={e => { setInput(e.target.value); setError(''); }} autoComplete="off" spellCheck={false} placeholder="Ej: AJ-7K4P-9M2X-6Q3D" /><button type="submit">Consultar estado →</button></form>}{loading && <div className="tracking-card" role="status">Consultando el estado de tu vehículo…</div>}{error && <div className="tracking-error" role="alert"><h2>No pudimos consultar tu orden</h2><p>{error}</p>{token && <div className="tracking-error-actions"><button type="button" onClick={() => { setLoading(!order); setRetry(n => n + 1); }}>Intentar de nuevo</button> <a href="/seguimiento">Ingresar otro código</a></div>}</div>}{(attention || order) && <AttentionTimeline appointment={appointment} order={order} />}{attention && <section className="tracking-card"><h2>Datos de la atención</h2><p>{attention.scheduled_date ? formatDateTime(attention.scheduled_date) : 'Ingreso en taller'}</p><p className="whitespace-pre-wrap break-words">{attention.reported_symptoms}</p>{!token && <p>Los datos del vehículo, fotografías e insumos aparecerán aquí cuando el taller registre su recepción.</p>}</section>}{order && <><section className="tracking-card tracking-vehicle"><h2>Tu vehículo</h2><dl className="tracking-details"><div><dt>Patente</dt><dd>{order.vehicle?.plate ? formatPlate(order.vehicle.plate) : 'No informada'}</dd></div><div><dt>Vehículo</dt><dd>{order.vehicle?.label || 'No informado'}</dd></div><div><dt>Ingreso al taller</dt><dd>{formatDateTime(order.created_at)}</dd></div><div><dt>Entrega estimada</dt><dd>{order.estimated_delivery_date ? formatDateTime(order.estimated_delivery_date) : 'Por confirmar'}</dd></div></dl>{order.technical_diagnosis && <div className="tracking-diagnosis"><h3>Diagnóstico</h3><p>{order.technical_diagnosis}</p></div>}</section><section className="tracking-card"><h2>Fotografías de ingreso</h2><p className="tracking-caption">Registro de la condición del vehículo al llegar al taller.</p>{order.photos?.length ? <div className="tracking-photos">{order.photos.map((url, index) => <button type="button" key={index} onClick={event => { photoTrigger.current = event.currentTarget; setPhotoIndex(index); }} aria-label={`Ampliar fotografía de ingreso ${index + 1}`}><img src={url} alt={`Fotografía de ingreso ${index + 1}`} loading="lazy" /></button>)}</div> : <p className="tracking-empty">No hay fotografías de ingreso disponibles.</p>}</section><section className="tracking-card"><h2>Repuestos asociados</h2><p className="tracking-caption">Elementos registrados para esta atención.</p>{order.items?.length ? <ul className="tracking-parts">{order.items.map((item, index) => <li key={`${item.item_sku}-${index}`}><strong>{item.item_name}</strong><span>Cantidad: {item.quantity}</span></li>)}</ul> : <p className="tracking-empty">Aún no hay repuestos asociados a esta atención.</p>}</section></>}</div><dialog ref={photoDialog} className="tracking-photo-dialog" aria-label="Fotografía de ingreso ampliada" onCancel={event => { event.preventDefault(); closePhoto(); }} onClick={event => { if (event.target === event.currentTarget) closePhoto(); }}><div className="tracking-photo-viewer"><header><span>Fotografía {photoIndex !== null ? photoIndex + 1 : ''} de {order?.photos?.length || 0}</span><button type="button" onClick={closePhoto} aria-label="Cerrar fotografía">×</button></header>{photoIndex !== null && order?.photos?.[photoIndex] && <img src={order.photos[photoIndex]} alt={`Fotografía de ingreso ${photoIndex + 1} ampliada`} />}{(order?.photos?.length || 0) > 1 && <nav aria-label="Navegación de fotografías"><button type="button" onClick={() => setPhotoIndex(i => (i - 1 + order.photos.length) % order.photos.length)}>← Anterior</button><button type="button" onClick={() => setPhotoIndex(i => (i + 1) % order.photos.length)}>Siguiente →</button></nav>}</div></dialog></main>;
}
