import { useSyncExternalStore } from 'react';

const key = 'ajconnect:theme';
const event = 'ajconnect:theme-change';
let tabPreference = null;
const media = window.matchMedia('(prefers-color-scheme: dark)');
function preference() {
  try { return localStorage.getItem(key); } catch { return null; }
}
function snapshot() {
  const saved = tabPreference || preference();
  return saved === 'light' || saved === 'dark' ? saved : media.matches ? 'dark' : 'light';
}
function apply() { document.documentElement.dataset.theme = snapshot(); }
function subscribe(callback) {
  const update = () => { apply(); callback(); };
  window.addEventListener(event, update);
  window.addEventListener('storage', update);
  media.addEventListener('change', update);
  return () => {
    window.removeEventListener(event, update);
    window.removeEventListener('storage', update);
    media.removeEventListener('change', update);
  };
}
export function useTheme() {
  const theme = useSyncExternalStore(subscribe, snapshot);
  function toggleTheme() {
    const next = theme === 'dark' ? 'light' : 'dark';
    tabPreference = next;
    try { localStorage.setItem(key, next); tabPreference = null; } catch { /* Keep the preference in memory when browser storage is unavailable. */ }
    document.documentElement.dataset.theme = next;
    window.dispatchEvent(new Event(event));
  }
  return { theme, toggleTheme };
}
apply();

