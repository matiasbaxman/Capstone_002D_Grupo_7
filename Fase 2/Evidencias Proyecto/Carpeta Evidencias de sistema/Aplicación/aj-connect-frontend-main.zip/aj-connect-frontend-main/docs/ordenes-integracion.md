# HU-05: órdenes de trabajo

Frontend: `/dashboard/ordenes` y `/dashboard/ordenes/:id`.
Se usan las rutas reales del backend de Romero, fusionado en main.

- GET `/api/workshop/work-orders/`: listado con filtros opcionales.
- GET `/api/workshop/work-orders/:id/`: detalle con cliente, vehículo, ingreso e historial.
- PATCH `/api/workshop/work-orders/:id/`: cambio mediante `status_id`.
- POST `/api/workshop/work-orders/:id/items/`: `{ item, quantity, request_id }`.

`src/api/workshop.js` adapta snake_case al componente. El detalle incluye `items`, `allowed_statuses` y `can_add_items`. Los estados disponibles vienen del servidor; se envía su ID al actualizar.

La asociación devuelve el insumo creado. El frontend relee el detalle para mostrar precios históricos y stock confirmado. Conserva el mismo `request_id` tras un fallo de una misma asociación: el backend devuelve el vínculo existente sin descontar stock otra vez. Reutilizar el identificador para otra cantidad o insumo devuelve 409.

Migraciones nuevas: `0005_workorderitem_request_id_and_more` agrega unicidad por OT y solicitud; `0006_workorder_status_catalog` crea los códigos del esquema suministrado (RECEPCIONADO, DIAGNOSTICO, REPARACION, LISTO, ENTREGADO), conservando registros existentes.

Se mantiene la política del backend de transiciones entre estados del catálogo. Cambio e historial comparten transacción; asociación y descuento también. El servidor exige administrador o mecánico. La UI confirma éxito solo tras una respuesta válida.

## T-08: fotografías

El check-in conectado por Romero envía los archivos preparados en multipart. Se procesan secuencialmente en el navegador, hasta 1920 px de lado mayor y JPEG con calidad 0.82. Si el resultado ocupa más que el original, se conserva el original. Límite: 10 fotos JPG/PNG/WebP de hasta 10 MB cada una. Se muestra procesamiento y peso resultante; las imágenes corruptas se rechazan.

## Verificación

- `node scripts/test-workshop.mjs`: adaptación del contrato e IDs de estados y asociación/relectura con transporte simulado.
- `node scripts/test-session.mjs`: renovación y persistencia de sesión.
- `npm run lint` y `npm run build`.
- Pruebas de backend de consulta, estados, permisos, stock e idempotencia.

T-12 y la subida real a Cloudinary quedan para validación final. No se subieron archivos ni se modificó la base remota durante esta integración.
