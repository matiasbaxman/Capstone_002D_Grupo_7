# Integración de recepción (frontend)

`CheckIn` recibe dos adaptadores. La ruta `/dashboard/check-in` conecta `lookupClient` a POST `/api/workshop/clients/lookup/` y `onSubmit` a POST `/api/workshop/check-in/` mediante multipart. Las fotografías se comprimen antes de enviarlas. El servidor confirma el registro y entrega el folio de OT. No hay clientes ficticios ni resultados de éxito simulados.

## lookupClient(rut)

Recibe el RUT normalizado, sin puntos ni guion, con K mayúscula. Devuelve:

```js
{
  client: { id, firstName, lastName, phone, email, notificationChannel },
  vehicles: [{ id, plate, label }]
}
```

Para un cliente no registrado devuelve explícitamente `{ client: null, vehicles: [] }`. Los errores de conexión o permisos deben rechazar la promesa; nunca convertirse en `client: null`. `label` es opcional (marca/modelo). El adaptador traduce los nombres del API al contrato de la interfaz; este documento no define tablas ni endpoints.

## onSubmit(payload)

Recibe `clientId` (null para cliente nuevo), `vehicleId` (null para vehículo nuevo), datos del cliente, patente normalizada, odómetro numérico, combustible, elementos presentes, observaciones y `photos` como archivos File. Teléfono nuevo: +569 seguido de ocho dígitos. El folio de OT lo genera el servidor.

La selección de cliente existente reutiliza su ID; los datos mostrados son de consulta y no solicitan modificar su perfil. El backend debe resolver unicidad, autorizaciones y creación de atención/OT, incluyendo concurrencia. El backend crea la cuenta sin contraseña utilizable y programa una bienvenida por el canal elegido solamente al registrar un cliente nuevo. La búsqueda devuelve notificationChannel para conservar la preferencia en futuras recepciones.

La interfaz no crea ni activa cuentas. El backend debe confirmar registro y subida antes de comunicar éxito. La respuesta incluye `work_order.folio_number`; la interfaz muestra éxito y limpia el formulario después del registro.

## Política temporal de comunicación

Correo obligatorio para recepción y agendamiento; teléfono/WhatsApp opcional. Los códigos y la bienvenida se envían por correo mientras se resuelven las restricciones de las cuentas de prueba de WhatsApp. El frontend conserva los formularios adaptables a teléfono y PC.
