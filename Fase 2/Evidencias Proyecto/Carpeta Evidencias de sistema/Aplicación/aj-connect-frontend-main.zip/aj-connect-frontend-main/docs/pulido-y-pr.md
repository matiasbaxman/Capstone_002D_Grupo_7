# Revisión del frontend y preparación del PR

## Base de trabajo

Rama local: `codex/pulido-y-docker`, creada desde `origin/main`.
Al preparar el entorno no existían ramas remotas `dev` ni `develop`.
Destino previsto: `main`. Comprobarlo de nuevo antes de abrir el PR.

El backend tiene una rama del mismo nombre. Son dos repositorios y requieren
dos PR distintos. El Compose del backend depende del Dockerfile de este repo:
para probar el conjunto deben estar disponibles ambas ramas.

## Primer alcance

- Dockerfile de desarrollo, exclusiones y ejemplo de variables.
- Documentación de arranque y rutas reales.
- Plantilla de PR con validaciones y dependencias entre repositorios.
- Corrección de la carga inicial de citas: actualiza estado al responder la
  petición e ignora respuestas tras desmontar, resolviendo el error de lint.
- Inicio simplificado a título, descripción y fecha.
- Transiciones de inventario sin desplazamiento ni reinicio de animación.

## Prioridad de diseño: uso del mecánico desde celular

El celular es el dispositivo principal de trabajo del mecánico. Las próximas
correcciones deben diseñarse y verificarse primero en pantallas pequeñas;
adaptar una vista de escritorio no basta como validación de experiencia móvil.

- Verificar anchos de 360, 390 y 430 px y navegación con una mano.
- Mantener acciones táctiles principales de al menos 48 px y separación cómoda.
- Evitar desbordamiento horizontal de la página y controles cortados.
- Revisar recepción, cámara/fotos, órdenes y consumo de repuestos con prioridad.
- Mantener formularios utilizables con el teclado abierto, errores junto al campo
  y acciones de guardar/cancelar accesibles.
- Verificar menús, diálogos, contraste, foco y estados de carga en móvil.
- Comprobar Android/Chrome e iPhone/Safari antes de cerrar una revisión móvil.

Estos son criterios para el pulido pendiente; todavía no se completó una
validación integral en dispositivos móviles.

## Recorrido pendiente para pulir las funcionalidades existentes

- [ ] Login: credenciales incorrectas, recordar sesión, renovación y logout.
- [ ] Navegación: enlaces directos, recarga y accesos según rol.
- [ ] Inventario y categorías: altas, edición, búsquedas, paginación y stock bajo.
- [ ] Personal: validaciones, creación y múltiples roles.
- [ ] Recepción: cliente nuevo/existente, patente, fotos y errores de subida.
- [ ] Órdenes: filtros, diagnóstico, estados, historial y consumo de repuestos.
- [ ] Agenda: disponibilidad, reserva, confirmación, reprogramación y cancelación.
- [ ] Estados vacíos, fallos de API, teclado y pantallas móviles.

Convertir hallazgos en cambios con alcance concreto y evidencia. La existencia
de esta lista no significa que esos recorridos ya estén verificados. Conectar
el portal de clientes o crear nuevos módulos requiere definir su alcance.

## Antes del PR

Ejecutar lint, build y ambos scripts de pruebas; registrar resultados reales.
Adjuntar capturas cuando cambie la interfaz y enlazar el PR del backend.
Mantener commits separados para infraestructura, documentación y correcciones.
Actualizar referencias remotas y revisar el diff contra la base antes de subir.
Un push puede crear un Preview de Vercel según la configuración del proyecto.

## Validación del entorno — 25 de octubre de 2026

- `npm.cmd ci --no-audit --no-fund`: completado con Node 24.
- `npm.cmd run lint`: correcto tras la corrección de carga de citas.
- `npm.cmd run build`: correcto.
- `node scripts/test-session.mjs`: correcto.
- `node scripts/test-workshop.mjs`: correcto.
- Docker local: imágenes construidas y servicios iniciados; HTTP 200 en frontend
  y backend. Inicio de sesión local verificado.
- Inicio y navegación Insumos/Categorías: revisados en navegador de escritorio.
- Recorridos integrales y validación móvil: pendientes.

Estas pruebas no reemplazan la revisión funcional de cada pantalla.
