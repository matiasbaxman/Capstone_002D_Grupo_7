# Nueva orden: diseño de recepción móvil

## Etapa actual: interfaz

El registro se agrupa en tres pantallas utilizando los campos y la API que ya
existían. No se agregan endpoints ni simulaciones de búsqueda o guardado.

1. **Cliente y vehículo:** búsqueda por RUT, datos del cliente nuevo cuando
   corresponde, selección de vehículo registrado o ingreso de uno nuevo.
2. **Ingreso y fotos:** kilometraje, combustible mediante botones, elementos
   presentes, observaciones y fotografías con cámara o galería.
3. **Confirmación:** resumen de la recepción y fotografías, accesos para editar
   los pasos anteriores y acción final «Crear orden de trabajo».

La tarjeta de identificación comienza directamente con «Ingresa el RUT del
cliente» y el texto «Obligatorio» en rojo, respaldado por `required` y
`aria-required`. Al buscar se reemplaza por el estado «Buscando cliente», un
indicador de progreso y el RUT consultado. Se mantiene al menos 600 ms para
evitar un destello en respuestas rápidas, tanto en resultados como en errores.
La espera mínima corre en paralelo con la petición: si la API tarda más, no
se agregan otros 600 ms. Solo se muestra el resultado cuando la API responde.
El cambio usa un fundido cruzado: el formulario se desvanece con un desenfoque
leve y el indicador aparece gradualmente. Ambas capas comparten el espacio para
evitar saltos; los controles quedan inactivos durante la búsqueda. Con movimiento
reducido, el cambio es inmediato y sin desenfoque.

En móvil se usa una columna, entradas de 16 px para evitar el zoom automático,
controles de al menos 48 px y barra inferior con acciones de 56 px. Se reserva
espacio de desplazamiento para llegar al último campo y los toast quedan encima
de la barra. El indicador mantiene tres etapas y el encabezado conserva su
alineación aunque cambie la altura de la pantalla.

La validación existente de cliente y vehículo se ejecuta antes de pasar a
Ingreso y fotos; la condición de ingreso es recomendada y al menos una fotografía sigue
siendo necesaria antes de la confirmación. Retroceder conserva lo ingresado.
Crear la orden es la única acción que persiste la recepción en el servidor.

## Próxima etapa funcional

El paso «Cliente y vehículo» muestra una sola tarjeta a la vez: búsqueda,
cliente encontrado o formulario de alta, y finalmente vehículo. «Usar este
cliente» valida los datos del cliente antes de mostrar el vehículo. «Volver»
desde el vehículo permite revisar al cliente conservando los datos ingresados.
El resumen lateral se oculta durante este paso para mantener una sola tarea visible.
Cuando
no existe el cliente, el mensaje «Cliente no registrado» aparece desde abajo
integrado en la barra de acciones. El botón principal pasa a «Ingresar cliente
al sistema →» y abre el formulario sin guardar todavía ningún registro.
«Buscar por otro RUT» permite reiniciar la búsqueda cuando no hay coincidencias.
Desde el cliente encontrado, «Volver» regresa a la búsqueda; desde el alta,
regresa al resultado sin coincidencias conservando el formulario para retomarlo.

- Búsqueda principal por patente, con alternativa por RUT.
- Recuperación de datos desde una cita y precarga del motivo de ingreso.
- Apertura de la orden recién creada en lugar de reiniciar el formulario.
- Revisión de los campos mínimos, selección de mecánico y borrador recuperable.

Estos puntos son propuestas pendientes; no están habilitados en la interfaz.

## Comprobaciones

Revisado el recorrido local hasta Confirmación con datos ficticios y una imagen
del repositorio, sin guardar una orden ni subir fotografías a Cloudinary.
Se comprobó la conservación de datos y la navegación entre los pasos. Falta
validar cámara/teclado en teléfonos físicos y el flujo completo con servicios
externos cuando se aborde la etapa funcional.

## Ficha del cliente encontrado

La ficha muestra contacto, vehículos asociados por patente y un resumen real de sus órdenes: cantidad de atenciones y fecha de ingreso de la última orden. La búsqueda por RUT devuelve `client.history.attentionCount` y `client.history.lastAttentionAt`; las citas pendientes no cuentan como atenciones. Sin órdenes muestra un estado vacío y, si falta el resumen en la respuesta, indica «No disponible». No se muestran fotos ni iniciales del cliente.

## Ingreso y fotos: una tarea a la vez

El paso 2 se divide internamente en condición de ingreso y fotografías. Los datos de condición son recomendados: si faltan se muestran en un aviso con puntos naranjos y se requiere pulsar «Confirmar y seguir a fotos»; un kilometraje informado debe ser válido. después se requiere al menos una imagen para revisar la orden. Volver desde fotos muestra la condición conservando datos e imágenes. Al llegar desde el vehículo se abre primero la condición. No se crean registros hasta confirmar la orden.

Los elementos se registran como Sí, No o Sin revisar. La API admite kilometraje nulo, combustible vacío y elementos nulos; omitirlos no equivale a 0 km ni a elementos ausentes. La migración 0011 habilita estos valores sin alterar los registros anteriores.

## Elementos adicionales

Rueda de repuesto y gata/herramientas son campos base. «Otro elemento» permite agregar hasta 20 nombres de 80 caracteres, sin duplicados, cada uno con estado Sí/No/Sin revisar y opción Quitar. El API recibe `additional_equipment` como JSON en multipart y lo devuelve en el detalle del check-in. Se guardan en la recepción, separados del inventario de repuestos. Los elementos sin revisar forman parte del aviso de condición incompleta; el aviso presenta cada categoría faltante en una lista vertical.
