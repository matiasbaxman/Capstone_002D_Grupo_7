# shadcn/ui

El frontend tiene configurada la base de shadcn/ui para React, Vite, Tailwind 4 y JavaScript. Los componentes se agregan de forma gradual con `npx shadcn@latest add <componente>` y viven en `src/components/ui`. El alias `@` apunta a `src`, y `cn` combina clases en `src/lib/utils.js`.

Los colores semánticos de Tailwind se conectan a los tokens existentes de `src/theme.css`, incluidos los temas claro y oscuro. Revisar visualmente cada componente y sus estados antes de incorporarlo; la configuración no reemplaza los componentes actuales ni implementa indicadores o gráficos. Para gráficos, instalar y evaluar Recharts al abordar esa funcionalidad.

Los commits se mantienen en `maintenance/general-improvements`; integrar mediante revisión hacia `dev` antes de cualquier cambio en `main`.
