# Toast: avisos del sistema

## Propósito

Confirma acciones y comunica avisos breves sin interrumpir el trabajo. El celular
es el dispositivo prioritario del mecánico: se muestra un aviso a la vez abajo,
con 12 px de separación del área segura y una entrada hacia arriba con rebote
suave, dejando libres el navbar, los títulos y las opciones superiores. En escritorio se ven
hasta tres, abajo a la derecha. Ambos respetan las áreas seguras del dispositivo.

## Uso

`ToastProvider` envuelve la aplicación en `src/main.jsx`. Para usarlo:

```jsx
import { useToast, notificationMessages } from '../components/notifications/useToast.js';

const toast = useToast();

toast.success(notificationMessages.itemUpdated, { icon: 'save' });
toast.error('No pudimos guardar los cambios.', {
  description: 'Revisa tu conexión e inténtalo nuevamente.',
});
const id = toast.info('Procesando solicitud…', { duration: 0 });
// Al terminar la operación:
toast.dismiss(id);
```

El hook requiere el proveedor y devuelve `success`, `error`, `warning`, `info`
y `dismiss`. Los cuatro primeros devuelven el identificador del mensaje, o
`null` si el texto está vacío. No cambian datos ni ejecutan la acción descrita.

| Opción | Comportamiento |
| --- | --- |
| `message` | Texto principal obligatorio; cadena no vacía |
| `description` | Detalle opcional, por ejemplo el folio de la OT |
| `icon` | `login`, `logout`, `create`, `save`, `checkin`, `archive`, `restore` o un tipo de aviso |
| `duration` | Milisegundos visibles; `0` conserva el aviso hasta cerrarlo |

Un icono desconocido usa el del tipo. Duraciones inválidas usan el valor
predeterminado. Los mensajes compartidos se agregan a `notificationMessages`;
no copies textos idénticos en distintas pantallas.

## Tipos y duraciones

| Tipo | Cuándo utilizarlo | Duración predeterminada |
| --- | --- | --- |
| `success` | Acción confirmada por el servidor | 6 segundos |
| `info` | Información breve no urgente | 6 segundos |
| `warning` | Situación que requiere atención | Hasta cierre manual |
| `error` | Operación que no pudo completarse | Hasta cierre manual |

No anuncies éxito antes de recibir confirmación. Explica el resultado y, cuando
corresponda, cómo continuar. No muestres contraseñas, tokens, respuestas crudas
del servidor ni información privada innecesaria.

## Cola y temporizador

Al cerrar un aviso o vencer su tiempo, baja y se desvanece durante 200 ms antes
de retirarse. El siguiente mensaje espera a que termine esa salida. Con movimiento
reducido desaparece sin desplazamiento.

- La cola es FIFO, sin eliminar el aviso antiguo cuando llega uno nuevo.
- Hasta 640 px se muestra uno; por encima, hasta tres. El contador indica
  cuántos quedan por mostrar. Un error persistente se cierra para avanzar.
- El tiempo solo corre mientras el aviso está visible. Esperar en cola no lo
  consume; al reducir el ancho se conserva el tiempo restante de los ocultos.
- Se pausa al enfocar el texto o el cierre, pasar el puntero, mantener una
  pulsación y ocultar la pestaña. Reanuda el tiempo restante al dejar de
  interactuar, siempre que no quede otro motivo de pausa.
- Se deduplican tipo + mensaje + descripción, incluso en cola. Dos folios
  distintos no se agrupan. Un duplicado devuelve el mismo ID sin reiniciar tiempo.
- Al desmontar el proveedor se cancelan sus temporizadores; tolera el ciclo de
  montaje y limpieza de React Strict Mode.

## Diseño y accesibilidad

El cierre tiene un área táctil de 48 × 48 px, etiqueta accesible y foco visible.
Texto e icono identifican el tipo sin depender solo del color. Los errores usan
`role="alert"`; el resto, `role="status"`. Los avisos no roban el foco y sus
textos largos pueden desplazarse con teclado. Respetan movimiento reducido,
tema claro/oscuro y las áreas seguras superior, inferior y laterales.

En móvil se usa el margen inferior de 12 px más el área segura del dispositivo,
tanto en el panel como en las páginas sin navbar. El aviso puede cubrir parte
del contenido inferior mientras está visible; se muestra solo uno y puede cerrarse.
Mantén el texto
breve. No reemplaces errores junto al campo, confirmaciones destructivas
ni información que deba quedar consultable en la pantalla. Si una acción ocurre
en un diálogo, conserva allí los errores: el diálogo mantiene su propio foco.

## Archivos

- `src/components/notifications/ToastProvider.jsx`: integración con React,
  accesibilidad, interacciones y límite según ancho.
- `src/components/notifications/toastStore.js`: cola y temporizadores.
- `src/components/notifications/useToast.js`: API pública y textos compartidos.
- `src/components/notifications/ToastIcon.jsx`: iconos.
- `src/components/notifications/Toast.css`: presentación y adaptación móvil.

## Verificación

```powershell
node scripts/test-toasts.mjs
npm.cmd run lint
npm.cmd run build
```

Las pruebas cubren cola, persistencia, pausas simultáneas, cambio de ancho,
desmontaje, deduplicación, descripción y duración personalizada. Para cerrar
una revisión visual, comprobar 360, 390 y 430 px, mensajes largos, teclado,
ambos temas y movimiento reducido. La prueba final en Android/Chrome,
iPhone/Safari y lectores de pantalla reales sigue siendo necesaria.

Comprobado en navegador con anchos de 360, 390 y 430 px: un solo aviso visible,
sin desbordamiento horizontal, cierre medido de 48 × 48 px, descripción y textos
largos legibles. Revisados los temas claro y oscuro y el avance de la cola al
cerrar. En escritorio, comprobados tres visibles y el cuarto en espera. Estos
controles usan viewport de escritorio; no sustituyen dispositivos físicos.
