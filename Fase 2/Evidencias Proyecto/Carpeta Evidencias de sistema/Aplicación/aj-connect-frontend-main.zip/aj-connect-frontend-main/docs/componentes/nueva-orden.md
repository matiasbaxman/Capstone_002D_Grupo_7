# Acceso flotante: Nueva orden

Acceso persistente a `/dashboard/check-in`, disponible dentro del panel para
Administrador y Mecánico. Usa el texto «Nueva orden», con un icono de suma,
en la esquina inferior derecha y un área táctil de al menos 56 px de alto.

Abre la recepción existente: no crea una orden hasta confirmar el formulario.
La recepción se organiza visualmente en tres pasos: Cliente y vehículo,
Ingreso y fotos, y Confirmación. Reutiliza la búsqueda por RUT y el guardado
existentes. Consulta [Diseño de recepción](recepcion.md).

- Respeta las áreas seguras del dispositivo y la navegación por teclado.
- Se oculta en recepción, con la navegación lateral móvil abierta, con un
  diálogo abierto o al enfocar un campo de escritura en móvil.
- El contenido tiene espacio inferior para que las últimas acciones puedan
  desplazarse por encima del acceso flotante.
- Los toast se desplazan por encima del botón para mantenerlo accesible.
- La API sigue validando los permisos; la visibilidad no reemplaza esa validación.

La implementación vive en `src/layouts/AdminLayout.jsx` y `AdminLayout.css`;
la separación de los avisos está en `src/components/notifications/Toast.css`.
