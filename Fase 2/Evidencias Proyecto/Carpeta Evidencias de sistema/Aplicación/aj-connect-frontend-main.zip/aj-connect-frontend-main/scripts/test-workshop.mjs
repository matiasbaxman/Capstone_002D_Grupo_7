import assert from 'node:assert/strict';
import { createServer } from 'vite';

class MemoryStorage {
  values = new Map();
  getItem(key) { return this.values.get(key) ?? null; }
  setItem(key, value) { this.values.set(key, String(value)); }
  removeItem(key) { this.values.delete(key); }
}
globalThis.localStorage = new MemoryStorage();
globalThis.sessionStorage = new MemoryStorage();
globalThis.window = new EventTarget();
const server = await createServer({ server: { middlewareMode: true } });
try {
  const { default: api } = await server.ssrLoadModule('/src/api/axiosConfig.js');
  const session = await server.ssrLoadModule('/src/api/session.js');
  const expires = Math.floor(Date.now() / 1000) + 3600;
  const refresh = `header.${Buffer.from(JSON.stringify({ exp: expires })).toString('base64url')}.signature`;
  session.saveSession({ access: 'test-only-access', refresh });
  const workshop = await server.ssrLoadModule('/src/api/workshop.js');
  const calls = [];
  const detail = { id: 'ot-1', folio_number: 1001, status_code: 'RECEPCIONADO', status: 'Recepcionado', status_id: 1, client: { full_name: 'Cliente de prueba', rut: '123456785' }, vehicle: { plate: 'BCDF12' }, allowed_statuses: [{ id: 2, code: 'EN_REPARACION', name: 'En reparación' }], can_add_items: true, items: [{ id: 'part-1', item: 'item-1', item_name: 'Filtro', item_sku: 'F1', quantity: 2, unit_price: '5000.00', current_stock: 3 }], status_history: [], checkin: { id: 'checkin-1', initial_odometer: 85000, photos: ['https://example.test/photo.jpg'] } };
  api.defaults.adapter = async (config) => {
    const body = typeof config.data === 'string' ? JSON.parse(config.data) : config.data;
    calls.push({ url: config.url, method: config.method, body });
    const data = config.url.endsWith('/items/') ? { id: 'part-1' } : config.url === '/workshop/work-orders/' ? [detail] : detail;
    return { status: 200, statusText: 'OK', headers: {}, config, data };
  };
  assert.equal((await workshop.listWorkOrders())[0].folio, 1001);
  const order = await workshop.getWorkOrder('ot-1');
  assert.equal(order.parts[0].unitPrice, 5000);
  assert.equal(order.parts[0].currentStock, 3);
  assert.equal(order.allowedStatuses[0].id, 2);
  assert.equal(order.checkIn.photos[0].url, 'https://example.test/photo.jpg');
  await workshop.updateOrderStatus('ot-1', 2);
  assert.deepEqual(calls.at(-1).body, { status_id: 2 });
  await workshop.addOrderPart('ot-1', 'item-1', 2, 'request-1');
  assert.deepEqual(calls.at(-2).body, { item: 'item-1', quantity: 2, request_id: 'request-1' });
  assert.equal(calls.at(-1).method, 'get');
  assert.equal(calls.at(-1).url, '/workshop/work-orders/ot-1/');
  api.defaults.adapter = async config => ({ status: 200, statusText: 'OK', headers: {}, config, data: new Blob(['%PDF-QA'], { type: 'application/pdf' }) });
  assert.equal((await workshop.getQuotePdf('quote-1')).type, 'application/pdf');
  api.defaults.adapter = async config => ({ status: 200, statusText: 'OK', headers: {}, config, data: new Blob(['not a PDF'], { type: 'application/json' }) });
  await assert.rejects(workshop.getQuotePdf('quote-1'), /no es un PDF/);
  console.log('Contrato de OT, estados, repuestos y MIME de cotización: OK');
} finally {
  await server.close();
}
