import assert from 'node:assert/strict';
import { Buffer } from 'node:buffer';
import { createServer } from 'vite';
import axios from 'axios';
class MemoryStorage {
  values = new Map();
  getItem(key) { return this.values.get(key) ?? null; }
  setItem(key, value) { this.values.set(key, String(value)); }
  removeItem(key) { this.values.delete(key); }
}
globalThis.localStorage = new MemoryStorage();
globalThis.sessionStorage = new MemoryStorage();
globalThis.window = new EventTarget();
const jwt = (expiry) => `header.${Buffer.from(JSON.stringify({ exp: expiry })).toString('base64url')}.signature`;
const deadline = Math.floor(Date.now() / 1000) + 3600;
const tokens = { access: 'old-access', refresh: jwt(deadline) };
const server = await createServer({ server: { middlewareMode: true } });
const originalPost = axios.post;
try {
  const session = await server.ssrLoadModule('/src/api/session.js');
  const { default: api } = await server.ssrLoadModule('/src/api/axiosConfig.js');
  session.saveSession(tokens);
  assert.equal(localStorage.getItem('access'), null);
  assert.equal(sessionStorage.getItem('access'), tokens.access);
  session.saveSession(tokens, true);
  assert.equal(sessionStorage.getItem('access'), null);
  assert.equal(localStorage.getItem('access'), tokens.access);
  console.log('Persistencia elegida y limpieza del almacenamiento anterior: OK');

  let refreshes = 0;
  axios.post = async () => {
    refreshes += 1;
    await new Promise((resolve) => setTimeout(resolve, 10));
    return { data: { access: 'new-access', refresh: jwt(deadline + 3600) } };
  };
  api.defaults.adapter = async (config) => {
    if (config.headers.Authorization === 'Bearer old-access') {
      throw { config, response: { status: 401 } };
    }
    return { config, status: 200, data: 'ok', headers: {} };
  };
  const responses = await Promise.all([api.get('/inventory/items/'), api.get('/inventory/categories/')]);
  assert.equal(refreshes, 1);
  assert.ok(responses.every((response) => response.data === 'ok'));
  assert.equal(session.getSession().expiresAt, deadline * 1000);
  assert.equal(session.getSession().access, 'new-access');
  console.log('401 simultáneos: una renovación, reintento y límite original conservado: OK');

  session.saveSession(tokens);
  axios.post = async () => { throw { response: { status: 401 } }; };
  await assert.rejects(api.get('/inventory/items/'));
  assert.equal(session.getSession(), null);
  console.log('Refresh inválido: sesión eliminada: OK');

  session.saveSession(tokens);
  axios.post = async () => { throw new Error('Sin conexión'); };
  await assert.rejects(api.get('/inventory/items/'));
  assert.ok(session.getSession());
  console.log('Fallo de red temporal: sesión conservada para reintentar: OK');

  const previousRevision = session.getSession().revision;
  session.clearSession();
  assert.throws(() => session.updateSession({ access: 'late-access' }, previousRevision));
  assert.equal(localStorage.getItem('access'), null);
  assert.equal(sessionStorage.getItem('access'), null);
  session.saveSession({ access: 'expired', refresh: jwt(1) }, true);
  assert.equal(session.getSession(), null);
  session.clearSession();
  console.log('Cierre de sesión, respuesta tardía y expiración: OK');
} finally {
  axios.post = originalPost;
  await server.close();
}
