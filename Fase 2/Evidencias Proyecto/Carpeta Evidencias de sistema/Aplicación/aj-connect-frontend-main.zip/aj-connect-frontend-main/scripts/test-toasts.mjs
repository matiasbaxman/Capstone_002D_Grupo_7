import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createToastStore } from '../src/components/notifications/toastStore.js';

function fixture(limit = 3, exitDuration = 0) {
  let time = 0;
  let next = 0;
  const timers = new Map();
  const store = createToastStore({
    exitDuration,
    now: () => time,
    schedule(callback, delay) { const id = ++next; timers.set(id, { callback, at: time + delay }); return id; },
    cancel: (id) => timers.delete(id),
  });
  store.setLimit(limit);
  store.pauseAll('unmounted', false);
  function tick(ms) {
    const end = time + ms;
    while (true) {
      const due = [...timers].filter(([, timer]) => timer.at <= end).sort((a, b) => a[1].at - b[1].at)[0];
      if (!due) break;
      time = due[1].at;
      timers.delete(due[0]);
      due[1].callback();
    }
    time = end;
  }
  return { store, tick, timers };
}

test('mobile preserves persistent errors and starts queued notice time only when shown', () => {
  const { store, tick } = fixture(1);
  const error = store.notify('error', 'No se pudo guardar');
  const success = store.notify('success', 'Cambios guardados');
  tick(20000);
  assert.equal(store.getSnapshot().visible[0].id, error);
  assert.equal(store.getSnapshot().pending, 1);
  store.dismiss(error);
  tick(5999);
  assert.equal(store.getSnapshot().visible[0].id, success);
  tick(1);
  assert.equal(store.getSnapshot().visible.length, 0);
});

test('manual close slides out before promoting the queue and ignores repeated closes', () => {
  const { store, tick } = fixture(1, 200);
  const first = store.notify('error', 'Error');
  const next = store.notify('success', 'Guardado');
  store.dismiss(first);
  assert.equal(store.getSnapshot().visible[0].leaving, true);
  tick(100);
  store.dismiss(first);
  tick(99);
  assert.equal(store.getSnapshot().visible[0].id, first);
  tick(1);
  assert.equal(store.getSnapshot().visible[0].id, next);
  tick(5999);
  assert.equal(store.getSnapshot().visible[0].leaving, false);
  tick(1);
  assert.equal(store.getSnapshot().visible[0].leaving, true);
  tick(200);
  assert.equal(store.getSnapshot().visible.length, 0);
});

test('unmount clears exit timers and remount completes the pending dismissal', () => {
  const { store, tick, timers } = fixture(1, 200);
  const id = store.notify('info', 'Aviso');
  store.dismiss(id);
  store.pauseAll('unmounted', true);
  assert.equal(timers.size, 0);
  tick(1000);
  store.pauseAll('unmounted', false);
  tick(200);
  assert.equal(store.getSnapshot().visible.length, 0);
  assert.equal(timers.size, 0);
});

test('focus and pointer pauses overlap and retain the remaining reading time', () => {
  const { store, tick } = fixture();
  const id = store.notify('info', 'Información');
  tick(2000);
  store.pause(id, 'focus', true);
  store.pause(id, 'pointer', true);
  tick(10000);
  store.pause(id, 'pointer', false);
  tick(10000);
  assert.equal(store.getSnapshot().visible.length, 1);
  store.pause(id, 'focus', false);
  tick(3999);
  assert.equal(store.getSnapshot().visible.length, 1);
  tick(1);
  assert.equal(store.getSnapshot().visible.length, 0);
});

test('switching to mobile pauses displaced messages without discarding them', () => {
  const { store, tick } = fixture();
  const first = store.notify('warning', 'Atención');
  const second = store.notify('info', 'Segundo');
  const third = store.notify('error', 'Tercero');
  store.notify('success', 'Cuarto');
  tick(2000);
  store.setLimit(1);
  tick(10000);
  assert.equal(store.getSnapshot().pending, 3);
  store.dismiss(first);
  assert.equal(store.getSnapshot().visible[0].id, second);
  tick(4000);
  assert.equal(store.getSnapshot().visible[0].id, third);
  assert.equal(store.getSnapshot().pending, 1);
});

test('hidden tabs and unmount stop timers; remount resumes instead of leaking', () => {
  const { store, tick, timers } = fixture();
  store.notify('success', 'Guardado');
  tick(1000);
  store.pauseAll('hidden', true);
  assert.equal(timers.size, 0);
  tick(10000);
  store.pauseAll('unmounted', true);
  store.pauseAll('hidden', false);
  assert.equal(timers.size, 0);
  store.pauseAll('unmounted', false);
  tick(5000);
  assert.equal(store.getSnapshot().visible.length, 0);
  assert.equal(timers.size, 0);
});

test('deduplication includes descriptions so different order folios are preserved', () => {
  const { store } = fixture(1);
  const first = store.notify('success', 'Check-in registrado', { description: 'OT 1' });
  assert.equal(store.notify('success', 'Check-in registrado', { description: 'OT 1' }), first);
  assert.notEqual(store.notify('success', 'Check-in registrado', { description: 'OT 2' }), first);
  assert.equal(store.getSnapshot().pending, 1);
  assert.equal(store.notify('info', '  '), null);
});

test('explicit persistence and custom timeout work; dismissing queued notices is safe', () => {
  const { store, tick } = fixture(1);
  const first = store.notify('success', 'Persistente', { duration: 0 });
  const queued = store.notify('info', 'En cola');
  store.dismiss(queued);
  tick(20000);
  assert.equal(store.getSnapshot().visible[0].id, first);
  store.dismiss(first);
  store.notify('warning', 'Advertencia temporal', { duration: 1000 });
  tick(1000);
  assert.equal(store.getSnapshot().visible.length, 0);
  store.dismiss(-1);
});
