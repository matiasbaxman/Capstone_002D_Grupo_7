# A&J Connect — Frontend

Interfaz React 19 + Vite 8, Tailwind CSS y Axios. Consume la API del repositorio
hermano `aj-connect-backend`.

## Desarrollo con Docker

Requisitos: Docker Desktop con el motor Linux iniciado y Docker Compose 2.24 o
superior. Clona ambos repositorios como carpetas hermanas:

```text
ajconnect/
├── aj-connect-frontend/
└── aj-connect-backend/
```

Desde `aj-connect-backend`:

```powershell
docker compose -f compose.dev.yaml up --build -d
docker compose -f compose.dev.yaml exec backend python manage.py createsuperuser
docker compose -f compose.dev.yaml logs -f
```

Abre http://127.0.0.1:5173/dashboard e inicia sesión con ese superusuario.
El montaje compartido permite editar el código desde Windows; Vite recarga la
interfaz. El contenedor instala las dependencias al iniciar para mantener el
volumen `node_modules` alineado con `package-lock.json`.

Los archivos Docker son de desarrollo. El Compose vive en el backend y necesita
el `Dockerfile.dev` de este repositorio. Consulta su README para persistencia,
fotos, pruebas y comandos de mantenimiento.

## Desarrollo sin Docker en Windows

Requiere Node.js 24 y el backend iniciado en otra terminal.

```powershell
npm.cmd ci
Copy-Item .env.example .env.development.local
npm.cmd run dev -- --host 127.0.0.1 --port 5173 --strictPort
```

`VITE_API_URL=http://127.0.0.1:8000` identifica al backend. Axios agrega `/api`.
Las variables `VITE_` son públicas: nunca incluyas claves privadas en ellas.

## Pantallas actuales

| Ruta | Función |
| --- | --- |
| `/` | Portada pública |
| `/agendar` | Reserva pública con verificación de contacto, dos cupos por hora |
| `/cliente` | Acceso OTP y órdenes del cliente |
| `/seguimiento/:codigo` y `/tracking/:codigo` | Seguimiento público |
| `/dashboard` | Login o resumen de inventario |
| `/dashboard/inventario` | Insumos y existencias |
| `/dashboard/inventario/categorias` | Categorías |
| `/dashboard/check-in` | Ingreso de vehículos y fotografías |
| `/dashboard/ordenes` | Listado de órdenes |
| `/dashboard/ordenes/:id` | Detalle, estados e insumos de una orden |
| `/dashboard/citas` | Gestión de citas |
| `/dashboard/users` | Listado y creación de personal con roles |
| `/dashboard/cuenta` | Consulta de datos de la sesión |

`/admin...` y `/inventario` redirigen a la estructura actual. Los permisos se
aplican también en la API; ocultar una pantalla no reemplaza esa validación.
El portal del cliente usa una sesión separada del personal, con vencimiento de una hora.
El detalle de OT permite generar, previsualizar, descargar y enviar cotizaciones.
La API calcula los precios netos, IVA y total; el correo se procesa en un worker.

## Componentes

Los cambios de interfaz deben priorizar el teléfono: los mecánicos trabajan
principalmente desde dispositivos móviles. Mantener también la adaptación a PC,
los controles táctiles accesibles y la ausencia de desbordamientos horizontales.

La documentación de los avisos está en [Componentes: Toast](docs/componentes/toast.md).

## Sesión

Sin recordar sesión, los tokens se guardan en `sessionStorage`; al recordarla,
en `localStorage`. Axios renueva el acceso ante un 401. La sesión conserva el
límite original del refresh, actualmente un día. Cerrar sesión limpia el
navegador; aún no revoca los tokens en el servidor. La identidad visual se lee
del JWT, mientras la API verifica cada petición autenticada.

## Validación y PR

```powershell
npm.cmd test
npm.cmd run lint
npm.cmd run build
node scripts/test-session.mjs
node scripts/test-workshop.mjs
```

Desde el backend, también puedes ejecutar estos comandos con
`docker compose -f compose.dev.yaml exec frontend ...`, usando `npm` en Linux.

El plan de revisión está en [docs/pulido-y-pr.md](docs/pulido-y-pr.md).
La plantilla de PR pide pruebas, límites y el enlace al PR del backend.

## Producción

`npm.cmd run build` genera `dist/`; utiliza `VITE_API_URL` del despliegue al
compilar. `vercel.json` conserva las rutas de la SPA. Comprueba en Vercel qué
rama está configurada para producción antes de publicar cambios. Los archivos
Docker de desarrollo no reemplazan ese despliegue.
