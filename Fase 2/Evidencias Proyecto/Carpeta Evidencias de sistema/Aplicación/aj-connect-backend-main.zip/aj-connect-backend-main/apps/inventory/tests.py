from django.contrib.auth.models import User
from rest_framework.test import APITestCase
from apps.authentication.models import UserProfile, Role, UserRole
from .models import ItemCategory


class CategoryTests(APITestCase):
    url = '/api/inventory/categories/'

    def setUp(self):
        self.admin = User.objects.create_user('admin', is_superuser=True)

    def test_normalization_and_duplicates(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post(self.url, {'name': '  Aceites   motor  '})
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data['name'], 'Aceites motor')
        self.assertEqual(self.client.post(self.url, {'name': 'aceites motor'}).status_code, 400)
        self.assertEqual(self.client.post(self.url, {'name': '   '}).status_code, 400)
        self.assertEqual(ItemCategory.objects.count(), 1)

    def test_role_permissions(self):
        self.assertEqual(self.client.get(self.url).status_code, 401)
        for role in ('ADMIN', 'RECEPCIONISTA', 'MECANICO', 'CLIENTE'):
            user = User.objects.create_user(role)
            UserProfile.objects.create(user=user)
            UserRole.objects.create(user=user, role=Role.objects.get(code=role))
            self.client.force_authenticate(user)
            self.assertEqual(self.client.get(self.url).status_code, 403 if role == 'CLIENTE' else 200)
            self.assertEqual(self.client.post(self.url, {'name': role}).status_code, 201 if role in ('ADMIN', 'RECEPCIONISTA') else 403)

    def test_archival_preserves_items_and_blocks_new_assignments(self):
        from .models import InventoryItem
        self.client.force_authenticate(self.admin)
        category = ItemCategory.objects.create(name='Aceites')
        other = ItemCategory.objects.create(name='Filtros')
        item = InventoryItem.objects.create(category=category, sku='A1', name='Aceite', unit_price=100, current_stock=3)
        second = InventoryItem.objects.create(category=other, sku='B1', name='Filtro', unit_price=100)
        detail = f'{self.url}{category.pk}/'
        response = self.client.patch(detail, {'is_active': False})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['item_count'], 1)
        item.refresh_from_db()
        self.assertEqual(item.category_id, category.pk)
        self.assertEqual(self.client.post('/api/inventory/items/', {'sku':'C1', 'name':'Nuevo', 'category':category.pk, 'unit_price':100}).status_code, 400)
        self.assertEqual(self.client.patch(f'/api/inventory/items/{second.pk}/', {'category':category.pk}).status_code, 400)
        self.assertEqual(self.client.patch(f'/api/inventory/items/{item.pk}/', {'category':category.pk, 'name':'Aceite editado'}).status_code, 200)
        self.assertEqual(self.client.delete(detail).status_code, 405)
        self.assertEqual(self.client.patch(detail, {'is_active': True}).status_code, 200)
        self.assertEqual(self.client.patch(f'/api/inventory/items/{second.pk}/', {'category':category.pk}).status_code, 200)

    def test_edit_duplicates_and_mechanic_cannot_archive(self):
        category = ItemCategory.objects.create(name='Aceites')
        ItemCategory.objects.create(name='Filtros')
        self.client.force_authenticate(self.admin)
        detail = f'{self.url}{category.pk}/'
        self.assertEqual(self.client.patch(detail, {'name':' filtros '}).status_code, 400)
        self.assertEqual(self.client.patch(detail, {'name':'Aceites motor'}).status_code, 200)
        mechanic = User.objects.create_user('mechanic')
        UserProfile.objects.create(user=mechanic)
        UserRole.objects.create(user=mechanic, role=Role.objects.get(code='MECANICO'))
        self.client.force_authenticate(mechanic)
        self.assertEqual(self.client.patch(detail, {'is_active':False}).status_code, 403)

    def test_pagination_search_status_and_ordering(self):
        from .models import InventoryItem
        self.client.force_authenticate(self.admin)
        for index in range(25):
            ItemCategory.objects.create(name=f'Cat {index:02}', is_active=index != 24)
        first = ItemCategory.objects.get(name='Cat 00')
        InventoryItem.objects.create(category=first, sku='TEST', name='Test', unit_price=0)
        response = self.client.get(self.url)
        self.assertEqual(response.data['count'], 25)
        self.assertEqual(len(response.data['results']), 20)
        second = self.client.get(self.url, {'page':2})
        self.assertEqual(len(second.data['results']), 5)
        self.assertFalse(set(row['id'] for row in response.data['results']) & set(row['id'] for row in second.data['results']))
        filtered = self.client.get(self.url, {'search':'Cat 24', 'status':'archived'})
        self.assertEqual(filtered.data['count'], 1)
        self.assertEqual(self.client.get(self.url, {'status':'active'}).data['count'], 24)
        ordered = self.client.get(self.url, {'ordering':'-item_count'})
        self.assertEqual(ordered.data['results'][0]['id'], first.pk)
        self.assertEqual(self.client.get(self.url, {'page':99}).status_code, 404)
        self.assertEqual(self.client.get(self.url, {'status':'invalid'}).status_code, 400)
