from django.contrib import admin
from .models import ItemCategory, InventoryItem

@admin.register(ItemCategory)
class ItemCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'created_at')
    search_fields = ('name',)

@admin.register(InventoryItem)
class InventoryItemAdmin(admin.ModelAdmin):
    list_display = ('sku', 'name', 'category', 'current_stock', 'minimum_stock', 'unit_price', 'is_low_stock')
    list_filter = ('category',)
    search_fields = ('sku', 'name')