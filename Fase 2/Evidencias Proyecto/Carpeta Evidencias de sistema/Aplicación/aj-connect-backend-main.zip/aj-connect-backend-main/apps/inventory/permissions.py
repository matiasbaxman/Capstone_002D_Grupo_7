from rest_framework.permissions import BasePermission, SAFE_METHODS

from apps.authentication.permissions import is_admin, is_recepcionista, is_mecanico


class InventoryItemPermissions(BasePermission):
    """Inventario: lectura para todos los autenticados; escritura para Administrador y Recepcionista."""

    message = 'El rol Mecánico tiene acceso de solo consulta a Inventario.'

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if request.method in SAFE_METHODS:
            return True
        return is_admin(user) or is_recepcionista(user)


class CategoryPermissions(BasePermission):
    """Personal consulta; administración y recepción gestionan categorías."""

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if is_admin(user):
            return True
        if request.method in SAFE_METHODS:
            # Mecánico y Recepcionista pueden consultar el catálogo de categorías.
            return is_mecanico(user) or is_recepcionista(user)
        return is_recepcionista(user)
