import uuid
from django.db import models

class ItemCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'item_categories'
        verbose_name = 'Categoría de Insumo'
        verbose_name_plural = 'Categorías de Insumos'

    def __str__(self):
        return self.name


class InventoryItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    category = models.ForeignKey(ItemCategory, on_delete=models.PROTECT, related_name='items')
    sku = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True, null=True)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    current_stock = models.IntegerField(default=0)
    minimum_stock = models.IntegerField(default=5)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'inventory_items'
        indexes = [
            models.Index(fields=['category'], name='idx_inv_items_cat'),
            models.Index(fields=['sku'], name='idx_inv_sku'),
        ]
        verbose_name = 'Insumo de Inventario'
        verbose_name_plural = 'Insumos de Inventario'

    def __str__(self):
        return f"[{self.sku}] {self.name} (Stock: {self.current_stock})"

    @property
    def is_low_stock(self):
        return self.current_stock <= self.minimum_stock
