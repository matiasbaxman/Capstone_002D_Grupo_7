from django.db.models import Count
from rest_framework import viewsets, permissions, filters
from rest_framework.pagination import PageNumberPagination
from rest_framework.exceptions import ValidationError
from .models import ItemCategory, InventoryItem
from .permissions import CategoryPermissions, InventoryItemPermissions
from .serializers import ItemCategorySerializer, InventoryItemSerializer


class CategoryPagination(PageNumberPagination):
    page_size = 20


class CategoryOrdering(filters.OrderingFilter):
    def get_ordering(self, request, queryset, view):
        ordering = super().get_ordering(request, queryset, view) or ['name']
        return [*ordering, 'id']


class ItemCategoryViewSet(viewsets.ModelViewSet):
    pagination_class = CategoryPagination
    filter_backends = [filters.SearchFilter, CategoryOrdering]
    search_fields = ['name']
    ordering_fields = ['name', 'item_count', 'is_active']
    ordering = ['name']

    def get_queryset(self):
        queryset = super().get_queryset()
        # Filters affect the list only, never lookup for edits or archival.
        if self.action == 'list':
            status = self.request.query_params.get('status', '')
            if status not in ('', 'active', 'archived'):
                raise ValidationError({'status': 'Estado inválido.'})
            if status:
                queryset = queryset.filter(is_active=status == 'active')
        return queryset

    queryset = ItemCategory.objects.annotate(item_count=Count('items')).order_by('name')
    http_method_names = ['get', 'post', 'patch', 'head', 'options']
    serializer_class = ItemCategorySerializer
    permission_classes = [permissions.IsAuthenticated, CategoryPermissions]


class InventoryItemViewSet(viewsets.ModelViewSet):
    # select_related optimiza la consulta SQL trayendo la categoría en un solo JOIN
    queryset = InventoryItem.objects.select_related('category').all().order_by('name')
    serializer_class = InventoryItemSerializer
    permission_classes = [permissions.IsAuthenticated, InventoryItemPermissions]

    # Búsqueda por SKU, nombre o categoría, y ordenamiento dinámico
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['sku', 'name', 'category__name']
    ordering_fields = ['name', 'current_stock', 'unit_price', 'created_at']
