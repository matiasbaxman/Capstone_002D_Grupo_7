from rest_framework import serializers
from .models import ItemCategory, InventoryItem


class ItemCategorySerializer(serializers.ModelSerializer):
    item_count = serializers.IntegerField(read_only=True, default=0)
    def validate_name(self, value):
        name = ' '.join(value.split())
        if not name:
            raise serializers.ValidationError('Ingresa un nombre para la categoría.')
        existing = ItemCategory.objects.filter(name__iexact=name)
        if self.instance:
            existing = existing.exclude(pk=self.instance.pk)
        if existing.exists():
            raise serializers.ValidationError('Ya existe una categoría con ese nombre.')
        return name

    class Meta:
        model = ItemCategory
        fields = ['id', 'name', 'is_active', 'item_count', 'created_at']


class InventoryItemSerializer(serializers.ModelSerializer):
    # Campo booleano calculado para que el front reciba la alerta directamente
    is_low_stock = serializers.BooleanField(read_only=True)
    
    # Detalle de la categoría legible (nombre) además del ID
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = InventoryItem
        fields = [
            'id',
            'sku',
            'name',
            'description',
            'category',
            'category_name',
            'unit_price',
            'current_stock',
            'minimum_stock',
            'is_low_stock',
            'created_at',
            'updated_at',
        ]

    def validate_category(self, value):
        # Existing assignments survive archival, including edits to the item.
        if not value.is_active and (not self.instance or self.instance.category_id != value.pk):
            raise serializers.ValidationError('Esta categoría está archivada. Selecciona una categoría activa.')
        return value

    # Validaciones de negocio: precios y stock no negativos
    def validate_current_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock actual no puede ser negativo.")
        return value

    def validate_unit_price(self, value):
        if value < 0:
            raise serializers.ValidationError("El precio unitario no puede ser negativo.")
        return value
