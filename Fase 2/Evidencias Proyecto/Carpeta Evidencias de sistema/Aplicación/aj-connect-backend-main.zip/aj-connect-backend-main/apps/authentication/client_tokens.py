from django.core.exceptions import ValidationError
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import AuthenticationFailed, InvalidToken, TokenError
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.tokens import Token

from apps.workshop.models import Client


class ClientAccessToken(Token):
    # Un JWT de cliente nunca es un AccessToken de empleado.
    token_type = 'client_access'
    lifetime = api_settings.ACCESS_TOKEN_LIFETIME

    @classmethod
    def for_client(cls, client):
        token = cls()
        token['client_id'] = str(client.pk)
        token['sub'] = str(client.pk)
        token['principal_type'] = 'client'
        return token


class ClientJWTAuthentication(JWTAuthentication):
    """Usar explícitamente en futuras vistas privadas del portal de clientes."""

    def get_validated_token(self, raw_token):
        try:
            return ClientAccessToken(raw_token)
        except TokenError as error:
            raise InvalidToken('El token de cliente no es válido o expiró.') from error

    def get_user(self, validated_token):
        if validated_token.get('principal_type') != 'client':
            raise InvalidToken('El token no corresponde a un cliente.')
        try:
            return Client.objects.get(pk=validated_token.get('client_id'))
        except (Client.DoesNotExist, ValidationError, ValueError, TypeError) as error:
            raise AuthenticationFailed('Cliente no encontrado.') from error
