from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.test import APIClient

from .models import Role


class UserAndTokenTests(TestCase):
    def setUp(self):
        self.api = APIClient()
        self.admin = User.objects.create_superuser('auth-admin', 'admin@example.test', 'test-only')

    def test_login_entrega_roles_y_ultimo_acceso(self):
        respuesta = self.api.post(
            '/api/auth/login/',
            {'username': 'auth-admin', 'password': 'test-only'},
            format='json',
        )
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn('Administrador', respuesta.data['roles'])
        self.assertEqual(respuesta.data['role'], 'Administrador')
        self.assertTrue(respuesta.data['is_superuser'])
        self.assertEqual(respuesta.data['roles_detail'][-1]['code'], 'ADMIN')
        self.assertIsNotNone(User.objects.get(username='auth-admin').last_login)

    def test_listado_expone_rol_de_superusuario(self):
        self.api.force_authenticate(self.admin)
        respuesta = self.api.get('/api/auth/users/')
        self.assertEqual(respuesta.status_code, 200)
        entry = next(item for item in respuesta.data if item['username'] == 'auth-admin')
        self.assertIn('Administrador', entry['roles'])
        self.assertEqual(entry['full_name'], 'auth-admin')
        self.assertEqual(entry['roles_detail'][-1]['code'], 'ADMIN')

    def test_crear_usuario_asigna_los_roles_del_payload(self):
        rol = Role.objects.get_or_create(code='MECANICO', defaults={'name': 'Mecánico'})[0]
        self.api.force_authenticate(self.admin)
        respuesta = self.api.post(
            '/api/auth/users/',
            {
                'username': 'nuevo-mecanico',
                'password': 'secret123',
                'first_name': 'Carla',
                'last_name': 'Muñoz',
                'roles': [str(rol.pk)],
            },
            format='json',
        )
        self.assertEqual(respuesta.status_code, 201)
        self.assertIn('Mecánico', respuesta.data['roles'])
        usuario = User.objects.get(username='nuevo-mecanico')
        self.assertTrue(usuario.check_password('secret123'))
        self.assertTrue(usuario.user_roles.filter(role=rol).exists())

    def test_serializador_de_usuarios_reemplaza_sus_roles(self):
        # No hay endpoint de detalle aún: se valida el serializer directamente.
        from .serializers import UserCreateSerializer

        mecanico = Role.objects.get_or_create(code='MECANICO', defaults={'name': 'Mecánico'})[0]
        recepcionista = Role.objects.get_or_create(code='RECEPCIONISTA', defaults={'name': 'Recepcionista'})[0]
        usuario = User.objects.create_user('empleado', password='test-only')
        usuario.user_roles.create(role=mecanico)

        serializer = UserCreateSerializer(
            instance=usuario, data={'roles': [str(recepcionista.pk)]}, partial=True
        )
        self.assertTrue(serializer.is_valid(), serializer.errors)
        serializer.save()

        usuario.refresh_from_db()
        self.assertFalse(usuario.user_roles.filter(role=mecanico).exists())
        self.assertTrue(usuario.user_roles.filter(role=recepcionista).exists())

    def test_usuario_duplicado_devuelve_400(self):
        User.objects.create_user('repetido', password='test-only')
        self.api.force_authenticate(self.admin)
        respuesta = self.api.post(
            '/api/auth/users/',
            {'username': 'repetido', 'password': 'secret123'},
            format='json',
        )
        self.assertEqual(respuesta.status_code, 400)
        self.assertIn('username', respuesta.data)
        self.assertEqual(User.objects.count(), 2)
