from rest_framework import generics, permissions
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth.models import User
from .models import Role
from .serializers import (
    CustomTokenObtainPairSerializer,
    RoleSerializer,
    UserCreateSerializer,
    UserListSerializer,
)
from .permissions import IsAdminRole


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class UserListCreateView(generics.ListCreateAPIView):
    """
    GET /api/auth/users/ : Retorna el listado de empleados registrados con sus perfiles y roles.
    POST /api/auth/users/ : Registra un nuevo empleado con transacción atómica.
    """
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]

    def get_queryset(self):
        return (
            User.objects.select_related('profile')
            .prefetch_related('user_roles__role')
            .all()
            .order_by('-date_joined')
        )

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserCreateSerializer
        return UserListSerializer


class RoleListView(generics.ListAPIView):
    """
    GET /api/auth/roles/ : Retorna el catálogo de roles disponibles.
    """
    permission_classes = [permissions.IsAuthenticated, IsAdminRole]
    queryset = Role.objects.all().order_by('name')
    serializer_class = RoleSerializer
