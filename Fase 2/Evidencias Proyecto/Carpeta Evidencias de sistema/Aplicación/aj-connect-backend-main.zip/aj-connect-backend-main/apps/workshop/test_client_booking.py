from django.test import TestCase, override_settings
from rest_framework.test import APIClient
from apps.authentication.client_tokens import ClientAccessToken
from . import test_client_onboarding as helpers
from .models import Client, Appointment

@override_settings(CLIENT_EMAIL_REQUIRED=True)
class ClientBookingTests(TestCase):
    setUp = helpers.ClientOnboardingTests.setUp
    data = helpers.ClientOnboardingTests.data
    booking = helpers.ClientOnboardingTests.booking

    def test_following_booking_requires_session_but_no_code_and_ignores_identity_override(self):
        self.assertEqual(self.booking().status_code, 201)
        customer = Client.objects.get()
        data = {'rut':'223456782', 'email':'attacker@example.test', 'scheduled_date':'2030-01-07T11:00:00-03:00', 'reported_symptoms':'Revisión general'}
        self.assertEqual(self.api.post('/api/auth/client-appointments/', data, format='json').status_code, 401)
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(customer)))
        response = self.api.post('/api/auth/client-appointments/', data, format='json')
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(Appointment.objects.count(), 2)
        self.assertEqual(Appointment.objects.filter(client=customer).count(), 2)
        customer.refresh_from_db()
        self.assertEqual(customer.email, 'ana@example.test')

    def test_authenticated_first_booking_still_requires_code(self):
        self.assertEqual(self.booking().status_code, 201)
        customer = Client.objects.get()
        Appointment.objects.all().delete()
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(customer)))
        response = self.api.post('/api/auth/client-appointments/', {'scheduled_date':'2030-01-07T11:00:00-03:00','reported_symptoms':'Revisión general'}, format='json')
        self.assertEqual(response.status_code, 400)
        self.assertFalse(Appointment.objects.exists())

    def test_existing_customer_cannot_book_anonymously_again(self):
        self.assertEqual(self.booking().status_code, 201)
        payload = {**self.data(), 'scheduled_date':'2030-01-07T11:00:00-03:00','reported_symptoms':'Revisión general'}
        self.assertEqual(self.api.post('/api/appointments/', payload, format='json').status_code, 403)
        self.assertEqual(self.api.post('/api/appointments/verify-contact/', payload, format='json').status_code, 403)
