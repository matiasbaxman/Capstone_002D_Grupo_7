"""Outbox persistente: el proceso HTTP solo registra el trabajo."""
from datetime import timedelta
from django.db import transaction
from django.db.models import F
from django.utils import timezone
from .models import EmailDelivery
from .notifications import send_quote_email, send_work_order_status_email, send_client_welcome, send_appointment_notice


def enqueue_email(kind, target_id):
    return EmailDelivery.objects.create(kind=kind, target_id=target_id)


def enqueue_client_welcome(client):
    """Un solo trabajo por cliente; se confirma junto con su registro."""
    return EmailDelivery.objects.get_or_create(kind='welcome', target_id=client.pk)[0]


def enqueue_order_tracking(order):
    # Si la bienvenida todavía no salió, incluye el seguimiento en ese correo.
    updated = EmailDelivery.objects.filter(
        kind='welcome', target_id=order.vehicle.client_id, status='PENDING', attempts=0, payload={},
    ).update(payload={'work_order_id': str(order.pk)})
    if not updated:
        EmailDelivery.objects.create(kind='work_order', target_id=order.pk, payload={'tracking_only': True})


def process_next():
    now = timezone.now()
    # Recupera trabajos de un worker interrumpido. SMTP no garantiza exactly-once.
    stale = EmailDelivery.objects.filter(status='PROCESSING', locked_at__lt=now - timedelta(minutes=5))
    if stale.exists():
        stale.update(status='PENDING', locked_at=None)
    candidate = EmailDelivery.objects.filter(status='PENDING', available_at__lte=now).order_by('created_at').first()
    if not candidate:
        return False
    with transaction.atomic():
        claimed = EmailDelivery.objects.filter(pk=candidate.pk, status='PENDING').update(status='PROCESSING', locked_at=now, attempts=F('attempts') + 1)
    if not claimed:
        return True
    candidate.refresh_from_db()
    sender = {'quote': send_quote_email, 'work_order': send_work_order_status_email, 'welcome': send_client_welcome}.get(candidate.kind)
    try:
        if candidate.kind == 'appointment_notice':
            success = send_appointment_notice(candidate.payload)
        elif candidate.kind == 'welcome':
            success = send_client_welcome(candidate.target_id, candidate.payload.get('work_order_id'))
        elif candidate.kind == 'work_order' and candidate.payload.get('tracking_only'):
            from .notifications import send_order_tracking
            success = send_order_tracking(candidate.target_id)
        else:
            success = bool(sender and sender(candidate.target_id))
    except Exception:
        success = False
    candidate.status = 'SENT' if success else 'FAILED' if candidate.attempts >= 3 else 'PENDING'
    candidate.last_error = '' if success else 'No se pudo entregar la notificación. Revisa el canal y el proveedor de envío.'
    candidate.sent_at = timezone.now() if success else None
    candidate.available_at = timezone.now() + timedelta(seconds=60 * 2 ** (candidate.attempts - 1))
    candidate.locked_at = None
    candidate.save()
    return True
