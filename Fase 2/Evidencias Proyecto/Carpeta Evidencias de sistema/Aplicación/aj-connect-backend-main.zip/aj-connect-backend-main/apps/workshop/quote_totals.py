from decimal import Decimal, ROUND_HALF_UP


def calculate_totals(items, tax_rate):
    subtotal = sum((line.unit_price * line.quantity for line in items), Decimal('0')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    tax = (subtotal * Decimal(tax_rate) / 100).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return {'subtotal_amount': subtotal, 'tax_amount': tax, 'total_amount': subtotal + tax}
