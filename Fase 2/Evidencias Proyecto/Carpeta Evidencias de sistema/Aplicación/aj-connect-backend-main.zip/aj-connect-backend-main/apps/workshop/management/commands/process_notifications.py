import time
from django.core.management.base import BaseCommand
from django.db import close_old_connections
from apps.workshop.email_queue import process_next


class Command(BaseCommand):
    help = 'Procesa correos y bienvenidas por el canal elegido; ejecutar como worker separado.'

    def add_arguments(self, parser):
        parser.add_argument('--once', action='store_true', help='Procesar los trabajos disponibles y terminar.')

    def handle(self, *args, **options):
        while True:
            close_old_connections()
            processed = process_next()
            if not processed:
                if options['once']:
                    return
                time.sleep(1)
