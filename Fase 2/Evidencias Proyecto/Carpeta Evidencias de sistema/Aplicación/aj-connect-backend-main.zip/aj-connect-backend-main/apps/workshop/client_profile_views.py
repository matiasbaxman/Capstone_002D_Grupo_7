from datetime import timedelta
import secrets
from django.conf import settings
from django.contrib.auth.hashers import make_password, check_password
from django.core.mail import send_mail
from django.db import transaction
from django.utils import timezone
from rest_framework import permissions, serializers
from rest_framework.response import Response
from apps.authentication.client_tokens import ClientJWTAuthentication
from .client_auth_views import PublicClientAuthView, OTPRequestThrottle, OTPVerifyThrottle
from .models import Client, ClientProfileChange

class ProfileSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    email = serializers.EmailField(max_length=255)
    phone = serializers.RegexField(r'^\+569[0-9]{8}$', allow_blank=True, default='')

    def validate_email(self, value):
        return value.strip().lower()

    def validate(self, attrs):
        other = Client.objects.exclude(pk=self.context['client'].pk)
        if other.filter(email__iexact=attrs['email']).exists():
            raise serializers.ValidationError({'email': 'Este correo ya está registrado por otro cliente.'})
        if attrs['phone'] and other.filter(phone=attrs['phone']).exists():
            raise serializers.ValidationError({'phone': 'Este teléfono ya está registrado por otro cliente.'})
        return attrs

class ClientProfileView(PublicClientAuthView):
    authentication_classes = [ClientJWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]
    throttle_classes = [OTPRequestThrottle]

    def post(self, request):
        serializer = ProfileSerializer(data=request.data, context={'client': request.user})
        serializer.is_valid(raise_exception=True)
        try:
            with transaction.atomic():
                client = Client.objects.select_for_update().get(pk=request.user.pk)
                previous = ClientProfileChange.objects.filter(client=client).first()
                now = timezone.now()
                if previous and previous.last_sent_at > now - timedelta(seconds=60):
                    return Response({'detail': 'Espera un minuto antes de solicitar otro código.'}, status=429)
                if not client.email:
                    return Response({'detail': 'Solicita al taller registrar tu correo.'}, status=400)
                code = f'{secrets.randbelow(1000000):06d}'
                ClientProfileChange.objects.update_or_create(client=client, defaults={
                    'payload': serializer.validated_data, 'email_at_request': client.email,
                    'code_hash': make_password(code), 'expires_at': now + timedelta(minutes=5),
                    'last_sent_at': now, 'attempts': 0, 'consumed_at': None,
                })
                sent = send_mail('Código para modificar tus datos A&J Connect',
                                f'Tu código para autorizar los cambios de tus datos personales es {code}. Expira en 5 minutos. Si no solicitaste cambios, no compartas el código.',
                                settings.DEFAULT_FROM_EMAIL, [client.email])
                if sent != 1:
                    raise RuntimeError('No se aceptó el correo.')
        except Exception:
            return Response({'detail': 'No pudimos enviar el código. Tus datos no se modificaron.'}, status=503)
        return Response({'detail': 'Enviamos un código a tu correo actual. Tus datos se guardarán al confirmarlo.'})

class ClientProfileConfirmView(ClientProfileView):
    throttle_classes = [OTPVerifyThrottle]

    def post(self, request):
        code = serializers.RegexField(r'^[0-9]{6}$').run_validation(request.data.get('code'))
        with transaction.atomic():
            client = Client.objects.select_for_update().get(pk=request.user.pk)
            change = ClientProfileChange.objects.select_for_update().filter(client=client).first()
            now = timezone.now()
            if not change or change.consumed_at or change.attempts >= 5 or change.expires_at <= now or change.email_at_request != client.email:
                return Response({'detail': 'El código expiró o ya fue utilizado. Solicita otro.'}, status=400)
            change.attempts += 1
            if not check_password(code, change.code_hash):
                change.save(update_fields=['attempts'])
                return Response({'detail': 'El código es incorrecto.'}, status=400)
            serializer = ProfileSerializer(data=change.payload, context={'client': client})
            serializer.is_valid(raise_exception=True)
            for field, value in serializer.validated_data.items():
                setattr(client, field, value)
            client.save(update_fields=[*serializer.validated_data, 'updated_at'])
            change.consumed_at = now
            change.save(update_fields=['attempts', 'consumed_at'])
        return Response({'detail': 'Tus datos se actualizaron correctamente.'})
