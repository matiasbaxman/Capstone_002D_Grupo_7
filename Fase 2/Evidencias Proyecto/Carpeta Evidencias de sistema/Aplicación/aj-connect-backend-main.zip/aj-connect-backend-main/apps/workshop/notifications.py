"""Envío de avisos por correo para cotizaciones y órdenes de trabajo."""
import logging

from django.conf import settings
from django.core.mail import EmailMessage

logger = logging.getLogger(__name__)


def tracking_instructions(order):
    return (
        f'\nSeguimiento de tu Orden de Trabajo #{order.folio_number}:\n'
        f'Código: {order.tracking_code}\n'
        f'Enlace: {settings.PUBLIC_PORTAL_URL.rstrip("/")}/seguimiento/{order.tracking_code}\n'
        'Puedes consultar tu atención sin iniciar sesión ni crear una contraseña.\n'
        'Conserva este enlace y compártelo solo con personas de confianza.\n'
    )


def send_order_tracking(work_order_id):
    from .models import WorkOrder
    order = WorkOrder.objects.select_related('vehicle__client').get(pk=work_order_id)
    client = order.vehicle.client
    if not client.email:
        return False
    return EmailMessage(
        subject=f'[A&J Connect] Seguimiento de tu atención - Orden #{order.folio_number}',
        body=f'Hola, {client.first_name}:\n\nRegistramos el ingreso de tu vehículo.\n' + tracking_instructions(order),
        from_email=settings.DEFAULT_FROM_EMAIL, to=[client.email],
    ).send(fail_silently=False) == 1


def send_client_welcome(client_id, work_order_id=None):
    """Bienvenida por el canal del cliente, sin contraseña predeterminada."""
    from .models import Client
    from django.utils.module_loading import import_string

    try:
        client = Client.objects.select_related('notification_channel').get(pk=client_id)
        channel = 'EMAIL' if settings.CLIENT_EMAIL_REQUIRED else client.notification_channel.code.upper()
        channel_name = 'WhatsApp' if channel == 'WHATSAPP' else 'correo electrónico'
        body = (
            f'Hola, {client.first_name}:\n\n'
            'Tu cuenta de cliente de A&J Connect está lista.\n\n'
            'Para ingresar:\n'
            f'1. Abre nuestro portal público: {settings.PUBLIC_PORTAL_URL}/\n'
            '2. Presiona «Iniciar sesión», en la parte superior.\n'
            '3. Ingresa tu RUT y presiona «Ingresar» sin contraseña si es tu primera visita.\n'
            f'4. Recibirás un código de seis dígitos por {channel_name}. '
            'Ingrésalo en el portal antes de que expire (cinco minutos).\n'
            '5. En tu primer ingreso, el portal te pedirá crear tu contraseña.\n\n'
            'Tu cuenta se creó sin contraseña predeterminada. Los ingresos posteriores '
            'se realizan con tu RUT y la contraseña que creaste.\n'
            'Si tu contacto registrado es incorrecto, comunícate con el taller para corregirlo.\n\n'
            'A&J Servicio Automotriz'
        )
        if work_order_id:
            from .models import WorkOrder
            order = WorkOrder.objects.get(pk=work_order_id, vehicle__client=client)
            body += '\n' + tracking_instructions(order)
        if channel == 'EMAIL' and client.email:
            message = EmailMessage(
                subject='[A&J Connect] Tu cuenta está lista: instrucciones de ingreso',
                body=body, from_email=settings.DEFAULT_FROM_EMAIL, to=[client.email],
            )
            return message.send(fail_silently=False) == 1
        if channel == 'WHATSAPP' and client.phone:
            if settings.CLIENT_OTP_DELIVERY_MODE == 'simulation' and settings.CLIENT_OTP_ALLOW_SIMULATION:
                logger.warning('SIMULACION BIENVENIDA WhatsApp cliente=%s: %s', client.pk, body)
                return True
            sender_path = settings.CLIENT_WHATSAPP_NOTIFICATION_SENDER
            if settings.CLIENT_OTP_DELIVERY_MODE != 'channel' or not sender_path:
                logger.error('No está configurado el proveedor de notificaciones WhatsApp.')
                return False
            # Adaptador de notificaciones, separado de las plantillas OTP.
            # Debe lanzar excepción o devolver False si el proveedor rechaza.
            return import_string(sender_path)(client.phone, body) is not False
        return False
    except Exception:
        logger.exception('No se pudo preparar o enviar la bienvenida del cliente %s.', client_id)
        return False


def send_client_email(*, client, subject, body, pdf, filename):
    """Envía un correo con un PDF en memoria; devuelve False ante cualquier fallo."""
    if not client.email:
        logger.warning('Notificación omitida: el cliente %s no tiene correo.', client.pk)
        return False

    try:
        message = EmailMessage(
            subject=subject,
            body=body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[client.email],
        )
        message.attach(filename, pdf.getvalue(), 'application/pdf')
        sent = message.send(fail_silently=False)
        if sent != 1:
            logger.error('SMTP no confirmó el correo para el cliente %s.', client.pk)
            return False
        logger.info('Correo enviado a cliente %s (%s).', client.pk, client.email)
        return True
    except Exception:
        # Las notificaciones no deben deshacer cambios de la OT o cotización.
        logger.exception('Error enviando correo al cliente %s.', client.pk)
        return False


def send_work_order_status_email(work_order_id):
    """Genera el informe al vuelo y avisa el cambio de estado de una OT."""
    from .models import WorkOrder
    from .pdf_generator import generate_work_order_pdf

    try:
        order = WorkOrder.objects.select_related(
            'status', 'vehicle__client__notification_channel', 'vehicle__model__brand', 'checkin',
        ).prefetch_related('items__item').get(pk=work_order_id)
        client = order.vehicle.client
        if not settings.CLIENT_EMAIL_REQUIRED and client.notification_channel.code.upper() != 'EMAIL':
            logger.info(
                'Aviso de OT #%s omitido: canal configurado %s.',
                order.folio_number, client.notification_channel.code,
            )
            return False
        pdf = generate_work_order_pdf(order)
        return send_client_email(
            client=client,
            subject=f'[A&J Connect] Actualización en tu Orden de Trabajo - Folio #{order.folio_number}',
            body=(
                f'Estimado/a {client.first_name}:\n\n'
                f'Tu Orden de Trabajo #{order.folio_number} cambió al estado '
                f'"{order.status.name}". Adjuntamos el informe en PDF.\n\n'
                f'{tracking_instructions(order)}\n'
                'A&J Servicio Automotriz'
            ),
            pdf=pdf,
            filename=f'Informe_Tecnico_AJ_OT_{order.folio_number}.pdf',
        )
    except Exception:
        logger.exception('No se pudo preparar el aviso de OT %s.', work_order_id)
        return False


def send_quote_email(quote_id):
    """Genera y envía la cotización PDF del cliente."""
    from .models import Quote
    from .pdf_generator import generate_quote_pdf

    try:
        quote = Quote.objects.select_related(
            'client__notification_channel', 'work_order__vehicle__model__brand',
            'work_order__vehicle__client', 'work_order__checkin',
        ).prefetch_related('items__item').get(pk=quote_id)
        client = quote.client
        if client.notification_channel.code.upper() != 'EMAIL':
            logger.info(
                'Cotización %s omitida: canal configurado %s.',
                quote.pk, client.notification_channel.code,
            )
            return False
        pdf = generate_quote_pdf(quote)
        folio = str(quote.pk)[:8].upper()
        approval = 'aprobada' if quote.is_approved else 'generada'
        return send_client_email(
            client=client,
            subject=f'[A&J Connect] Cotización {approval} - Folio #{folio}',
            body=(
                f'Estimado/a {client.first_name}:\n\n'
                f'Tu cotización {folio} ha sido {approval}. Adjuntamos el documento en PDF.\n\n'
                'A&J Servicio Automotriz'
            ),
            pdf=pdf,
            filename=f'Cotizacion_AJ_{folio}.pdf',
        )
    except Exception:
        logger.exception('No se pudo preparar el aviso de cotización %s.', quote_id)
        return False


def send_appointment_notice(payload):
    from django.core.mail import send_mail
    labels = {'CONFIRMADA': 'aceptada', 'CANCELADA': 'cancelada', 'RECHAZADA': 'rechazada'}
    status = labels.get(payload.get('status'))
    if not status or not payload.get('email'):
        return False
    return send_mail(f'[A&J Connect] Tu cita fue {status}',
                     f"Hola, {payload['name']}. Tu cita para {payload['date']} fue {status}. Consulta los detalles en tu cuenta: {settings.PUBLIC_PORTAL_URL}/cliente",
                     settings.DEFAULT_FROM_EMAIL, [payload['email']]) == 1
