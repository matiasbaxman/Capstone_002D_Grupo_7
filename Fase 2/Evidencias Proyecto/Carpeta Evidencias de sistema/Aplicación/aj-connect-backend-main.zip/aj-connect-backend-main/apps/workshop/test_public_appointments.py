from datetime import datetime
from decimal import Decimal
from unittest.mock import patch
from zoneinfo import ZoneInfo

from django.contrib.auth.hashers import is_password_usable
from django.contrib.auth.models import User
from django.test import TestCase
from django.core.cache import cache
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from datetime import timedelta
from .models import BookingVerification
from .booking_verification import payload_hash
from rest_framework.exceptions import ValidationError
from rest_framework.test import APIClient

from .models import Appointment, Client, NotificationChannel, Service, Vehicle, VehicleBrand, VehicleModel
from .serializers import PublicAppointmentCreateSerializer


class PublicAppointmentAPITests(TestCase):
    @classmethod
    def setUpTestData(cls):
        channel, _ = NotificationChannel.objects.get_or_create(code='WHATSAPP', defaults={'name': 'WhatsApp'})
        cls.customer = Client.objects.create(
            rut='12.345.678-5', first_name='Ana', last_name='Pérez',
            phone='+56912345678', email='ana@example.test', password_hash='!test', notification_channel=channel,
        )
        brand = VehicleBrand.objects.create(name='Toyota')
        model = VehicleModel.objects.create(brand=brand, name='Yaris')
        cls.vehicle = Vehicle.objects.create(client=cls.customer, model=model, plate='ABCD12', year=2021)
        cls.service = Service.objects.create(
            name='Diagnóstico', description='Revisión del vehículo', base_price=Decimal('25000'),
            estimated_duration_minutes=60,
        )
        cls.inactive = Service.objects.create(name='Servicio archivado', is_active=False)

    def setUp(self):
        cache.clear()
        self.api = APIClient()
        clock = patch('apps.workshop.models.timezone.now', return_value=self.date(hour=8))
        self.now = clock.start()
        self.addCleanup(clock.stop)

    @staticmethod
    def date(day=7, hour=10, minute=0):
        return datetime(2030, 1, day, hour, minute, tzinfo=ZoneInfo('America/Santiago'))

    def payload(self, **changes):
        data = {
            'rut': '123456785', 'scheduled_date': self.date().isoformat(),
            'reported_symptoms': 'Ruido al frenar', 'service': self.service.pk,
        }
        data.update(changes)
        return data

    def reserve(self, **changes):
        return self.post_payload(self.payload(**changes))

    def post_payload(self, payload):
        serializer = PublicAppointmentCreateSerializer(data=payload)
        if serializer.is_valid():
            if serializer.existing_client and serializer.existing_client.appointments.exists():
                from apps.authentication.client_tokens import ClientAccessToken
                client_api = APIClient()
                client_api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(serializer.existing_client)))
                return client_api.post('/api/auth/client-appointments/', payload, format='json')
            challenge = BookingVerification.objects.create(rut=serializer.validated_data['rut'], payload_hash=payload_hash(serializer.validated_data), code_hash=make_password('012345'), expires_at=timezone.now() + timedelta(minutes=5))
            payload = {**payload, 'verification_id': str(challenge.pk), 'code': '012345'}
        return self.api.post('/api/appointments/', payload, format='json')

    def test_catalog_is_public_and_only_returns_active_services(self):
        self.api.credentials(HTTP_AUTHORIZATION='Bearer invalid-token')
        response = self.api.get('/api/services/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), [{
            'id': self.service.pk, 'name': 'Diagnóstico', 'description': 'Revisión del vehículo',
            'base_price': '25000.00', 'estimated_duration_minutes': 60,
        }])
        self.assertEqual(self.api.post('/api/services/', {}, format='json').status_code, 405)

    def test_catalog_allows_unspecified_prices_and_duration(self):
        service = Service.objects.create(name='Evaluación')
        rows = self.api.get('/api/services/').json()
        row = next(row for row in rows if row['id'] == service.pk)
        self.assertIsNone(row['base_price'])
        self.assertIsNone(row['estimated_duration_minutes'])

    def test_existing_customer_is_reused_without_overwriting_or_exposing_profile(self):
        response = self.reserve(first_name='Otra persona', phone='+56999999999', vehicle=str(self.vehicle.pk))
        self.assertEqual(response.status_code, 201, response.data)
        appointment = Appointment.objects.get(pk=response.data['id'])
        self.assertEqual(appointment.client, self.customer)
        self.assertEqual(appointment.vehicle, self.vehicle)
        self.assertEqual(appointment.service, self.service)
        self.assertEqual(appointment.status, Appointment.Status.PENDIENTE)
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.first_name, 'Ana')
        self.assertEqual(self.customer.phone, '+56912345678')
        self.assertEqual(Client.objects.count(), 1)
        for value in ('123456785', 'ana@example.test', '+56912345678', '!test', 'ABCD12'):
            self.assertNotIn(value, str(response.json()))

    def test_new_customer_is_created_with_unusable_password(self):
        response = self.reserve(
            rut='22.345.678-2', first_name='Luis', last_name='Soto', phone='+56987654321',
            notification_channel='EMAIL', email='luis@example.test',
        )
        self.assertEqual(response.status_code, 201, response.data)
        customer = Client.objects.get(rut='223456782')
        self.assertFalse(is_password_usable(customer.password_hash))
        self.assertEqual(customer.notification_channel.code, 'EMAIL')
        appointment = Appointment.objects.get(pk=response.data['id'])
        self.assertEqual(appointment.client, customer)
        self.assertIsNone(appointment.vehicle)

    def test_new_customer_requires_contact_and_email_for_email_channel(self):
        for changes, expected in (
            ({'rut': '223456782'}, 'first_name'),
            ({'rut': '223456782', 'first_name': 'Luis', 'last_name': 'Soto',
              'phone': '+56987654321', 'notification_channel': 'EMAIL'}, 'email'),
            ({'phone': 'incorrecto'}, 'phone'), ({'email': 'incorrecto'}, 'email'),
        ):
            response = self.reserve(**changes)
            self.assertEqual(response.status_code, 400)
            self.assertIn(expected, response.data)
        self.assertEqual(Client.objects.count(), 1)

    def test_invalid_rut_and_duplicate_legacy_ruts_return_field_errors(self):
        self.assertIn('rut', self.reserve(rut='123456784').data)
        Client.objects.create(
            rut='123456785', first_name='Duplicado', last_name='Pérez',
            phone='+56912345678', password_hash='!test', notification_channel=self.customer.notification_channel,
        )
        response = self.reserve()
        self.assertEqual(response.status_code, 400)
        self.assertIn('rut', response.data)

    def test_date_and_capacity_errors_reuse_model_validation(self):
        for scheduled in (self.date(day=4), self.date(hour=18), self.date(day=12), self.date(minute=30)):
            with self.subTest(scheduled=scheduled):
                response = self.reserve(scheduled_date=scheduled.isoformat())
                self.assertEqual(response.status_code, 400)
                self.assertIn('scheduled_date', response.data)
        self.assertEqual(self.reserve().status_code, 201)
        self.assertEqual(self.reserve().status_code, 201)
        response = self.reserve()
        self.assertEqual(response.status_code, 400)
        self.assertIn('scheduled_date', response.data)
        self.assertEqual(Appointment.objects.count(), 2)

    def test_inactive_or_unknown_service_is_rejected(self):
        for service in (self.inactive.pk, 999999):
            response = self.reserve(service=service)
            self.assertEqual(response.status_code, 400)
            self.assertIn('service', response.data)

    def test_vehicle_must_belong_to_customer(self):
        response = self.reserve(
            rut='223456782', first_name='Luis', last_name='Soto', phone='+56987654321',
            vehicle=str(self.vehicle.pk),
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn('vehicle', response.data)
        self.assertEqual(Client.objects.count(), 1)

    def test_public_request_cannot_choose_confirmed_status(self):
        response = self.reserve(status='CONFIRMADA')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data['status'], 'PENDIENTE')

    def test_public_booking_works_with_or_without_jwt(self):
        self.api.credentials(HTTP_AUTHORIZATION='Bearer expired-token')
        self.assertEqual(self.reserve().status_code, 201)
        self.api.force_authenticate(User.objects.create_user('public-api-user'))
        self.assertEqual(self.api.post('/api/appointments/', self.payload(scheduled_date=self.date(hour=11).isoformat()), format='json').status_code, 403)
        self.assertEqual(self.reserve(scheduled_date=self.date(hour=11).isoformat()).status_code, 201)

    def test_availability_lists_only_free_slots_and_no_customer_details(self):
        self.assertEqual(self.reserve().status_code, 201)
        response = self.api.get('/api/appointments/', {'date': '2030-01-07'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['timezone'], 'America/Santiago')
        self.assertEqual(data['slot_duration_minutes'], 60)
        self.assertEqual(len(data['slots']), 9)
        starts = [slot['start'] for slot in data['slots']]
        self.assertIn(self.date().isoformat(), starts)
        self.assertEqual(next(slot for slot in data['slots'] if slot['start'] == self.date().isoformat())['remaining_capacity'], 1)
        self.assertIn(self.date(hour=9).isoformat(), starts)
        self.assertIn(self.date(hour=17).isoformat(), starts)
        self.assertEqual(set(data['slots'][0]), {'start', 'end', 'remaining_capacity'})
        self.assertNotIn('Ana', str(data))
        self.assertEqual(response['Cache-Control'], 'no-store')

    def test_cancellation_releases_availability(self):
        self.reserve()
        appointment = Appointment.objects.get()
        appointment.status = Appointment.Status.CANCELADA
        appointment.save()
        response = self.api.get('/api/appointments/', {'date': '2030-01-07'})
        self.assertEqual(len(response.data['slots']), 9)

    def test_weekends_and_past_days_have_no_slots(self):
        for day in ('2030-01-04', '2030-01-12', '2030-01-13'):
            response = self.api.get('/api/appointments/', {'date': day})
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.data['slots'], [])

    def test_elapsed_slots_are_omitted_today(self):
        self.now.return_value = self.date(hour=10, minute=30)
        response = self.api.get('/api/appointments/', {'date': '2030-01-07'})
        self.assertEqual(len(response.data['slots']), 7)
        self.assertEqual(response.data['slots'][0]['start'], self.date(hour=11).isoformat())

    def test_availability_requires_valid_date(self):
        for params in ({'date': 'invalid'}, {'date': '2030-02-30'}):
            response = self.api.get('/api/appointments/', params)
            self.assertEqual(response.status_code, 400)
            self.assertIn('date', response.data)
        self.assertEqual(self.api.get('/api/appointments/').status_code, 401)

    def test_failed_booking_rolls_back_new_customer_if_slot_was_taken(self):
        serializer = PublicAppointmentCreateSerializer(data=self.payload(
            rut='223456782', first_name='Luis', last_name='Soto', phone='+56987654321',
        ))
        self.assertTrue(serializer.is_valid(), serializer.errors)
        self.assertEqual(self.reserve().status_code, 201)
        self.assertEqual(self.reserve().status_code, 201)
        with self.assertRaises(ValidationError):
            serializer.save()
        self.assertFalse(Client.objects.filter(rut='223456782').exists())
        self.assertEqual(Appointment.objects.count(), 2)

    def test_service_is_optional(self):
        payload = self.payload()
        payload.pop('service')
        response = self.post_payload(payload)
        self.assertEqual(response.status_code, 201)
        self.assertIsNone(response.data['service'])
