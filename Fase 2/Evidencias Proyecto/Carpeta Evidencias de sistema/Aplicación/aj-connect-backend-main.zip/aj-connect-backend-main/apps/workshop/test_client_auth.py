from datetime import timedelta
from unittest.mock import patch

from django.contrib.auth.hashers import check_password
from django.contrib.auth.models import User
from django.core.cache import cache
from django.core import mail
from django.test import TestCase, override_settings
from django.utils import timezone
from rest_framework.test import APIClient, APIRequestFactory
from rest_framework_simplejwt.exceptions import InvalidToken
from rest_framework_simplejwt.tokens import AccessToken

from apps.authentication.client_tokens import ClientAccessToken, ClientJWTAuthentication
from .client_otp_delivery import deliver_client_otp
from .models import Client, ClientOTP, NotificationChannel


class ClientAuthTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        channel, _ = NotificationChannel.objects.get_or_create(code='WHATSAPP', defaults={'name': 'WhatsApp'})
        cls.customer = Client.objects.create(
            rut='12.345.678-5', first_name='Ana', last_name='Pérez', phone='+56912345678',
            email='ana@example.test', password_hash='!sin-acceso-web', notification_channel=channel,
        )

    def setUp(self):
        cache.clear()
        self.api = APIClient()
        self.send = patch('apps.workshop.client_auth_views.deliver_client_otp').start()
        self.addCleanup(patch.stopall)
        patch('apps.workshop.client_auth_views.secrets.randbelow', return_value=12345).start()

    def request_code(self, **changes):
        payload = {'rut': '123456785'}
        payload.update(changes)
        return self.api.post('/api/auth/client-login/', payload, format='json')

    def verify(self, **changes):
        payload = {'rut': '123456785', 'code': '012345', 'password': 'MotorSeguro!2026'}
        payload.update(changes)
        return self.api.post('/api/auth/client-otp/', payload, format='json')

    def test_request_generates_six_digits_hash_expiry_and_preferred_channel(self):
        before = timezone.now()
        response = self.request_code()
        self.assertEqual(response.status_code, 200)
        otp = ClientOTP.objects.get(client=self.customer)
        delivered_customer, code = self.send.call_args.args
        self.assertEqual(code, '012345')
        self.assertEqual(delivered_customer.notification_channel.code, 'WHATSAPP')
        self.assertNotEqual(otp.code_hash, code)
        self.assertTrue(check_password(code, otp.code_hash))
        self.assertGreaterEqual(otp.expires_at, before + timedelta(minutes=5))
        self.assertIsNone(otp.consumed_at)
        self.assertIsNone(otp.verified_at)
        self.assertNotIn(code, str(response.data))
        self.assertEqual(response['Cache-Control'], 'no-store')

    def test_unknown_rut_returns_not_found_without_creating_customer(self):
        self.request_code()
        unknown = self.request_code(rut='223456782')
        self.assertEqual(unknown.status_code, 404)
        self.assertIn('No encontramos una cuenta', unknown.data['detail'])
        self.assertEqual(Client.objects.count(), 1)
        self.assertEqual(self.send.call_count, 1)

    def test_invalid_rut_is_structured_error(self):
        response = self.request_code(rut='123456784')
        self.assertEqual(response.status_code, 400)
        self.assertIn('rut', response.data)
        self.send.assert_not_called()

    def test_wrong_and_expired_otp_are_rejected_and_expiry_is_persisted(self):
        self.request_code()
        response = self.verify(code='999999')
        self.assertEqual(response.status_code, 400)
        self.assertIn('code', response.data)
        otp = ClientOTP.objects.get(client=self.customer)
        self.assertEqual(otp.attempts, 1)
        ClientOTP.objects.filter(pk=otp.pk).update(expires_at=timezone.now() - timedelta(seconds=1))
        self.assertEqual(self.verify().status_code, 400)
        otp.refresh_from_db()
        self.assertIsNotNone(otp.consumed_at)
        self.assertIsNone(otp.verified_at)

    def test_maximum_attempts_invalidates_code_even_if_next_attempt_is_correct(self):
        self.request_code()
        for _ in range(5):
            self.assertEqual(self.verify(code='999999').status_code, 400)
        self.assertEqual(self.verify().status_code, 400)
        otp = ClientOTP.objects.get(client=self.customer)
        self.assertEqual(otp.attempts, 5)
        self.assertIsNotNone(otp.consumed_at)

    def test_first_login_creates_password_and_client_jwt(self):
        self.request_code()
        response = self.verify()
        self.assertEqual(response.status_code, 200, response.data)
        self.assertTrue(response.data['first_login'])
        self.assertEqual(response.data['token_type'], 'Bearer')
        self.assertEqual(response.data['expires_in'], 3600)
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.check_password('MotorSeguro!2026'))
        self.assertNotEqual(self.customer.password_hash, 'MotorSeguro!2026')
        token = ClientAccessToken(response.data['access'])
        self.assertEqual(token['client_id'], str(self.customer.pk))
        self.assertEqual(token['token_type'], 'client_access')
        self.assertNotIn('user_id', token)
        otp = ClientOTP.objects.get(client=self.customer)
        self.assertIsNotNone(otp.consumed_at)
        self.assertIsNotNone(otp.verified_at)
        self.assertEqual(User.objects.count(), 0)

    def test_used_code_is_never_reusable(self):
        self.request_code()
        self.assertEqual(self.verify().status_code, 200)
        self.assertEqual(self.verify().status_code, 400)

    def test_first_login_requires_valid_password_without_consuming_otp(self):
        self.request_code()
        for password in (None, '12345678', 'short'):
            payload = {'rut': '123456785', 'code': '012345'}
            if password is not None:
                payload['password'] = password
            response = self.api.post('/api/auth/client-otp/', payload, format='json')
            self.assertEqual(response.status_code, 400)
            self.assertIn('password', response.data)
        self.assertIsNone(ClientOTP.objects.get(client=self.customer).consumed_at)
        self.assertEqual(self.verify().status_code, 200)

    def test_existing_password_logs_in_without_requesting_an_otp(self):
        self.customer.set_password('ExistingPassword!2026')
        self.customer.save()
        response = self.request_code(password='ExistingPassword!2026')
        self.assertEqual(response.status_code, 200, response.data)
        self.assertFalse(response.data['first_login'])
        self.assertEqual(ClientAccessToken(response.data['access'])['client_id'], str(self.customer.pk))
        self.send.assert_not_called()
        self.assertFalse(ClientOTP.objects.exists())

    def test_existing_account_requires_correct_password_without_sending_email(self):
        self.customer.set_password('ExistingPassword!2026')
        self.customer.save()
        self.assertEqual(self.request_code().status_code, 400)
        self.assertEqual(self.request_code(password='incorrecta').status_code, 401)
        self.send.assert_not_called()
        self.assertFalse(ClientOTP.objects.exists())
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.check_password('ExistingPassword!2026'))

    def test_first_login_then_password_login_without_another_otp(self):
        self.request_code()
        self.assertEqual(self.verify().status_code, 200)
        self.send.reset_mock()
        self.assertEqual(self.request_code(password='MotorSeguro!2026').status_code, 200)
        self.send.assert_not_called()
        self.assertEqual(self.verify().status_code, 400)

    def test_similar_surname_error_is_in_spanish_and_keeps_code_usable(self):
        self.request_code()
        self.customer.last_name = 'ApellidoDePruebaExtenso'
        self.customer.save()
        response = self.verify(password='ApellidoDePruebaExtenso')
        self.assertEqual(response.status_code, 400)
        message = ' '.join(response.data['password'])
        self.assertNotIn('last name', message)
        self.assertIn('similar', message)
        self.assertIsNone(ClientOTP.objects.get(client=self.customer).consumed_at)
        self.assertEqual(self.verify().status_code, 200)

    def test_database_busy_returns_json_and_rolls_back_first_password(self):
        from django.db import OperationalError
        self.request_code()
        with patch('apps.workshop.models.Client.save', side_effect=OperationalError('database is locked')):
            response = self.verify()
        self.assertEqual(response.status_code, 503)
        self.assertIn('ocupado', response.data['detail'])
        self.assertEqual(response['Retry-After'], '3')
        self.customer.refresh_from_db()
        self.assertFalse(self.customer.has_usable_password())
        self.assertIsNone(ClientOTP.objects.get(client=self.customer).consumed_at)
        self.assertEqual(self.verify().status_code, 200)

    def test_resend_has_cooldown_and_replaces_previous_code(self):
        self.request_code()
        self.assertEqual(self.request_code().status_code, 200)
        self.assertEqual(self.send.call_count, 1)
        ClientOTP.objects.filter(client=self.customer).update(last_sent_at=timezone.now() - timedelta(minutes=1))
        cache.clear()
        with patch('apps.workshop.client_auth_views.secrets.randbelow', return_value=654321):
            self.assertEqual(self.request_code().status_code, 200)
        self.assertEqual(ClientOTP.objects.count(), 1)
        self.assertEqual(self.verify().status_code, 400)
        self.assertEqual(self.verify(code='654321').status_code, 200)

    def test_failed_delivery_does_not_leave_valid_challenge(self):
        self.send.side_effect = RuntimeError('provider unavailable')
        response = self.request_code()
        self.assertEqual(response.status_code, 503)
        self.assertEqual(ClientOTP.objects.count(), 0)

    def test_jwt_failure_rolls_back_password_and_otp_consumption(self):
        self.request_code()
        with patch('apps.workshop.client_auth_views.ClientAccessToken.for_client', side_effect=RuntimeError('token failure')):
            with self.assertRaises(RuntimeError):
                self.verify()
        self.customer.refresh_from_db()
        self.assertFalse(self.customer.has_usable_password())
        self.assertIsNone(ClientOTP.objects.get(client=self.customer).consumed_at)

    def test_client_jwt_authenticates_only_with_client_authentication(self):
        token = str(ClientAccessToken.for_client(self.customer))
        request = APIRequestFactory().get('/', HTTP_AUTHORIZATION=f'Bearer {token}')
        client, _ = ClientJWTAuthentication().authenticate(request)
        self.assertEqual(client, self.customer)
        self.assertTrue(client.is_authenticated)
        self.api.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
        for url in ('/api/auth/users/', '/api/workshop/work-orders/', '/api/inventory/items/'):
            self.assertEqual(self.api.get(url).status_code, 401)
        self.assertEqual(self.api.post('/api/auth/refresh/', {'refresh': token}, format='json').status_code, 401)

    def test_staff_and_expired_tokens_are_rejected_by_client_authentication(self):
        employee = User.objects.create_user('staff-otp-test')
        staff_token = str(AccessToken.for_user(employee))
        expired = ClientAccessToken.for_client(self.customer)
        expired.set_exp(lifetime=timedelta(seconds=-1))
        for token in (staff_token, str(expired)):
            request = APIRequestFactory().get('/', HTTP_AUTHORIZATION=f'Bearer {token}')
            with self.assertRaises(InvalidToken):
                ClientJWTAuthentication().authenticate(request)

    def test_verify_without_challenge_or_unknown_customer_returns_400(self):
        self.assertEqual(self.verify().status_code, 400)
        self.assertEqual(self.verify(rut='223456782').status_code, 400)

    def test_otp_endpoints_ignore_expired_staff_jwt_and_reject_malformed_code(self):
        self.api.credentials(HTTP_AUTHORIZATION='Bearer invalid')
        self.assertEqual(self.request_code().status_code, 200)
        for code in ('12345', '1234567', 'abcdef'):
            response = self.verify(code=code)
            self.assertEqual(response.status_code, 400)
            self.assertIn('code', response.data)
        self.assertEqual(self.verify().status_code, 200)

    def test_delivery_adapters_use_preferred_channels(self):
        email, _ = NotificationChannel.objects.get_or_create(code='EMAIL', defaults={'name': 'Correo'})
        self.customer.notification_channel = email
        with override_settings(CLIENT_OTP_DELIVERY_MODE='channel', EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend'):
            deliver_client_otp(self.customer, '012345')
        self.assertEqual(mail.outbox[0].to, ['ana@example.test'])
        self.assertIn('012345', mail.outbox[0].body)
        self.customer.notification_channel = NotificationChannel.objects.get(code='WHATSAPP')
        with override_settings(CLIENT_OTP_DELIVERY_MODE='channel', CLIENT_OTP_WHATSAPP_SENDER='provider.send'):
            with patch('apps.workshop.client_otp_delivery.import_string') as importer:
                deliver_client_otp(self.customer, '654321')
                self.assertEqual(importer.return_value.call_args.args[0], self.customer.phone)
                self.assertIn('654321', importer.return_value.call_args.args[1])

    def test_local_simulation_is_explicit_and_disabled_in_production(self):
        with override_settings(CLIENT_OTP_DELIVERY_MODE='simulation', CLIENT_OTP_ALLOW_SIMULATION=True):
            with self.assertLogs('apps.workshop.client_otp_delivery', level='WARNING') as logs:
                deliver_client_otp(self.customer, '012345')
            self.assertIn('012345', logs.output[0])
        with override_settings(CLIENT_OTP_DELIVERY_MODE='simulation', CLIENT_OTP_ALLOW_SIMULATION=False):
            with self.assertRaises(RuntimeError):
                deliver_client_otp(self.customer, '012345')

    def test_request_ip_throttle_rejects_excess_requests(self):
        for _ in range(10):
            self.assertEqual(self.request_code(rut='223456782').status_code, 404)
        self.assertEqual(self.request_code(rut='223456782').status_code, 429)
