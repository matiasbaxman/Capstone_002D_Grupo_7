from datetime import datetime, time, timedelta

from django.core.exceptions import ValidationError
from django.db import transaction, OperationalError
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import permissions, serializers
from rest_framework.exceptions import NotAuthenticated, PermissionDenied
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.authentication.permissions import is_admin, is_recepcionista
from .models import Appointment, Service
from .booking_verification import BookingThrottle, verify_booking
from .serializers import (
    AppointmentAdminSerializer,
    AppointmentSerializer,
    PublicAppointmentCreateSerializer,
    PublicAppointmentResultSerializer,
    PublicServiceSerializer,
)


class PublicServiceListView(ListAPIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    serializer_class = PublicServiceSerializer
    queryset = Service.objects.filter(is_active=True)
    pagination_class = None


class AvailabilityQuerySerializer(serializers.Serializer):
    date = serializers.DateField(input_formats=['%Y-%m-%d'])


class PublicAppointmentView(APIView):
    permission_classes = [permissions.AllowAny]

    def get_throttles(self):
        return [BookingThrottle()] if self.request.method == 'POST' else []

    def initialize_request(self, request, *args, **kwargs):
        self.public_request = request.method == 'POST' or (request.method == 'GET' and 'date' in request.GET)
        return super().initialize_request(request, *args, **kwargs)

    def get_authenticators(self):
        return [] if getattr(self, 'public_request', False) else super().get_authenticators()

    def get(self, request):
        # La disponibilidad pública conserva el parámetro `date`. Sin fecha,
        # esta ruta entrega el listado administrativo y exige personal autorizado.
        if 'date' not in request.query_params:
            if not request.user or not request.user.is_authenticated:
                raise NotAuthenticated('Inicia sesión para consultar las citas.')
            if not (is_admin(request.user) or is_recepcionista(request.user)):
                raise PermissionDenied('Se requiere rol de Administración o Recepción.')
            queryset = Appointment.objects.select_related(
                'client', 'vehicle__model__brand', 'service',
            )
            status = request.query_params.get('status')
            date_from = request.query_params.get('date_from')
            date_to = request.query_params.get('date_to')
            if status:
                if status not in Appointment.Status.values:
                    raise serializers.ValidationError({'status': 'Estado de cita no válido.'})
                queryset = queryset.filter(status=status)
            date_field = serializers.DateField()
            parsed_from = None
            parsed_to = None
            if date_from:
                parsed_from = date_field.run_validation(date_from)
                queryset = queryset.filter(scheduled_date__date__gte=parsed_from)
            if date_to:
                parsed_to = date_field.run_validation(date_to)
                queryset = queryset.filter(scheduled_date__date__lte=parsed_to)
            if parsed_from and parsed_to and parsed_from > parsed_to:
                raise serializers.ValidationError({'date_to': 'Debe ser igual o posterior a date_from.'})
            return Response(AppointmentAdminSerializer(queryset, many=True).data)

        query = AvailabilityQuerySerializer(data=request.query_params)
        query.is_valid(raise_exception=True)
        day = query.validated_data['date']
        zone = timezone.get_default_timezone()
        slots = []
        for hour in range(Appointment.OPENING_HOUR, Appointment.CLOSING_HOUR):
            start = timezone.make_aware(datetime.combine(day, time(hour)), zone)
            candidate = Appointment(scheduled_date=start)
            try:
                candidate.clean()
            except ValidationError:
                continue
            slots.append({
                'start': start.isoformat(),
                'end': (start + timedelta(minutes=Appointment.SLOT_MINUTES)).isoformat(),
                'remaining_capacity': Appointment.CAPACITY - Appointment.objects.filter(scheduled_date=start).exclude(status__in=Appointment.INACTIVE_STATUSES).count(),
            })
        response = Response({
            'date': day.isoformat(), 'timezone': str(zone),
            'slot_duration_minutes': Appointment.SLOT_MINUTES,
            'capacity_per_slot': Appointment.CAPACITY, 'slots': slots,
        })
        response['Cache-Control'] = 'no-store'
        return response

    def post(self, request):
        try:
            serializer = PublicAppointmentCreateSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            if serializer.existing_client and serializer.existing_client.appointments.exists():
                return Response({'detail': 'Ya tienes una cuenta con citas. Inicia sesión para agendar sin otro código.'}, status=403)
            with transaction.atomic():
                challenge, error = verify_booking(request.data, serializer.validated_data)
                if error:
                    # Los intentos fallidos deben persistir; no lanzar excepción.
                    return Response(error, status=400)
                appointment = serializer.save()
                challenge.consumed_at = timezone.now()
                challenge.save(update_fields=['consumed_at'])
        except OperationalError:
            return Response({'detail': 'La agenda se está actualizando. Intenta nuevamente.'}, status=409)
        response = Response(PublicAppointmentResultSerializer(appointment).data, status=201)
        response['Cache-Control'] = 'no-store'
        return response


class AppointmentAdminDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def check_permissions(self, request):
        super().check_permissions(request)
        if not (is_admin(request.user) or is_recepcionista(request.user)):
            raise PermissionDenied('Se requiere rol de Administración o Recepción.')

    @transaction.atomic
    def patch(self, request, appointment_id):
        allowed_fields = {'status', 'scheduled_date'}
        unexpected = set(request.data) - allowed_fields
        if unexpected:
            raise serializers.ValidationError({
                field: 'Este campo no se puede modificar desde la gestión de citas.'
                for field in unexpected
            })
        appointment = get_object_or_404(
            Appointment.objects.select_for_update(of=('self',)).select_related('client', 'vehicle__model__brand', 'service'),
            pk=appointment_id,
        )
        serializer = AppointmentSerializer(appointment, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        previous_status = appointment.status
        updated = serializer.save()
        if updated.status != previous_status and updated.status in ('CONFIRMADA', 'CANCELADA', 'RECHAZADA'):
            from .models import EmailDelivery
            EmailDelivery.objects.create(kind='appointment_notice', target_id=updated.pk, payload={
                'email': updated.client.email, 'name': updated.client.first_name,
                'status': updated.status, 'date': timezone.localtime(updated.scheduled_date).isoformat(),
            })
        return Response(AppointmentAdminSerializer(updated).data)


class ClientAppointmentCreateView(APIView):
    from apps.authentication.client_tokens import ClientJWTAuthentication
    authentication_classes = [ClientJWTAuthentication]
    permission_classes = [permissions.IsAuthenticated]
    throttle_classes = [BookingThrottle]

    @transaction.atomic
    def post(self, request):
        from .models import Client
        client = Client.objects.select_for_update().get(pk=request.user.pk)
        payload = {**request.data, 'rut': client.rut, 'first_name': client.first_name,
                   'last_name': client.last_name, 'email': client.email or '',
                   'phone': client.phone, 'notification_channel': 'EMAIL'}
        serializer = PublicAppointmentCreateSerializer(data=payload)
        serializer.is_valid(raise_exception=True)
        if serializer.existing_client.pk != client.pk:
            raise serializers.ValidationError({'detail': 'No pudimos validar tu cuenta.'})
        if not client.appointments.exists():
            challenge, error = verify_booking(request.data, serializer.validated_data)
            if error:
                return Response(error, status=400)
            appointment = serializer.save()
            challenge.consumed_at = timezone.now()
            challenge.save(update_fields=['consumed_at'])
        else:
            appointment = serializer.save()
        return Response(PublicAppointmentResultSerializer(appointment).data, status=201)
