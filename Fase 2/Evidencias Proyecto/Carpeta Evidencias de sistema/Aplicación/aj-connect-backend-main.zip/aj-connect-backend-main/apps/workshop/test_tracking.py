import uuid
from datetime import timedelta
from decimal import Decimal

from django.db import IntegrityError, connection, transaction
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient

from apps.inventory.models import InventoryItem, ItemCategory
from .models import (
    Client, NotificationChannel, Vehicle, VehicleBrand, VehicleModel,
    WorkOrder, WorkOrderCheckIn, WorkOrderItem, WorkOrderPhoto,
    WorkOrderStatus, WorkOrderStatusHistory,
)


class PublicTrackingTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        channel, _ = NotificationChannel.objects.get_or_create(
            code='WHATSAPP', defaults={'name': 'WhatsApp'},
        )
        client = Client.objects.create(
            rut='123456785', first_name='Ana', last_name='Pérez',
            phone='+56912345678', email='ana@example.test',
            password_hash='!sin-acceso-web', notification_channel=channel,
        )
        brand = VehicleBrand.objects.create(name='Toyota')
        model = VehicleModel.objects.create(brand=brand, name='Yaris')
        cls.vehicle = Vehicle.objects.create(
            client=client, model=model, plate='ABCD12', year=2021,
        )
        cls.received, _ = WorkOrderStatus.objects.get_or_create(
            code='RECEPCIONADO', defaults={'name': 'Recepcionado', 'sequence_order': 1},
        )
        repairing, _ = WorkOrderStatus.objects.get_or_create(
            code='EN_PROCESO', defaults={'name': 'En proceso', 'sequence_order': 2},
        )
        cls.order = WorkOrder.objects.create(
            folio_number=3001, vehicle=cls.vehicle, status=repairing,
            client_observations='Revisar frenos', technical_diagnosis='Pastillas gastadas',
            estimated_delivery_date=timezone.now() + timedelta(days=1),
        )
        checkin = WorkOrderCheckIn.objects.create(
            work_order=cls.order, initial_odometer=12000, fuel_level='1/2',
            bodywork_details='Rayón en puerta',
        )
        WorkOrderPhoto.objects.create(
            checkin=checkin, photo_cloudinary_url='https://example.test/checkin.jpg',
            public_id='internal-photo-id',
        )
        first = WorkOrderStatusHistory.objects.create(
            work_order=cls.order, to_status=cls.received, notes='Nota interna',
        )
        WorkOrderStatusHistory.objects.filter(pk=first.pk).update(
            changed_at=timezone.now() - timedelta(hours=1),
        )
        WorkOrderStatusHistory.objects.create(
            work_order=cls.order, from_status=cls.received, to_status=repairing,
        )
        category = ItemCategory.objects.create(name='Frenos')
        item = InventoryItem.objects.create(
            category=category, sku='FRE-001', name='Pastilla',
            unit_price=Decimal('15000'), current_stock=8,
        )
        WorkOrderItem.objects.create(
            work_order=cls.order, item=item, quantity=2, unit_price=Decimal('14000'),
        )

    def setUp(self):
        self.api = APIClient()
        self.url = f'/api/tracking/{self.order.tracking_token}/'

    def test_public_tracking_and_staff_pdf_use_same_order(self):
        from django.contrib.auth.models import User
        response = self.api.get(f'/api/tracking/{self.order.tracking_code}/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['folio_number'], self.order.folio_number)
        self.assertEqual(response.data['items'][0]['item_name'], 'Pastilla')
        pdf_url = f'/api/workshop/work-orders/{self.order.pk}/pdf/'
        self.assertEqual(self.api.get(pdf_url).status_code, 401)
        self.api.force_authenticate(User.objects.create_superuser('pdf-test', 'pdf@example.test', 'test-only'))
        pdf = self.api.get(pdf_url)
        self.assertEqual(pdf.status_code, 200)
        self.assertEqual(pdf['Content-Type'], 'application/pdf')
        self.assertTrue(pdf.content.startswith(b'%PDF'))

    def test_friendly_code_and_legacy_token(self):
        code = self.order.tracking_code
        formatted = f'{code[:2]}-{code[2:6]}-{code[6:10]}-{code[10:14]}'
        self.assertEqual(self.api.get(f'/api/tracking/{formatted.lower()}/').status_code, 200)
        self.assertEqual(self.api.get(f'/api/tracking/{code}/').status_code, 200)
        self.assertEqual(self.api.get(f'/api/tracking/{self.order.tracking_token}/').status_code, 200)
        self.assertEqual(self.api.get('/api/tracking/AJ-2222-2222-2222/').status_code, 404)

    def test_friendly_code_throttles_repeated_attempts(self):
        from django.core.cache import cache
        cache.clear()
        with self.settings(REST_FRAMEWORK={'DEFAULT_THROTTLE_RATES': {}}):
            from unittest.mock import patch
            with patch('apps.workshop.views.TrackingCodeThrottle.rate', '2/min'):
                self.assertEqual(self.api.get('/api/tracking/AJ-2222-2222-2222/').status_code, 404)
                self.assertEqual(self.api.get('/api/tracking/AJ-2222-2222-2222/').status_code, 404)
                self.assertEqual(self.api.get('/api/tracking/AJ-2222-2222-2222/').status_code, 429)
        cache.clear()

    def test_default_generates_distinct_uuid4_and_survives_save(self):
        other = WorkOrder.objects.create(
            folio_number=3002, vehicle=self.vehicle, status=self.received,
        )
        for order in (self.order, other):
            self.assertEqual(len(order.tracking_token), 32)
            self.assertEqual(uuid.UUID(order.tracking_token).version, 4)
        self.assertNotEqual(self.order.tracking_token, other.tracking_token)
        token = other.tracking_token
        other.client_observations = 'Nueva observación'
        other.save()
        other.refresh_from_db()
        self.assertEqual(other.tracking_token, token)

    def test_database_has_unique_index_and_rejects_duplicate(self):
        with connection.cursor() as cursor:
            constraints = connection.introspection.get_constraints(cursor, WorkOrder._meta.db_table)
        self.assertTrue(any(
            constraint['unique'] and constraint['columns'] == ['tracking_token']
            for constraint in constraints.values()
        ))
        with self.assertRaises(IntegrityError), transaction.atomic():
            WorkOrder.objects.create(
                folio_number=3002, vehicle=self.vehicle, status=self.received,
                tracking_token=self.order.tracking_token,
            )

    def test_public_detail_includes_timeline_photos_and_price_snapshot(self):
        response = self.api.get(self.url)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['folio_number'], 3001)
        self.assertEqual(data['status_code'], 'EN_PROCESO')
        self.assertIsNotNone(data['estimated_delivery_date'])
        self.assertEqual(data['client_observations'], 'Revisar frenos')
        self.assertEqual(data['technical_diagnosis'], 'Pastillas gastadas')
        self.assertEqual(data['bodywork_details'], 'Rayón en puerta')
        self.assertEqual(data['vehicle']['brand'], 'Toyota')
        self.assertEqual(data['vehicle']['model_name'], 'Yaris')
        self.assertEqual(data['vehicle']['plate'], 'ABCD12')
        self.assertEqual([entry['to_status_code'] for entry in data['status_history']],
                         ['RECEPCIONADO', 'EN_PROCESO'])
        self.assertIsNone(data['status_history'][0]['from_status'])
        self.assertEqual(data['photos'], ['https://example.test/checkin.jpg'])
        self.assertEqual(data['items'][0]['unit_price'], '14000.00')
        self.assertEqual(data['items'][0]['subtotal'], '28000.00')
        self.assertEqual(response['Cache-Control'], 'no-store')

    def test_public_contract_excludes_private_fields(self):
        data = self.api.get(self.url).json()
        self.assertNotIn('client', data)
        self.assertNotIn('assigned_mechanic', data)
        self.assertNotIn('changed_by', data['status_history'][0])
        self.assertNotIn('notes', data['status_history'][0])
        self.assertNotIn('current_stock', data['items'][0])
        for value in ('123456785', '+56912345678', 'ana@example.test', 'internal-photo-id'):
            self.assertNotIn(value, str(data))

    def test_expired_or_invalid_jwt_does_not_block_public_lookup(self):
        self.api.credentials(HTTP_AUTHORIZATION='Bearer invalid-token')
        self.assertEqual(self.api.get(self.url).status_code, 200)

    def test_unknown_and_malformed_tokens_return_structured_404(self):
        for token in (uuid.uuid4().hex, str(uuid.uuid4()), 'invalid', '1' * 100):
            with self.subTest(token=token):
                response = self.api.get(f'/api/tracking/{token}/')
                self.assertEqual(response.status_code, 404)
                self.assertEqual(response.json(), {'detail': 'Orden de trabajo no encontrada'})

    def test_canonical_uuid_and_legacy_hex_links(self):
        canonical = str(uuid.UUID(self.order.tracking_token))
        self.assertEqual(self.api.get(f'/api/tracking/{canonical}/').status_code, 200)
        legacy = '0123456789abcdef0123456789abcdef'
        WorkOrder.objects.filter(pk=self.order.pk).update(tracking_token=legacy)
        self.assertEqual(self.api.get(f'/api/tracking/{legacy}/').status_code, 200)

    def test_order_without_checkin_history_or_items(self):
        other = WorkOrder.objects.create(
            folio_number=3002, vehicle=self.vehicle, status=self.received,
        )
        response = self.api.get(f'/api/tracking/{other.tracking_token}/')
        self.assertEqual(response.status_code, 200)
        for field in ('photos', 'items', 'status_history'):
            self.assertEqual(response.data[field], [])
        self.assertIsNone(response.data['bodywork_details'])

    def test_public_route_cannot_modify_order(self):
        for method in ('post', 'patch', 'put', 'delete'):
            with self.subTest(method=method):
                self.assertEqual(getattr(self.api, method)(self.url).status_code, 405)

    def test_private_workshop_endpoint_still_requires_jwt(self):
        response = self.api.get(f'/api/workshop/work-orders/{self.order.pk}/')
        self.assertEqual(response.status_code, 401)
