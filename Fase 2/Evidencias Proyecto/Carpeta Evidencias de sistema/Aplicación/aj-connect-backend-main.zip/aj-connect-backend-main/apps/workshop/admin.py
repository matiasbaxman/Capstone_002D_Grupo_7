from django.contrib import admin
from .models import (
    Appointment,
    Service,
    NotificationChannel,
    Client,
    VehicleBrand,
    VehicleModel,
    Vehicle,
    WorkOrderStatus,
    WorkOrder,
    WorkOrderCheckIn,
    WorkOrderPhoto,
    Quote,
    QuoteItem,
)

admin.site.register(NotificationChannel)
admin.site.register(VehicleBrand)
admin.site.register(VehicleModel)
admin.site.register(WorkOrderStatus)
admin.site.register(WorkOrderPhoto)
admin.site.register(Quote)
admin.site.register(QuoteItem)

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('rut', 'first_name', 'last_name', 'phone', 'email')
    search_fields = ('rut', 'first_name', 'last_name', 'phone')

@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ('plate', 'model', 'year', 'color', 'client')
    search_fields = ('plate', 'client__rut', 'client__last_name')
    list_filter = ('model__brand', 'year')

@admin.register(WorkOrder)
class WorkOrderAdmin(admin.ModelAdmin):
    list_display = ('folio_number', 'vehicle', 'status', 'assigned_mechanic', 'created_at')
    search_fields = ('folio_number', 'vehicle__plate', 'tracking_token')
    list_filter = ('status',)

@admin.register(WorkOrderCheckIn)
class WorkOrderCheckInAdmin(admin.ModelAdmin):
    list_display = ('work_order', 'initial_odometer', 'fuel_level', 'receptionist', 'created_at')
    search_fields = ('work_order__folio_number', 'work_order__vehicle__plate')


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'client', 'vehicle', 'scheduled_date', 'status', 'created_at')
    list_filter = ('status', 'scheduled_date')
    search_fields = (
        'client__first_name', 'client__last_name', 'client__rut',
        'vehicle__plate', 'reported_symptoms',
    )
    raw_id_fields = ('client', 'vehicle')


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'base_price', 'estimated_duration_minutes', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'description')
