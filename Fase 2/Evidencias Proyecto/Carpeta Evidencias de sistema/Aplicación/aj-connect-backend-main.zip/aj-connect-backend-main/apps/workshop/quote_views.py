from decimal import Decimal
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import get_object_or_404
from rest_framework import permissions, serializers
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import WorkOrder, Quote, QuoteItem, EmailDelivery
from .quote_totals import calculate_totals
from .views import WorkshopStaffPermission


class QuoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Quote
        fields = ['id', 'work_order', 'created_at', 'subtotal_amount', 'tax_rate', 'tax_amount', 'total_amount', 'is_approved']
        read_only_fields = fields


class WorkOrderQuotesView(APIView):
    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        order = get_object_or_404(WorkOrder, pk=pk)
        return Response(QuoteSerializer(order.quotes.all(), many=True).data)

    @transaction.atomic
    def post(self, request, pk):
        order = get_object_or_404(WorkOrder.objects.select_for_update().select_related('vehicle'), pk=pk)
        if request.data:
            raise serializers.ValidationError({'detail': 'La cotización se calcula desde los repuestos de la orden.'})
        items = list(order.items.select_related('item').all())
        if not items:
            raise serializers.ValidationError({'detail': 'Agrega insumos o repuestos antes de generar la cotización.'})
        tax_rate = Decimal(settings.AJ_QUOTE_TAX_RATE)
        quote = Quote(work_order=order, client_id=order.vehicle.client_id, tax_rate=tax_rate, **calculate_totals(items, tax_rate))
        try:
            quote.full_clean()
            quote.save()
        except ValidationError as error:
            raise serializers.ValidationError(error.message_dict) from error
        for line in items:
            item = QuoteItem(quote=quote, item=line.item, quantity=line.quantity, unit_price=line.unit_price)
            try:
                item.full_clean()
                item.save()
            except ValidationError as error:
                raise serializers.ValidationError(error.message_dict) from error
        try:
            quote.full_clean()
        except ValidationError as error:
            raise serializers.ValidationError(error.message_dict) from error
        return Response(QuoteSerializer(quote).data, status=201)


class EmailDeliveryView(APIView):
    permission_classes = [permissions.IsAuthenticated, WorkshopStaffPermission]

    def get(self, request, pk):
        job = get_object_or_404(EmailDelivery, pk=pk)
        return Response({'id': str(job.pk), 'status': job.status, 'attempts': job.attempts, 'detail': job.last_error})
