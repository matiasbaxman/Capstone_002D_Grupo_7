from datetime import datetime, timedelta
from decimal import Decimal
from unittest.mock import patch
from zoneinfo import ZoneInfo

from django.contrib.auth.models import User
from django.core import mail
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase, override_settings
from django.utils import timezone
from rest_framework.test import APIClient

from apps.inventory.models import InventoryItem, ItemCategory
from .email_queue import process_next
from .models import Appointment, BookingVerification, Client, ClientOTP, EmailDelivery, Quote, QuoteItem, WorkOrder, WorkOrderItem, WorkOrderStatus


@override_settings(EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class SprintFlowTests(TestCase):
    def setUp(self):
        cache.clear()
        self.api = APIClient()
        self.staff = User.objects.create_superuser('qa-flow', 'qa@example.test', 'StaffSeguro!2026')
        self.payload = {
            'rut': '123456785', 'first_name': 'Cliente', 'last_name': 'QA',
            'email': 'cliente@example.test', 'phone': '+56912345678', 'notification_channel': 'EMAIL',
            'scheduled_date': datetime(2030, 1, 7, 10, tzinfo=ZoneInfo('America/Santiago')).isoformat(),
            'reported_symptoms': 'Ruido al frenar',
        }

    def verified_payload(self, payload=None):
        payload = payload or self.payload
        with patch('apps.workshop.booking_verification.deliver_client_otp') as delivery:
            response = self.api.post('/api/appointments/verify-contact/', payload, format='json')
        self.assertEqual(response.status_code, 200, response.data)
        code = delivery.call_args.args[1]
        self.assertNotIn(code, str(response.data))
        return {**payload, 'verification_id': response.data['verification_id'], 'code': code}

    def test_booking_login_tracking_quote_pdf_email_complete_flow(self):
        booking = self.api.post('/api/appointments/', self.verified_payload(), format='json')
        self.assertEqual(booking.status_code, 201, booking.data)
        client = Client.objects.get(rut='123456785')
        with patch('apps.workshop.client_auth_views.deliver_client_otp') as delivery:
            self.assertEqual(self.api.post('/api/auth/client-login/', {'rut': client.rut}, format='json').status_code, 200)
        code = delivery.call_args.args[1]
        login = self.api.post('/api/auth/client-otp/', {'rut': client.rut, 'code': code, 'password': 'MotorSeguro!2026'}, format='json')
        self.assertEqual(login.status_code, 200, login.data)
        self.api.credentials(HTTP_AUTHORIZATION=f"Bearer {login.data['access']}")
        self.assertEqual(self.api.get('/api/auth/client-session/').status_code, 200)
        self.assertEqual(self.api.get('/api/workshop/work-orders/').status_code, 401)
        self.api.force_authenticate(self.staff)
        confirmed = self.api.patch(f"/api/appointments/{booking.data['id']}/", {'status': 'CONFIRMADA'}, format='json')
        self.assertEqual(confirmed.status_code, 200)
        checkin = self.api.post('/api/workshop/check-in/', {
            'client_id': str(client.pk), 'email': client.email, 'notification_channel': 'EMAIL',
            'plate': 'BCDF12', 'brand': 'Toyota', 'vehicle_model': 'Yaris', 'year': 2021,
        }, format='json')
        self.assertEqual(checkin.status_code, 201, checkin.data)
        order = WorkOrder.objects.get()
        item = InventoryItem.objects.create(category=ItemCategory.objects.create(name='Frenos QA'), sku='QA-01', name='Pastillas', unit_price=Decimal('10000'), current_stock=10)
        associated = self.api.post(f'/api/workshop/work-orders/{order.pk}/items/', {'item': str(item.pk), 'quantity': 2}, format='json')
        self.assertEqual(associated.status_code, 201, associated.data)
        diagnosis = WorkOrderStatus.objects.get(code='DIAGNOSTICO')
        self.assertEqual(self.api.patch(f'/api/workshop/work-orders/{order.pk}/', {'status_id': diagnosis.pk, 'technical_diagnosis': 'Cambiar pastillas'}, format='json').status_code, 200)
        self.api.force_authenticate(None)
        tracking = self.api.get(f'/api/tracking/{order.tracking_token}/')
        self.assertEqual(tracking.status_code, 200)
        self.assertEqual(tracking.data['status_code'], 'DIAGNOSTICO')
        self.assertEqual(tracking.data['items'][0]['quantity'], 2)
        self.assertNotIn(client.email, str(tracking.data))
        self.api.force_authenticate(self.staff)
        with self.settings(AJ_QUOTE_TAX_RATE=Decimal('19')):
            quote = self.api.post(f'/api/workshop/work-orders/{order.pk}/quotes/', {}, format='json')
        self.assertEqual(quote.status_code, 201, quote.data)
        self.assertEqual(quote.data['subtotal_amount'], '20000.00')
        self.assertEqual(quote.data['tax_amount'], '3800.00')
        self.assertEqual(quote.data['total_amount'], '23800.00')
        pdf = self.api.get(f"/api/workshop/quotes/{quote.data['id']}/pdf/")
        self.assertEqual(pdf.status_code, 200)
        self.assertEqual(pdf['Content-Type'], 'application/pdf')
        self.assertIn('Cotizacion_AJ_', pdf['Content-Disposition'])
        self.assertTrue(pdf.content.startswith(b'%PDF'))
        with patch('apps.workshop.notifications.EmailMessage.send') as smtp:
            queued = self.api.post(f"/api/workshop/quotes/{quote.data['id']}/email/", {}, format='json')
            self.assertEqual(queued.status_code, 202)
            smtp.assert_not_called()
        while process_next():
            pass
        self.assertEqual(EmailDelivery.objects.get(pk=queued.data['id']).status, 'SENT')
        attachment = mail.outbox[-1].attachments[0]
        self.assertEqual(attachment.mimetype, 'application/pdf')
        self.assertTrue(attachment.content.startswith(b'%PDF'))
        mime = mail.outbox[-1].message()
        self.assertTrue(any(part.get_content_disposition() == 'attachment' for part in mime.walk()))
        # El snapshot no cambia al editar el precio del inventario.
        item.unit_price = 50000
        item.save()
        self.assertEqual(Quote.objects.get(pk=quote.data['id']).total_amount, Decimal('23800.00'))

    def test_two_slots_third_rejected_and_admin_rejection_releases_one(self):
        first = self.api.post('/api/appointments/', self.verified_payload(), format='json')
        cache.clear()
        from apps.authentication.client_tokens import ClientAccessToken
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(Client.objects.get())))
        second = self.api.post('/api/auth/client-appointments/', self.payload, format='json')
        self.assertEqual([first.status_code, second.status_code], [201, 201])
        full = self.api.get('/api/appointments/?date=2030-01-07').data
        self.assertEqual(full['capacity_per_slot'], 2)
        self.assertNotIn(self.payload['scheduled_date'], [slot['start'] for slot in full['slots']])
        third = self.api.post('/api/appointments/', self.payload, format='json')
        self.assertEqual(third.status_code, 400)
        self.assertEqual(Appointment.objects.count(), 2)
        self.api.force_authenticate(self.staff)
        self.assertEqual(self.api.patch(f"/api/appointments/{first.data['id']}/", {'status': 'RECHAZADA'}, format='json').status_code, 200)
        free = self.api.get('/api/appointments/?date=2030-01-07').data
        self.assertEqual(next(slot for slot in free['slots'] if slot['start'] == self.payload['scheduled_date'])['remaining_capacity'], 1)
        self.api.force_authenticate(None)
        cache.clear()
        self.api.credentials(HTTP_AUTHORIZATION='Bearer '+str(ClientAccessToken.for_client(Client.objects.get())))
        replacement = self.api.post('/api/auth/client-appointments/', self.payload, format='json')
        self.assertEqual(replacement.status_code, 201, replacement.data)
        self.assertEqual(Appointment.objects.count(), 3)
        self.assertEqual(Appointment.objects.exclude(status__in=Appointment.INACTIVE_STATUSES).count(), 2)

    def test_booking_requires_contact_verification_and_code_has_attempt_limit(self):
        self.assertEqual(self.api.post('/api/appointments/', self.payload, format='json').status_code, 400)
        payload = self.verified_payload()
        for _ in range(5):
            self.assertEqual(self.api.post('/api/appointments/', {**payload, 'code': 'incorrect'}, format='json').status_code, 400)
        # Los formatos inválidos no consumen intentos. Cinco códigos numéricos sí.
        wrong = '000000' if payload['code'] != '000000' else '999999'
        for _ in range(5):
            self.assertEqual(self.api.post('/api/appointments/', {**payload, 'code': wrong}, format='json').status_code, 400)
        self.assertEqual(self.api.post('/api/appointments/', payload, format='json').status_code, 400)
        self.assertEqual(BookingVerification.objects.get().attempts, 5)
        self.assertFalse(Appointment.objects.exists())

    def test_unknown_rut_stays_not_found_and_known_rut_keeps_cooldown(self):
        self.api.post('/api/appointments/', self.verified_payload(), format='json')
        with patch('apps.workshop.client_auth_views.deliver_client_otp'):
            for rut, expected in (('123456785', 200), ('223456782', 404)):
                responses = [self.api.post('/api/auth/client-login/', {'rut': rut}, format='json') for _ in range(2)]
                self.assertEqual([r.status_code for r in responses], [expected, expected])
                self.assertEqual(responses[0].data, responses[1].data)

    def test_notification_retries_and_records_failure_without_raising(self):
        import uuid
        job = EmailDelivery.objects.create(kind='quote', target_id=uuid.uuid4())
        with patch('apps.workshop.email_queue.send_quote_email', side_effect=RuntimeError('SMTP unavailable')):
            for _ in range(3):
                EmailDelivery.objects.filter(pk=job.pk).update(available_at=timezone.now() - timedelta(seconds=1))
                self.assertTrue(process_next())
        job.refresh_from_db()
        self.assertEqual(job.status, 'FAILED')
        self.assertEqual(job.attempts, 3)

    def test_database_enforces_two_places_even_without_save_validation(self):
        # Reutiliza un cliente verificado y prueba el límite con inserciones directas.
        self.api.post('/api/appointments/', self.verified_payload(), format='json')
        first = Appointment.objects.get()
        values = {'client': first.client, 'scheduled_date': first.scheduled_date, 'reported_symptoms': 'QA'}
        Appointment.objects.bulk_create([Appointment(**values, slot_number=2)])
        for number in (1, 2, 3):
            with self.assertRaises(IntegrityError), transaction.atomic():
                Appointment.objects.bulk_create([Appointment(**values, slot_number=number)])

    def test_quote_negative_values_are_rejected_by_model_and_database(self):
        self.api.post('/api/appointments/', self.verified_payload(), format='json')
        client = Client.objects.get()
        with self.assertRaises(ValidationError):
            Quote(client=client, total_amount=-1).full_clean()
        with self.assertRaises(IntegrityError), transaction.atomic():
            Quote.objects.create(client=client, total_amount=-1)

    def test_delivered_order_cannot_be_reopened_to_edit_diagnosis(self):
        from .test_tracking import PublicTrackingTests
        # Fixture local de vehículo, sin depender de llamadas a proveedores.
        PublicTrackingTests.setUpTestData()
        order = PublicTrackingTests.order
        WorkOrder.objects.filter(pk=order.pk).update(status=WorkOrderStatus.objects.get(code='ENTREGADO'))
        self.api.force_authenticate(self.staff)
        result = self.api.patch(f'/api/workshop/work-orders/{order.pk}/', {'status_id': WorkOrderStatus.objects.get(code='DIAGNOSTICO').pk, 'technical_diagnosis': 'Alterado'}, format='json')
        self.assertEqual(result.status_code, 400)

    def test_booking_rejects_changed_payload_expired_and_replayed_codes(self):
        payload = self.verified_payload()
        changed = self.api.post('/api/appointments/', {**payload, 'reported_symptoms': 'Cambio de solicitud'}, format='json')
        self.assertEqual(changed.status_code, 400)
        self.assertFalse(Appointment.objects.exists())
        challenge = BookingVerification.objects.get()
        challenge.expires_at = timezone.now() - timedelta(seconds=1)
        challenge.save()
        self.assertEqual(self.api.post('/api/appointments/', payload, format='json').status_code, 400)
        challenge.expires_at = timezone.now() + timedelta(minutes=5)
        challenge.save()
        self.assertEqual(self.api.post('/api/appointments/', payload, format='json').status_code, 201)
        self.assertEqual(self.api.post('/api/appointments/', payload, format='json').status_code, 403)
        self.assertEqual(Appointment.objects.count(), 1)

    def test_administrative_permissions_and_invalid_reschedule(self):
        booking = self.api.post('/api/appointments/', self.verified_payload(), format='json')
        url = f"/api/appointments/{booking.data['id']}/"
        self.assertEqual(self.api.get('/api/appointments/').status_code, 401)
        self.assertEqual(self.api.patch(url, {'status': 'RECHAZADA'}, format='json').status_code, 401)
        self.api.force_authenticate(User.objects.create_user('no-role'))
        self.assertEqual(self.api.patch(url, {'status': 'RECHAZADA'}, format='json').status_code, 403)
        self.api.force_authenticate(self.staff)
        self.assertEqual(self.api.patch(url, {'scheduled_date': ''}, format='json').status_code, 400)
        self.assertEqual(self.api.patch(url, {'client': 'another'}, format='json').status_code, 400)
        self.assertEqual(self.api.patch(url, {'status': 'CANCELADA'}, format='json').status_code, 200)
        free = self.api.get('/api/appointments/?date=2030-01-07').data
        self.assertEqual(next(slot for slot in free['slots'] if slot['start'] == self.payload['scheduled_date'])['remaining_capacity'], 2)
