from django.urls import path
from .views import (
    CheckInCreateView,
    ClientLookupView,
    WorkOrderDetailView,
    WorkOrderItemDetailView,
    WorkOrderItemListCreateView,
    WorkOrderListView,
    QuotePdfView,
    WorkOrderPdfView,
    QuoteEmailView,
)
from .quote_views import WorkOrderQuotesView, EmailDeliveryView

urlpatterns = [
    path('work-orders/<uuid:pk>/quotes/', WorkOrderQuotesView.as_view(), name='work-order-quotes'),
    path('email-deliveries/<uuid:pk>/', EmailDeliveryView.as_view(), name='email-delivery'),
    path('clients/lookup/', ClientLookupView.as_view(), name='client-lookup'),
    path('check-in/', CheckInCreateView.as_view(), name='check-in-create'),
    path('work-orders/', WorkOrderListView.as_view(), name='work-order-list'),
    path('work-orders/<uuid:pk>/', WorkOrderDetailView.as_view(), name='work-order-detail'),
    path('work-orders/<uuid:pk>/pdf/', WorkOrderPdfView.as_view(), name='work-order-pdf'),
    path('quotes/<uuid:pk>/pdf/', QuotePdfView.as_view(), name='quote-pdf'),
    path('quotes/<uuid:pk>/email/', QuoteEmailView.as_view(), name='quote-email'),
    path(
        'work-orders/<uuid:pk>/items/',
        WorkOrderItemListCreateView.as_view(),
        name='work-order-items',
    ),
    path(
        'work-orders/<uuid:pk>/items/<uuid:item_id>/',
        WorkOrderItemDetailView.as_view(),
        name='work-order-item-detail',
    ),
]
