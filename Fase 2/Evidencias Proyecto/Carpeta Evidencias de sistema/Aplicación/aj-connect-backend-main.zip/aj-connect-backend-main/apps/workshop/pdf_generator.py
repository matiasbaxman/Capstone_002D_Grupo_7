"""Generación en memoria de cotizaciones e informes técnicos A&J."""

from decimal import Decimal
from html import escape
from io import BytesIO

from django.utils import timezone
from django.conf import settings
NAVY = '#17324D'
TEAL = '#168C8C'
PALE = '#EAF3F4'


def _text(value):
    return escape(str(value or '—')).replace('\n', '<br/>')


def _money(value):
    amount = Decimal(value or 0)
    rendered = f'{amount:,.2f}' if amount != amount.to_integral_value() else f'{amount:,.0f}'
    return '$' + rendered.replace(',', '_').replace('.', ',').replace('_', '.')


def _base_styles():
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_RIGHT
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    navy = colors.HexColor(NAVY)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name='AJTitle', parent=styles['Title'], fontName='Helvetica-Bold',
        fontSize=17, leading=21, textColor=navy, alignment=0, spaceAfter=2,
    ))
    styles.add(ParagraphStyle(
        name='AJSmall', parent=styles['Normal'], fontSize=8, leading=11,
        textColor=colors.HexColor('#536473'),
    ))
    styles.add(ParagraphStyle(
        name='AJSection', parent=styles['Heading2'], fontSize=10, leading=13,
        textColor=navy, spaceBefore=9, spaceAfter=5,
    ))
    styles.add(ParagraphStyle(
        name='AJRight', parent=styles['Normal'], alignment=TA_RIGHT,
    ))
    styles.add(ParagraphStyle(
        name='AJCell', parent=styles['Normal'], fontSize=8, leading=10,
    ))
    return styles


def _header(title, folio, created, styles):
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, Table, TableStyle

    info = [
        Paragraph('<b>A&amp;J SERVICIO AUTOMOTRIZ</b>', styles['AJTitle']),
        Paragraph('Quilpué · Servicio y diagnóstico automotriz', styles['AJSmall']),
    ]
    contact = ' · '.join(filter(None, [settings.AJ_BUSINESS_PHONE, settings.AJ_BUSINESS_EMAIL]))
    if contact:
        info.append(Paragraph(_text(contact), styles['AJSmall']))
    right = [
        Paragraph(f'<b>{_text(title)}</b>', styles['AJRight']),
        Paragraph(f'Folio: {_text(folio)}', styles['AJRight']),
        Paragraph(f'Emisión: {timezone.localtime(created).strftime("%d-%m-%Y")}', styles['AJRight']),
    ]
    table = Table([[info, right]], colWidths=[110 * mm, 65 * mm])
    table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LINEBELOW', (0, 0), (-1, -1), 2, colors.HexColor(TEAL)),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 9),
    ]))
    return table


def _party_vehicle(client, vehicle, odometer, styles):
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, Table, TableStyle

    rows = [
        [Paragraph('<b>CLIENTE</b>', styles['AJCell']), Paragraph('<b>VEHÍCULO</b>', styles['AJCell'])],
        [Paragraph(f'{_text(client.first_name)} {_text(client.last_name)}<br/>RUT: {_text(client.rut)}<br/>Teléfono: {_text(client.phone)}<br/>Email: {_text(client.email)}', styles['AJCell']),
         Paragraph(f'Patente: {_text(getattr(vehicle, "plate", None))}<br/>Marca: {_text(getattr(getattr(getattr(vehicle, "model", None), "brand", None), "name", None))}<br/>Modelo: {_text(getattr(getattr(vehicle, "model", None), "name", None))}<br/>Año: {_text(getattr(vehicle, "year", None))}<br/>Kilometraje: {_text(f"{odometer:,}".replace(",", ".") + " km" if odometer is not None else None)}', styles['AJCell'])]
    ]
    table = Table(rows, colWidths=[87.5 * mm, 87.5 * mm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(PALE)),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#C9D7DC')),
        ('INNERGRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#D7E1E5')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    return table


def _items_table(items, styles, total, tax_rate=None, tax_amount=None):
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, Table, TableStyle

    rows = [[
        Paragraph('<font color="white"><b>Descripción</b></font>', styles['AJCell']),
        Paragraph('<font color="white"><b>Cant.</b></font>', styles['AJCell']),
        Paragraph('<font color="white"><b>Precio unit.</b></font>', styles['AJCell']),
        Paragraph('<font color="white"><b>Subtotal</b></font>', styles['AJCell']),
    ]]
    for line in items:
        rows.append([
            Paragraph(_text(line.item.name), styles['AJCell']), str(line.quantity),
            _money(line.unit_price), _money(line.subtotal),
        ])
    table = Table(rows, colWidths=[91 * mm, 18 * mm, 32 * mm, 34 * mm], repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(NAVY)),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (1, 1), (-1, -1), 'RIGHT'),
        ('ALIGN', (1, 0), (-1, 0), 'RIGHT'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor(PALE)]),
        ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#C9D7DC')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    subtotal = sum((line.subtotal for line in items), Decimal('0.00'))
    total_table = Table([
        ['Subtotal', _money(subtotal)],
        [f'IVA ({Decimal(tax_rate):g}%)' if tax_rate is not None else 'Impuestos', _money(tax_amount) if tax_amount is not None else 'No incluidos'],
        [Paragraph('<b>TOTAL</b>', styles['AJCell']), Paragraph(f'<b>{_money(total)}</b>', styles['AJCell'])],
    ], colWidths=[45 * mm, 35 * mm], hAlign='RIGHT')
    total_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('LINEABOVE', (0, 2), (-1, 2), 1, TEAL),
        ('TEXTCOLOR', (0, 2), (-1, 2), colors.HexColor(NAVY)),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    return table, total_table


def _render(title, folio, created, client, vehicle, odometer, items, total, notes='', tax_rate=None, tax_amount=None):
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table

    if not items:
        raise ValueError('El documento no tiene items vinculados.')
    buffer = BytesIO()
    document = SimpleDocTemplate(
        buffer, pagesize=LETTER, rightMargin=18 * mm, leftMargin=18 * mm,
        topMargin=16 * mm, bottomMargin=18 * mm,
        title=f'{title} {folio}', author='A&J Servicio Automotriz',
    )
    styles = _base_styles()
    item_table, total_table = _items_table(items, styles, total, tax_rate, tax_amount)
    story = [
        _header(title, folio, created, styles), Spacer(1, 8 * mm),
        _party_vehicle(client, vehicle, odometer, styles),
        Paragraph('DETALLE', styles['AJSection']), item_table,
        total_table, Paragraph('Notas y condiciones', styles['AJSection']),
        Paragraph(_text(notes) if notes else 'Valores sujetos a revisión y autorización del cliente. Garantía según normativa vigente y condiciones del servicio.', styles['Normal']),
        Spacer(1, 13 * mm),
        Table([['____________________________', '____________________________'], ['Firma cliente', 'A&J Servicio Automotriz']], colWidths=[87.5 * mm, 87.5 * mm]),
    ]
    document.build(story)
    buffer.seek(0)
    return buffer


def generate_quote_pdf(quote):
    quote.full_clean()
    vehicle = quote.work_order.vehicle if quote.work_order_id else None
    odometer = None
    if quote.work_order_id:
        checkin = getattr(quote.work_order, 'checkin', None)
        odometer = checkin.initial_odometer if checkin else None
    return _render(
        'COTIZACIÓN', f'COT-{str(quote.id)[:8].upper()}', quote.created_at,
        quote.client, vehicle, odometer, list(quote.items.all()), quote.total_amount,
        quote.work_order.client_observations if quote.work_order_id else '',
        tax_rate=quote.tax_rate, tax_amount=quote.tax_amount,
    )


def generate_work_order_pdf(work_order):
    checkin = getattr(work_order, 'checkin', None)
    return _render(
        'INFORME TÉCNICO', f'OT-{work_order.folio_number}', work_order.created_at,
        work_order.vehicle.client, work_order.vehicle,
        checkin.initial_odometer if checkin else None, list(work_order.items.all()),
        sum((line.subtotal for line in work_order.items.all()), Decimal('0.00')),
        '\n'.join(filter(None, [work_order.technical_diagnosis, work_order.client_observations])),
    )
