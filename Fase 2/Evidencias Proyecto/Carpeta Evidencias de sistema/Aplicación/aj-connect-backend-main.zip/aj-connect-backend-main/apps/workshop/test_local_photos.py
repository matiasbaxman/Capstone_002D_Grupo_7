from tempfile import TemporaryDirectory
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import SimpleTestCase, override_settings
from .services import upload_checkin_photo


class LocalCheckInPhotoTests(SimpleTestCase):
    def test_upload_stores_photo_in_configured_local_media(self):
        with TemporaryDirectory() as root, override_settings(CHECKIN_LOCAL_PHOTOS=True, MEDIA_ROOT=root, MEDIA_URL='/api/media/'):
            photo = SimpleUploadedFile('photo.jpg', b'local-image-data', content_type='image/jpeg')
            result = upload_checkin_photo(photo, checkin_id='test-checkin')
            self.assertTrue(result['url'].startswith('/api/media/checkins/test-checkin/'))
            from pathlib import Path
            self.assertEqual((Path(root) / result['public_id'].removeprefix('local/')).read_bytes(), b'local-image-data')
