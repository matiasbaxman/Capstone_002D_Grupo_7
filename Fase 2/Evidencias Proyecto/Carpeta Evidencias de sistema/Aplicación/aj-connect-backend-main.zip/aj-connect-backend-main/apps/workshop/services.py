import logging
import os
import uuid

import cloudinary
import cloudinary.uploader
from django.conf import settings
from django.core.files.storage import FileSystemStorage

logger = logging.getLogger(__name__)

FOLDER_ROOT = "aj_connect/checkins"

CREDENTIAL_ENV_VARS = (
    'CLOUDINARY_CLOUD_NAME',
    'CLOUDINARY_API_KEY',
    'CLOUDINARY_API_SECRET',
)


def configurar_cloudinary():
    """
    Aplica la configuración de Cloudinary desde variables de entorno.

    settings.py ya la carga, pero se repite aquí para que el servicio no
    dependa del orden de importación y para que un worker de Celery o un
    script suelto puedan subir sin settings. Devuelve un dict con las
    credenciales efectivas (valores vacíos si faltan).
    """
    credenciales = {nombre: (os.getenv(nombre) or '').strip() for nombre in CREDENTIAL_ENV_VARS}
    cloudinary.config(
        cloud_name=credenciales['CLOUDINARY_CLOUD_NAME'],
        api_key=credenciales['CLOUDINARY_API_KEY'],
        api_secret=credenciales['CLOUDINARY_API_SECRET'],
        secure=True,
    )
    return credenciales


def upload_checkin_photo(file_obj, checkin_id=None):
    """
    Sube una foto del check-in vehicular a Cloudinary y retorna URL segura y public_id.
    """
    if getattr(settings, 'CHECKIN_LOCAL_PHOTOS', False):
        extension = os.path.splitext(file_obj.name)[1].lower()
        name = f'checkins/{checkin_id}/{uuid.uuid4().hex}{extension}'
        storage = FileSystemStorage(location=settings.MEDIA_ROOT, base_url=settings.MEDIA_URL)
        saved = storage.save(name, file_obj)
        return {'url': storage.url(saved), 'public_id': f'local/{saved}'}

    credenciales = configurar_cloudinary()
    faltantes = [nombre for nombre, valor in credenciales.items() if not valor]
    if faltantes:
        # Mensaje accionable: el 500 sin detalle no ayuda a nadie.
        raise RuntimeError(
            'Faltan variables de entorno de Cloudinary: '
            + ', '.join(faltantes)
            + '. Verificá backend/.env (CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, '
              'CLOUDINARY_API_SECRET) y que python-dotenv esté instalado.'
        )

    try:
        folder_path = f"{FOLDER_ROOT}/{checkin_id}" if checkin_id else FOLDER_ROOT

        upload_result = cloudinary.uploader.upload(
            file_obj,
            folder=folder_path,
            resource_type="image",
            transformation=[
                {'quality': 'auto', 'fetch_format': 'auto'},
                {'width': 1920, 'crop': 'limit'}
            ]
        )

        return {
            'url': upload_result.get('secure_url'),
            'public_id': upload_result.get('public_id')
        }
    except Exception as e:
        logger.error(f"Error al subir imagen a Cloudinary: {str(e)}")
        raise
