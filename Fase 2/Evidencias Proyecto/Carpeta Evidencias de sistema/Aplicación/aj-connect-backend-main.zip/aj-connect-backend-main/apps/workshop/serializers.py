from django.conf import settings
import re
import copy

from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError, transaction
from django.db.models import Value
from django.db.models.functions import Replace, Upper
from rest_framework import serializers

from apps.inventory.models import InventoryItem

from .models import (
    Appointment,
    Client,
    NotificationChannel,
    Service,
    Vehicle,
    WorkOrder,
    WorkOrderCheckIn,
    WorkOrderItem,
    WorkOrderStatus,
    WorkOrderStatusHistory,
)
from .utils import normalized_rut

MAX_PHOTOS = 10
ALLOWED_PHOTO_TYPES = ('image/jpeg', 'image/png', 'image/webp')
MAX_PHOTO_BYTES = 10 * 1024 * 1024


class AppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = [
            'id', 'client', 'vehicle', 'service', 'status', 'scheduled_date',
            'reported_symptoms', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
        # La disponibilidad se valida en el modelo, con errores por campo.
        validators = []

    def validate(self, attrs):
        # Copia para validar PATCH con los valores actuales, sin modificar la
        # instancia original cuando la validación falla.
        candidate = copy.copy(self.instance) if self.instance else Appointment()
        for field, value in attrs.items():
            setattr(candidate, field, value)
        try:
            candidate.full_clean()
        except DjangoValidationError as error:
            raise serializers.ValidationError(error.message_dict) from error
        return attrs

    def _persist(self, operation, *args):
        try:
            with transaction.atomic():
                return operation(*args)
        except DjangoValidationError as error:
            # Revalida al guardar: el cupo pudo ocuparse después de is_valid().
            raise serializers.ValidationError(error.message_dict) from error
        except IntegrityError as error:
            # Dos reservas pueden superar clean() al mismo tiempo. El índice
            # único arbitra la carrera; otros errores de integridad se propagan.
            values = args[-1]
            scheduled = values.get('scheduled_date', getattr(self.instance, 'scheduled_date', None))
            status = values.get('status', getattr(self.instance, 'status', Appointment.Status.PENDIENTE))
            occupied = Appointment.objects.filter(scheduled_date=scheduled).exclude(
                status__in=Appointment.INACTIVE_STATUSES,
            )
            if self.instance:
                occupied = occupied.exclude(pk=self.instance.pk)
            if status not in Appointment.INACTIVE_STATUSES and occupied.count() >= Appointment.CAPACITY:
                raise serializers.ValidationError({
                    'scheduled_date': 'El bloque horario ya no tiene cupos disponibles.',
                }) from error
            raise

    def create(self, validated_data):
        return self._persist(super().create, validated_data)

    def update(self, instance, validated_data):
        return self._persist(super().update, instance, validated_data)


class AppointmentClientAdminSerializer(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields = ['id', 'first_name', 'last_name', 'rut', 'phone', 'email']


class AppointmentVehicleAdminSerializer(serializers.ModelSerializer):
    brand = serializers.CharField(source='model.brand.name', read_only=True)
    model = serializers.CharField(source='model.name', read_only=True)

    class Meta:
        model = Vehicle
        fields = ['id', 'brand', 'model', 'plate', 'year', 'color']


class AppointmentServiceAdminSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'name', 'description', 'base_price', 'estimated_duration_minutes']


class AppointmentAdminSerializer(serializers.ModelSerializer):
    client = AppointmentClientAdminSerializer(read_only=True)
    vehicle = AppointmentVehicleAdminSerializer(read_only=True, allow_null=True)
    service = AppointmentServiceAdminSerializer(read_only=True, allow_null=True)

    class Meta:
        model = Appointment
        fields = [
            'id', 'client', 'vehicle', 'service', 'status', 'scheduled_date',
            'reported_symptoms', 'created_at', 'updated_at',
        ]

# Códigos esperados en `notification_channels.code`. La comparación es
# insensible a mayúsculas/minúsculas para no depender de cómo se guardó.
NOTIFICATION_CHANNELS = ('WHATSAPP', 'EMAIL')
DEFAULT_NOTIFICATION_CHANNEL = 'EMAIL' if settings.CLIENT_EMAIL_REQUIRED else 'WHATSAPP'

# Estado terminal del catálogo: al entregar la OT, el diagnóstico técnico
# queda congelado y no puede modificarse desde la API.
FINAL_ORDER_STATUS_CODE = 'ENTREGADO'


class PublicServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'name', 'description', 'base_price', 'estimated_duration_minutes']


class PublicAppointmentResultSerializer(serializers.ModelSerializer):
    """Confirmación pública sin datos del perfil del cliente ni del vehículo."""

    service = PublicServiceSerializer(read_only=True)

    class Meta:
        model = Appointment
        fields = ['id', 'status', 'scheduled_date', 'reported_symptoms', 'service', 'created_at']


class PublicAppointmentCreateSerializer(serializers.Serializer):
    rut = serializers.CharField(max_length=20)
    first_name = serializers.CharField(max_length=100, required=False)
    last_name = serializers.CharField(max_length=100, required=False)
    phone = serializers.RegexField(r'^\+569\d{8}$', max_length=20, required=False, allow_blank=True)
    email = serializers.EmailField(max_length=255, required=False, allow_blank=True)
    notification_channel = serializers.ChoiceField(choices=NOTIFICATION_CHANNELS, default=DEFAULT_NOTIFICATION_CHANNEL)
    vehicle = serializers.PrimaryKeyRelatedField(queryset=Vehicle.objects.all(), required=False, allow_null=True)
    service = serializers.PrimaryKeyRelatedField(queryset=Service.objects.filter(is_active=True), required=False, allow_null=True)
    scheduled_date = serializers.DateTimeField()
    reported_symptoms = serializers.CharField()

    def validate_rut(self, value):
        try:
            return normalized_rut(value)
        except serializers.ValidationError as error:
            raise serializers.ValidationError(error.detail['rut']) from error

    def validate(self, attrs):
        if settings.CLIENT_EMAIL_REQUIRED:
            attrs['notification_channel'] = 'EMAIL'
        # Incluye RUT legados con puntos/guion sin modificar el perfil público.
        expression = Upper(Replace(Replace(Replace('rut', Value('.'), Value('')), Value('-'), Value('')), Value(' '), Value('')))
        clients = list(Client.objects.annotate(rut_key=expression).filter(rut_key=attrs['rut'])[:2])
        if len(clients) > 1:
            raise serializers.ValidationError({'rut': 'Solicita revisión del registro a administración.'})
        self.existing_client = clients[0] if clients else None
        if self.existing_client is None:
            errors = {field: 'Este campo es obligatorio para registrar un cliente nuevo.'
                      for field in (('first_name', 'last_name', 'email') if settings.CLIENT_EMAIL_REQUIRED else ('first_name', 'last_name', 'phone')) if not attrs.get(field)}
            if attrs['notification_channel'] == 'EMAIL' and not attrs.get('email'):
                errors['email'] = 'Ingresa un correo para utilizar el canal Email.'
            if errors:
                raise serializers.ValidationError(errors)
        if settings.CLIENT_EMAIL_REQUIRED and self.existing_client and not self.existing_client.email:
            raise serializers.ValidationError({'email': 'Solicita al taller registrar tu correo antes de agendar.'})
        # Reutiliza las reglas de T-02 antes de escribir registros. En clientes
        # nuevos la FK todavía no existe; se valida al persistir en la transacción.
        candidate = Appointment(
            client=self.existing_client or Client(),
            vehicle=attrs.get('vehicle'), service=attrs.get('service'),
            scheduled_date=attrs['scheduled_date'], reported_symptoms=attrs['reported_symptoms'],
        )
        try:
            candidate.full_clean(exclude=['client'])
        except DjangoValidationError as error:
            raise serializers.ValidationError(error.message_dict) from error
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        client = self.existing_client
        if client is None:
            channel, _ = NotificationChannel.objects.get_or_create(
                code=validated_data['notification_channel'],
                defaults={'name': {'WHATSAPP': 'WhatsApp', 'EMAIL': 'Correo Electrónico'}[validated_data['notification_channel']]},
            )
            # get_or_create también resuelve dos altas concurrentes del mismo RUT.
            client, created = Client.objects.get_or_create(
                rut=validated_data['rut'],
                defaults={
                    'first_name': validated_data['first_name'], 'last_name': validated_data['last_name'],
                    'phone': validated_data.get('phone', ''), 'email': validated_data.get('email') or None,
                    'notification_channel': channel, 'password_hash': make_password(None),
                },
            )
            if created:
                from .email_queue import enqueue_client_welcome
                enqueue_client_welcome(client)
        appointment_data = {
            'client': str(client.pk), 'scheduled_date': validated_data['scheduled_date'],
            'reported_symptoms': validated_data['reported_symptoms'],
            'vehicle': validated_data['vehicle'].pk if validated_data.get('vehicle') else None,
            'service': validated_data['service'].pk if validated_data.get('service') else None,
        }
        serializer = AppointmentSerializer(data=appointment_data)
        Client.objects.select_for_update().get(pk=client.pk)
        from django.utils import timezone
        if Appointment.objects.filter(client=client, status='PENDIENTE', scheduled_date__gt=timezone.now()).count() >= 2:
            raise serializers.ValidationError({'detail': 'Ya tienes dos solicitudes pendientes. Contacta al taller antes de agendar otra.'})
        serializer.is_valid(raise_exception=True)
        return serializer.save()


class AssignedMechanicMixin(serializers.Serializer):
    """Expone el mecánico asignado como nombre completo en texto plano."""

    mecanico_nombre = serializers.SerializerMethodField(read_only=True)

    def get_mecanico_nombre(self, obj):
        mechanic = obj.assigned_mechanic
        if not mechanic:
            return 'Sin asignar'
        full_name = f"{mechanic.first_name} {mechanic.last_name}".strip()
        return full_name or mechanic.username


class CheckInCreateSerializer(serializers.Serializer):
    appointment_id = serializers.UUIDField(required=False, allow_null=True)
    """Recepción vehicular: cliente, vehículo, inspección y fotografías."""

    client_id = serializers.UUIDField(required=False, allow_null=True)
    vehicle_id = serializers.UUIDField(required=False, allow_null=True)

    # Mecánico que atenderá la OT. Si no viene en el payload, la vista asigna
    # al usuario autenticado que registra el ingreso.
    assigned_mechanic_id = serializers.PrimaryKeyRelatedField(
        queryset=get_user_model().objects.all(),
        required=False,
        allow_null=True,
    )

    first_name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    last_name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    rut = serializers.CharField(max_length=12, required=False, allow_blank=True)
    email = serializers.EmailField(required=False, allow_blank=True, default='')
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    notification_channel = serializers.CharField(
        required=False,
        default=DEFAULT_NOTIFICATION_CHANNEL,
    )

    plate = serializers.CharField(max_length=10)
    brand = serializers.CharField(max_length=50, required=False, allow_blank=True)
    vehicle_model = serializers.CharField(max_length=50, required=False, allow_blank=True)
    year = serializers.IntegerField(required=False, allow_null=True, min_value=1900)
    color = serializers.CharField(max_length=30, required=False, allow_blank=True)

    odometer = serializers.IntegerField(min_value=0, required=False, allow_null=True, default=None)
    fuel = serializers.CharField(max_length=20, required=False, allow_blank=True, default='')
    spare = serializers.BooleanField(required=False, allow_null=True, default=None)
    tools = serializers.BooleanField(required=False, allow_null=True, default=None)
    notes = serializers.CharField(required=False, allow_blank=True, default='')
    additional_equipment = serializers.JSONField(required=False, default=list)

    def validate_additional_equipment(self, value):
        if not isinstance(value, list) or len(value) > 20:
            raise serializers.ValidationError('Puedes agregar hasta 20 elementos.')
        result, names = [], set()
        for item in value:
            if not isinstance(item, dict) or not isinstance(item.get('name'), str):
                raise serializers.ValidationError('Cada elemento debe tener un nombre.')
            name = item['name'].strip()
            if not name or len(name) > 80 or name.casefold() in names:
                raise serializers.ValidationError('Usa nombres únicos de hasta 80 caracteres.')
            present = item.get('present')
            if present is not None and type(present) is not bool:
                raise serializers.ValidationError('El estado debe ser sí, no o sin revisar.')
            names.add(name.casefold())
            result.append({'name': name, 'present': present})
        return result

    photos = serializers.ListField(
        child=serializers.FileField(),
        required=False,
        allow_empty=True,
        max_length=MAX_PHOTOS,
    )

    def validate_rut(self, value):
        value = (value or '').strip()
        if not value:
            return value
        return normalized_rut(value)

    def validate_plate(self, value):
        plate = (value or '').strip().upper().replace(' ', '').replace('-', '')
        if not re.fullmatch(r'[A-Z]{2,4}\d{2,4}', plate):
            raise serializers.ValidationError(
                'Ingresa una patente válida: 4 letras y 2 números, o 2 letras y 4 números.'
            )
        return plate

    def validate_fuel(self, value):
        if not (value or '').strip():
            return ''
        allowed = {'vacío', '1/4', '1/2', '3/4', 'lleno'}
        if (value or '').strip().lower() not in allowed:
            raise serializers.ValidationError('Selecciona un nivel de combustible válido.')
        return (value or '').strip()

    def validate_notification_channel(self, value):
        normalized = (value or '').strip().upper()
        for code in NOTIFICATION_CHANNELS:
            if code.upper() == normalized:
                return code
        raise serializers.ValidationError(
            'Selecciona un canal de notificación válido (WhatsApp o Correo).'
        )

    def validate_photos(self, value):
        for image in value:
            content_type = getattr(image, 'content_type', '')
            if content_type not in ALLOWED_PHOTO_TYPES:
                raise serializers.ValidationError(
                    'Selecciona imágenes JPG, PNG o WebP.'
                )
            if getattr(image, 'size', 0) > MAX_PHOTO_BYTES:
                raise serializers.ValidationError(
                    'Cada fotografía debe pesar hasta 10 MB.'
                )
        return value

    def validate(self, attrs):
        # Cliente: si no viene de la búsqueda, se crea uno nuevo con sus datos.
        if not attrs.get('client_id'):
            if not attrs.get('first_name') or not attrs.get('last_name'):
                raise serializers.ValidationError(
                    {'first_name': 'Ingresa el nombre y apellido del cliente.'}
                )
            if not attrs.get('rut'):
                raise serializers.ValidationError({'rut': 'Ingresa el RUT del cliente.'})
            if not settings.CLIENT_EMAIL_REQUIRED and not attrs.get('phone'):
                raise serializers.ValidationError(
                    {'phone': 'Ingresa el teléfono móvil del cliente.'}
                )
            if Client.objects.filter(rut=attrs['rut']).exists():
                raise serializers.ValidationError(
                    {'rut': 'Este RUT ya está registrado. Búscalo por RUT para continuar.'}
                )

        if settings.CLIENT_EMAIL_REQUIRED:
            existing = Client.objects.filter(pk=attrs.get('client_id')).first() if attrs.get('client_id') else None
            email = attrs.get('email') if 'email' in self.initial_data else (existing.email if existing else '')
            if not email:
                raise serializers.ValidationError({'email': 'El correo electrónico es obligatorio.'})
            attrs['notification_channel'] = 'EMAIL'

        # El canal Correo solo tiene sentido si hay un correo válido.
        if attrs.get('notification_channel') == 'EMAIL' and not attrs.get('email') and not (settings.CLIENT_EMAIL_REQUIRED and attrs.get('client_id') and 'email' not in self.initial_data):
            raise serializers.ValidationError(
                {'notification_channel': 'Ingresa un correo electrónico para elegir este canal.'}
            )

        # Vehículo: si no viene de la búsqueda, se registra con marca y modelo.
        if not attrs.get('vehicle_id'):
            if not attrs.get('brand') or not attrs.get('vehicle_model'):
                raise serializers.ValidationError(
                    {'brand': 'Ingresa la marca y el modelo del vehículo.'}
                )
            if not attrs.get('year'):
                raise serializers.ValidationError({'year': 'Ingresa el año del vehículo.'})
            if Vehicle.objects.filter(plate=attrs['plate']).exists():
                raise serializers.ValidationError(
                    {'plate': 'Esta patente ya está registrada.'}
                )
        return attrs


class WorkOrderStatusHistorySerializer(serializers.ModelSerializer):
    """Entrada del historial de estados, con los nombres legibles."""

    from_status = serializers.CharField(source='from_status.name', read_only=True, default=None)
    from_status_code = serializers.CharField(source='from_status.code', read_only=True, default=None)
    to_status = serializers.CharField(source='to_status.name', read_only=True)
    to_status_code = serializers.CharField(source='to_status.code', read_only=True)
    changed_by = serializers.CharField(source='changed_by.username', read_only=True, default=None)

    class Meta:
        model = WorkOrderStatusHistory
        fields = [
            'id',
            'from_status',
            'from_status_code',
            'to_status',
            'to_status_code',
            'changed_by',
            'notes',
            'changed_at',
        ]


class ClientSummarySerializer(serializers.ModelSerializer):
    full_name = serializers.SerializerMethodField()

    class Meta:
        model = Client
        fields = ['id', 'rut', 'first_name', 'last_name', 'full_name', 'phone', 'email']

    def get_full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}".strip()


class VehicleSummarySerializer(serializers.ModelSerializer):
    brand = serializers.CharField(source='model.brand.name', read_only=True)
    model_name = serializers.CharField(source='model.name', read_only=True)
    label = serializers.SerializerMethodField()

    class Meta:
        model = Vehicle
        fields = ['id', 'plate', 'brand', 'model_name', 'label', 'year', 'color']

    def get_label(self, obj):
        return f"{obj.model.brand.name} {obj.model.name} {obj.year}".strip()


class WorkOrderListSerializer(AssignedMechanicMixin, serializers.ModelSerializer):
    """Listado general: lo mínimo para identificar la OT en una tabla."""

    plate = serializers.CharField(source='vehicle.plate', read_only=True)
    client_name = serializers.SerializerMethodField()
    client_rut = serializers.SerializerMethodField()
    assigned_mechanic = serializers.CharField(
        source='assigned_mechanic.username', read_only=True, default=None
    )
    status = serializers.CharField(source='status.name', read_only=True)
    status_code = serializers.CharField(source='status.code', read_only=True)
    vehicle_label = serializers.CharField(source='vehicle.model.name', read_only=True)

    class Meta:
        model = WorkOrder
        fields = [
            'id',
            'folio_number',
            'tracking_token',
            'tracking_code',
            'plate',
            'vehicle_label',
            'client_name',
            'client_rut',
            'assigned_mechanic',
            'assigned_mechanic_id',
            'mecanico_nombre',
            'status',
            'status_code',
            'status_id',
            'created_at',
        ]

    def get_client_name(self, obj):
        client = obj.vehicle.client if obj.vehicle else None
        return f"{client.first_name} {client.last_name}".strip() if client else ''

    def get_client_rut(self, obj):
        client = obj.vehicle.client if obj.vehicle else None
        return client.rut if client else ''


class WorkOrderCheckInSummarySerializer(serializers.ModelSerializer):
    """Datos del check-in anidados en el detalle de la OT."""

    receptionist = serializers.CharField(source='receptionist.username', read_only=True, default=None)
    photos = serializers.SerializerMethodField()

    class Meta:
        model = WorkOrderCheckIn
        fields = [
            'id',
            'receptionist',
            'initial_odometer',
            'fuel_level',
            'has_spare_tire',
            'has_jack_and_tools',
            'bodywork_details',
            'additional_equipment',
            'created_at',
            'photos',
        ]

    def get_photos(self, obj):
        return list(obj.photos.values_list('photo_cloudinary_url', flat=True))


class WorkOrderDetailSerializer(AssignedMechanicMixin, serializers.ModelSerializer):
    """Detalle completo: OT + vehículo + cliente + check-in + historial."""

    client = serializers.SerializerMethodField()
    vehicle = serializers.SerializerMethodField()
    checkin = serializers.SerializerMethodField()
    assigned_mechanic = serializers.CharField(
        source='assigned_mechanic.username', read_only=True, default=None
    )
    status = serializers.CharField(source='status.name', read_only=True)
    status_code = serializers.CharField(source='status.code', read_only=True)
    status_history = serializers.SerializerMethodField()
    items = serializers.SerializerMethodField()
    allowed_statuses = serializers.SerializerMethodField()
    can_add_items = serializers.SerializerMethodField()

    class Meta:
        model = WorkOrder
        fields = [
            'id',
            'folio_number',
            'tracking_token',
            'tracking_code',
            'client',
            'vehicle',
            'assigned_mechanic',
            'assigned_mechanic_id',
            'mecanico_nombre',
            'status',
            'status_code',
            'status_id',
            'client_observations',
            'technical_diagnosis',
            'estimated_delivery_date',
            'closed_at',
            'created_at',
            'updated_at',
            'checkin',
            'status_history',
            'items',
            'allowed_statuses',
            'can_add_items',
        ]

    def get_client(self, obj):
        client = obj.vehicle.client if obj.vehicle else None
        return ClientSummarySerializer(client).data if client else None

    def get_vehicle(self, obj):
        return VehicleSummarySerializer(obj.vehicle).data if obj.vehicle else None

    def get_checkin(self, obj):
        checkin = getattr(obj, 'checkin', None)
        return WorkOrderCheckInSummarySerializer(checkin).data if checkin else None

    def get_status_history(self, obj):
        return WorkOrderStatusHistorySerializer(obj.status_history.all(), many=True).data

    def get_items(self, obj):
        return WorkOrderItemSerializer(obj.items.select_related('item', 'added_by_user'), many=True).data

    def get_allowed_statuses(self, obj):
        if obj.status.code.upper() == FINAL_ORDER_STATUS_CODE:
            return []
        # Se ofrece todo el catálogo menos el estado actual de la OT.
        return list(WorkOrderStatus.objects.exclude(pk=obj.status_id).order_by('sequence_order', 'id').values('id', 'code', 'name'))

    def get_can_add_items(self, obj):
        from apps.authentication.permissions import is_admin, is_mecanico
        request = self.context.get('request')
        return bool(request and (is_admin(request.user) or is_mecanico(request.user)))


class PublicWorkOrderStatusHistorySerializer(serializers.ModelSerializer):
    from_status = serializers.CharField(source='from_status.name', read_only=True, default=None)
    from_status_code = serializers.CharField(source='from_status.code', read_only=True, default=None)
    to_status = serializers.CharField(source='to_status.name', read_only=True)
    to_status_code = serializers.CharField(source='to_status.code', read_only=True)

    class Meta:
        model = WorkOrderStatusHistory
        fields = ['from_status', 'from_status_code', 'to_status', 'to_status_code', 'changed_at']


class PublicWorkOrderItemSerializer(serializers.ModelSerializer):
    item_name = serializers.CharField(source='item.name', read_only=True)
    item_sku = serializers.CharField(source='item.sku', read_only=True)
    subtotal = serializers.DecimalField(max_digits=22, decimal_places=2, read_only=True)

    class Meta:
        model = WorkOrderItem
        fields = ['item_name', 'item_sku', 'quantity', 'unit_price', 'subtotal']


class PublicWorkOrderTrackingSerializer(serializers.ModelSerializer):
    appointment = serializers.SerializerMethodField()
    """Contrato público: sin contacto del cliente ni identidad del personal."""

    status = serializers.CharField(source='status.name', read_only=True)
    status_code = serializers.CharField(source='status.code', read_only=True)
    vehicle = VehicleSummarySerializer(read_only=True)
    status_history = PublicWorkOrderStatusHistorySerializer(many=True, read_only=True)
    items = PublicWorkOrderItemSerializer(many=True, read_only=True)
    photos = serializers.SerializerMethodField()
    bodywork_details = serializers.CharField(source='checkin.bodywork_details', read_only=True, default=None)

    class Meta:
        model = WorkOrder
        fields = [
            'appointment', 'folio_number', 'status', 'status_code', 'estimated_delivery_date',
            'client_observations', 'technical_diagnosis', 'bodywork_details',
            'created_at', 'updated_at', 'closed_at', 'vehicle',
            'status_history', 'photos', 'items',
        ]

    def get_appointment(self, obj):
        if not obj.appointment_id:
            return None
        appointment = obj.appointment
        return {'id': str(appointment.pk), 'status': appointment.status,
                'scheduled_date': appointment.scheduled_date, 'created_at': appointment.created_at}

    def get_photos(self, obj):
        checkin = getattr(obj, 'checkin', None)
        return [photo.photo_cloudinary_url for photo in checkin.photos.all()] if checkin else []


class WorkOrderUpdateSerializer(serializers.ModelSerializer):
    """
    Actualización parcial de la OT. Expone los campos que el frontend gestiona:
    mecánico asignado, estado, diagnóstico técnico y fecha estimada de entrega.
    `notes` no es un campo del modelo, se consume en la vista para el historial.
    """

    assigned_mechanic_id = serializers.PrimaryKeyRelatedField(
        source='assigned_mechanic',
        queryset=get_user_model().objects.all(),
        required=False,
        allow_null=True,
    )
    status_id = serializers.PrimaryKeyRelatedField(
        source='status',
        queryset=WorkOrderStatus.objects.all(),
        required=False,
    )
    notes = serializers.CharField(required=False, allow_blank=True, allow_null=True)

    class Meta:
        model = WorkOrder
        fields = [
            'assigned_mechanic_id',
            'status_id',
            'notes',
            'technical_diagnosis',
            'estimated_delivery_date',
        ]

    def validate(self, attrs):
        # Un PATCH vacío no debería generar un registro de historial inútil.
        if not any(
            field in attrs
            for field in ('assigned_mechanic', 'status', 'technical_diagnosis', 'estimated_delivery_date')
        ):
            raise serializers.ValidationError(
                {'detail': 'Envía al menos el mecánico, el estado o el diagnóstico a actualizar.'}
            )

        # El diagnóstico queda congelado en una OT entregada: se rechaza tanto
        # editarlo sobre una OT que ya está en ENTREGADO como intentar entregar
        # y modificar el diagnóstico en la misma llamada.
        if 'technical_diagnosis' in attrs:
            target_status = attrs.get('status') or getattr(self.instance, 'status', None)
            current_status = getattr(self.instance, 'status', None)
            if any(state and state.code.upper() == FINAL_ORDER_STATUS_CODE for state in (current_status, target_status)):
                raise serializers.ValidationError(
                    {'technical_diagnosis': 'El diagnóstico no se puede modificar en una OT entregada.'}
                )
        if getattr(getattr(self.instance, 'status', None), 'code', '').upper() == FINAL_ORDER_STATUS_CODE and 'status' in attrs and attrs['status'] != self.instance.status:
            raise serializers.ValidationError({'status_id': 'Una OT entregada no se puede reabrir desde este formulario.'})
        return attrs


class WorkOrderSummarySerializer(AssignedMechanicMixin, serializers.ModelSerializer):
    plate = serializers.CharField(source='vehicle.plate', read_only=True)
    client_name = serializers.SerializerMethodField()
    status = serializers.CharField(source='status.name', read_only=True)
    status_code = serializers.CharField(source='status.code', read_only=True)

    class Meta:
        model = WorkOrder
        fields = [
            'id',
            'folio_number',
            'tracking_token',
            'tracking_code',
            'plate',
            'client_name',
            'assigned_mechanic_id',
            'mecanico_nombre',
            'status',
            'status_code',
        ]

    def get_client_name(self, obj):
        vehicle = obj.vehicle
        if vehicle and vehicle.client:
            return f"{vehicle.client.first_name} {vehicle.client.last_name}".strip()
        return ''


class WorkOrderItemSerializer(serializers.ModelSerializer):
    """
    Gestión de insumos vinculados a una OT.

    `item` es escribible (solo en el alta, vía POST); el resto de los campos de
    negocio (`unit_price`, `added_by_user`) los fija la vista dentro de la
    transacción, por lo que son de solo lectura aquí.
    """

    item = serializers.PrimaryKeyRelatedField(queryset=InventoryItem.objects.all())
    item_name = serializers.CharField(source='item.name', read_only=True)
    item_sku = serializers.CharField(source='item.sku', read_only=True)
    current_stock = serializers.IntegerField(source='item.current_stock', read_only=True)
    added_by_user = serializers.CharField(
        source='added_by_user.username', read_only=True, default=None
    )
    subtotal = serializers.SerializerMethodField()

    class Meta:
        model = WorkOrderItem
        fields = [
            'id',
            'work_order',
            'item',
            'item_name',
            'item_sku',
            'current_stock',
            'quantity',
            'unit_price',
            'subtotal',
            'added_by_user',
            'created_at',
        ]
        read_only_fields = ['work_order', 'unit_price', 'created_at']

    def get_subtotal(self, obj):
        return obj.subtotal

    def validate_quantity(self, value):
        if value is None or value <= 0:
            raise serializers.ValidationError('La cantidad debe ser mayor a 0.')
        return value

    def validate(self, attrs):
        item = attrs.get('item') or getattr(self.instance, 'item', None)
        quantity = attrs.get('quantity')
        if quantity is None and self.instance:
            quantity = self.instance.quantity
        if item is not None and quantity is not None and quantity > item.current_stock:
            raise serializers.ValidationError('Stock insuficiente')
        return attrs


class CheckInDetailSerializer(WorkOrderCheckInSummarySerializer):
    """Respuesta del alta de check-in: resumen del check-in + OT creada."""

    plate = serializers.CharField(source='work_order.vehicle.plate', read_only=True)
    work_order = WorkOrderSummarySerializer(read_only=True)

    class Meta(WorkOrderCheckInSummarySerializer.Meta):
        fields = [
            'work_order',
            'plate',
            *WorkOrderCheckInSummarySerializer.Meta.fields,
        ]
