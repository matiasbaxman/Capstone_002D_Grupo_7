"""Configuración exclusiva para desarrollo; no usa la base de datos remota."""
from .settings import *  # noqa: F403

DEBUG = True
CLIENT_OTP_DELIVERY_MODE = os.getenv('CLIENT_OTP_DELIVERY_MODE', 'simulation')
CLIENT_OTP_ALLOW_SIMULATION = CLIENT_OTP_DELIVERY_MODE == 'simulation'
SECRET_KEY = 'django-insecure-local-development-only-ajconnect'
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'testserver']
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
        'OPTIONS': {'timeout': 20, 'transaction_mode': 'IMMEDIATE'},
    }
}
CORS_ALLOWED_ORIGINS = ['http://localhost:5173', 'http://127.0.0.1:5173']
# Cloudinary usa las credenciales reales de settings.py (cargadas desde .env)
# para que el check-in con fotos funcione igual que en producción. Anularlas
# provocaba el error "Must supply api_key" al subir.
