"""Desarrollo en Docker: SQLite persistente y correo en la consola."""
from .settings_local import *  # noqa: F403

# Nombre del servicio usado por el proxy de Vite dentro de Docker.
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'testserver', 'backend']

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '/data/db.sqlite3',
        'OPTIONS': {'timeout': 20, 'transaction_mode': 'IMMEDIATE'},
    }
}

# Permite revisar los avisos sin enviar correos reales desde desarrollo.
EMAIL_BACKEND = os.getenv(
    'EMAIL_BACKEND',
    EMAIL_BACKEND
    if CLIENT_OTP_DELIVERY_MODE == 'channel' or EMAIL_PROVIDER == 'brevo'
    else 'django.core.mail.backends.console.EmailBackend',
)

# Las fotos de desarrollo quedan en el volumen local, sin usar Cloudinary.
CHECKIN_LOCAL_PHOTOS = True
MEDIA_ROOT = '/data/media'
MEDIA_URL = '/api/media/'
