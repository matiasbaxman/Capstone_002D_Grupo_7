"""
Django settings for ajconnect_api project.
"""

from pathlib import Path
import os
import secrets
from decimal import Decimal
from django.core.exceptions import ImproperlyConfigured
from datetime import timedelta
import dj_database_url
from dotenv import load_dotenv
import cloudinary

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Cargar variables de entorno desde .env (en local)
load_dotenv(BASE_DIR / '.env')

# Quick-start development settings - unsuitable for production
DEBUG = os.getenv('DEBUG', 'False') == 'True'
_LOCAL_SETTINGS = os.getenv('DJANGO_SETTINGS_MODULE', '').endswith(('settings_local', 'settings_docker', 'settings_ci'))
SECRET_KEY = os.getenv('SECRET_KEY', '')
if not DEBUG and not _LOCAL_SETTINGS and (len(SECRET_KEY) < 50 or SECRET_KEY.startswith('django-insecure-') or len(set(SECRET_KEY)) < 5):
    raise ImproperlyConfigured('Configura una SECRET_KEY aleatoria de al menos 50 caracteres para producción.')
SECRET_KEY = SECRET_KEY or secrets.token_urlsafe(64)
SECURE_SSL_REDIRECT = not (DEBUG or _LOCAL_SETTINGS)
if os.getenv('TRUST_PROXY_SSL_HEADER', 'False') == 'True':
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
SESSION_COOKIE_SECURE = not (DEBUG or _LOCAL_SETTINGS)
CSRF_COOKIE_SECURE = not (DEBUG or _LOCAL_SETTINGS)
SECURE_HSTS_SECONDS = int(os.getenv('SECURE_HSTS_SECONDS', '3600')) if not (DEBUG or _LOCAL_SETTINGS) else 0
CACHES = {'default': {
    'BACKEND': os.getenv('CACHE_BACKEND', 'django.core.cache.backends.locmem.LocMemCache' if DEBUG or _LOCAL_SETTINGS else 'django.core.cache.backends.db.DatabaseCache'),
    'LOCATION': os.getenv('CACHE_LOCATION', 'ajconnect_cache'),
}}
AJ_QUOTE_TAX_RATE = Decimal(os.getenv('AJ_QUOTE_TAX_RATE', '19.00'))

# Datos institucionales opcionales impresos en cotizaciones e informes PDF.
AJ_BUSINESS_PHONE = os.getenv('AJ_BUSINESS_PHONE', '')
AJ_BUSINESS_EMAIL = os.getenv('AJ_BUSINESS_EMAIL', '')

# ALLOWED_HOSTS dinámico desde variable de entorno
allowed_hosts_env = os.getenv('ALLOWED_HOSTS', 'localhost,127.0.0.1')
if allowed_hosts_env == '*' and not (DEBUG or _LOCAL_SETTINGS):
    raise ImproperlyConfigured('ALLOWED_HOSTS debe enumerar los dominios de producción.')
if allowed_hosts_env == '*':
    ALLOWED_HOSTS = ['*']
else:
    ALLOWED_HOSTS = [host.strip() for host in allowed_hosts_env.split(',') if host.strip()]


cloudinary.config(
    cloud_name=os.getenv('CLOUDINARY_CLOUD_NAME'),
    api_key=os.getenv('CLOUDINARY_API_KEY'),
    api_secret=os.getenv('CLOUDINARY_API_SECRET'),
    secure=True
)

# Application definition

INSTALLED_APPS = [
    # Django apps
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # Third party apps
    'rest_framework',
    'corsheaders',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',  # Requerido por BLACKLIST_AFTER_ROTATION

    # Local apps
    'apps.authentication.apps.AuthenticationConfig',
    'apps.inventory.apps.InventoryConfig',
    'apps.workshop.apps.WorkshopConfig',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'ajconnect_api.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'ajconnect_api.wsgi.application'


# Database (Neon PostgreSQL)

DATABASES = {
    'default': dj_database_url.config(
        default=os.getenv('DATABASE_URL'),
        conn_max_age=0,
        ssl_require=True
    )
}


# Password validation

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization

LANGUAGE_CODE = 'es-cl'

TIME_ZONE = 'America/Santiago'

USE_I18N = True

USE_TZ = True

# T-04: producción requiere habilitar un canal real. La simulación solo se
# activa explícitamente en settings_local y nunca devuelve códigos por HTTP.
CLIENT_OTP_DELIVERY_MODE = os.getenv('CLIENT_OTP_DELIVERY_MODE', 'disabled')
CLIENT_OTP_ALLOW_SIMULATION = False
CLIENT_OTP_WHATSAPP_SENDER = os.getenv('CLIENT_OTP_WHATSAPP_SENDER', '')
CLIENT_WHATSAPP_NOTIFICATION_SENDER = os.getenv('CLIENT_WHATSAPP_NOTIFICATION_SENDER', '')
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID', '')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN', '')
TWILIO_WHATSAPP_FROM = os.getenv('TWILIO_WHATSAPP_FROM', '')
TWILIO_WHATSAPP_TEST_TO = os.getenv('TWILIO_WHATSAPP_TEST_TO', '')
TWILIO_WHATSAPP_SANDBOX = os.getenv('TWILIO_WHATSAPP_SANDBOX', 'False') == 'True'
META_WHATSAPP_ACCESS_TOKEN = os.getenv('META_WHATSAPP_ACCESS_TOKEN', '')
META_WHATSAPP_PHONE_NUMBER_ID = os.getenv('META_WHATSAPP_PHONE_NUMBER_ID', '')
META_WHATSAPP_BUSINESS_ACCOUNT_ID = os.getenv('META_WHATSAPP_BUSINESS_ACCOUNT_ID', '')
META_WHATSAPP_TEST_TO = os.getenv('META_WHATSAPP_TEST_TO', '')
META_WHATSAPP_API_VERSION = os.getenv('META_WHATSAPP_API_VERSION', 'v25.0')
META_WHATSAPP_OTP_TEMPLATE = os.getenv('META_WHATSAPP_OTP_TEMPLATE', '')
META_WHATSAPP_TEMPLATE_LANGUAGE = os.getenv('META_WHATSAPP_TEMPLATE_LANGUAGE', 'es')
EMAIL_PROVIDER = os.getenv('EMAIL_PROVIDER', 'smtp').lower()
if EMAIL_PROVIDER not in ('smtp', 'brevo'):
    raise ImproperlyConfigured('EMAIL_PROVIDER debe ser smtp o brevo.')
EMAIL_BACKEND = os.getenv('EMAIL_BACKEND') or (
    'apps.workshop.brevo_backend.BrevoEmailBackend' if EMAIL_PROVIDER == 'brevo'
    else 'django.core.mail.backends.smtp.EmailBackend'
)
BREVO_API_KEY = os.getenv('BREVO_API_KEY', '')
EMAIL_HOST = os.getenv('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.getenv('EMAIL_PORT', '587'))
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = os.getenv('EMAIL_USE_TLS', 'True') == 'True'
EMAIL_USE_SSL = os.getenv('EMAIL_USE_SSL', 'False') == 'True'
EMAIL_TIMEOUT = 10
DEFAULT_FROM_EMAIL = os.getenv('DEFAULT_FROM_EMAIL', EMAIL_HOST_USER or 'noreply@localhost')
PUBLIC_PORTAL_URL = os.getenv('PUBLIC_PORTAL_URL', 'http://localhost:5173').rstrip('/')


# Static files (CSS, JavaScript, Images)

STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'


# CORS Configuration dinámico

cors_env = os.getenv('CORS_ALLOWED_ORIGINS', '')
if cors_env:
    CORS_ALLOWED_ORIGINS = [origin.strip() for origin in cors_env.split(',') if origin.strip()]
else:
    CORS_ALLOWED_ORIGINS = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]


# Django REST Framework

REST_FRAMEWORK = {
    'NUM_PROXIES': int(os.getenv('TRUSTED_PROXY_COUNT', '0')),
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
}


# Simple JWT Configuration

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=60),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'AUTH_HEADER_TYPES': ('Bearer',),
    # Actualiza User.last_login en cada login exitoso (viene en False por defecto
    # en la versión instalada de simplejwt).
    'UPDATE_LAST_LOGIN': True,
}

# Política temporal: correo obligatorio y acceso por email.
CLIENT_EMAIL_REQUIRED = os.getenv('CLIENT_EMAIL_REQUIRED', 'True') == 'True'
