import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Boxes,
  Clock3,
  PackageCheck,
  RefreshCw,
  Sparkles,
  Wrench,
} from 'lucide-react';
import { listAllItems, mensajeDeError } from '../api/inventory.js';
import {
  getDemandForecast,
  getWorkshopAnalytics,
  getWorkshopOverview,
  requestDemandForecast,
} from '../api/workshop.js';
import './MetricsDashboard.css';

const PERIODS = [
  ['today', 'Hoy'],
  ['week', 'Esta semana'],
  ['month', 'Este mes'],
  ['year', 'Este año'],
];

const DEFAULT_PERIOD = 'month';

const STATUS_LABELS = {
  pending: 'Pendientes',
  in_progress: 'En proceso',
  completed: 'Completadas',
  cancelled: 'Canceladas',
  other: 'Otras',
};

const numberFormat = new Intl.NumberFormat('es-CL');
const currencyFormat = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});
const dateTimeFormat = new Intl.DateTimeFormat('es-CL', {
  dateStyle: 'medium',
  timeStyle: 'short',
  timeZone: 'America/Santiago',
});

function number(value) {
  return numberFormat.format(Number(value) || 0);
}

function fechaHora(value) {
  const date = value ? new Date(value) : null;
  return date && !Number.isNaN(date.getTime()) ? dateTimeFormat.format(date) : '';
}

function MetricCard({ label, value, note, icon: Icon, tone = '' }) {
  return (
    <article className="metrics-kpi">
      <div className="metrics-kpi-top">
        <span>{label}</span>
        <span className={`metrics-kpi-icon ${tone}`}><Icon size={18} /></span>
      </div>
      <strong>{value}</strong>
      <p>{note}</p>
    </article>
  );
}

function errorMessage(error) {
  if (error?.response?.status === 403) {
    return 'Tu cuenta no tiene permisos para consultar estas métricas.';
  }

  return mensajeDeError(error);
}

export default function MetricsDashboard({ isAdmin, showOrders, showSupplies }) {
  const [period, setPeriod] = useState(DEFAULT_PERIOD);
  const [analytics, setAnalytics] = useState(null);
  const [forecastSnapshot, setForecastSnapshot] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [generatingForecast, setGeneratingForecast] = useState(false);
  const [forecastError, setForecastError] = useState('');
  const [error, setError] = useState('');

  const latestLoad = useRef(0);
  const latestGeneration = useRef(0);

  const load = useCallback((selectedPeriod, {
    includeForecast = true,
    refreshExpired = false,
  } = {}) => {
    const request = ++latestLoad.current;
    const getMetrics = isAdmin ? getWorkshopAnalytics : getWorkshopOverview;
    const loadForecast = isAdmin && includeForecast && selectedPeriod !== 'today';
    const requests = [
      getMetrics({ period: selectedPeriod }),
      isAdmin ? listAllItems() : null,
      loadForecast ? getDemandForecast({
        period: selectedPeriod,
        refresh_expired: String(refreshExpired),
      }) : null,
    ];

    Promise.allSettled(requests).then(([metricsResult, itemsResult, forecastResult]) => {
      if (request !== latestLoad.current) return;

      if (metricsResult.status === 'fulfilled') {
        setAnalytics(metricsResult.value);
      } else {
        setError(errorMessage(metricsResult.reason));
      }

      if (isAdmin) {
        if (itemsResult.status === 'fulfilled') {
          setItems(itemsResult.value);
        } else if (metricsResult.status === 'fulfilled') {
          setError(`No se pudo cargar el stock actual: ${errorMessage(itemsResult.reason)}`);
        }
      }

      if (loadForecast) {
        if (forecastResult.status === 'fulfilled') {
          setForecastSnapshot(forecastResult.value);
          setForecastError('');
        } else {
          setForecastError(errorMessage(forecastResult.reason));
        }
      }

      setLoading(false);
      setRefreshing(false);
    });
  }, [isAdmin]);

  useEffect(() => {
    let active = true;

    queueMicrotask(() => {
      if (active) load(DEFAULT_PERIOD, { refreshExpired: true });
    });

    return () => {
      active = false;
      latestLoad.current += 1;
      latestGeneration.current += 1;
    };
  }, [load]);

  function changePeriod(event) {
    const selectedPeriod = event.target.value;
    latestGeneration.current += 1;
    setPeriod(selectedPeriod);
    setLoading(true);
    setRefreshing(false);
    setGeneratingForecast(false);
    setForecastSnapshot(null);
    setForecastError('');
    setError('');
    load(selectedPeriod);
  }

  function refreshMetrics() {
    setRefreshing(true);
    setError('');
    load(period, { includeForecast: false });
  }

  async function generarProyeccion() {
    const request = ++latestGeneration.current;
    setGeneratingForecast(true);
    setForecastError('');

    try {
      const snapshot = await requestDemandForecast({ period });

      if (request === latestGeneration.current) {
        setForecastSnapshot(snapshot);
      }
    } catch (requestError) {
      if (request === latestGeneration.current) {
        setForecastError(errorMessage(requestError));
      }
    } finally {
      if (request === latestGeneration.current) {
        setGeneratingForecast(false);
      }
    }
  }

  const metrics = analytics?.metrics;
  const forecast = forecastSnapshot?.demand_forecast;
  const supplies = metrics?.supplies_summary;
  const usedParts = supplies?.top_consumed_parts || [];
  const lowStock = isAdmin
    ? items.filter((item) => Number(item.current_stock) <= Number(item.minimum_stock)).length
    : supplies?.low_stock_count;
  const bothBlocks = showOrders && showSupplies;

  const predictions = (forecast?.predictions || []).map((prediction) => {
    const matches = items.filter((candidate) => candidate.name === prediction.part_name);
    const item = matches.length === 1 ? matches[0] : null;
    const stock = Number(item?.current_stock ?? 0);
    const minimum = Number(item?.minimum_stock ?? 0);
    const demand = Number(prediction.estimated_demand) || 0;
    const purchase = Math.max(0, demand + minimum - stock);
    const risk = !item ? 'unknown' : stock <= demand ? 'critical' : stock <= minimum ? 'warning' : 'stable';

    return { ...prediction, stock, minimum, purchase, risk };
  });

  const statuses = metrics?.orders_by_status || {};
  const statusRows = Object.entries({ other: 0, ...statuses });
  const maxStatus = Math.max(1, ...statusRows.map(([, value]) => Number(value) || 0));
  const hasProjection = forecast?.has_sufficient_history === true;
  const forecastSource = forecast?.source === 'gemini_ai'
    ? 'Generado con Gemini'
    : 'Estimación estadística';
  const forecastLocked = Boolean(forecastSnapshot?.has_forecast && !forecastSnapshot.can_generate);
  const availableAt = fechaHora(forecastSnapshot?.expires_at);
  const forecastButtonLabel = generatingForecast
    ? 'Generando…'
    : forecastLocked
      ? availableAt ? `Disponible ${availableAt}` : 'Proyección vigente'
      : hasProjection ? 'Actualizar proyección' : 'Generar proyección';

  return (
    <section className={bothBlocks ? 'metrics-page' : 'metrics-page metrics-page-single'} aria-labelledby="metrics-title">
      <header className="admin-page-heading metrics-heading">
        <h1 id="metrics-title">Resumen del taller</h1>

        <div className="metrics-controls">
          <div className="metrics-period">
            <label htmlFor="metrics-period">Período</label>
            <select id="metrics-period" value={period} onChange={changePeriod}>
              {PERIODS.map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>
          <button
            type="button"
            className="metrics-refresh"
            onClick={refreshMetrics}
            disabled={refreshing || loading}
            aria-label="Actualizar métricas"
          >
            <RefreshCw size={16} className={refreshing ? 'metrics-spinning' : ''} />
            <span>Actualizar</span>
          </button>
        </div>
      </header>

      {error && (
        <div className="metrics-error" role="alert">
          <AlertTriangle size={18} />
          <span>{error}</span>
          <button type="button" onClick={refreshMetrics}>Reintentar</button>
        </div>
      )}

      <div className="metrics-kpis" aria-busy={loading}>
        {loading ? (
          Array.from({ length: bothBlocks ? 4 : 2 }, (_, index) => (
            <div key={index} className="metrics-kpi metrics-skeleton" />
          ))
        ) : (
          <>
            {showOrders && <>
              <MetricCard label="Órdenes del período" value={number(metrics?.total_orders)} note="Órdenes registradas" icon={Wrench} />
              <MetricCard label="En proceso" value={number(statuses.in_progress)} note="Actualmente en atención" icon={Activity} />
            </>}
            {showSupplies && <>
              <MetricCard label="Insumos consumidos" value={number(supplies?.total_items_consumed)} note="Unidades agregadas a órdenes" icon={Boxes} />
              <MetricCard label="Stock bajo" value={number(lowStock)} note="En o bajo el mínimo configurado" icon={AlertTriangle} tone={lowStock ? 'is-warning' : ''} />
            </>}
          </>
        )}
      </div>

      <div className="metrics-grid">
        <div className="metrics-overview">
          {showOrders && <section className="metrics-panel metrics-activity">
            <header className="metrics-panel-heading">
              <div>
                <span className="metrics-panel-icon"><BarChart3 size={18} /></span>
                <div>
                  <h2>Estado de órdenes</h2>
                  <p>Distribución del período seleccionado</p>
                </div>
              </div>
            </header>

            {loading ? (
              <div className="metrics-panel-loading"><span className="metrics-loader" />Cargando actividad…</div>
            ) : (
              <div className="metrics-status-list">
                {statusRows.map(([key, value]) => (
                  <div className="metrics-status-row" key={key}>
                    <div className="metrics-status-label">
                      <span>{STATUS_LABELS[key] || key}</span>
                      <strong>{number(value)}</strong>
                    </div>
                    <div className="metrics-track">
                      <span style={{ width: `${Math.max(0, (Number(value) || 0) / maxStatus * 100)}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="metrics-service-time">
              <Clock3 size={17} />
              <span>Tiempo promedio de servicio</span>
              <strong>
                {metrics?.average_service_time_hours == null
                  ? '—'
                  : `${number(metrics.average_service_time_hours)} h`}
              </strong>
            </div>
          </section>}

          {showSupplies && <section className="metrics-panel metrics-consumption">
            <header className="metrics-panel-heading">
              <div>
                <span className="metrics-panel-icon"><Boxes size={18} /></span>
                <div>
                  <h2>Insumos más utilizados</h2>
                  <p>Consumo registrado en órdenes de trabajo</p>
                </div>
              </div>
              <span className="metrics-count">{number(usedParts.length)} insumos</span>
            </header>

            {loading ? (
              <div className="metrics-panel-loading"><span className="metrics-loader" />Cargando consumo…</div>
            ) : usedParts.length === 0 ? (
              <div className="metrics-empty compact"><p>No hay consumos registrados para este período.</p></div>
            ) : (
              <div
                role="region"
                aria-label="Tabla de consumo de insumos"
                tabIndex={0}
                className="metrics-table-wrap admin-table-scroll"
              >
                <table>
                  <thead>
                    <tr><th>Insumo</th><th>Unidades consumidas</th>{isAdmin && <th>Costo registrado</th>}</tr>
                  </thead>
                  <tbody>
                    {usedParts.map((part) => (
                      <tr key={part.name}>
                        <td>{part.name}</td>
                        <td>{number(part.quantity)}</td>
                        {isAdmin && <td>{currencyFormat.format(part.total_cost)}</td>}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>}
        </div>

        {isAdmin && period !== 'today' && (
          <section className="metrics-panel metrics-forecast">
            <header className="metrics-panel-heading">
              <div>
                <span className="metrics-panel-icon is-ai"><Sparkles size={18} /></span>
                <div>
                  <h2>Proyección de demanda</h2>
                  <p>{period === 'week' ? 'Basada en los últimos 28 días de consumo' : 'Consumo estimado y reposición sugerida'}</p>
                </div>
              </div>

              <div className="metrics-forecast-actions">
                {hasProjection && (
                  <span className="metrics-source">
                    {forecast.source === 'gemini_ai' && <Sparkles size={13} />}
                    {forecastSource}
                  </span>
                )}
                <button
                  type="button"
                  className="metrics-generate"
                  onClick={generarProyeccion}
                  disabled={loading || generatingForecast || forecastLocked}
                >
                  {forecastLocked && <Clock3 size={14} />}
                  {forecastButtonLabel}
                </button>
              </div>
            </header>

            {forecastError && <div className="metrics-forecast-error" role="alert">{forecastError}</div>}

            {loading ? (
              <div className="metrics-panel-loading"><span className="metrics-loader" />Cargando proyección guardada…</div>
            ) : !forecastSnapshot?.has_forecast ? (
              <div className="metrics-empty">
                <span className="metrics-empty-icon"><PackageCheck size={20} /></span>
                <h3>Aún no se ha generado</h3>
                <p>La proyección se genera al pulsar el botón y se conserva durante siete días para este período.</p>
              </div>
            ) : !forecast?.has_sufficient_history ? (
              <div className="metrics-empty">
                <span className="metrics-empty-icon"><PackageCheck size={20} /></span>
                <h3>Historial en construcción</h3>
                <p>{forecast?.message || 'Aún no hay suficientes datos para generar una proyección.'}</p>
              </div>
            ) : predictions.length === 0 ? (
              <div className="metrics-empty">
                <span className="metrics-empty-icon"><PackageCheck size={20} /></span>
                <h3>Sin consumos proyectados</h3>
                <p>No se encontraron insumos con consumo en el período analizado.</p>
              </div>
            ) : (
              <div className="metrics-predictions">
                {predictions.map((prediction, index) => (
                  <article className={`metrics-prediction risk-${prediction.risk}`} key={`${prediction.part_name}-${index}`}>
                    <div className="metrics-prediction-main">
                      <span className="metrics-prediction-icon"><Boxes size={17} /></span>
                      <div>
                        <h3>{prediction.part_name}</h3>
                        <p>Consumo estimado <strong>{number(prediction.estimated_demand)} u.</strong></p>
                      </div>
                    </div>
                    <div className="metrics-prediction-stock">
                      <span>Stock actual</span>
                      <strong>{number(prediction.stock)} <small>/ mín. {number(prediction.minimum)}</small></strong>
                    </div>
                    <div className="metrics-recommendation">
                      <span className={`metrics-risk-badge risk-${prediction.risk}`}>
                        {prediction.risk === 'critical' ? 'Quiebre posible'
                          : prediction.risk === 'warning' ? 'Stock bajo'
                          : prediction.risk === 'unknown' ? 'Stock sin datos'
                          : 'Stock estable'}
                      </span>
                      <span>
                        {prediction.purchase > 0
                          ? `Sugerencia: reponer ${number(prediction.purchase)} u.`
                          : prediction.recommendation}
                      </span>
                    </div>
                  </article>
                ))}
              </div>
            )}

            {hasProjection && forecastSnapshot?.generated_at && (
              <p className="metrics-fallback-note">
                Generada el {fechaHora(forecastSnapshot.generated_at)}. Se conserva siete días.
              </p>
            )}
          </section>
        )}
      </div>

      {isAdmin && period !== 'today' && (
        <p className="metrics-footnote">
          Las proyecciones son orientativas y se calculan según el historial disponible y el stock registrado.
        </p>
      )}
    </section>
  );
}
