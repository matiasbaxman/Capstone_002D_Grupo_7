import ClientLookup from '../components/ClientLookup.jsx';
import { compressPhoto, photoSize } from '../utils/compressPhoto.js';
import { normalizeRut, formatRut, validRut } from '../utils/rutValidation.js';
import { normalizePlate, validPlate, formatPlate } from '../utils/plateValidation.js';
import { validContactEmail, mobileDigits, mobileContact } from '../utils/contactValidation.js';
import { formatKm } from '../utils/format.js';
import { useEffect, useRef, useState } from 'react';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast, notificationMessages } from '../components/notifications/useToast.js';
import './CheckIn.css';
import { randomId } from '../utils/randomId.js';

const steps = ['Cliente y vehículo', 'Ingreso y fotos', 'Confirmación'];
const MIN_CLIENT_SEARCH_MS = 600;
const empty = { firstName: '', lastName: '', rut: '', email: '', phone: '', notificationChannel: 'EMAIL', plate: '', brand: '', vehicleModel: '', year: '', color: '', odometer: '', fuel: '', spare: null, tools: null, notes: '', reportedSymptoms: '', additionalEquipment: [] };
function CameraIcon() { return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="M3 7h4l2-3h6l2 3h4v13H3Z" /><circle cx="12" cy="13" r="4" /></svg>; }

// Traduce la validación del backend (400) a un mensaje concreto. Cualquier otro
// fallo cae en el mensaje genérico para no filtrar detalles del servidor.
function parseCheckInError(err) {
  const data = err?.response?.data;
  if (err?.response?.status === 400 && data && typeof data === 'object') {
    const partes = Object.entries(data)
      .filter(([campo]) => campo !== 'detail' && campo !== 'non_field_errors')
      .map(([, valor]) => [].concat(valor).join(' '));
    if (partes.length) return partes.join(' · ');
    if (data.non_field_errors) return [].concat(data.non_field_errors).join(' ');
  }
  if (err?.response?.status === 403) return 'Tu rol no tiene permiso para registrar ingresos.';
  return 'No pudimos registrar el check-in. Tus datos se conservan; intenta nuevamente.';
}

// Receives the agreed API adapter later; no database writes or simulated success.
export default function CheckIn({ onSubmit, lookupClient, onNavigate }) {
  const [step, setStep] = useState(0);
  const [identificationStage, setIdentificationStage] = useState('client');
  const [intakeStage, setIntakeStage] = useState('condition');
  const [confirmMissing, setConfirmMissing] = useState(false);
  const [equipmentName, setEquipmentName] = useState('');
  const [equipmentError, setEquipmentError] = useState('');
  const [clientStatus, setClientStatus] = useState('idle');
  const [clientError, setClientError] = useState('');
  const [client, setClient] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [appointmentId, setAppointmentId] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const requestVersion = useRef(0);
  useEffect(() => () => { requestVersion.current++; }, []);
  function clearClient() {
    setAppointments([]); setAppointmentId('');
    setIdentificationStage('client');
    requestVersion.current++;
    setClientStatus('idle'); setClientError(''); setClient(null); setVehicles([]); setSelectedVehicle('');
    setForm((previous) => ({ ...previous, rut: '', firstName: '', lastName: '', email: '', phone: '', plate: '' }));
    setError('');
  }
  function returnToLookup() {
    clearClient();
    requestAnimationFrame(() => rutInput.current?.focus());
  }
  async function searchClient() {
    if (clientStatus === 'loading') return;
    if (!validRut(form.rut)) { setClientError('Ingresa un RUT válido, incluyendo el dígito verificador.'); return; }
    const version = ++requestVersion.current;
    setClientStatus('loading'); setClientError(''); setError('');
    const minimumLoading = new Promise((resolve) => setTimeout(resolve, MIN_CLIENT_SEARCH_MS));
    try {
      if (!lookupClient) throw new Error('unavailable');
      const result = await lookupClient(normalizeRut(form.rut));
      await minimumLoading;
      if (version !== requestVersion.current) return;
      if (!result || !Object.hasOwn(result, 'client')) throw new Error('invalid response');
      if (result.client === null) { setClientStatus('not-found'); return; }
      if (!result.client?.id || !result.client.firstName || !result.client.lastName) throw new Error('invalid client');
      setAppointments(result.appointments || []); setAppointmentId('');
      setClient(result.client); setVehicles(result.vehicles || []); setClientStatus('found');
      setForm((previous) => ({ ...previous, firstName: result.client.firstName, lastName: result.client.lastName, email: result.client.email || '', phone: mobileDigits(result.client.phone || ''), notificationChannel: 'EMAIL' }));
    } catch {
      await minimumLoading;
      if (version !== requestVersion.current) return;
      setClientStatus('error'); setClientError('No pudimos buscar al cliente. Intenta nuevamente. No se ha creado ningún registro.');
    }
  }
  const [form, setForm] = useState(empty);
  const [photos, setPhotos] = useState([]);
  const [preparingPhotos, setPreparingPhotos] = useState(false);
  const photoVersion = useRef(0);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [registrado, setRegistrado] = useState(null);
  const toast = useToast();
  const [discard, setDiscard] = useState(false);
  const urls = useRef(new Set());
  const heading = useRef(null);
  const rutInput = useRef(null);
  const firstNameInput = useRef(null);
  function beginClientRegistration() {
    setClient(null); setAppointments([]); setAppointmentId('');
    setClientStatus('new'); setError('');
    requestAnimationFrame(() => firstNameInput.current?.focus());
  }
  const dirty = Object.keys(empty).some((key) => form[key] !== empty[key]) || photos.length > 0 || preparingPhotos;
  useEffect(() => {
    const allocated = urls.current;
    const version = photoVersion;
    return () => { version.current++; allocated.forEach((url) => URL.revokeObjectURL(url)); };
  }, []);
  useEffect(() => {
    function warn(event) { if (dirty) { event.preventDefault(); event.returnValue = ''; } }
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);
  // El canal Correo solo es elegible con un correo válido; si el campo se
  // borra o queda incompleto, la preferencia vuelve a WhatsApp.

  const missingCondition = [!form.odometer.trim() && 'Kilometraje', !form.fuel && 'Combustible', (form.spare === null || form.tools === null || form.additionalEquipment.some(item => item.present === null)) && 'Elementos presentes', !form.notes.trim() && 'Observaciones de carrocería'].filter(Boolean);
  function addEquipment() {
    const name = equipmentName.trim();
    if (!name) { setEquipmentError('Escribe el nombre del elemento.'); return; }
    if (form.additionalEquipment.length >= 20) { setEquipmentError('Puedes agregar hasta 20 elementos.'); return; }
    if (['rueda de repuesto', 'gata y herramientas', ...form.additionalEquipment.map(item => item.name.toLocaleLowerCase('es'))].includes(name.toLocaleLowerCase('es'))) { setEquipmentError('Este elemento ya está en la lista.'); return; }
    setForm(previous => ({ ...previous, additionalEquipment: [...previous.additionalEquipment, { id: randomId(), name, present: null }] }));
    setEquipmentName(''); setEquipmentError(''); setConfirmMissing(false);
  }
  function change(event) {
    setConfirmMissing(false);
    const { name, type, value, checked } = event.target;
    setForm((previous) => {
      const nextValue = name === 'rut' ? normalizeRut(value)
        : name === 'plate' ? normalizePlate(value)
          : name === 'phone' ? mobileDigits(value)
            : type === 'checkbox' ? checked
              : value;
      const next = { ...previous, [name]: nextValue };
      return next;
    });
    setError('');
  }
  function move(next) {
    if (preparingPhotos) return;
    if (next > step && step === 0) {
      if (!['found', 'new'].includes(clientStatus)) { setError('Busca al cliente por RUT antes de continuar.'); return; }
      if (clientStatus === 'new') {
      if (!form.firstName.trim() || !form.lastName.trim()) { setError('Ingresa el nombre y apellido del cliente.'); return; }
      if (!validRut(form.rut)) { setError('Ingresa un RUT válido, incluyendo su dígito verificador.'); return; }
      if (!form.email.trim()) { setError('Ingresa el correo electrónico del cliente.'); return; }
      if (form.email.trim() && !validContactEmail(form.email)) { setError('Revisa el formato del correo electrónico.'); return; }
      if (form.phone && !/^\d{8}$/.test(form.phone)) { setError('Ingresa los 8 dígitos del celular después de +56 9.'); return; }
      }
      if (!form.email.trim() || !validContactEmail(form.email)) { setError('Ingresa un correo electrónico válido para el acceso del cliente.'); return; }
      if (identificationStage === 'client') {
        setIdentificationStage('vehicle'); setError('');
        requestAnimationFrame(() => heading.current?.focus());
        return;
      }
      if (!validPlate(form.plate)) { setError('Ingresa una patente de automóvil válida: 4 letras y 2 números, o 2 letras y 4 números.'); return; }
      // Marca, modelo y año solo aplican cuando el vehículo no viene del catálogo.
      if (!selectedVehicle) {
        if (!form.brand.trim() || !form.vehicleModel.trim()) { setError('Ingresa la marca y el modelo del vehículo.'); return; }
        if (!/^\d{4}$/.test(form.year.trim())) { setError('Ingresa el año del vehículo en formato AAAA.'); return; }
      }
    }
    if (next > step && step === 1 && form.odometer.trim() && !/^\d+$/.test(form.odometer)) { setError('Revisa el kilometraje: ingresa un número entero igual o mayor a cero.'); return; }
    if (next > step && step === 1 && intakeStage === 'condition') {
      if (equipmentName.trim()) { setEquipmentError('Agrega el elemento o borra su nombre antes de continuar.'); return; }
      if (missingCondition.length && !confirmMissing) { setConfirmMissing(true); setError(''); return; }
      setConfirmMissing(false);
      setIntakeStage('photos'); setError('');
      requestAnimationFrame(() => heading.current?.focus()); return;
    }
    if (next > step && step === 1 && !photos.length) { setError('Agrega al menos una fotografía del vehículo.'); return; }
    if (step === 0 && next === 1) setIntakeStage('condition');
    setError(''); setStep(next); requestAnimationFrame(() => heading.current?.focus());
  }
  function goBack() {
    if (step === 1 && intakeStage === 'photos') {
      setIntakeStage('condition'); setError('');
      requestAnimationFrame(() => heading.current?.focus());
    } else if (step > 0) {
      move(step - 1);
    } else if (identificationStage === 'vehicle') {
      setIdentificationStage('client'); setError('');
      requestAnimationFrame(() => heading.current?.focus());
    } else if (clientStatus === 'new') {
      setClientStatus('not-found'); setError('');
      requestAnimationFrame(() => heading.current?.focus());
    } else {
      returnToLookup();
    }
  }
  async function addPhotos(event) {
    if (preparingPhotos) return;
    const selected = [...event.target.files];
    const files = selected.slice(0, Math.max(0, 10 - photos.length));
    event.target.value = '';
    if (!files.length) { if (selected.length) setError('Puedes agregar hasta 10 fotografías por ingreso.'); return; }
    const version = ++photoVersion.current;
    setPreparingPhotos(true); setError('');
    const prepared = [];
    let rejected = selected.length - files.length;
    // Sequential processing limits memory consumption on mobile devices.
    for (const original of files) {
      try {
        const file = await compressPhoto(original);
        if (version !== photoVersion.current) return;
        prepared.push({ id: randomId(), file, originalSize: original.size });
      } catch { rejected++; }
      if (version !== photoVersion.current) return;
    }
    setPhotos((previous) => [...previous, ...prepared.map((photo) => {
      const url = URL.createObjectURL(photo.file); urls.current.add(url); return { ...photo, url };
    })]);
    setError(rejected ? `No pudimos agregar ${rejected} fotografía(s). El límite es 10 fotos por ingreso, en JPG, PNG o WebP de hasta 10 MB cada una.` : '');
    setPreparingPhotos(false);
  }
  function remove(photo) { URL.revokeObjectURL(photo.url); urls.current.delete(photo.url); setPhotos((previous) => previous.filter((item) => item.id !== photo.id)); }
  function reset() { photoVersion.current++; setPreparingPhotos(false); photos.forEach((photo) => { URL.revokeObjectURL(photo.url); urls.current.delete(photo.url); }); setPhotos([]); setEquipmentName(''); setEquipmentError(''); clearClient(); setForm(empty); setStep(0); setIntakeStage('condition'); setConfirmMissing(false); setError(''); setDiscard(false); }
  async function submit() {
    if (busy) return;
    if (!onSubmit) { setError('No pudimos registrar el check-in. El servicio no está disponible. Tus datos se conservan; intenta más tarde.'); return; }
    setBusy(true); setError('');
    try {
      const creado = await onSubmit({ ...form, clientId: client?.id || null, appointmentId: appointmentId || null, clientLookupVerified: true, vehicleId: selectedVehicle || null, firstName: form.firstName.trim(), lastName: form.lastName.trim(), rut: normalizeRut(form.rut), email: form.email.trim(), phone: mobileContact(form.phone), plate: normalizePlate(form.plate), notificationChannel: form.notificationChannel, brand: form.brand.trim(), vehicleModel: form.vehicleModel.trim(), year: form.year.trim() ? Number(form.year.trim()) : null, color: form.color.trim(), odometer: form.odometer.trim() ? Number(form.odometer) : null, photos: photos.map((photo) => photo.file) });
      // El 201 trae la OT creada; se confirma con el folio y se limpia el
      // formulario para que el siguiente ingreso parta de cero.
      const { id, folio_number: folio } = creado?.work_order ?? {};
      setRegistrado({ folio: folio ?? null, plate: normalizePlate(form.plate) });
      reset();
      toast?.success(notificationMessages.checkInCreated, {
        icon: 'checkin',
        action: id ? {
          label: 'Ver orden de trabajo',
          href: '/dashboard/ordenes/' + encodeURIComponent(id),
          onNavigate,
        } : undefined,
        description: folio ? `Orden de trabajo N.° ${folio} creada.` : 'La orden de trabajo fue creada.',
      });
    }
    catch (submitError) { setError(parseCheckInError(submitError)); }
    finally { setBusy(false); }
  }
  const lookingUpClient = step === 0 && identificationStage === 'client';
  const clientNotFound = lookingUpClient && clientStatus === 'not-found';
  const showActions = !lookingUpClient || ['found', 'new', 'not-found'].includes(clientStatus);
  const showClear = !lookingUpClient || clientStatus === 'new';
  let nextLabel = 'Continuar con este vehículo';
  if (lookingUpClient) {
    nextLabel = { 'not-found': 'Ingresar cliente al sistema', found: 'Usar este cliente', new: 'Continuar al vehículo' }[clientStatus];
  } else if (step === 1) {
    nextLabel = intakeStage === 'photos' ? 'Revisar orden' : confirmMissing ? 'Confirmar y seguir a fotos' : 'Continuar a fotografías';
  } else if (step === 2) {
    nextLabel = busy ? 'Creando orden…' : 'Crear orden de trabajo';
  }
  function advance() {
    if (clientNotFound) beginClientRegistration();
    else if (step === 2) submit();
    else move(step + 1);
  }

  return <section className="checkin">
    <header className="inventory-heading"><div><h1>Nueva orden</h1><p>Registra la recepción del vehículo en tres pasos.</p></div><span className="checkin-progress-label">Paso {step + 1} de {steps.length}</span></header>
    <ol className="checkin-steps" aria-label="Progreso de la nueva orden">{steps.map((label, index) => <li key={label} className={index === step ? 'is-current' : index < step ? 'is-complete' : ''} aria-current={index === step ? 'step' : undefined}><span>{index < step ? '✓' : index + 1}</span><strong>{label}</strong></li>)}</ol>
    <div className="checkin-grid"><div className={`checkin-card${step === 0 ? ' checkin-card--identification' : ''}`}>
      {step > 0 && <header><p className="checkin-eyebrow">RECEPCIÓN DEL VEHÍCULO</p><div className="checkin-card-title">{step === 0 && <span className="checkin-section-number" aria-hidden="true">01</span>}<h2 ref={heading} tabIndex={-1}>{step === 1 ? intakeStage === 'condition' ? 'Condición de ingreso' : 'Fotografías del vehículo' : steps[step]}</h2></div><p>{step === 1 ? intakeStage === 'condition' ? 'Registra cómo llega el vehículo al taller.' : 'Agrega una vista general y cualquier daño visible.' : 'Una última mirada antes de crear la orden.'}</p></header>}
      <div className="checkin-fields">
        {step === 1 && intakeStage === 'condition' && (
          <label>
            <span>Motivo de ingreso (opcional)</span>
            <textarea
              name="reportedSymptoms"
              value={form.reportedSymptoms}
              onChange={change}
              rows={3}
              maxLength={1000}
              placeholder="Ej. El vehículo vibra al frenar."
              aria-describedby="checkin-symptoms-help"
            />
            <small id="checkin-symptoms-help" className="checkin-help">
              Describe solo los síntomas del vehículo para la sugerencia de diagnóstico. Omite datos personales y patente.
            </small>
          </label>
        )}
        {step === 0 && <h2 className="sr-only" ref={heading} tabIndex={-1}>{identificationStage === 'vehicle' ? 'Vehículo' : 'Cliente'}</h2>}
        {lookingUpClient && <ClientLookup rut={form.rut} rutInput={rutInput} email={form.email} onEmailChange={change} status={clientStatus} client={client} vehicles={vehicles} error={clientError} onRutChange={(event) => { change(event); setClientError(''); setClientStatus('idle'); }} onSearch={searchClient}><div className="checkin-field-row"><label><span>Nombre <span aria-hidden="true">*</span></span><input ref={firstNameInput} name="firstName" autoComplete="given-name" value={form.firstName} onChange={change} placeholder="Ej: Camila" maxLength={100} required /></label><label><span>Apellido <span aria-hidden="true">*</span></span><input name="lastName" autoComplete="family-name" value={form.lastName} onChange={change} placeholder="Ej: González" maxLength={100} required /></label></div><div className="checkin-field-row"><label>Correo electrónico (obligatorio)<input name="email" type="email" required autoComplete="email" value={form.email} onChange={change} placeholder="Ej: camila@correo.cl" maxLength={255} aria-describedby="client-contact-help" /></label><label><span>Teléfono / WhatsApp (opcional)</span><span className="checkin-phone"><span className="checkin-phone-prefix" aria-hidden="true">+56 9</span><input name="phone" type="tel" maxLength={8} onPaste={(event) => { event.preventDefault(); const digits = mobileDigits(event.clipboardData.getData('text')); setForm((previous) => ({ ...previous, phone: digits })); setError(''); }} inputMode="numeric" autoComplete="tel-national" value={form.phone} onChange={change} placeholder="12345678" aria-label="Teléfono móvil, prefijo +56 9, ocho dígitos" aria-describedby="client-phone-help client-contact-help" /></span><small id="client-phone-help">Escribe 8 números. El +56 9 ya está incluido.</small></label></div><p id="client-contact-help" className="checkin-help">El correo es obligatorio para recibir códigos e instrucciones de acceso. El teléfono / WhatsApp es opcional.</p></ClientLookup>}
        {step === 0 && identificationStage === 'vehicle' && <section className="checkin-vehicle-card">{client && <label>Cita asociada<select value={appointmentId} onChange={event => { const id = event.target.value; setAppointmentId(id); const cita = appointments.find(item => String(item.id) === id); if (cita?.vehicle_id) { setSelectedVehicle(String(cita.vehicle_id)); const vehicle = vehicles.find(item => String(item.id) === String(cita.vehicle_id)); if (vehicle) setForm(current => ({ ...current, plate: normalizePlate(vehicle.plate) })); } }}><option value="">Ingreso sin cita</option>{appointments.map(cita => <option key={cita.id} value={cita.id}>{new Date(cita.scheduled_date).toLocaleString('es-CL')} · {cita.service__name || 'Evaluación general'}</option>)}</select><small>Solo citas aceptadas y sin orden asociada.</small></label>}<header className="vehicle-card-heading"><h3>¿Qué vehículo ingresa?</h3><p>{client ? `Selecciona o agrega el vehículo de ${client.firstName}.` : `Agrega el vehículo de ${form.firstName.trim() || 'este cliente'}.`}</p></header>{client && vehicles.length > 0 && <label>Vehículo registrado<select value={selectedVehicle} onChange={(event) => { const id = event.target.value; setSelectedVehicle(id); const vehicle = vehicles.find((item) => String(item.id) === id); setForm((previous) => ({ ...previous, plate: vehicle ? normalizePlate(vehicle.plate) : '' })); setError(''); }}><option value="">Ingresar otro vehículo</option>{vehicles.map((vehicle) => <option key={vehicle.id} value={String(vehicle.id)}>{formatPlate(vehicle.plate)}{vehicle.label ? ` · ${vehicle.label}` : ''}</option>)}</select></label>}{!vehicles.length && <p className="vehicle-new-notice">Este cliente aún no tiene vehículos asociados. Ingresa los datos para agregar uno.</p>}<label><span>Patente <span className="client-required" aria-hidden="true">*</span></span><input name="plate" readOnly={Boolean(selectedVehicle)} value={form.plate} onChange={change} placeholder="Ej: BCDF12" autoCapitalize="characters" maxLength={6} autoComplete="off" spellCheck={false} aria-describedby="plate-format-help" onPaste={(event) => { event.preventDefault(); setForm((previous) => ({ ...previous, plate: normalizePlate(event.clipboardData.getData('text')) })); setError(''); }} /></label><p id="plate-format-help" className="checkin-help">Sin espacios ni guiones. Ej: BCDF12 o AB1234.</p>{!selectedVehicle && <div className="checkin-field-row"><label><span>Marca <span className="client-required" aria-hidden="true">*</span></span><input name="brand" value={form.brand} onChange={change} placeholder="Ej: Toyota" maxLength={50} required /></label><label><span>Modelo <span className="client-required" aria-hidden="true">*</span></span><input name="vehicleModel" value={form.vehicleModel} onChange={change} placeholder="Ej: Hilux" maxLength={50} required /></label></div>}{!selectedVehicle && <div className="checkin-field-row"><label><span>Año <span className="client-required" aria-hidden="true">*</span></span><input name="year" type="number" inputMode="numeric" min="1900" max="2100" step="1" value={form.year} onChange={change} placeholder="Ej: 2021" required /></label><label>Color<input name="color" value={form.color} onChange={change} placeholder="Ej: Blanco" maxLength={30} /></label></div>}</section>}
        {step === 1 && intakeStage === 'condition' && <><p className="checkin-recommendation-help"><span className="checkin-recommended" aria-hidden="true">*</span> Recomendado para respaldar la condición del vehículo. Puedes continuar sin completarlo.</p><div className="checkin-field-row"><label><span>Kilometraje (km) <span className="checkin-recommended" aria-hidden="true">*</span></span><input name="odometer" type="number" inputMode="numeric" min="0" step="1" value={form.odometer} onChange={change} placeholder="Ej: 85000" /></label><fieldset className="checkin-fuel"><legend>Combustible <span className="checkin-recommended" aria-hidden="true">*</span></legend><div className="checkin-fuel-options">{['Vacío', '1/4', '1/2', '3/4', 'Lleno'].map((value) => <button type="button" key={value} aria-pressed={form.fuel === value} onClick={() => { setForm((previous) => ({ ...previous, fuel: value })); setConfirmMissing(false); setError(''); }}>{value}</button>)}</div></fieldset></div><fieldset className="checkin-equipment"><legend>Elementos presentes <span className="checkin-recommended" aria-hidden="true">*</span></legend>{[['spare', 'Rueda de repuesto'], ['tools', 'Gata y herramientas']].map(([name, label]) => <div className="checkin-equipment-row" key={name}><span>{label}</span><div role="group" aria-label={label}>{[[true, 'Sí'], [false, 'No'], [null, 'Sin revisar']].map(([value, text]) => <button type="button" key={text} aria-pressed={form[name] === value} onClick={() => { setForm(previous => ({ ...previous, [name]: value })); setConfirmMissing(false); setError(''); }}>{text}</button>)}</div></div>)}{form.additionalEquipment.map(item => <div className="checkin-equipment-row" key={item.id}><div className="checkin-equipment-title"><span>{item.name}</span><button type="button" className="equipment-remove" aria-label={`Quitar ${item.name}`} onClick={() => { setForm(previous => ({ ...previous, additionalEquipment: previous.additionalEquipment.filter(current => current.id !== item.id) })); setConfirmMissing(false); }}>×</button></div><div role="group" aria-label={item.name}>{[[true, 'Sí'], [false, 'No'], [null, 'Sin revisar']].map(([value, text]) => <button type="button" key={text} aria-pressed={item.present === value} onClick={() => { setForm(previous => ({ ...previous, additionalEquipment: previous.additionalEquipment.map(current => current.id === item.id ? { ...current, present: value } : current) })); setConfirmMissing(false); }}>{text}</button>)}</div></div>)}<div className="equipment-add"><label htmlFor="equipment-name">Otro elemento</label><div><input id="equipment-name" value={equipmentName} onChange={event => { setEquipmentName(event.target.value); setEquipmentError(''); }} maxLength={80} placeholder="Ej: Extintor, triángulos…" aria-invalid={Boolean(equipmentError)} aria-describedby={equipmentError ? 'equipment-error' : undefined} onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); addEquipment(); } }} /><button type="button" onClick={addEquipment} disabled={form.additionalEquipment.length >= 20}>+ Agregar elemento</button></div>{equipmentError && <p id="equipment-error" className="checkin-error" role="alert">{equipmentError}</p>}</div></fieldset><label><span>Observaciones de carrocería <span className="checkin-recommended" aria-hidden="true">*</span></span><textarea name="notes" rows="4" value={form.notes} onChange={change} placeholder="Ej: Rayón en la puerta delantera derecha." /></label></>}
        {step === 1 && intakeStage === 'photos' && <><div className="checkin-photo-actions"><label className="checkin-upload"><CameraIcon /><strong>Tomar fotografía</strong><span>Usa la cámara del dispositivo</span><input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" capture="environment" disabled={preparingPhotos} onChange={addPhotos} /></label><label className="checkin-upload"><CameraIcon /><strong>Seleccionar fotografías</strong><span>Elige imágenes de tu galería</span><input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={preparingPhotos} onChange={addPhotos} /></label></div><p className="checkin-help">JPG, PNG o WebP · Hasta 10 MB por fotografía</p><p className="checkin-help">Las fotos se optimizan automáticamente antes de enviarlas.</p>{preparingPhotos && <p className="checkin-photo-processing" role="status"><span aria-hidden="true" />Preparando fotografías…</p>}<div className="checkin-photo-grid">{photos.map((photo, index) => <figure key={photo.id}><img src={photo.url} alt={`Fotografía de ingreso ${index + 1}`} /><button type="button" onClick={() => remove(photo)} aria-label={`Quitar fotografía ${index + 1}`}>×</button><figcaption>Foto {index + 1}<small>{photoSize(photo.file.size)}{photo.file.size < photo.originalSize ? ` · ${Math.round((1 - photo.file.size / photo.originalSize) * 100)}% menos peso` : " · Lista para enviar"}</small></figcaption></figure>)}</div>{!photos.length && <p className="checkin-photo-empty">Las fotografías que agregues aparecerán aquí.</p>}</>}
        {step === 2 && <><div className="checkin-confirmation-note"><span aria-hidden="true">✓</span><div><h3>Todo listo para recibir el vehículo</h3><p>Revisa los datos. La orden se creará al confirmar.</p></div></div><div className="checkin-review-action"><h3>Datos de la recepción</h3><button type="button" onClick={() => move(0)}>Editar</button></div><dl className="checkin-review">{[['Cita asociada', appointmentId ? new Date(appointments.find(item => String(item.id) === appointmentId)?.scheduled_date).toLocaleString('es-CL') : 'Ingreso sin cita'], ['Cliente', form.firstName.trim() + ' ' + form.lastName.trim()], ['RUT', formatRut(form.rut)], ['Correo electrónico', form.email.trim() || 'No indicado'], ['Teléfono', mobileContact(form.phone) || 'No indicado'], ['Canal preferido', form.notificationChannel === 'EMAIL' ? 'Correo Electrónico' : 'WhatsApp'], ['Patente', formatPlate(form.plate)], ...(!selectedVehicle ? [['Marca', form.brand || 'No indicada'], ['Modelo', form.vehicleModel || 'No indicado'], ['Año', form.year || 'No indicado'], ['Color', form.color || 'No indicado']] : []), ['Odómetro', form.odometer.trim() ? formatKm(form.odometer) : 'No registrado'], ['Combustible', form.fuel || 'No registrado'], ['Rueda de repuesto', form.spare === null ? 'Sin revisar' : form.spare ? 'Presente' : 'No presente'], ['Gata y herramientas', form.tools === null ? 'Sin revisar' : form.tools ? 'Presentes' : 'No presentes'], ...form.additionalEquipment.map(item => [item.name, item.present === null ? 'Sin revisar' : item.present ? 'Presente' : 'No presente']), ['Motivo de ingreso', form.reportedSymptoms.trim() || 'No registrado'], ['Observaciones', form.notes || 'No registradas']].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="checkin-review-action"><h3>Fotografías de ingreso ({photos.length})</h3><button type="button" onClick={() => move(1)}>Editar ingreso</button></div><div className="checkin-photo-grid">{photos.map((photo, index) => <img key={photo.id} src={photo.url} alt={`Fotografía de ingreso ${index + 1}`} />)}</div>{!photos.length && <p className="checkin-help">No se han agregado fotografías.</p>}</>}
        {error && <p className="checkin-error" role="alert">{error}</p>}
      </div>
      {showActions && <footer className="checkin-footer">
        {step === 1 && intakeStage === 'condition' && confirmMissing && <div className="checkin-missing-note" role="status"><strong>Continuarás sin registrar:</strong><ul>{missingCondition.map(label => <li key={label}>{label}</li>)}</ul><p>Estos datos quedarán como no registrados en la orden.</p></div>}
        <button type="button" className="checkin-back" disabled={busy || preparingPhotos} onClick={clientNotFound ? returnToLookup : goBack}>
          {clientNotFound ? 'Buscar por otro RUT' : 'Volver'}
        </button>
        {showClear && <button type="button" className="checkin-clear" disabled={busy || preparingPhotos} onClick={() => setDiscard(true)}>Limpiar</button>}
        <button type="button" className="checkin-next" disabled={busy || preparingPhotos} onClick={advance}>
          {nextLabel}{step < 2 && ' →'}
        </button>
      </footer>}
    </div><aside className={`checkin-summary${step < 2 ? ' checkin-summary--hidden' : ''}`}><p className="checkin-eyebrow">INGRESO AL TALLER</p><h2>{formatPlate(form.plate) || 'Vehículo por identificar'}</h2><p>Nuevo registro de recepción</p><hr /><dl><div><dt>Cliente</dt><dd>{`${form.firstName.trim()} ${form.lastName.trim()}`.trim() || 'Por registrar'}</dd></div><div><dt>Odómetro</dt><dd>{form.odometer ? formatKm(form.odometer) : 'Por registrar'}</dd></div><div><dt>Fotografías</dt><dd>{photos.length} agregadas</dd></div></dl><p className="checkin-tip">Fotografía las vistas generales y cualquier daño visible antes de comenzar el trabajo.</p></aside></div>
    {registrado && <div className="checkin-success" role="status"><div><h2>Orden de trabajo creada</h2><p>La orden de trabajo{registrado.folio ? ` N.° ${registrado.folio}` : ''} quedó creada{registrado.plate ? ` para el vehículo ${formatPlate(registrado.plate)}` : ''}. Ya puedes gestionarla desde el taller.</p></div><button type="button" onClick={() => setRegistrado(null)}>Crear otra orden</button></div>}
    {discard && <ConfirmDialog title="¿Descartar los cambios?" confirmLabel="Descartar" variant="danger" onCancel={() => setDiscard(false)} onConfirm={reset}>Se eliminarán los datos y fotografías de este formulario.</ConfirmDialog>}
  </section>;
}
