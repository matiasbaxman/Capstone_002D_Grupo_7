import CodeVerificationDialog from '../components/CodeVerificationDialog.jsx';
import { getClientSession, getClientAccount } from '../api/clientAuth.js';
import { useEffect, useMemo, useState } from 'react';
import { createPublicAppointment, getAppointmentAvailability, getPublicServices, requestBookingVerification } from '../api/appointments.js';
import { validRut, formatRut } from '../utils/rutValidation.js';
import { validContactEmail, mobileContact } from '../utils/contactValidation.js';
import { formatPhone } from '../utils/rut.js';
import './PublicPortal.css';
import './BookingPage.css';

const steps = ['Servicio', 'Fecha y hora', 'Tus datos', 'Confirmación'];
const generalService = {
  id: null,
  name: 'Evaluación general',
  description: 'Elige esta opción si aún no sabes qué servicio necesita tu vehículo.',
};
const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Santiago' });
const textInput = 'w-full min-w-0 rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-(--portal-accent) focus:ring-2 focus:ring-neutral-200';

function apiError(error) {
  const data = error.response?.data;
  if (typeof data === 'string') return data;
  if (data && typeof data === 'object') return Object.values(data).flat(Infinity).join(' ');
  return 'No pudimos conectar con el servicio. Revisa tu conexión e inténtalo nuevamente.';
}

function Field({ id, label, error, children }) {
  return <div className="space-y-1.5 text-sm font-semibold text-slate-700">
    <label htmlFor={id} className="block">{label}</label>
    {children}
    {error && <p id={id + '-error'} className="text-xs font-medium text-rose-700">{error}</p>}
  </div>;
}

const nameIsValid = (value) => value.trim().length <= 100 && /\p{L}/u.test(value) && !/\p{Nd}/u.test(value);
const rutIsValid = (value) => /^[1-9][0-9]{6,7}[0-9kK]$/.test(value.replace(/[.\-\s]/g, '')) && validRut(value);
const phoneDigits = (value) => value.replace(/[\s-]/g, '').replace(/^\+569(?=[0-9]{8}$)/, '');
const phoneInputValue = (value) => value.replace(/^([0-9]{4})(?=[0-9])/, '$1 ');

const contactFields = [
  { name: 'rut', label: 'RUT', autoComplete: 'off', maxLength: 12, placeholder: '12.345.678-5' },
  { name: 'first_name', label: 'Nombre', autoComplete: 'given-name', maxLength: 100 },
  { name: 'last_name', label: 'Apellido', autoComplete: 'family-name', maxLength: 100 },
  { name: 'phone', label: 'Teléfono', type: 'tel', autoComplete: 'tel-local', placeholder: '1234 5678' },
  { name: 'email', label: 'Correo electrónico', type: 'email', autoComplete: 'email', maxLength: 254 },
];

export default function BookingPage() {
  const [customer, setCustomer] = useState(null);
  const [loadingAccount, setLoadingAccount] = useState(() => Boolean(getClientSession()));
  const [accountError, setAccountError] = useState(false);
  const [step, setStep] = useState(0);
  const [services, setServices] = useState([]);
  const [service, setService] = useState(null);
  const [date, setDate] = useState('');
  const [slots, setSlots] = useState([]);
  const [slot, setSlot] = useState(null);
  const [loadingServices, setLoadingServices] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [showContactErrors, setShowContactErrors] = useState(false);
  const [booking, setBooking] = useState(null);
  const [verification, setVerification] = useState(null);
  const [code, setCode] = useState('');
  const [codeOpen, setCodeOpen] = useState(false);
  const [form, setForm] = useState({ rut: '', first_name: '', last_name: '', phone: '', email: '', notification_channel: 'EMAIL' });

  useEffect(() => {
    if (!getClientSession()) return;
    let alive = true;
    getClientAccount().then(data => {
      if (!alive) return;
      setCustomer(data);
      const { rut, first_name, last_name, phone, email } = data.client;
      const storedPhone = phone?.replaceAll(' ', '') ?? '';
      setForm(current => ({
        ...current, rut: rut ?? '', first_name: first_name ?? '', last_name: last_name ?? '',
        phone: /^\+569[0-9]{8}$/.test(storedPhone) ? storedPhone.slice(4) : '', email: email ?? '',
      }));
    }).catch(() => { if (alive) { setAccountError(true); setError('No pudimos recuperar tus datos. Inicia sesión nuevamente antes de agendar.'); } })
      .finally(() => { if (alive) setLoadingAccount(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    let alive = true;
    getPublicServices().then((rows) => { if (alive) setServices(rows); })
      .catch((err) => { if (alive) setError(apiError(err)); })
      .finally(() => { if (alive) setLoadingServices(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!date) return undefined;
    let alive = true;
    getAppointmentAvailability(date).then((data) => { if (alive) setSlots(data.slots || []); })
      .catch((err) => { if (alive) { setSlots([]); setError(apiError(err)); } })
      .finally(() => { if (alive) setLoadingSlots(false); });
    return () => { alive = false; };
  }, [date]);

  const errors = useMemo(() => {
    const result = {};
    if (!rutIsValid(form.rut)) result.rut = 'Ingresa un RUT válido.';
    if (!nameIsValid(form.first_name)) result.first_name = 'Ingresa un nombre válido.';
    if (!nameIsValid(form.last_name)) result.last_name = 'Ingresa un apellido válido.';
    if (!/^[0-9]{8}$/.test(form.phone)) result.phone = 'Ingresa los 8 dígitos de tu celular.';
    if (!validContactEmail(form.email)) result.email = 'Ingresa un correo electrónico válido.';
    return result;
  }, [form]);

  function update(key, value) { setVerification(null); setCode(''); setForm((current) => ({ ...current, [key]: value })); }
  function toggleService(item) {
    setService(current => current?.id === item.id ? null : item);
    setVerification(null);
    setCode('');
    setError('');
  }

  function continueStep() {
    setError('');
    if (loadingAccount || accountError) { setError('Espera a que se cargue tu cuenta o vuelve a iniciar sesión.'); return; }
    if (step === 0 && !service) return setError('Selecciona un servicio para continuar.');
    if (step === 1 && (!date || !slot)) return setError('Selecciona una fecha y un horario disponible.');
    if (step === 2 && Object.keys(errors).length) {
      setShowContactErrors(true);
      if (!customer) setError('Revisa los campos indicados antes de continuar.');
      return;
    }
    setStep((current) => Math.min(3, current + 1));
  }

  async function confirmBooking(resend = false) {
    if (submitting || loadingAccount || accountError) return;
    if (!slot || !service || Object.keys(errors).length) { setError('Revisa los datos de tu solicitud antes de confirmar.'); return; }
    setSubmitting(true); setError('');
    try {
      const payload = {
        rut: form.rut, first_name: form.first_name.trim(), last_name: form.last_name.trim(),
        phone: mobileContact(form.phone), email: form.email.trim(),
        notification_channel: form.notification_channel, service: service?.id ?? null,
        scheduled_date: slot.start,
      };
      if (customer && !getClientSession()) { setError('Tu sesión expiró. Inicia sesión nuevamente.'); return; }
      if (customer?.appointments?.length > 0) {
        setBooking(await createPublicAppointment(payload)); return;
      }
      if (!verification || resend) {
        setVerification(await requestBookingVerification(payload));
        setCode(''); setCodeOpen(true);
        return;
      }
      if (!/^\d{6}$/.test(code)) { setError('Ingresa los seis dígitos del código recibido.'); return; }
      const result = await createPublicAppointment({ ...payload, verification_id: verification.verification_id, code });
      setBooking(result);
    } catch (err) { setError(apiError(err)); }
    finally { setSubmitting(false); }
  }

  const formattedDate = date ? new Intl.DateTimeFormat('es-CL', { dateStyle: 'full', timeZone: 'America/Santiago' }).format(new Date(`${date}T12:00:00`)) : '';
  const selectedTime = slot ? new Intl.DateTimeFormat('es-CL', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Santiago' }).format(new Date(slot.start)) : '';

  if (booking) return <main className="portal-page booking-page"><section className="portal-card mx-auto max-w-xl p-7 text-center sm:p-12"><div className="mx-auto mb-5 grid size-16 place-items-center rounded-full bg-neutral-100 text-3xl text-(--portal-accent)">✓</div><p className="text-sm font-bold uppercase tracking-[.2em] text-(--portal-accent)">Agendamiento recibido</p><h1 className="portal-title mt-3">¡Gracias, {form.first_name}!</h1><p className="mt-3 text-slate-600">Tu solicitud quedó registrada. Te contactaremos para confirmar los detalles. Si es tu primer registro, recibirás las instrucciones de acceso a tu cuenta por correo electrónico.</p><div className="mt-7 rounded-2xl bg-slate-50 p-5 text-left text-sm text-slate-700"><p><b>Reserva:</b> {booking.id}</p><p className="mt-2"><b>Servicio:</b> {service?.name || 'Evaluación general'}</p><p className="mt-2"><b>Fecha:</b> {formattedDate}, {selectedTime}</p><p className="mt-2"><b>Estado:</b> {booking.status}</p></div><a href="/" className="portal-button portal-button-primary mt-7">Volver al inicio</a></section></main>;

  return <main className={`portal-page booking-page${step === 0 ? ' booking-page--service' : ''}`}><div className="portal-container portal-container-form"><section className="portal-card portal-card-form" aria-labelledby="booking-title"><header className="portal-form-heading"><h1 id="booking-title">Reserva tu hora</h1><p>Cuéntanos qué necesita tu vehículo. Nuestro equipo te contactará para confirmar.</p></header><div className="portal-form-content"><ol className="booking-progress mb-6 grid grid-cols-2 gap-2 sm:mb-8 sm:grid-cols-4" aria-label="Progreso de reserva">{steps.map((name, index) => <li key={name} className="min-w-0" aria-current={index === step ? 'step' : undefined}><div className={`h-1.5 rounded-full ${index <= step ? 'bg-(--portal-accent)' : 'bg-slate-100'}`} /><p className={`mt-2 text-[11px] font-semibold sm:text-sm ${index === step ? 'text-(--portal-accent)' : 'text-slate-400'}`}><span className="mr-1">{index + 1}.</span>{name}</p></li>)}</ol>
      {error && !codeOpen && <div role="alert" className="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{error}</div>}

      {step === 0 && (
        <section>
          <div className="booking-service-intro mb-5">
            <h2 className="text-xl font-bold">¿Qué servicio necesitas?</h2>
            <p className="mt-1 text-sm text-slate-500">Elige el motivo principal de tu visita. Puedes agendar una evaluación general.</p>
          </div>
          {loadingServices ? <p className="rounded-xl bg-slate-50 p-5 text-sm text-slate-500">Cargando servicios…</p> : (
            <div className="booking-service-grid grid gap-3 sm:grid-cols-2">
              {[generalService, ...services].map(item => (
                <button type="button" key={item.id ?? 'general'} onClick={() => toggleService(item)}
                  aria-pressed={service?.id === item.id}
                  className="booking-service flex flex-col rounded-2xl border border-slate-200 p-5 text-left transition">
                  <span className="flex w-full items-start justify-between gap-3">
                    <b className="text-base">{item.name}</b>
                    <span className="grid size-5 shrink-0 place-items-center rounded-full border border-slate-300 text-xs text-(--portal-accent)">{service?.id === item.id ? '✓' : ''}</span>
                  </span>
                  <span className="booking-service-description mt-2 block text-sm leading-relaxed text-slate-500">{item.description || 'Servicio de atención automotriz.'}</span>
                  {item.base_price != null && (
                    <span className="booking-service-price mt-4 text-xs font-semibold text-slate-600">
                      Desde ${Number(item.base_price).toLocaleString('es-CL')} neto
                    </span>
                  )}
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      {step === 1 && <section><h2 className="text-xl font-bold">Elige fecha y hora</h2><p className="mb-5 mt-1 text-sm text-slate-500">Atendemos de lunes a viernes, entre 09:00 y 18:00.</p><Field id="booking-date" label="Fecha"><input id="booking-date" type="date" required min={today} value={date} onChange={(event) => { setVerification(null); setCode(''); setDate(event.target.value); setLoadingSlots(Boolean(event.target.value)); setSlots([]); setSlot(null); setError(''); }} className={textInput} /></Field>{date && <div className="mt-6"><p className="mb-3 text-sm font-semibold text-slate-700">Horarios disponibles</p>{loadingSlots ? <p className="text-sm text-slate-500">Consultando disponibilidad…</p> : slots.length ? <div className="grid grid-cols-2 gap-2 min-[400px]:grid-cols-3 sm:grid-cols-5">{slots.map((item) => { const time = new Intl.DateTimeFormat('es-CL', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/Santiago' }).format(new Date(item.start)); return <button type="button" key={item.start} onClick={() => { setSlot(item); setVerification(null); setCode(''); }} aria-pressed={slot?.start === item.start} className={`rounded-xl border px-3 py-3 text-sm font-semibold ${slot?.start === item.start ? 'border-(--portal-accent) bg-(--portal-accent) text-white' : 'border-slate-200 hover:border-(--portal-accent)'}`}>{time}<span className="mt-1 block text-[10px] font-normal">{item.remaining_capacity} {item.remaining_capacity === 1 ? 'cupo' : 'cupos'}</span></button>; })}</div> : <p className="rounded-xl bg-amber-50 p-4 text-sm text-amber-900">No hay horas disponibles este día. Prueba con otra fecha entre semana.</p>}</div>}</section>}

      {step === 2 && <section>
        <h2 className="text-xl font-bold">Tus datos de contacto</h2>
        {customer && <p className="mt-1 text-sm text-slate-600">
          Usaremos los datos de tu cuenta. Puedes actualizarlos en <a className="booking-profile-link" href="/cliente#datos">Datos personales</a>.
        </p>}
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          {contactFields.map(({ name, label, type = 'text', autoComplete, maxLength, placeholder }) => {
            const id = 'booking-' + name;
            const fieldError = (showContactErrors || form[name]) && errors[name];
            const value = name === 'phone' ? phoneInputValue(form.phone) : form[name];
            if (customer) {
              const displayValue = name === 'phone' ? formatPhone(mobileContact(form.phone)) : name === 'rut' ? formatRut(form.rut) : value;
              return <div key={name} className="space-y-1.5 text-sm text-slate-700">
                <p className="font-semibold">{label}</p>
                <p className="break-words">{displayValue || 'Sin registrar'}</p>
                {errors[name] && <p className="text-xs font-medium text-rose-700">{errors[name]}</p>}
              </div>;
            }
            const input = <input
              id={id} name={name} type={type} value={value} onChange={(event) => update(name, name === 'phone' ? phoneDigits(event.target.value) : event.target.value)}
              onBlur={name === 'rut' ? () => { if (rutIsValid(form.rut)) update('rut', formatRut(form.rut)); } : undefined}
              inputMode={name === 'phone' ? 'numeric' : undefined}
              autoComplete={autoComplete} maxLength={maxLength} placeholder={placeholder}
              aria-invalid={Boolean(fieldError)} aria-describedby={fieldError ? id + '-error' : undefined}
              className={name === 'phone' ? 'min-w-0 flex-1 px-4 py-3 font-normal tabular-nums outline-none' : textInput}
              required
            />;
            return <Field key={name} id={id} label={label} error={fieldError}>
              {name === 'phone' ? <div className="booking-phone">
                <span aria-hidden="true">+56 9</span>
                {input}
              </div> : input}
            </Field>;
          })}
        </div>
        <p className="mt-5 text-sm text-slate-600">Los códigos y las instrucciones se enviarán por correo. WhatsApp aún no está disponible. Estamos trabajando para habilitarlo.</p>
      </section>}

      {step === 3 && <section><h2 className="text-xl font-bold">Revisa tu solicitud</h2><p className="mb-5 mt-1 text-sm text-slate-500">Confirma que los datos estén correctos antes de enviar.</p><div className="grid gap-4 sm:grid-cols-2"><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Servicio</p><p className="mt-2 font-semibold">{service?.name || 'Evaluación general'}</p>{service?.description && <p className="mt-1 text-sm text-slate-500">{service.description}</p>}</div><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Fecha y hora</p><p className="mt-2 font-semibold capitalize">{formattedDate}</p><p className="text-sm text-slate-600">{selectedTime} hrs</p></div><div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Cliente</p><p className="mt-2 font-semibold">{form.first_name} {form.last_name}</p><p className="text-sm text-slate-600">RUT {formatRut(form.rut)}</p><p className="text-sm text-slate-600">{formatPhone(mobileContact(form.phone))}</p>{form.email && <p className="text-sm text-slate-600">{form.email}</p>}</div></div></section>}

      {step === 3 && verification && codeOpen && <CodeVerificationDialog code={code} onChange={setCode} busy={submitting} error={error} title="Confirma tu cita" confirmLabel="Confirmar agendamiento" description="Ingresa el código que enviamos a tu correo para registrar tu solicitud. Expira en cinco minutos." onConfirm={() => confirmBooking()} onClose={() => { setCodeOpen(false); setError(''); }} onResend={() => confirmBooking(true)} />}
       <div className="booking-actions mt-8 flex flex-col-reverse gap-3 border-t border-slate-100 pt-5 sm:flex-row sm:justify-between">{step > 0 ? <button type="button" disabled={submitting} onClick={() => { setError(''); setStep((s) => s - 1); }} className="portal-button">Volver</button> : <span />}{step < 3 ? <button type="button" disabled={loadingServices || loadingSlots} onClick={continueStep} className="portal-button portal-button-primary">Continuar <span aria-hidden="true">→</span></button> : <button type="button" disabled={submitting} onClick={() => verification ? setCodeOpen(true) : confirmBooking()} className="portal-button portal-button-primary">{submitting ? 'Procesando…' : verification ? 'Ingresar código de verificación' : customer?.appointments?.length > 0 ? 'Confirmar agendamiento' : 'Enviar código de verificación'}</button>}</div>
      <p className="booking-availability mt-5 text-center text-xs text-slate-400">La disponibilidad se confirma nuevamente al registrar tu solicitud.</p>
    </div></section></div></main>;
}
