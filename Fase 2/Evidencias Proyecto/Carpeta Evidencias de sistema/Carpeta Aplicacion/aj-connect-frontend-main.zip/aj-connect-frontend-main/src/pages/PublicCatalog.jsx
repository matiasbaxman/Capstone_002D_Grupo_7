import { useEffect, useState } from 'react';
import { MapPin } from 'lucide-react';
import { listPublicCatalog } from '../api/inventory.js';
import { CatalogFilters, CatalogImage } from '../components/CatalogDisplay.jsx';
import { formatMoney } from '../utils/format.js';
import './PublicPortal.css';

const stockBadges = {
  available: { label: 'Disponible en tienda', tone: 'is-available' },
  low_stock: { label: 'Poco stock', tone: 'is-low' },
  out_of_stock: { label: 'Agotado', tone: 'is-out' },
};

export default function PublicCatalog() {
  const [items, setItems] = useState(null);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');

  useEffect(() => {
    const controller = new AbortController();
    listPublicCatalog(controller.signal)
      .then(setItems)
      .catch(() => {
        if (!controller.signal.aborted) setError(true);
      });
    return () => controller.abort();
  }, [attempt]);

  const products = items || [];
  const categories = [...new Set(products.map((item) => item.category_name))].sort((a, b) => a.localeCompare(b, 'es'));
  const term = search.trim().toLocaleLowerCase('es-CL');
  const shown = products.filter((item) =>
    (!category || item.category_name === category)
    && [item.title, item.sku, item.brand_name].some((value) => value?.toLocaleLowerCase('es-CL').includes(term)));

  return (
    <main className="portal-page catalog-public">
      <div className="portal-container portal-container-wide">
        <header className="portal-page-heading catalog-public-heading">
          <h1 className="portal-title">Catálogo de insumos</h1>
          <p>Consulta precios y disponibilidad de repuestos y lubricantes.</p>
        </header>
        <section className="portal-card catalog-public-controls" aria-label="Filtros del catálogo">
          <CatalogFilters {...{ search, setSearch, category, setCategory, categories }} />
          <p className="catalog-store-notice"><MapPin size={18} aria-hidden="true" /> Compras presenciales en nuestro taller de Quilpué.</p>
        </section>
        {error && <div className="portal-card catalog-public-state" role="alert">
          <p>No pudimos cargar el catálogo.</p>
          <button type="button" className="portal-button" onClick={() => { setError(false); setAttempt((value) => value + 1); }}>Reintentar</button>
        </div>}
        {!items && !error && <p className="portal-card catalog-public-state" role="status">Cargando catálogo…</p>}
        {items && !shown.length && <div className="portal-card catalog-public-state">
          <p role="status">{items.length ? 'No encontramos insumos con esos filtros.' : 'El catálogo aún no tiene insumos publicados.'}</p>
          {items.length > 0 && <button type="button" className="portal-button" onClick={() => { setSearch(''); setCategory(''); }}>Limpiar filtros</button>}
        </div>}
        <div className="catalog-grid">
          {shown.map((item) => {
            const badge = stockBadges[item.stock_status]
              ?? (item.in_stock === false ? stockBadges.out_of_stock : { label: 'Consultar disponibilidad', tone: '' });
            return (
              <article className="catalog-card" key={item.id}>
                <CatalogImage src={item.image_url} title={item.title} />
                <div className="catalog-card-content">
                  <p className="catalog-category">{[item.brand_name, item.category_name].filter(Boolean).join(' · ')}</p>
                  <h2>{item.title}</h2>
                  {item.description && <p className="catalog-description">{item.description}</p>}
                  <div className="catalog-card-footer">
                    <strong>{formatMoney(item.price)}</strong>
                    <span className={`catalog-stock ${badge.tone}`}>{badge.label}</span>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </main>
  );
}
