import AttentionTimeline from '../components/AttentionTimeline.jsx';
import TrackingParts from '../components/TrackingParts.jsx';
import { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import { Mail } from 'lucide-react';
import { BACKEND_URL } from '../api/axiosConfig.js';
import { formatPlate } from '../utils/plateValidation.js';
import { formatDateTime } from '../utils/format.js';
import { attentionStatus } from '../utils/attentions.js';
import './PublicPortal.css';
import './Tracking.css';

const publicApi = axios.create({ baseURL: `${BACKEND_URL}/api`, timeout: 15000 });
const validToken = value => /^(?:[0-9a-f]{32}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})$/i.test(value) || /^AJ[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{12}$/.test(value.replaceAll('-', '').toUpperCase());

export default function Tracking({ token, attention }) {
  const [input, setInput] = useState(token || '');
  const [photoIndex, setPhotoIndex] = useState(null);
  const photoDialog = useRef(null);
  const photoTrigger = useRef(null);
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(token && !validToken(token) ? 'El código de seguimiento no es válido. Revisa el enlace o código recibido.' : '');
  const [loading, setLoading] = useState(Boolean(token) && validToken(token));
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    if (!token) return;
    if (!validToken(token)) return;
    let active = true;
    let controller;
    async function load() {
      if (document.hidden) return;
      controller?.abort(); controller = new AbortController();
      try {
        const { data } = await publicApi.get(`/tracking/${encodeURIComponent(token)}/`, { signal: controller.signal });
        if (active) { setOrder(data); setError(''); setLoading(false); }
      } catch (err) {
        if (!active || axios.isCancel(err)) return;
        if (err.response?.status === 429) { setError('Demasiadas consultas. Espera unos minutos antes de intentarlo nuevamente.'); }
        else if (err.response?.status === 404) { setOrder(null); setError('No encontramos una orden con este código. Revisa el enlace recibido.'); }
        else setError('No pudimos actualizar el estado. Revisa tu conexión e inténtalo nuevamente.');
        setLoading(false);
      }
    }
    load(); const interval = setInterval(load, 30000);
    const visible = () => { if (!document.hidden) load(); };
    document.addEventListener('visibilitychange', visible);
    return () => { active = false; controller?.abort(); clearInterval(interval); document.removeEventListener('visibilitychange', visible); };
  }, [token, retry]);
  useEffect(() => {
    const dialog = photoDialog.current;
    if (photoIndex !== null && dialog && !dialog.open) dialog.showModal();
    if (photoIndex === null && dialog?.open) dialog.close();
  }, [photoIndex]);
  function closePhoto() { setPhotoIndex(null); requestAnimationFrame(() => photoTrigger.current?.focus()); }
  function submit(event) {
    event.preventDefault();
    const next = input.trim();
    if (!validToken(next)) { setError('Ingresa el código completo de seguimiento.'); return; }
    window.location.assign(`/seguimiento/${encodeURIComponent(next)}`);
  }
  const appointment = order?.appointment || (attention && !attention.withoutAppointment ? attention : null);
  const lookup = !token && !attention;
  const number = order?.folio_number || attention?.work_order__folio_number
    || attention?.id?.split(':').at(-1).slice(0, 8).toUpperCase();
  const status = attentionStatus(appointment, order?.status || attention?.work_order__status__name);

  return (
    <main className="portal-page tracking">
      {lookup ? (
        <div className="portal-container portal-container-form">
          <section className="portal-card portal-card-form" aria-labelledby="tracking-title">
            <header className="portal-form-heading">
              <h1 id="tracking-title">Tu vehículo, paso a paso</h1>
              <p>Consulta el avance de tu orden de trabajo en el taller.</p>
            </header>
            <div className="portal-form-content portal-form-content-narrow">
              <form className="tracking-form" onSubmit={submit}>
                <label htmlFor="tracking-token">Código de seguimiento</label>
                <input
                  id="tracking-token"
                  value={input}
                  onChange={(event) => { setInput(event.target.value); setError(''); }}
                  autoComplete="off"
                  autoCapitalize="characters"
                  spellCheck={false}
                  placeholder="Ej: AJ-7K4P-9M2X-6Q3D"
                  aria-describedby={error ? 'tracking-lookup-error tracking-lookup-help' : 'tracking-lookup-help'}
                  aria-invalid={Boolean(error)}
                />
                {error && <p id="tracking-lookup-error" className="tracking-lookup-error" role="alert">{error}</p>}
                <button type="submit" className="portal-button portal-button-primary">Consultar estado <span aria-hidden="true">→</span></button>
              </form>
              <div className="tracking-lookup-help" id="tracking-lookup-help">
                <Mail size={20} aria-hidden="true" />
                <div>
                  <p><strong>¿Dónde encuentro el código?</strong></p>
                  <p>Está en el correo de seguimiento que te enviamos al recibir tu vehículo.</p>
                </div>
              </div>
            </div>
          </section>
        </div>
      ) : (
        <div className="portal-container tracking-detail">
          {attention && <a href="/cliente#atenciones" className="portal-button tracking-back-button">← Volver a mis atenciones</a>}
          <header className="portal-page-heading tracking-intro">
            <h1 className="portal-title">{number ? `Detalle de atención N.° ${number}` : 'Tu vehículo, paso a paso'}</h1>
            {status.label && <span className="portal-status" data-tone={status.tone}>{status.label}</span>}
          </header>
          {loading && <div className="portal-card tracking-card" role="status">Consultando el estado de tu vehículo…</div>}
          {error && (
            <div className="tracking-error" role="alert">
              <h2>No pudimos consultar tu orden</h2>
              <p>{error}</p>
              {token && (
                <div className="tracking-error-actions">
                  <button type="button" onClick={() => { setLoading(!order); setRetry(n => n + 1); }}>Intentar de nuevo</button>
                  <a href="/seguimiento">Ingresar otro código</a>
                </div>
              )}
            </div>
          )}
          {(attention || order) && (
            <div className="tracking-detail-grid">
              <AttentionTimeline appointment={appointment} order={order} />
              <div className="tracking-detail-summary">
                {attention && !order && (
                  <section className="portal-card tracking-card">
                    <h2 className="portal-section-title">Datos de la atención</h2>
                    <p>{attention.scheduled_date ? formatDateTime(attention.scheduled_date) : 'Ingreso en taller'}</p>
                    {attention.reported_symptoms && <p className="whitespace-pre-wrap">{attention.reported_symptoms}</p>}
                    {!token && <p>Los datos del vehículo, fotografías e insumos aparecerán aquí cuando el taller registre su recepción.</p>}
                  </section>
                )}
                {order && (
                  <section className="portal-card tracking-card tracking-vehicle">
                    <h2 className="portal-section-title">{attention && !attention.withoutAppointment ? 'Vehículo y atención' : 'Tu vehículo'}</h2>
                    <dl className="tracking-details">
                      <div><dt>Patente</dt><dd>{order.vehicle?.plate ? formatPlate(order.vehicle.plate) : 'No informada'}</dd></div>
                      <div><dt>Vehículo</dt><dd>{order.vehicle?.label || 'No informado'}</dd></div>
                      <div><dt>Ingreso al taller</dt><dd>{formatDateTime(order.created_at)}</dd></div>
                      <div><dt>Entrega estimada</dt><dd>{order.estimated_delivery_date ? formatDateTime(order.estimated_delivery_date) : 'Por confirmar'}</dd></div>
                      {attention?.scheduled_date && !attention.withoutAppointment && <div><dt>Fecha de la cita</dt><dd>{formatDateTime(attention.scheduled_date)}</dd></div>}
                    </dl>
                    {attention?.reported_symptoms && !attention.withoutAppointment && <div className="tracking-diagnosis"><h3>Motivo de la cita</h3><p className="whitespace-pre-wrap">{attention.reported_symptoms}</p></div>}
                    {order.technical_diagnosis && <div className="tracking-diagnosis"><h3>Diagnóstico</h3><p>{order.technical_diagnosis}</p></div>}
                  </section>
                )}
                {order && <TrackingParts items={order.items} />}
              </div>
              {order && (
                  <section className="portal-card tracking-card tracking-detail-gallery">
                    <h2 className="portal-section-title">Fotografías de ingreso</h2>
                    <p>Registro de la condición del vehículo al llegar al taller.</p>
                    {order.photos?.length ? (
                      <div className="tracking-photos">
                        {order.photos.map((url, index) => (
                          <button type="button" key={index} onClick={event => {
                            photoTrigger.current = event.currentTarget;
                            setPhotoIndex(index);
                          }} aria-label={`Ampliar fotografía de ingreso ${index + 1}`}>
                            <img src={url} alt={`Fotografía de ingreso ${index + 1}`} loading="lazy" />
                          </button>
                        ))}
                      </div>
                    ) : <p className="tracking-empty">No hay fotografías de ingreso disponibles.</p>}
                  </section>
              )}
            </div>
          )}
          <dialog ref={photoDialog} className="tracking-photo-dialog" aria-label="Fotografía de ingreso ampliada"
            onCancel={event => { event.preventDefault(); closePhoto(); }}
            onClick={event => { if (event.target === event.currentTarget) closePhoto(); }}>
            <div className="tracking-photo-viewer">
              <header>
                <span>Fotografía {photoIndex !== null ? photoIndex + 1 : ''} de {order?.photos?.length || 0}</span>
                <button type="button" onClick={closePhoto} aria-label="Cerrar fotografía">×</button>
              </header>
              {photoIndex !== null && order?.photos?.[photoIndex] && <img src={order.photos[photoIndex]} alt={`Fotografía de ingreso ${photoIndex + 1} ampliada`} />}
              {(order?.photos?.length || 0) > 1 && (
                <nav aria-label="Navegación de fotografías">
                  <button type="button" onClick={() => setPhotoIndex(i => (i - 1 + order.photos.length) % order.photos.length)}>← Anterior</button>
                  <button type="button" onClick={() => setPhotoIndex(i => (i + 1) % order.photos.length)}>Siguiente →</button>
                </nav>
              )}
            </div>
          </dialog>
        </div>
      )}
    </main>
  );
}
