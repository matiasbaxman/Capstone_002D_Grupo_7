import Tracking from './Tracking.jsx';
import { unifiedAttentions } from '../utils/attentions.js';
import AppointmentCards from '../components/AppointmentCards.jsx';
import ClientProfile from '../components/ClientProfile.jsx';
import { useEffect, useState } from 'react';
import { clearClientSession, getClientAccount, getClientSession } from '../api/clientAuth.js';
import ClientAccess from '../components/ClientAccess.jsx';
import './PublicPortal.css';
import './ClientPortal.css';

export default function ClientPortal({ onAuthenticated = () => window.location.assign('/') }) {
  const [detail, setDetail] = useState(() => window.location.hash.startsWith('#atencion=') ? window.location.hash.slice(10) : '');
  const [section, setSection] = useState(() => window.location.hash === '#datos' ? 'datos' : 'citas');
  useEffect(() => { const sync = () => { setSection(window.location.hash === '#datos' ? 'datos' : 'citas'); setDetail(window.location.hash.startsWith('#atencion=') ? window.location.hash.slice(10) : ''); window.scrollTo(0, 0); }; window.addEventListener('hashchange', sync); return () => window.removeEventListener('hashchange', sync); }, []);
  const [session, setSession] = useState(getClientSession);
  const [account, setAccount] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!session) return;
    const controller = new AbortController();
    const timer = setTimeout(() => { clearClientSession(); setSession(null); setAccount(null); setError('Tu sesión expiró. Ingresa nuevamente con tu RUT y contraseña.'); }, Math.max(0, session.expiresAt - Date.now()));
    getClientAccount(controller.signal).then(data => { if (!controller.signal.aborted) setAccount(data); }).catch(err => {
      if (!controller.signal.aborted) { setError(err.response?.data?.detail || 'No pudimos cargar tus órdenes.'); if (!getClientSession()) setSession(null); }
    });
    const refresh = setInterval(() => { if (!document.hidden) getClientAccount(controller.signal).then(data => { if (!controller.signal.aborted) setAccount(data); }).catch(() => {}); }, 15000);
    return () => { clearTimeout(timer); clearInterval(refresh); controller.abort(); };
  }, [session]);
  const selected = detail && account ? unifiedAttentions(account.appointments, account.orders).find(item => encodeURIComponent(item.id) === detail) : null;
  if (session && detail && account) {
    return selected ? <Tracking key={selected.id} token={selected.work_order__tracking_code} attention={selected} /> : (
      <main className="portal-page">
        <div className="portal-container">
          <header className="portal-page-heading"><h1 className="portal-title">Atención no encontrada</h1></header>
          <a className="portal-button" href="/cliente#atenciones">← Volver a mis atenciones</a>
        </div>
      </main>
    );
  }
  if (!session) {
    return (
      <main className="client-access-page">
        <ClientAccess onAuthenticated={onAuthenticated} notice={error} />
      </main>
    );
  }

  return (
    <main className="portal-page">
      <section className="portal-container">
        <header className="portal-page-heading">
          <h1 className="portal-title">Mi cuenta</h1>
          {account && <p>Hola, {[account.client.first_name, account.client.last_name].filter(Boolean).join(' ')}.</p>}
        </header>
        <nav className="account-tabs" aria-label="Secciones de mi cuenta">
          <a href="/cliente#datos" aria-current={section === 'datos' ? 'page' : undefined}>Datos personales</a>
          <a href="/cliente#atenciones" aria-current={section === 'citas' ? 'page' : undefined}>Mis atenciones</a>
        </nav>
        {error && <p role="alert" className="my-4 rounded-xl bg-rose-50 p-4 text-rose-800">{error}</p>}
        {!account ? (
          !error && <p className="portal-card account-empty" role="status">Cargando tu cuenta…</p>
        ) : section === 'datos' ? (
          <ClientProfile client={account.client} onSaved={() => getClientAccount().then(setAccount).catch(() => setError('Tus datos se guardaron. Recarga la página para verlos.'))} />
        ) : (
          account.appointments?.length || account.orders?.length
            ? <AppointmentCards appointments={account.appointments} orders={account.orders} />
            : <p className="portal-card account-empty">Aún no tienes atenciones registradas.</p>
        )}
        <button type="button" className="portal-button mt-6" onClick={() => { clearClientSession(); setSession(null); setAccount(null); }}>
          Cerrar sesión
        </button>
      </section>
    </main>
  );
}
