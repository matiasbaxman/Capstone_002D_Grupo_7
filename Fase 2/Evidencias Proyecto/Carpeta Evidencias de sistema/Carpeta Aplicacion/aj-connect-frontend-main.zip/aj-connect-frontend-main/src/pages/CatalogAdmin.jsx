import { useEffect, useRef, useState } from 'react';
import { listAllItems, mensajeDeError, publishCatalogItems, updateItem } from '../api/inventory.js';
import { CatalogFilters, CatalogImage } from '../components/CatalogDisplay.jsx';
import { formatMoney } from '../utils/format.js';

function CatalogEditor({ item, draft, step, total, saving, error, onSave, onClose, onBack }) {
  const dialogRef = useRef(null);
  const previewRef = useRef(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [failedPreview, setFailedPreview] = useState(null);
  const pendingImage = selectedImage || draft?.public_image;
  const preview = pendingImage || item.public_image;
  const preparing = total > 0;

  useEffect(() => {
    dialogRef.current.showModal();
  }, []);

  useEffect(() => {
    if (!pendingImage) return;
    const url = URL.createObjectURL(pendingImage);
    previewRef.current.src = url;
    return () => URL.revokeObjectURL(url);
  }, [pendingImage]);

  function submit(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const image = form.get('public_image');
    const description = form.get('public_description').trim();
    if (preparing && !description) {
      const input = event.currentTarget.elements.public_description;
      input.setCustomValidity('Escribe una descripción para continuar.');
      input.reportValidity();
      return;
    }
    if (image.size > 5 * 1024 * 1024) {
      const input = event.currentTarget.elements.public_image;
      input.setCustomValidity('La imagen debe pesar como máximo 5 MB.');
      input.reportValidity();
      return;
    }
    const fields = {
      public_title: preparing ? item.name : form.get('public_title').trim(),
      public_description: description,
    };
    if (!preparing) fields.public_price = form.get('public_price') || null;
    const newImage = image.size ? image : draft?.public_image;
    if (newImage) fields.public_image = newImage;
    onSave(fields);
  }

  return (
    <dialog ref={dialogRef} className="catalog-admin catalog-dialog" aria-labelledby="catalog-editor-title" onCancel={(event) => { event.preventDefault(); if (!saving) onClose(); }}>
      <form onSubmit={submit} className="catalog-editor" aria-busy={saving}>
        <h2 id="catalog-editor-title">{preparing ? item.name : 'Editar ficha'}</h2>
        <p>{[preparing ? `Insumo ${step} de ${total}` : item.name, item.brand_name, item.sku].filter(Boolean).join(' · ')}</p>
        {error && <p className="catalog-error" role="alert">{error}</p>}
        {!preparing && <label><span>Título comercial</span><input name="public_title" defaultValue={item.public_title ?? ''} maxLength={150} placeholder={item.name} /></label>}
        <label><span>Descripción</span><textarea name="public_description" rows={4} required={preparing} disabled={saving} defaultValue={draft?.public_description ?? item.public_description ?? ''} onChange={(event) => event.currentTarget.setCustomValidity('')} /></label>
        {!preparing && <label><span>Precio web (CLP)</span><input name="public_price" type="number" min="0" max="9999999999" step="1" defaultValue={item.public_price ?? ''} placeholder={formatMoney(item.unit_price)} /><small>Si lo dejas en blanco, se usa el precio de inventario.</small></label>}
        <label><span>Foto del insumo</span><input name="public_image" type="file" accept="image/jpeg,image/png,image/webp" required={preparing && !draft?.public_image && !item.public_image} disabled={saving} onChange={(event) => {
          event.currentTarget.setCustomValidity('');
          setSelectedImage(event.currentTarget.files[0] || null);
          setFailedPreview(null);
        }} /><small>JPG, PNG o WebP de hasta 5 MB.</small></label>
        {preview && (
          <figure className="catalog-photo-preview">
            <figcaption>{pendingImage ? `Vista previa · ${pendingImage.name}` : 'Foto actual'}</figcaption>
            <img
              ref={previewRef}
              src={pendingImage ? undefined : item.public_image}
              alt={pendingImage ? 'Foto seleccionada del insumo' : 'Foto actual del insumo'}
              hidden={failedPreview === preview}
              onError={() => setFailedPreview(preview)}
            />
            {failedPreview === preview && <p role="status">No se pudo mostrar la imagen.</p>}
          </figure>
        )}
        <div className="catalog-actions">
          <button type="button" className="catalog-action" disabled={saving} onClick={onClose}>Cancelar</button>
          {preparing && step > 1 && <button type="button" className="catalog-action" disabled={saving} onClick={(event) => {
            const form = new FormData(event.currentTarget.form);
            onBack({
              public_title: item.name,
              public_description: form.get('public_description'),
              ...(pendingImage ? { public_image: pendingImage } : {}),
            });
          }}>Anterior</button>}
          <button type="submit" className="catalog-action catalog-primary" disabled={saving}>{preparing ? (step < total ? 'Siguiente' : saving ? 'Publicando…' : total === 1 ? 'Publicar insumo' : 'Publicar lote') : 'Guardar ficha'}</button>
        </div>
      </form>
    </dialog>
  );
}

export default function CatalogAdmin() {
  const [items, setItems] = useState(null);
  const [selected, setSelected] = useState(new Set());
  const [batch, setBatch] = useState(null);
  const [editing, setEditing] = useState(null);
  const [editorError, setEditorError] = useState('');
  const [feedback, setFeedback] = useState(null);
  const [busy, setBusy] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [tab, setTab] = useState('published');

  useEffect(() => {
    let active = true;
    listAllItems().then((data) => {
      if (active) setItems(data);
    }).catch((error) => {
      if (active) setFeedback({ error: mensajeDeError(error) });
    });
    return () => { active = false; };
  }, [attempt]);

  const inventory = items || [];
  const published = inventory.filter((item) => item.is_published);
  const hidden = inventory.filter((item) => !item.is_published);
  const categories = [...new Set(inventory.map((item) => item.category_name))].sort((a, b) => a.localeCompare(b, 'es'));
  const term = search.trim().toLocaleLowerCase('es-CL');
  const shown = hidden.filter((item) =>
    (!category || item.category_name === category)
    && [item.name, item.sku, item.brand_name].some((value) => value?.toLocaleLowerCase('es-CL').includes(term)));
  const allShownSelected = shown.length > 0 && shown.every(({ id }) => selected.has(id));

  function changeTab(next) {
    if (next === tab) return;
    setTab(next);
    window.scrollTo(0, 0);
  }

  function select(ids, checked) {
    setSelected((previous) => {
      const next = new Set(previous);
      for (const id of ids) {
        if (checked) next.add(id);
        else next.delete(id);
      }
      return next;
    });
  }

  function saveUpdated(results) {
    const updates = new Map(results.map((item) => [item.id, item]));
    setItems((previous) => previous.map((item) => updates.get(item.id) || item));
  }

  function edit(item) {
    setEditorError('');
    setEditing(item);
  }

  async function save(fields) {
    setBusy(true);
    setEditorError('');
    try {
      const form = new FormData();
      Object.entries(fields).forEach(([key, value]) => form.append(key, value ?? ''));
      saveUpdated([await updateItem(editing.id, form)]);
      setEditing(null);
      setFeedback({ message: 'Ficha actualizada.' });
    } catch (error) {
      setEditorError(mensajeDeError(error));
    } finally {
      setBusy(false);
    }
  }

  async function hide(item) {
    setBusy(true);
    setFeedback(null);
    try {
      saveUpdated([await updateItem(item.id, { is_published: false })]);
      setFeedback({ message: `${item.public_title || item.name} ya no se muestra en el catálogo público.` });
    } catch (error) {
      setFeedback({ error: mensajeDeError(error) });
    } finally {
      setBusy(false);
    }
  }

  function startBatch() {
    setEditorError('');
    setFeedback(null);
    setBatch({ items: hidden.filter(({ id }) => selected.has(id)), index: 0, drafts: {} });
  }

  async function saveBatchStep(fields) {
    const drafts = { ...batch.drafts, [batch.items[batch.index].id]: fields };
    setEditorError('');
    if (batch.index < batch.items.length - 1) {
      setBatch({ ...batch, drafts, index: batch.index + 1 });
      return;
    }

    setBatch({ ...batch, drafts });
    setBusy(true);
    try {
      const results = await publishCatalogItems(batch.items.map(({ id }) => id), drafts);
      saveUpdated(results);
      setBatch(null);
      setSelected(new Set());
      setFeedback({ message: results.length === 1 ? '1 insumo publicado.' : `${results.length} insumos publicados.` });
    } catch (error) {
      setEditorError(mensajeDeError(error));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="catalog-admin">
      <header className="inventory-heading">
        <div>
          <h1>Catálogo Web</h1>
          <p>Gestiona los insumos que los clientes pueden consultar en el portal.</p>
        </div>
        <a className="catalog-action" href="/catalogo" target="_blank" rel="noreferrer">Ver catálogo público</a>
      </header>
      {items && (
        <nav className="catalog-admin-tabs" aria-label="Estado de publicación">
          <button type="button" aria-pressed={tab === 'published'} onClick={() => changeTab('published')}>
            Publicados en la Web <span>{published.length}</span>
          </button>
          <button type="button" aria-pressed={tab === 'pending'} onClick={() => changeTab('pending')}>
            Por publicar <span>{hidden.length}</span>
          </button>
        </nav>
      )}
      {feedback && <p role={feedback.error ? 'alert' : 'status'} className={feedback.error ? 'catalog-error' : 'catalog-feedback'}>{feedback.error || feedback.message}
        {!items && feedback.error && <button className="catalog-action" type="button" onClick={() => { setFeedback(null); setAttempt((value) => value + 1); }}>Reintentar</button>}
      </p>}
      {!items && !feedback && <p role="status">Cargando inventario…</p>}
      {items && (tab === 'published' ? (
          <section aria-labelledby="catalog-published-title">
            <h2 id="catalog-published-title" className="sr-only">Publicados en la Web</h2>
            {!published.length && <p>No hay insumos publicados.</p>}
            <div className="catalog-grid">
              {published.map((item) => (
                <article className="catalog-card" key={item.id}>
                  <CatalogImage src={item.public_image} title={item.public_title || item.name} />
                  <div className="catalog-card-content">
                    <p className="catalog-category">{[item.brand_name, item.category_name].filter(Boolean).join(' · ')}</p>
                    <h3>{item.public_title || item.name}</h3>
                    <div className="catalog-card-footer"><strong>{formatMoney(item.public_price ?? item.unit_price)}</strong><span>Stock: {item.current_stock}</span></div>
                    <div className="catalog-actions">
                      <button type="button" className="catalog-action" disabled={busy} onClick={() => edit(item)}>Editar ficha</button>
                      <button type="button" className="catalog-action" disabled={busy} onClick={() => hide(item)}>Ocultar</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ) : (
          <section aria-labelledby="catalog-available-title">
            <h2 id="catalog-available-title" className="sr-only">Disponibles para publicar</h2>
            <CatalogFilters {...{ search, setSearch, category, setCategory, categories }} />
            <div className="catalog-actions catalog-bulk">
              <span>{selected.size} {selected.size === 1 ? 'seleccionado' : 'seleccionados'}</span>
              <button type="button" className="catalog-action catalog-primary" disabled={busy || !selected.size} onClick={startBatch}>Publicar seleccionados</button>
            </div>
            {!shown.length ? <p>{hidden.length ? 'No encontramos insumos con esos filtros.' : 'No hay insumos pendientes de publicación.'}</p> : (
              <div role="region" aria-label="Insumos disponibles para publicar" tabIndex={0} className="catalog-table-wrap admin-table-scroll">
                <table className="catalog-table">
                  <thead><tr>
                    <th scope="col"><input type="checkbox" checked={allShownSelected} disabled={busy} onChange={(event) => select(shown.map(({ id }) => id), event.target.checked)} aria-label="Seleccionar todos los insumos visibles" /></th>
                    <th scope="col">Insumo</th><th scope="col">Categoría</th><th scope="col">Precio web</th><th scope="col">Stock</th>
                  </tr></thead>
                  <tbody>{shown.map((item) => (
                    <tr key={item.id}>
                      <td><input type="checkbox" checked={selected.has(item.id)} disabled={busy} onChange={(event) => select([item.id], event.target.checked)} aria-label={`Seleccionar ${item.name}`} /></td>
                      <td><strong>{item.name}</strong><small>{[item.brand_name, item.sku].filter(Boolean).join(' · ')}</small></td>
                      <td>{item.category_name}</td>
                      <td>{formatMoney(item.public_price ?? item.unit_price)}</td>
                      <td>{item.current_stock}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            )}
          </section>
      ))}
      {editing && <CatalogEditor key={editing.id} item={editing} saving={busy} error={editorError} onSave={save} onClose={() => setEditing(null)} />}
      {batch && <CatalogEditor
        key={batch.items[batch.index].id}
        item={batch.items[batch.index]}
        draft={batch.drafts[batch.items[batch.index].id]}
        step={batch.index + 1}
        total={batch.items.length}
        saving={busy}
        error={editorError}
        onSave={saveBatchStep}
        onClose={() => setBatch(null)}
        onBack={(fields) => {
          setEditorError('');
          setBatch({
            ...batch,
            drafts: { ...batch.drafts, [batch.items[batch.index].id]: fields },
            index: batch.index - 1,
          });
        }}
      />}
    </div>
  );
}
