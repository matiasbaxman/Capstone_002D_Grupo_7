import { useEffect, useState } from 'react';
import { createItemBrand, erroresPorCampo, listItemBrands, mensajeDeError, updateItemBrand } from '../api/inventory.js';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import InventoryTabs from '../components/InventoryTabs.jsx';
import { useToast } from '../components/notifications/useToast.js';

const brandsPath = '/dashboard/inventario/marcas';

function BrandEditor({ brand, onClose, onSaved }) {
  const [name, setName] = useState(brand?.name || '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function save() {
    if (saving) return;
    if (!name.trim()) {
      setError('Ingresa un nombre para la marca.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      if (brand) await updateItemBrand(brand.id, { name: name.trim() });
      else await createItemBrand(name.trim());
      onSaved();
    } catch (err) {
      setError(erroresPorCampo(err?.response?.data).name || mensajeDeError(err));
      setSaving(false);
    }
  }

  return (
    <ConfirmDialog title={brand ? 'Editar marca' : 'Nueva marca'} confirmLabel={brand ? 'Guardar cambios' : 'Crear marca'} busyLabel="Guardando…"
      busy={saving} error={error} onCancel={onClose} onConfirm={save}>
      <form onSubmit={(event) => { event.preventDefault(); save(); }}>
        <label htmlFor="new-item-brand" className="mb-2 block font-medium">Nombre</label>
        <input id="new-item-brand" value={name} disabled={saving} maxLength={100} aria-invalid={Boolean(error)}
          onChange={(event) => { setName(event.target.value); setError(''); }}
          className="w-full rounded-lg border border-[var(--line)] bg-[var(--chrome)] px-3 py-2 text-[var(--ink)]" />
      </form>
    </ConfirmDialog>
  );
}

function BrandStatusDialog({ brand, onClose, onSaved }) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const action = brand.is_active ? 'Archivar' : 'Reactivar';

  async function save() {
    if (saving) return;
    setSaving(true);
    setError('');
    try {
      await updateItemBrand(brand.id, { is_active: !brand.is_active });
      onSaved();
    } catch (err) {
      setError(mensajeDeError(err));
      setSaving(false);
    }
  }

  return (
    <ConfirmDialog title={`${action} «${brand.name}»`} confirmLabel={action} busyLabel="Guardando…"
      busy={saving} error={error} onCancel={onClose} onConfirm={save}>
      {brand.is_active
        ? 'Los insumos asociados conservarán esta marca. Para volver a asignarla, tendrás que reactivarla.'
        : 'Esta marca volverá a estar disponible al crear o editar un insumo.'}
    </ConfirmDialog>
  );
}

export default function ItemBrands({ onNavigate, canManage }) {
  const [brands, setBrands] = useState(null);
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [status, setStatus] = useState('');
  const [editor, setEditor] = useState(null);
  const [archive, setArchive] = useState(null);
  const toast = useToast();

  useEffect(() => {
    const controller = new AbortController();
    listItemBrands(controller.signal, { includeUnidentified: true, includeArchived: true })
      .then((data) => { if (!controller.signal.aborted) setBrands(data); })
      .catch((err) => { if (!controller.signal.aborted) setError(mensajeDeError(err)); });
    return () => controller.abort();
  }, [attempt]);

  const query = search.trim().toLocaleLowerCase('es-CL');
  const visible = brands?.filter(({ name, is_active: active, is_unidentified: unidentified }) =>
    (!status || (!unidentified && (status === 'active') === active)) && name.toLocaleLowerCase('es-CL').includes(query));

  function openItems(event, url) {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    onNavigate(url);
  }

  function brandSaved() {
    if (archive) {
      toast.success(archive.is_active ? 'Marca archivada' : 'Marca reactivada', { icon: archive.is_active ? 'archive' : 'restore' });
    } else {
      toast.success(editor.brand ? 'Cambios de la marca guardados' : 'Marca creada', { icon: editor.brand ? 'save' : 'create' });
      setSearch('');
      if (!editor.brand) setStatus('');
    }
    setEditor(null);
    setArchive(null);
    setError('');
    setAttempt((value) => value + 1);
  }

  return (
    <section>
      <header className="inventory-heading">
        <div><h1>Inventario</h1><p>Selecciona una marca para ver sus insumos.</p></div>
        {canManage && (
          <button type="button" onClick={() => setEditor({ brand: null })}
            className="admin-primary-action rounded-lg bg-[var(--button)] px-4 py-2 text-sm font-semibold text-[var(--button-text)]">
            + Nueva marca
          </button>
        )}
      </header>
      <InventoryTabs path={brandsPath} onNavigate={onNavigate} />
      <div className="inventory-filters mt-6">
        <label className="inventory-search">
          <span className="sr-only">Buscar marcas</span>
          <input type="search" value={search} onChange={(event) => setSearch(event.target.value)}
            placeholder="Buscar marca…" className="w-full rounded-lg border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-sm" />
        </label>
        <label className="inventory-filter">
          <span className="sr-only">Estado de la marca</span>
          <select value={status} onChange={(event) => setStatus(event.target.value)}>
            <option value="">Todos los estados</option>
            <option value="active">Activas</option>
            <option value="archived">Archivadas</option>
          </select>
        </label>
      </div>
      {error ? (
        <div className="admin-alert" role="alert">
          {error}<button onClick={() => { setError(''); setAttempt((value) => value + 1); }}>Reintentar</button>
        </div>
      ) : !visible ? (
        <p className="mt-5 text-sm text-[var(--muted)]" role="status">Cargando marcas…</p>
      ) : (
        <div role="region" aria-label="Tabla de marcas" tabIndex={0}
          className="admin-table-scroll mt-4 rounded-xl border border-[var(--line)] bg-[var(--surface)]">
          <table className="inventory-data-table w-full text-left text-sm">
            <caption className="sr-only">Marcas de insumos</caption>
            <thead className="bg-[var(--chrome)] text-xs text-[var(--muted)]">
              <tr>
                <th scope="col">Marca</th><th scope="col" className="text-right">Insumos</th><th scope="col">Estado</th>
                {canManage && <th scope="col" className="text-right">Acciones</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--line)]">
              {visible.map((brand) => {
                const { id, name, item_count: count, is_active: active, is_unidentified: unidentified } = brand;
                const url = `/dashboard/inventario?brand=${id}`;
                return (
                  <tr key={id} className="transition hover:bg-[var(--chrome)]">
                    <td className="px-4 py-3 font-medium">
                      <a className="inventory-count-link [overflow-wrap:anywhere]" href={url} onClick={(event) => openItems(event, url)}>{name}</a>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{count}</td>
                    <td className="px-4 py-3">
                      <span className={`category-status ${active && !unidentified ? 'is-active' : ''}`}>
                        {unidentified ? 'Pendiente' : active ? 'Activa' : 'Archivada'}
                      </span>
                    </td>
                    {canManage && (
                      <td className="px-4 py-3">
                        {!unidentified && (
                          <div className="flex justify-end gap-2">
                            <button type="button" aria-label={`Editar ${name}`} className="category-action" onClick={() => setEditor({ brand })}>Editar</button>
                            <button type="button" aria-label={`${active ? 'Archivar' : 'Reactivar'} ${name}`} className="category-action"
                              onClick={() => setArchive(brand)}>{active ? 'Archivar' : 'Reactivar'}</button>
                          </div>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
              {visible.length === 0 && (
                <tr><td colSpan={canManage ? 4 : 3} className="px-4 py-9 text-center text-[var(--muted)]">
                  {query || status ? 'No hay marcas que coincidan con los filtros.' : 'Aún no hay marcas registradas.'}
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      {editor && <BrandEditor brand={editor.brand} onClose={() => setEditor(null)} onSaved={brandSaved} />}
      {archive && <BrandStatusDialog brand={archive} onClose={() => setArchive(null)} onSaved={brandSaved} />}
    </section>
  );
}
