import MetricsDashboard from './MetricsDashboard.jsx';

export default function AdminHome({ isAdmin = false, isMecanico = false, isRecepcionista = false }) {
  const showOrders = isAdmin || isMecanico;
  const showSupplies = isAdmin || isRecepcionista;
  if (showOrders || showSupplies) {
    return (
      <MetricsDashboard
        key={`${isAdmin}-${showOrders}-${showSupplies}`}
        isAdmin={isAdmin}
        showOrders={showOrders}
        showSupplies={showSupplies}
      />
    );
  }

  return (
    <section className="admin-home">
      <header className="admin-page-heading">
        <div>
          <h1>Resumen del taller</h1>
          <p>Lo esencial de tu taller, a mano.</p>
        </div>

        <span className="admin-date">
          {new Intl.DateTimeFormat('es-CL', {
            dateStyle: 'long',
            timeZone: 'America/Santiago',
          }).format(new Date())}
        </span>
      </header>
    </section>
  );
}
