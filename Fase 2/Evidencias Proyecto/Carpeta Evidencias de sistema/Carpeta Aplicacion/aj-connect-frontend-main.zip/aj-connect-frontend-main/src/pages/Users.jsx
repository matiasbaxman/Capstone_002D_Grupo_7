import { useEffect, useMemo, useState } from 'react';
import UserTable from '../components/UserTable.jsx';
import UserModal from '../components/UserModal.jsx';
import { listRoles, listUsers, parseGeneralError } from '../api/users.js';
import { cleanRut } from '../utils/rut.js';

const skeletonRows = Array.from({ length: 4 }, (_, idx) => idx);

export default function Users({ canEditSuperusers = false }) {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [busqueda, setBusqueda] = useState('');
  const [editor, setEditor] = useState(null);

  async function cargarDatos() {
    setCargando(true);
    setError('');
    try {
      const [usersData, rolesData] = await Promise.all([listUsers(), listRoles()]);
      setUsers(Array.isArray(usersData) ? usersData : []);
      setRoles(Array.isArray(rolesData) ? rolesData : []);
    } catch (err) {
      setError(parseGeneralError(err));
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => {
    let active = true;
    Promise.all([listUsers(), listRoles()])
      .then(([usersData, rolesData]) => {
        if (!active) return;
        setUsers(Array.isArray(usersData) ? usersData : []);
        setRoles(Array.isArray(rolesData) ? rolesData : []);
      })
      .catch((err) => { if (active) setError(parseGeneralError(err)); })
      .finally(() => { if (active) setCargando(false); });
    return () => { active = false; };
  }, []);

  function alGuardar() {
    setEditor(null);
    cargarDatos();
  }

  const usuariosFiltrados = useMemo(() => {
    const q = busqueda.trim().toLowerCase();
    if (!q) return users;
    const cleanQ = cleanRut(q).toLowerCase();
    const queryDigits = q.replace(/\D/g, '');

    return users.filter((u) => {
      const fullName = (u.full_name || `${u.first_name || ''} ${u.last_name || ''}`).toLowerCase();
      const username = (u.username || '').toLowerCase();
      const email = (u.email || '').toLowerCase();
      const rut = (u.rut || '').toLowerCase();
      const userCleanRut = cleanRut(u.rut || '').toLowerCase();
      const phone = (u.phone || '').toLowerCase();
      const userPhoneDigits = (u.phone || '').replace(/\D/g, '');
      const rolesList = (u.roles || []).join(' ').toLowerCase();

      const rutMatches = rut.includes(q) || (cleanQ.length >= 2 && userCleanRut.includes(cleanQ));
      const phoneMatches = phone.includes(q) || (queryDigits.length >= 3 && userPhoneDigits.includes(queryDigits));

      return (
        fullName.includes(q) ||
        username.includes(q) ||
        email.includes(q) ||
        rutMatches ||
        phoneMatches ||
        rolesList.includes(q)
      );
    });
  }, [users, busqueda]);

  return (
    <div className="text-[var(--ink)]">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-[var(--ink)]">Personal y Usuarios</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            {cargando
              ? 'Cargando empleados…'
              : `${users.length} empleado(s) registrado(s)`}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setEditor({ user: null })}
          disabled={cargando || Boolean(error)}
          className="min-h-11 w-full cursor-pointer rounded-lg bg-[var(--button)] sm:w-auto px-4 py-2 text-sm font-semibold text-[var(--button-text)] transition hover:bg-[var(--button-hover)] disabled:cursor-not-allowed disabled:opacity-40"
        >
          + Nuevo Empleado
        </button>
      </header>

      {/* Barra de búsqueda */}
      <div className="mt-6 max-w-md">
        <label htmlFor="buscar-empleado" className="sr-only">
          Buscar empleados
        </label>
        <div className="relative">
          <input
            id="buscar-empleado"
            type="search"
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Buscar por nombre, usuario, RUT, teléfono, rol…"
            className="w-full rounded-lg border border-[var(--line)] bg-[var(--surface)] py-2 pl-3 pr-9 text-sm text-[var(--ink)] placeholder-[var(--muted)] outline-none transition focus:border-emerald-500"
          />
          {busqueda ? (
            <button
              type="button"
              onClick={() => setBusqueda('')}
              aria-label="Limpiar búsqueda"
              className="absolute inset-y-0 right-0 px-3 text-lg leading-none text-[var(--muted)] transition hover:text-[var(--ink)]"
            >
              &times;
            </button>
          ) : null}
        </div>
      </div>

      {/* Contenido principal: error, skeleton o tabla */}
      <div className="mt-4">
        {error ? (
          <div role="alert" className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-[var(--danger)]">
            <p>{error}</p>
            <button
              type="button"
              onClick={cargarDatos}
              className="mt-2 cursor-pointer text-xs font-semibold underline hover:no-underline"
            >
              Reintentar
            </button>
          </div>
        ) : cargando ? (
          <div className="overflow-hidden rounded-xl border border-[var(--line)] bg-[var(--surface)]">
            {skeletonRows.map((idx) => (
              <div
                key={idx}
                className="h-16 animate-pulse border-b border-[var(--line)] last:border-0"
              />
            ))}
          </div>
        ) : (
          <UserTable users={usuariosFiltrados} onEdit={(user) => setEditor({ user })} canEditSuperusers={canEditSuperusers} />
        )}
      </div>

      {editor ? (
        <UserModal
          key={editor.user?.id ?? 'new'}
          employee={editor.user}
          roles={roles}
          onCerrar={() => setEditor(null)}
          onGuardado={alGuardar}
        />
      ) : null}
    </div>
  );
}
