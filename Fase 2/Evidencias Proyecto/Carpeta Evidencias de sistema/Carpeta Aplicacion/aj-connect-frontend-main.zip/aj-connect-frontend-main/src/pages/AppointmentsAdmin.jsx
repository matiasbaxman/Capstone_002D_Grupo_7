import { useCallback, useEffect, useMemo, useState } from 'react';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast, notificationMessages } from '../components/notifications/useToast.js';
import { listAppointments, updateAppointment } from '../api/appointments.js';
import './AppointmentsAdmin.css';

const statuses = [ ['PENDIENTE', 'Pendiente'], ['CONFIRMADA', 'Confirmada'], ['CANCELADA', 'Cancelada'], ['RECHAZADA', 'Rechazada'], ['ATENDIDA', 'Atendida'] ];
const titleStatus = (status) => statuses.find(([code]) => code === status)?.[1] || status || 'Sin estado';
const dateTime = (value) => value ? new Intl.DateTimeFormat('es-CL', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : 'Sin fecha';
const personName = (client) => [client?.first_name || client?.firstName, client?.last_name || client?.lastName].filter(Boolean).join(' ') || 'Cliente';
const vehicleName = (vehicle) => vehicle ? [vehicle.brand, vehicle.model, vehicle.year].filter(Boolean).join(' ') : 'Vehículo no asociado';
const errorMessage = (error) => (error?.response?.data && Object.values(error.response.data).flat(Infinity).join(' ')) || 'No pudimos completar la operación. Verifica que la API administrativa esté disponible.';

export default function AppointmentsAdmin() {
  const toast = useToast();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  const [range, setRange] = useState('all');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [selected, setSelected] = useState(null);
  const [edit, setEdit] = useState(null);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try { setAppointments(await listAppointments()); }
    catch (err) { setAppointments([]); setError(errorMessage(err)); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => {
    let active = true;
    listAppointments()
      .then((items) => { if (active) setAppointments(items); })
      .catch((err) => { if (active) setError(errorMessage(err)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const filtered = useMemo(() => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endWeek = new Date(today); endWeek.setDate(today.getDate() + (7 - (today.getDay() || 7)));
    return appointments.filter((item) => {
      const date = new Date(item.scheduled_date);
      if (status && item.status !== status) return false;
      if (range === 'today' && (date < today || date >= new Date(today.getTime() + 86400000))) return false;
      if (range === 'week' && (date < today || date > endWeek)) return false;
      if (range === 'custom' && ((from && date < new Date(`${from}T00:00:00`)) || (to && date > new Date(`${to}T23:59:59`)))) return false;
      return true;
    });
  }, [appointments, status, range, from, to]);

  async function save(payload) {
    setBusy(true); setActionError('');
    try {
      await updateAppointment(edit.id, payload);
      toast.success(notificationMessages.appointmentUpdated); setEdit(null); await load();
    } catch (err) { setActionError(errorMessage(err)); }
    finally { setBusy(false); }
  }
  function submitEdit() {
    if (edit.kind === 'reschedule') {
      const date = new Date(edit.date);
      if (!edit.date || !Number.isFinite(date.getTime())) { setActionError('Selecciona una fecha y hora válida.'); return; }
      return save({ scheduled_date: date.toISOString() });
    }
    return save({ status: edit.kind === 'confirm' ? 'CONFIRMADA' : edit.kind === 'reject' ? 'RECHAZADA' : 'CANCELADA' });
  }
  function openEdit(item, kind) { const date = item.scheduled_date ? new Date(item.scheduled_date) : null; const localDate = date ? new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''; setEdit({ ...item, kind, date: localDate }); setActionError(''); }

  return <main className="appointments-admin">
    <header className="appointments-heading"><div><p className="appointments-eyebrow">AGENDA DEL TALLER</p><h1>Gestión de citas</h1><p>Revisa solicitudes, confirma horarios y mantén al cliente informado.</p></div><button className="appointments-button" onClick={load} disabled={loading}>↻ Actualizar</button></header>
    <section className="appointments-filters" aria-label="Filtros de citas"><div className="appointments-quick-filters">{[['all','Todas'],['today','Hoy'],['week','Esta semana'],['custom','Rango manual']].map(([key,label]) => <button key={key} className={range===key?'selected':''} onClick={() => setRange(key)}>{label}</button>)}</div><label>Estado<select value={status} onChange={e=>setStatus(e.target.value)}><option value="">Todos los estados</option>{statuses.map(([code,label])=><option key={code} value={code}>{label}</option>)}</select></label>{range==='custom'&&<><label>Desde<input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label><label>Hasta<input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label></>}</section>
    {error ? <section className="appointments-empty" role="alert"><h2>No pudimos cargar las citas</h2><p>{error}</p><button className="appointments-button primary" onClick={load}>Reintentar</button></section> : loading ? <div className="appointments-loading" role="status">Cargando agenda…</div> : <section className="appointments-table-card"><header><h2>Citas agendadas</h2><span>{filtered.length} {filtered.length===1?'resultado':'resultados'}</span></header><div role="region" aria-label="Tabla de citas" tabIndex={0} className="appointments-table-scroll admin-table-scroll"><table><thead><tr><th>Fecha y hora</th><th>Cliente</th><th>Vehículo</th><th>Servicio / síntomas</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{filtered.map(item=><tr key={item.id}><td><strong>{dateTime(item.scheduled_date)}</strong></td><td>{personName(item.client)}<small>{item.client?.rut || item.rut || 'RUT no disponible'} · {item.client?.phone || item.phone || 'Teléfono no disponible'}</small></td><td>{vehicleName(item.vehicle)}<small>{item.vehicle?.plate || item.plate || 'Patente no disponible'}</small></td><td>{item.service?.name || item.service_name || 'Evaluación general'}<small>{item.reported_symptoms || 'Sin síntomas reportados'}</small></td><td><span className={`appointment-status status-${String(item.status).toLowerCase()}`}>{titleStatus(item.status)}</span></td><td><div className="appointment-row-actions"><button onClick={()=>setSelected(item)}>Detalle</button>{item.status==='PENDIENTE'&&<button className="confirm" onClick={()=>openEdit(item,'confirm')}>Confirmar</button>}{['PENDIENTE','CONFIRMADA'].includes(item.status)&&<><button onClick={()=>openEdit(item,'reschedule')}>Reprogramar</button><button className="reject" onClick={()=>openEdit(item,item.status==='PENDIENTE'?'reject':'cancel')}>{item.status==='PENDIENTE'?'Rechazar':'Cancelar'}</button></>}</div></td></tr>)}</tbody></table>{!filtered.length&&<p className="appointments-empty">No hay citas para los filtros seleccionados.</p>}</div></section>}
    {selected&&<ConfirmDialog title="Detalle de la cita" confirmLabel="Listo" cancelLabel="Cerrar" onCancel={()=>setSelected(null)} onConfirm={()=>setSelected(null)}><div className="appointment-detail"><p><b>Fecha y hora:</b> {dateTime(selected.scheduled_date)}</p><p><b>Estado:</b> {titleStatus(selected.status)}</p><p><b>Cliente:</b> {personName(selected.client)}</p><p><b>RUT:</b> {selected.client?.rut || selected.rut || 'No disponible'}</p><p><b>Teléfono:</b> {selected.client?.phone || selected.phone || 'No disponible'}</p>{(selected.client?.phone || selected.phone)&&<div className="appointment-contact"><a href={`tel:${selected.client?.phone||selected.phone}`}>Llamar</a><a target="_blank" rel="noreferrer" href={`https://wa.me/${String(selected.client?.phone||selected.phone).replace(/\D/g,'')}`}>WhatsApp</a></div>}<p><b>Vehículo:</b> {vehicleName(selected.vehicle)} · {selected.vehicle?.plate || selected.plate || 'Sin patente'}</p><p><b>Servicio:</b> {selected.service?.name || selected.service_name || 'Evaluación general'}</p><p><b>Síntomas:</b></p><p className="appointment-symptoms">{selected.reported_symptoms || 'Sin información'}</p><p><b>Creada:</b> {dateTime(selected.created_at)}</p></div></ConfirmDialog>}
    {edit&&<ConfirmDialog title={edit.kind==='confirm'?'Confirmar cita':edit.kind==='reschedule'?'Reprogramar cita':edit.kind==='reject'?'Rechazar cita':'Cancelar cita'} confirmLabel={edit.kind==='confirm'?'Aprobar cita':edit.kind==='reschedule'?'Guardar horario':edit.kind==='reject'?'Rechazar cita':'Cancelar cita'} variant={['cancel','reject'].includes(edit.kind)?'danger':'default'} busy={busy} busyLabel="Guardando…" error={actionError} onCancel={()=>setEdit(null)} onConfirm={submitEdit}><p>{edit.kind==='confirm'?'La cita quedará confirmada para el horario agendado. La creación de una orden de trabajo no está disponible desde este flujo.':edit.kind==='reschedule'?'Selecciona una nueva fecha y hora para la cita.':'El cupo se liberará inmediatamente y conservaremos el registro de la cita.'}</p>{edit.kind==='reschedule'&&<label className="appointment-dialog-label">Nueva fecha y hora<input type="datetime-local" value={edit.date} onChange={e=>setEdit({...edit,date:e.target.value})} required/></label>}</ConfirmDialog>}
  </main>;
}
