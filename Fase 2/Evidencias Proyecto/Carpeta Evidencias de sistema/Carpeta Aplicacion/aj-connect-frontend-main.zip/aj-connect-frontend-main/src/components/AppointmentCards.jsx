import { ArrowRight } from 'lucide-react';
import { attentionStatus, unifiedAttentions } from '../utils/attentions.js';
import { formatDateTime } from '../utils/format.js';
import { formatPlate } from '../utils/plateValidation.js';

export default function AppointmentCards({ appointments = [], orders = [] }) {
  return (
    <ul className="account-attentions">
      {unifiedAttentions(appointments, orders).map(item => {
        const status = attentionStatus(item, item.work_order__status__name);
        return (
          <li key={item.id}>
            <a className="portal-card account-attention" href={`/cliente#atencion=${encodeURIComponent(item.id)}`}>
              <div>
                <strong>{item.work_order__folio_number ? `Atención N.° ${item.work_order__folio_number}` : 'Atención agendada'}</strong>
                <p>{item.scheduled_date ? formatDateTime(item.scheduled_date) : 'Ingreso en taller'}</p>
              </div>
              {item.plate && <div><span className="account-attention-label">Patente</span> {formatPlate(item.plate)}</div>}
              <div className="account-attention-action">
                {status.label && <span className="portal-status" data-tone={status.tone}>{status.label}</span>}
                <span className="account-attention-link">Ver detalle <ArrowRight size={16} aria-hidden="true" /></span>
              </div>
            </a>
          </li>
        );
      })}
    </ul>
  );
}
