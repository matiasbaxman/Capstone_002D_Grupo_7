import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, LockKeyhole, Mail } from 'lucide-react';
import { requestClientCode, verifyClientCode } from '../api/clientAuth.js';
import { validRut, formatRut, normalizeRut } from '../utils/rutValidation.js';
import teamPhoto from '../assets/equipo-taller.webp';
import './ClientAccess.css';

const inputClass = 'mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3';
const invalidCredentials = 'Usuario y contraseña incorrectos.';
const accessSteps = {
  login: { title: 'Iniciar sesión', submit: 'Ingresar' },
  activate: { title: 'Activa tu acceso', description: 'Ingresa tu RUT para recibir un código en el correo registrado.', submit: 'Enviar código' },
  code: { title: 'Revisa tu correo', description: 'Ingresa el código de seis dígitos. Expira en cinco minutos.', submit: 'Continuar' },
  password: { title: 'Crea tu contraseña', description: 'La usarás junto con tu RUT en tus próximas visitas.', submit: 'Crear contraseña e ingresar' },
};

export default function ClientAccess({ onAuthenticated, notice }) {
  const [rut, setRut] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [step, setStep] = useState('login');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const heading = useRef(null);

  useEffect(() => {
    if (step !== 'login') heading.current?.focus();
  }, [step]);

  function changeStep(next) { setError(''); setStep(next); }
  function reset() { setCode(''); setPassword(''); setConfirmation(''); changeStep('login'); }
  async function submit(event, action = step) {
    event?.preventDefault();
    if (busy) return;
    if (action === 'code') {
      if (/^\d{6}$/.test(code)) changeStep('password');
      return;
    }
    if (!validRut(rut)) {
      setError(action === 'login' ? invalidCredentials : 'Ingresa un RUT válido.');
      return;
    }
    if (action === 'password' && password !== confirmation) { setError('Las contraseñas no coinciden.'); return; }
    setBusy(true); setError('');
    try {
      if (action === 'password') {
        await verifyClientCode({ rut, code, password });
        reset(); onAuthenticated();
      } else {
        const result = await requestClientCode(rut, action === 'login' ? password : '');
        setPassword(''); setCode('');
        if (result.access) onAuthenticated();
        else if (action === 'login') setError(invalidCredentials);
        else setStep('code');
      }
    } catch (err) {
      if (action === 'login' || action === 'activate') {
        setError(invalidCredentials);
        return;
      }
      const data = err.response?.data;
      const messages = data && typeof data === 'object'
        ? ['detail', 'rut', 'code', 'password'].flatMap(key => data[key] || []).filter(value => typeof value === 'string') : [];
      setError(messages.join(' ') || 'No pudimos completar el ingreso. Intenta nuevamente en unos segundos.');
      if (data?.code) { setPassword(''); setConfirmation(''); setStep('code'); }
    } finally { setBusy(false); }
  }
  const creating = step === 'password';
  const { title, description, submit: actionLabel } = accessSteps[step];
  return (
    <section className="client-access-card" aria-labelledby="client-access-title">
      <div className="client-access-main">
        <header className="client-access-header">
          <h1 id="client-access-title" tabIndex={-1} ref={heading}>{title}</h1>
          {description && <p>{description}</p>}
        </header>
        <div className="client-access-body">
          {(error || (step === 'login' && notice)) && (
            <p role="alert" className="mb-4 rounded-xl bg-rose-50 p-4 text-rose-800">{error || notice}</p>
          )}
          <form onSubmit={submit} className="grid gap-5">
            {(step === 'login' || step === 'activate') && (
              <label>RUT
                <input className={inputClass} value={formatRut(rut)} onChange={event => { setRut(normalizeRut(event.target.value)); setError(''); }} maxLength={12} autoComplete={step === 'login' ? 'username' : 'off'} autoCapitalize="characters" spellCheck={false} placeholder="12.345.678-5" disabled={busy} required />
              </label>
            )}
            {step === 'code' && (
              <label>Código de seis dígitos
                <input className={inputClass} inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={event => setCode(event.target.value.replace(/\D/g, ''))} disabled={busy} required />
              </label>
            )}
            {(step === 'login' || creating) && (
              <div>
                <label>{creating ? 'Crea tu contraseña de primer ingreso' : 'Contraseña'}
                  <input type="password" className={inputClass} autoComplete={creating ? 'new-password' : 'current-password'} minLength={creating ? 8 : undefined} maxLength={128} value={password} onChange={event => setPassword(event.target.value)} required disabled={busy} aria-describedby={creating ? 'client-password-help' : undefined} />
                </label>
                {creating && <p id="client-password-help" className="client-access-help">Usa al menos 8 caracteres. Evita tu RUT y datos fáciles de adivinar.</p>}
              </div>
            )}
            {creating && (
              <label>Confirma tu contraseña
                <input type="password" autoComplete="new-password" className={inputClass} value={confirmation} onChange={event => setConfirmation(event.target.value)} disabled={busy} required minLength={8} maxLength={128} />
              </label>
            )}
            <button type="submit" disabled={busy || (step === 'code' && code.length !== 6)} className="client-access-submit">
              {busy ? 'Procesando…' : actionLabel}
            </button>
          </form>
          {step === 'login' ? (
            <div className="client-access-activation">
              <p>¿Es tu primer ingreso?</p>
              <button type="button" className="client-access-secondary" disabled={busy} onClick={() => { setPassword(''); changeStep('activate'); }}>
                <Mail size={17} aria-hidden="true" /> Activar acceso con código
              </button>
            </div>
          ) : (
            <div className="client-access-step-actions">
              <button type="button" disabled={busy} onClick={creating ? () => { setPassword(''); setConfirmation(''); changeStep('code'); } : reset}>
                <ArrowLeft size={16} aria-hidden="true" /> {creating ? 'Volver al código' : 'Volver a iniciar sesión'}
              </button>
              {step === 'code' && <button type="button" disabled={busy} onClick={() => submit(undefined, 'resend')}>Solicitar otro código</button>}
            </div>
          )}
          <div className="client-access-privacy">
            <LockKeyhole size={18} aria-hidden="true" />
            <div>
              <a href="/privacidad">Privacidad y datos</a>
              <p>Usamos tu RUT para identificar tu cuenta y tu correo para enviarte códigos de acceso.</p>
            </div>
          </div>
        </div>
      </div>
      <aside className="client-access-brand">
        <picture>
          <source media="(min-width: 900px)" srcSet={teamPhoto} />
          <img alt="Equipo de A&J Servicio Automotriz en el taller" width={1093} height={1439} decoding="async" />
        </picture>
      </aside>
    </section>
  );
}
