import { useState } from 'react';

const pageSize = 4;

export default function TrackingParts({ items = [] }) {
  const [requestedPage, setPage] = useState(0);
  const pageCount = Math.ceil(items.length / pageSize);
  const page = Math.min(requestedPage, Math.max(0, pageCount - 1));
  const start = page * pageSize;
  const end = Math.min(start + pageSize, items.length);

  return (
    <section className="portal-card tracking-card" aria-labelledby="tracking-parts-title">
      <div className="tracking-parts-heading">
        <h2 id="tracking-parts-title" className="portal-section-title">Repuestos asociados</h2>
        {items.length > 0 && <span>{items.length} {items.length === 1 ? 'repuesto' : 'repuestos'}</span>}
      </div>
      {items.length > 0 ? (
        <ul className="tracking-parts">
          {items.slice(start, end).map((item, index) => (
            <li key={`${item.item_sku}-${start + index}`}>
              <strong>{item.item_name}</strong>
              <span>Cantidad: {item.quantity}</span>
            </li>
          ))}
        </ul>
      ) : <p className="tracking-empty">Aún no hay repuestos asociados a esta atención.</p>}
      {pageCount > 1 && (
        <nav className="tracking-parts-navigation" aria-label="Páginas de repuestos">
          <span role="status">Mostrando {start + 1}–{end} de {items.length}</span>
          <div>
            <button type="button" className="portal-button" disabled={page === 0} onClick={() => setPage(page - 1)}>Anterior</button>
            <button type="button" className="portal-button" disabled={page === pageCount - 1} onClick={() => setPage(page + 1)}>Siguiente</button>
          </div>
        </nav>
      )}
    </section>
  );
}
