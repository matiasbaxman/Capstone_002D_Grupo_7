import { formatPlate } from '../utils/plateValidation.js';
import { formatRut } from '../utils/rutValidation.js';

export default function ClientLookup({ rut, rutInput, status, client, vehicles = [], error, onRutChange, onSearch, email, onEmailChange, children }) {
  const loading = status === 'loading';
  return <>{!['found', 'new', 'not-found'].includes(status) && <div className={`client-lookup-stage${loading ? ' is-searching' : ''}`}>
    <div className="client-lookup" inert={loading} aria-hidden={loading}>

    <div className="client-search-row"><label><span className="client-field-label"><span>Ingresa el RUT del cliente <span className="client-required" aria-hidden="true">*</span></span></span><span className="client-rut-control"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="8.5" cy="10" r="1.5"/><path d="M6 15c0-2.5 5-2.5 5 0m3-5h4m-4 4h3"/></svg><input ref={rutInput} value={formatRut(rut)} onChange={onRutChange} name="rut" required aria-required="true" aria-invalid={Boolean(error)} aria-errormessage={error ? 'client-search-error' : undefined} placeholder="Ej: 12.345.678-5" maxLength={12} autoComplete="off" spellCheck={false} disabled={loading} aria-describedby="client-search-help" onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); onSearch(); } }} /></span></label><button type="button" className="checkin-next" onClick={onSearch} disabled={loading || !rut}>{status === 'loading' ? 'Buscando…' : status === 'error' ? 'Reintentar' : <><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg>Buscar cliente</>}</button></div>
    <p id="client-search-help" className="checkin-help"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-9v.1"/></svg><span>Buscaremos si el cliente ya está registrado.<br />Si no lo está, podrás agregarlo.</span></p>
    {error && <p id="client-search-error" className="checkin-error" role="alert">{error}</p>}
    </div>
    <div className="client-lookup-loading" role="status" aria-live="polite" aria-atomic="true" aria-hidden={!loading}>
      <span className="client-search-spinner" aria-hidden="true" />
      <h3>Buscando cliente</h3>
      <p>Estamos consultando sus datos en nuestros registros.</p>
      <span className="client-search-rut">{formatRut(rut)}</span>
    </div>
  </div>}
    {status === 'not-found' && <section className="client-not-found" role="status">
      <h3>Cliente no registrado</h3>
      <p>RUT {formatRut(rut)}</p>
    </section>}
    {status === 'found' && <section className="client-result" aria-label="Cliente encontrado"><div className="client-profile-heading"><div><span className="client-status" role="status">Cliente registrado en el sistema</span><h3>{client.firstName} {client.lastName}</h3><p className="client-profile-rut">RUT {formatRut(rut)}</p></div></div><dl className="client-contact-details"><div><dt>Teléfono móvil</dt><dd>{client.phone ? <a href={`tel:${client.phone.replace(/[^+0-9]/g, '')}`}>{client.phone.replace(/^\+?56(9)(\d{4})(\d{4})$/, '+56 $1 $2 $3')}</a> : <span className="client-contact-missing">Sin teléfono registrado</span>}</dd></div><div><dt>Correo electrónico</dt><dd>{client.email ? <a href={`mailto:${client.email}`}>{client.email}</a> : <input type="email" name="email" value={email} onChange={onEmailChange} required maxLength={255} aria-label="Correo electrónico del cliente" placeholder="Ingresa el correo del cliente" />}</dd></div></dl><div className="client-history"><h4>Historial en el taller</h4>{client.history ? <dl><div><dt>Atenciones previas</dt><dd>{client.history ? client.history.attentionCount === 0 ? 'Sin atenciones previas' : client.history.attentionCount : 'No disponible'}</dd></div><div><dt>Última atención</dt><dd>{client.history?.lastAttentionAt ? new Intl.DateTimeFormat('es-CL', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'America/Santiago' }).format(new Date(client.history.lastAttentionAt)) : client.history?.attentionCount === 0 ? 'Aún no registra atenciones' : 'No disponible'}</dd></div></dl> : <p className="client-history-unavailable">No pudimos obtener el historial. Vuelve a buscar al cliente para actualizarlo.</p>}<h4 className="client-vehicles-heading">Vehículos asociados <span>{vehicles.length}</span></h4>{vehicles.length ? <ul className="client-vehicle-list">{vehicles.map((vehicle) => <li key={vehicle.id}><strong>{formatPlate(vehicle.plate)}</strong>{vehicle.label && <span>{vehicle.label}</span>}</li>)}</ul> : <p>Sin vehículos asociados. Podrás agregar uno al continuar.</p>}</div><p className="client-profile-note">La orden quedará asociada al historial de este cliente.</p></section>}
    {status === 'new' && <section className="client-registration"><div className="client-new-header" role="status"><h3>Datos del nuevo cliente</h3><p>Recibirá las instrucciones de acceso por correo al confirmar la orden.</p></div>{children}</section>}
  </>;
}
