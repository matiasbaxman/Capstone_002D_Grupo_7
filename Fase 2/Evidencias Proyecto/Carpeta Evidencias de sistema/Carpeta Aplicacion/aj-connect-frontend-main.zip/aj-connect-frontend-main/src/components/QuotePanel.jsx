import { useEffect, useState } from 'react';
import { createQuote, emailQuote, getEmailDelivery, listQuotes, listQuoteServices } from '../api/workshop.js';
import { formatDateTime } from '../utils/format.js';
import PdfPreview from './PdfPreview.jsx';

const errorText = err => err.response?.data ? Object.values(err.response.data).flat().join(' ') : 'No pudimos conectar. Intenta nuevamente.';
const moneyFormatter = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 2 });
const formatMoney = value => moneyFormatter.format(Number(value));
const quoteFolio = quote => `COT-${quote.id.slice(0, 8).toUpperCase()}`;

function QuoteActions({ quote, onPreview, onSend, sendDisabled }) {
  return (
    <div className="ot-quote-actions">
      <button type="button" className="ot-button" onClick={() => onPreview(quote)}>Ver cotización PDF</button>
      <button type="button" className="ot-button" disabled={sendDisabled} onClick={() => onSend(quote)}>
        Enviar por correo
      </button>
    </div>
  );
}

function QuoteBreakdown({ quote }) {
  const lines = quote.items || [];
  const rows = quote.service_name ? [{
    id: 'service',
    item_name: `Servicio: ${quote.service_name}`,
    quantity: 1,
    unit_price: quote.service_amount,
    subtotal: quote.service_amount,
  }, ...lines] : lines;

  return (
    <>
      {rows.length ? (
        <div className="ot-quote-table-wrap">
          <table className="ot-quote-table" role="table" aria-label={`Detalle de ${quoteFolio(quote)}`}>
            <thead role="rowgroup">
              <tr role="row">
                <th role="columnheader" scope="col">Concepto</th>
                <th role="columnheader" scope="col">Cantidad</th>
                <th role="columnheader" scope="col">Precio unitario neto</th>
                <th role="columnheader" scope="col">Importe neto</th>
              </tr>
            </thead>
            <tbody role="rowgroup">
              {rows.map(item => (
                <tr key={item.id} role="row">
                  <td role="cell">
                    {item.item_name}
                    {item.brand_name && <small className="mt-1 block text-xs text-[var(--muted)]">{item.brand_name}</small>}
                  </td>
                  <td role="cell"><span className="ot-quote-mobile-label" aria-hidden="true">Cantidad </span>{item.quantity}</td>
                  <td role="cell"><span className="ot-quote-mobile-label" aria-hidden="true">Unitario neto </span>{formatMoney(item.unit_price)}</td>
                  <td role="cell"><span className="ot-quote-mobile-label" aria-hidden="true">Neto </span>{formatMoney(item.subtotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <p className="ot-help">Esta cotización no tiene un desglose disponible.</p>}
      <dl className="ot-quote-totals">
        <div><dt>Subtotal neto</dt><dd>{formatMoney(quote.subtotal_amount)}</dd></div>
        <div><dt>IVA ({Number(quote.tax_rate)} %)</dt><dd>{formatMoney(quote.tax_amount)}</dd></div>
        <div className="ot-quote-total"><dt>Total</dt><dd>{formatMoney(quote.total_amount)}</dd></div>
      </dl>
    </>
  );
}

export default function QuotePanel({ order }) {
  const [quotes, setQuotes] = useState(null);
  const [serviceOptions, setServiceOptions] = useState(null);
  const [serviceSelection, setServiceSelection] = useState(null);
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(null);
  const [delivery, setDelivery] = useState(null);
  useEffect(() => {
    const controller = new AbortController();
    Promise.all([listQuotes(order.id, controller.signal), listQuoteServices(order.id, controller.signal)])
      .then(([rows, options]) => {
        if (controller.signal.aborted) return;
        setQuotes(rows);
        setServiceOptions(options);
      })
      .catch(err => { if (!controller.signal.aborted) setError(errorText(err)); });
    return () => controller.abort();
  }, [order.id, attempt]);
  useEffect(() => {
    if (!delivery || ['SENT', 'FAILED'].includes(delivery.status)) return;
    const controller = new AbortController();
    const interval = setInterval(() => {
      getEmailDelivery(delivery.id, controller.signal).then(row => { if (!controller.signal.aborted) setDelivery(row); }).catch(err => { if (!controller.signal.aborted) setError(errorText(err)); });
    }, 3000);
    return () => { controller.abort(); clearInterval(interval); };
  }, [delivery]);
  async function generate() {
    if (busy) return;
    setBusy(true); setError('');
    try {
      const row = await createQuote(order.id, {
        service: serviceId ? Number(serviceId) : null,
        ...(serviceId && description.trim() ? { service_description: description.trim() } : {}),
      });
      setQuotes(current => [row, ...(current || [])]);
    }
    catch (err) { setError(errorText(err)); }
    finally { setBusy(false); }
  }
  async function send(quote) {
    if (busy) return;
    setBusy(true); setError('');
    try { setDelivery(await emailQuote(quote.id)); }
    catch (err) { setError(errorText(err)); }
    finally { setBusy(false); }
  }
  const [latest, ...previousQuotes] = quotes || [];
  const serviceId = serviceSelection ?? String(serviceOptions?.default_service_id ?? '');
  const sendDisabled = busy || Boolean(delivery && !['SENT', 'FAILED'].includes(delivery.status));
  const actions = { onPreview: setPreview, onSend: send, sendDisabled };

  return (
    <section className="ot-card">
      <header>
        <h2>Cotizaciones</h2>
        <button className="ot-button primary" type="button" disabled={busy || !serviceOptions || quotes === null || (!serviceId && !order.parts?.length)} onClick={generate}>
          Generar cotización
        </button>
      </header>
      <div className="ot-card-body">
        {error && (
          <div className="ot-error" role="alert">
            <p>{error}</p>
            {quotes === null && <button type="button" className="ot-button" onClick={() => { setError(''); setAttempt(n => n + 1); }}>Reintentar</button>}
          </div>
        )}
        {quotes === null && !error && <p role="status">Cargando cotizaciones…</p>}
        {serviceOptions?.services.length > 0 && (
          <div className="ot-quote-service">
            <label>
              <span className="ot-help">Servicio para la próxima cotización</span>
              <select className="ot-input" value={serviceId} disabled={busy} onChange={event => {
                setServiceSelection(event.target.value);
                setDescription('');
              }}>
                <option value="">Sin servicio</option>
                {serviceOptions.services.map(service => (
                  <option key={service.id} value={service.id}>{service.name} · {formatMoney(service.base_price)} neto</option>
                ))}
              </select>
            </label>
            {serviceId && (
              <label>
                <span className="ot-help">Detalle del trabajo (opcional)</span>
                <input className="ot-input" maxLength={96} value={description} disabled={busy}
                  placeholder="Ej. Revisión del tren delantero" onChange={event => setDescription(event.target.value)} />
              </label>
            )}
          </div>
        )}
        {quotes?.length === 0 && <p>Aún no hay cotizaciones. Selecciona un servicio o agrega repuestos para generar una.</p>}
        {latest && (
          <div className="ot-quote-latest">
            <div className="ot-quote-heading">
              <h3>{quoteFolio(latest)}</h3>
              <time dateTime={latest.created_at}>{formatDateTime(latest.created_at)}</time>
            </div>
            <QuoteBreakdown quote={latest} />
            <QuoteActions quote={latest} {...actions} />
          </div>
        )}
        {previousQuotes.length > 0 && (
          <details className="ot-quote-history">
            <summary>Ver historial <span>{previousQuotes.length}</span></summary>
            <ul>
              {previousQuotes.map(quote => (
                <li key={quote.id}>
                  <div className="ot-quote-heading">
                    <div>
                      <h3>{quoteFolio(quote)}</h3>
                      <time dateTime={quote.created_at}>{formatDateTime(quote.created_at)}</time>
                    </div>
                    <strong>{formatMoney(quote.total_amount)}</strong>
                  </div>
                  <QuoteActions quote={quote} {...actions} />
                </li>
              ))}
            </ul>
          </details>
        )}
        {delivery && (
          <p role="status" className="ot-help ot-quote-delivery">
            {delivery.status === 'SENT' ? 'Cotización enviada por correo.'
              : delivery.status === 'FAILED' ? 'No se pudo enviar la cotización. Verifica el correo del cliente y vuelve a intentarlo.'
                : 'Envío programado. Te mostraremos el resultado cuando termine.'}
          </p>
        )}
      </div>
      {preview && <PdfPreview quote={preview} onClose={() => setPreview(null)} />}
    </section>
  );
}
