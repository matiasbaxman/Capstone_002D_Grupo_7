import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

function PhotoPreview({ photo, onClose }) {
  const dialog = useRef(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const panel = dialog.current;
    panel.showModal();
    return () => panel.close();
  }, []);

  return createPortal(
    <dialog
      ref={dialog}
      className="ot-photo-preview admin-modal-layer"
      aria-labelledby="ot-photo-title"
      onCancel={(event) => { event.preventDefault(); onClose(); }}
      onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}
    >
      <div className="ot-photo-panel">
        <header>
          <h2 id="ot-photo-title">{photo.label}</h2>
          <button type="button" className="ot-button" onClick={onClose}>Cerrar</button>
        </header>
        {failed
          ? <p role="alert">No se pudo mostrar la fotografía.</p>
          : <img src={photo.url} alt={photo.label} onError={() => setFailed(true)} />}
      </div>
    </dialog>,
    document.body,
  );
}

export default function WorkOrderPhotos({ photos }) {
  const [selected, setSelected] = useState(null);
  if (!photos?.length) return null;

  return <>
    <div className="ot-gallery">
      {photos.map((photo, index) => {
        const label = `Fotografía de ingreso ${index + 1}`;
        return (
          <button key={photo.id} type="button" aria-label={`Ver ${label.toLowerCase()}`} onClick={() => setSelected({ url: photo.url, label })}>
            <img src={photo.url} alt="" loading="lazy" />
          </button>
        );
      })}
    </div>
    {selected && <PhotoPreview photo={selected} onClose={() => setSelected(null)} />}
  </>;
}
