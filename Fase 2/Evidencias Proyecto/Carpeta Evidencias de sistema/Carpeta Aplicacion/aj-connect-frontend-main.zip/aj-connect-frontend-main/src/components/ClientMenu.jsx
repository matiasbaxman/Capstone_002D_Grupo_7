import { useEffect, useRef, useState } from 'react';
import { clearClientSession, getClientSession, getClientAccount } from '../api/clientAuth.js';
export default function ClientMenu() {
  const [client, setClient] = useState(null);
  const menu = useRef(null);
  useEffect(() => {
    let version = 0;
    let timer;
    const sync = () => {
      const current = ++version;
      clearTimeout(timer);
      const session = getClientSession();
      if (!session) { setClient(null); return; }
      timer = setTimeout(sync, Math.max(0, session.expiresAt - Date.now()));
      getClientAccount().then(data => { if (current === version) setClient(data.client); }).catch(() => { if (current === version) setClient(null); });
    };
    sync(); window.addEventListener('aj-client-session', sync);
    return () => { ++version; clearTimeout(timer); window.removeEventListener('aj-client-session', sync); };
  }, []);
  if (!client) return <a href="/cliente">Iniciar sesión</a>;
  function closeMenu() {
    menu.current.open = false;
  }

  return (
    <details className="client-menu" ref={menu}>
      <summary>{[client.first_name, client.last_name].filter(Boolean).join(' ')} ▾</summary>
      <nav aria-label="Mi cuenta">
        <a href="/cliente#datos" onClick={closeMenu}>Datos personales</a>
        <a href="/cliente#atenciones" onClick={closeMenu}>Atenciones</a>
        <button type="button" onClick={() => { closeMenu(); clearClientSession(); window.location.assign('/'); }}>
          Cerrar sesión
        </button>
      </nav>
    </details>
  );
}
