import { useLayoutEffect, useRef, useState } from 'react';
import { ArrowUpRight, Play } from 'lucide-react';

const instagramOrigin = 'https://www.instagram.com';
const reelUrl = `${instagramOrigin}/reel/DYE92ErOErB/`;
const embedTimeout = 10000;

export default function InstagramReel() {
  const frame = useRef(null);
  const [status, setStatus] = useState('loading');

  useLayoutEffect(() => {
    const timeout = window.setTimeout(() => {
      stopListening();
      setStatus('unavailable');
    }, embedTimeout);

    function stopListening() {
      window.clearTimeout(timeout);
      window.removeEventListener('message', onMessage);
    }

    function onMessage(event) {
      if (!frame.current || event.source !== frame.current.contentWindow || event.origin !== instagramOrigin) return;

      let message = event.data;
      if (typeof message === 'string') {
        try {
          message = JSON.parse(message);
        } catch {
          return;
        }
      }

      // El iframe también puede disparar load cuando el navegador lo bloquea.
      // El embed de Instagram envía MEASURE después de renderizar su contenido.
      const height = message?.details?.height;
      if (message?.type !== 'MEASURE' || !Number.isFinite(height) || height <= 0) return;
      stopListening();
      setStatus('ready');
    }

    window.addEventListener('message', onMessage);
    return stopListening;
  }, []);

  const ready = status === 'ready';
  return (
    <div className="storefront-social-mark">
      {!ready && (
        <a className="storefront-social-link storefront-reel-link" href={reelUrl} target="_blank" rel="noopener noreferrer">
          <Play size={18} aria-hidden="true" />
          Ver reel en Instagram
          <ArrowUpRight size={16} aria-hidden="true" />
          <span className="storefront-sr-only"> (se abre en una pestaña nueva)</span>
        </a>
      )}
      {status !== 'unavailable' && (
        <div className={`storefront-reel-frame${ready ? '' : ' storefront-reel-frame--pending'}`} aria-hidden={!ready || undefined} inert={!ready || undefined}>
          <iframe ref={frame} title="Reel de A&J Servicio Automotriz" src={`${reelUrl}embed/`} scrolling="no" allow="encrypted-media; picture-in-picture" />
        </div>
      )}
    </div>
  );
}
