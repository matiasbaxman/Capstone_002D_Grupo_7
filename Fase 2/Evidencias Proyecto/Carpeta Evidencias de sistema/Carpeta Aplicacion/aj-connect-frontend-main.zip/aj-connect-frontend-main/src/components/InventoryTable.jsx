const currency = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
});

// Tailwind v4 solo detecta clases escritas como literales en el código, por
// eso la alineación se resuelve con este mapa y no con `text-${alineado}`.
const alineaciones = {
  left: 'text-left',
  right: 'text-right',
};

function ColumnaOrdenable({ campo, etiqueta, ordering, onOrdenChange, alineado = 'left' }) {
  const activa = ordering === campo || ordering === `-${campo}`;
  const descendente = ordering === `-${campo}`;

  return (
    <th scope="col" className={`px-4 py-3 ${alineaciones[alineado]} font-semibold`}>
      <button
        type="button"
        onClick={() => onOrdenChange(descendente ? campo : `-${campo}`)}
        className={`inline-flex items-center gap-1 uppercase tracking-wide transition hover:text-[var(--accent)] ${
          alineado === 'right' ? 'flex-row-reverse' : ''
        }`}
      >
        {etiqueta}
        <span className={activa ? 'text-[var(--accent)]' : 'text-[var(--muted)]'}>
          {descendente ? '↓' : '↑'}
        </span>
      </button>
    </th>
  );
}

export default function InventoryTable({ items, ordering, onOrdenChange, onEditar }) {
  return (
    <div role="region" aria-label="Tabla de insumos" tabIndex={0} className="admin-table-scroll rounded-xl border border-[var(--line)] bg-[var(--surface)]">
      <table className="inventory-data-table w-full text-left text-sm">
        <thead className="border-b border-[var(--line)] bg-[var(--chrome)] text-xs text-[var(--muted)]">
          <tr>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              SKU
            </th>
            <ColumnaOrdenable
              campo="name"
              etiqueta="Insumo"
              ordering={ordering}
              onOrdenChange={onOrdenChange}
            />
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Categoría
            </th>
            <ColumnaOrdenable
              campo="unit_price"
              etiqueta="Precio"
              ordering={ordering}
              onOrdenChange={onOrdenChange}
              alineado="right"
            />
            <ColumnaOrdenable
              campo="current_stock"
              etiqueta="Stock"
              ordering={ordering}
              onOrdenChange={onOrdenChange}
              alineado="right"
            />
            <th scope="col" className="px-4 py-3 text-right font-semibold uppercase tracking-wide">
              Mín.
            </th>
            <th scope="col" className="px-4 py-3 font-semibold uppercase tracking-wide">
              Estado
            </th>
            <th scope="col" className="px-4 py-3 text-right font-semibold uppercase tracking-wide">
              Acciones
            </th>
          </tr>
        </thead>

        <tbody className="divide-y divide-[var(--line)]">
          {items.length === 0 ? (
            <tr>
              <td colSpan={8} className="px-4 py-12 text-center text-[var(--muted)]">
                Sin resultados
              </td>
            </tr>
          ) : (
            items.map((item) => (
              <tr key={item.id} className="transition hover:bg-[var(--chrome)]">
                <td className="px-4 py-3 font-mono text-xs text-[var(--muted)]">{item.sku}</td>

                <td className="px-4 py-3">
                  <p className="font-medium text-[var(--ink)]">{item.name}</p>
                  <p className="mt-0.5 text-xs text-[var(--muted)]">{item.brand_name || 'Marca por identificar'}</p>
                  {item.description ? (
                    <p className="mt-0.5 max-w-xs truncate text-xs text-[var(--muted)]">
                      {item.description}
                    </p>
                  ) : null}
                </td>

                <td className="px-4 py-3 text-[var(--muted)]">{item.category_name}</td>

                <td className="px-4 py-3 text-right tabular-nums text-[var(--ink)]">
                  {currency.format(Number(item.unit_price))}
                </td>

                <td className="px-4 py-3 text-right tabular-nums font-semibold text-[var(--ink)]">
                  {item.current_stock}
                </td>

                <td className="px-4 py-3 text-right tabular-nums text-[var(--muted)]">
                  {item.minimum_stock}
                </td>

                <td className="px-4 py-3">
                  <span
                    className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${
                      item.is_low_stock
                        ? 'border-amber-500/30 bg-amber-500/10 text-[var(--warning)]'
                        : 'border-emerald-500/30 bg-[var(--active)] text-[var(--accent)]'
                    }`}
                  >
                    {item.is_low_stock ? 'Stock bajo' : 'Stock ok'}
                  </span>
                </td>

                <td className="px-4 py-3 text-right">
                  {onEditar ? (
                    <button
                      type="button"
                      onClick={() => onEditar(item)}
                      className="category-action"
                    >
                      Editar
                    </button>
                  ) : (
                    <span className="text-xs text-[var(--muted)]">—</span>
                  )}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
