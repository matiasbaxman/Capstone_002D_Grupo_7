// FIFO queue: only visible messages consume their reading time.
export function createToastStore({ now = Date.now, schedule = setTimeout, cancel = clearTimeout, exitDuration = 0 } = {}) {
  let entries = [];
  let limit = 3;
  let nextId = 0;
  const listeners = new Set();
  const globalPauses = new Set(['unmounted']);
  let snapshot = { visible: [], pending: 0 };

  function stop(entry) {
    if (entry.timer === null) return;
    cancel(entry.timer);
    entry.remaining = Math.max(0, entry.remaining - (now() - entry.startedAt));
    entry.timer = null;
  }

  function sync() {
    entries.forEach((entry, index) => {
      if (entry.leaving) {
        stop(entry);
        if (globalPauses.size) {
          cancel(entry.exitTimer);
          entry.exitTimer = null;
        } else if (entry.exitTimer === null) {
          entry.exitTimer = schedule(() => remove(entry.id), exitDuration);
        }
        return;
      }
      if (index >= limit || globalPauses.size || entry.pauses.size) stop(entry);
      else if (entry.duration > 0 && entry.timer === null) {
        entry.startedAt = now();
        entry.timer = schedule(() => dismiss(entry.id), entry.remaining);
      }
    });
    snapshot = { visible: entries.slice(0, limit), pending: Math.max(0, entries.length - limit) };
    listeners.forEach((listener) => listener());
  }

  function remove(id) {
    const entry = entries.find((item) => item.id === id);
    if (!entry) return;
    stop(entry);
    cancel(entry.exitTimer);
    entries = entries.filter((item) => item.id !== id);
    sync();
  }

  function dismiss(id) {
    const index = entries.findIndex((item) => item.id === id);
    const entry = entries[index];
    if (!entry || entry.leaving) return;
    if (!exitDuration || index >= limit) { remove(id); return; }
    stop(entry);
    entry.leaving = true;
    sync();
  }

  function notify(type, message, options = {}) {
    if (typeof message !== 'string' || !message.trim()) return null;
    message = message.trim();
    const description = typeof options.description === 'string' ? options.description.trim() : '';
    const action = options.action;
    const duplicate = entries.find((entry) => !entry.leaving && entry.type === type && entry.message === message && entry.description === description && entry.action?.href === action?.href);
    if (duplicate) return duplicate.id;
    const fallback = type === 'error' || type === 'warning' ? 0 : 6000;
    const duration = Number.isFinite(options.duration) && options.duration >= 0 ? options.duration : fallback;
    const entry = { id: ++nextId, type, message, description, action, icon: options.icon, duration, remaining: duration, timer: null, exitTimer: null, leaving: false, startedAt: 0, pauses: new Set() };
    entries = [...entries, entry];
    sync();
    return entry.id;
  }

  return {
    notify,
    dismiss,
    getSnapshot: () => snapshot,
    subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
    setLimit(value) { limit = value; sync(); },
    pause(id, reason, paused) {
      const entry = entries.find((item) => item.id === id);
      if (!entry) return;
      if (paused) entry.pauses.add(reason);
      else entry.pauses.delete(reason);
      sync();
    },
    pauseAll(reason, paused) {
      if (paused) globalPauses.add(reason);
      else globalPauses.delete(reason);
      sync();
    },
  };
}
