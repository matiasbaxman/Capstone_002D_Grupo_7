import { useState } from 'react';
import { Cog } from 'lucide-react';
import '../pages/Catalog.css';

export function CatalogImage({ src, title }) {
  const [failed, setFailed] = useState(null);

  return (
    <div className="catalog-image">
      {src && failed !== src
        ? <img src={src} alt={title} loading="lazy" onError={() => setFailed(src)} />
        : <Cog size={44} strokeWidth={1.25} aria-hidden="true" />}
    </div>
  );
}

export function CatalogFilters({ search, setSearch, category, setCategory, categories }) {
  return (
    <div className="catalog-filters">
      <label>
        <span>Buscar insumos</span>
        <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Nombre, marca o SKU" />
      </label>
      <label>
        <span>Categoría</span>
        <select value={category} onChange={(event) => setCategory(event.target.value)}>
          <option value="">Todas las categorías</option>
          {categories.map((name) => <option key={name} value={name}>{name}</option>)}
        </select>
      </label>
    </div>
  );
}
