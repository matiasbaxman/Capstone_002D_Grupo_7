import { useState } from 'react';
import { requestProfileChange, confirmProfileChange } from '../api/clientAuth.js';
import { formatRut } from '../utils/rutValidation.js';
import { formatPhone } from '../utils/phone.js';

const fields = [
  ['first_name', 'Nombre', 'text', 100, 'given-name'],
  ['last_name', 'Apellido', 'text', 100, 'family-name'],
  ['email', 'Correo electrónico', 'email', 255, 'email'],
  ['phone', 'Teléfono', 'tel', 20, 'tel'],
];

const profileForm = client => ({
  first_name: client.first_name || '',
  last_name: client.last_name || '',
  email: client.email || '',
  phone: client.phone || '',
});

export default function ClientProfile({ client, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState(() => profileForm(client));
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  function closeEditor() {
    setEditing(false);
    setSent(false);
    setCode('');
  }

  async function submit(event) {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setMessage('');
    try {
      const result = sent ? await confirmProfileChange(code) : await requestProfileChange(form);
      setMessage(result.detail);
      if (sent) {
        closeEditor();
        onSaved();
      } else {
        setSent(true);
      }
    } catch (error) {
      const data = error.response?.data;
      setMessage(data && typeof data === 'object' ? Object.values(data).flat().join(' ') : 'No pudimos guardar los cambios. Intenta nuevamente.');
    } finally {
      setBusy(false);
    }
  }

  const details = [
    ['Nombre', client.first_name],
    ['Apellido', client.last_name],
    ['RUT', formatRut(client.rut || '')],
    ['Teléfono', formatPhone(client.phone || '')],
    ['Correo electrónico', client.email],
  ];

  return (
    <section className="portal-card account-profile" aria-labelledby="profile-title">
      <header className="account-profile-header">
        <h2 id="profile-title" className="portal-section-title">Datos personales</h2>
        {!editing && (
          <button className="portal-button portal-button-primary" type="button" onClick={() => {
            setForm(profileForm(client));
            setEditing(true);
            setMessage('');
          }}>
            Modificar datos
          </button>
        )}
      </header>
      {message && <p role="status" className="account-profile-message">{message}</p>}
      {editing ? (
        <form onSubmit={submit} className="account-profile-form">
          <p>Para guardar los cambios enviaremos un código a tu correo actual registrado.</p>
          <div className="account-profile-grid">
            {fields.map(([key, label, type, maxLength, autoComplete]) => (
              <label key={key}>
                {label}{key === 'phone' && <span> Opcional</span>}
                <input type={type} maxLength={maxLength} autoComplete={autoComplete} value={form[key]}
                  required={key !== 'phone'} disabled={sent || busy}
                  onChange={event => setForm({ ...form, [key]: event.target.value })}
                  placeholder={key === 'phone' ? '+56912345678' : undefined} />
              </label>
            ))}
          </div>
          {sent && (
            <label>Código de autorización
              <input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6}
                required value={code} onChange={event => setCode(event.target.value.replace(/\D/g, ''))} />
            </label>
          )}
          <div className="account-profile-actions">
            <button type="button" className="portal-button" disabled={busy} onClick={() => { closeEditor(); setMessage(''); }}>Cancelar</button>
            <button className="portal-button portal-button-primary" disabled={busy}>
              {busy ? 'Procesando…' : sent ? 'Confirmar cambios' : 'Enviar código para guardar'}
            </button>
          </div>
        </form>
      ) : (
        <dl className="account-profile-grid">
          {details.map(([label, value]) => (
            <div key={label}><dt>{label}</dt><dd>{value || 'No indicado'}</dd></div>
          ))}
        </dl>
      )}
    </section>
  );
}
