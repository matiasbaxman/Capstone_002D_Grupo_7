import { useEffect, useRef, useState } from 'react';
import { Bot, MessageCircle, Send, X } from 'lucide-react';
import api from '../api/axiosConfig.js';
import './ChatbotWidget.css';

const endpoint = import.meta.env.VITE_CHAT_API_PATH || '/assistant/chat/';
const greeting = { role: 'assistant', content: '¡Hola! Soy el asistente de A&J Servicio Automotriz. ¿En qué puedo ayudarte?' };

function responseText(data) {
  const result = data?.reply ?? data?.response ?? data?.message ?? data?.answer;
  return typeof result === 'string' ? result : result?.content || result?.text || '';
}

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([greeting]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const listRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) {
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
      inputRef.current?.focus();
    }
  }, [open, messages, sending]);

  async function sendMessage(event) {
    event.preventDefault();
    const content = draft.trim();
    if (!content || sending) return;
    const userMessage = { role: 'user', content };
    setMessages((current) => [...current, userMessage]);
    setDraft('');
    setSending(true);
    setError('');
    try {
      const { data } = await api.post(endpoint, { message: content }, { skipAuth: true });
      const reply = responseText(data);
      if (!reply) throw new Error('empty-response');
      setMessages((current) => [...current, { role: 'assistant', content: reply }]);
    } catch (requestError) {
      const data = requestError.response?.data;
      const fallback = responseText(data) || data?.error;
      if (fallback) {
        setMessages((current) => [...current, { role: 'assistant', content: fallback }]);
        setError(requestError.response?.status === 503 ? 'El asistente está temporalmente en modo de respuesta alternativa.' : '');
      } else {
        setMessages((current) => [...current, { role: 'assistant', content: 'No pude conectarme en este momento. Inténtalo nuevamente en unos minutos o contáctanos directamente.' }]);
        setError('No se pudo conectar con el asistente.');
      }
    } finally {
      setSending(false);
    }
  }

  return <div className="chatbot-widget">
    {open && <section className="chatbot-panel" aria-label="Chat con el asistente A&J">
      <header className="chatbot-header"><span className="chatbot-avatar"><Bot size={20} /></span><div><strong>Asistente A&J</strong><span className="chatbot-status"><i /> Disponible para ayudarte</span></div><button type="button" className="chatbot-close" aria-label="Cerrar chat" onClick={() => setOpen(false)}><X size={19} /></button></header>
      <div className="chatbot-messages" ref={listRef} role="log" aria-live="polite" aria-relevant="additions text">
        {messages.map((message, index) => <div className={`chatbot-message chatbot-message-${message.role}`} key={`${index}-${message.role}`}><p>{message.content}</p></div>)}
        {sending && <div className="chatbot-message chatbot-message-assistant"><p className="chatbot-typing"><span /><span /><span /><em>Escribiendo...</em></p></div>}
      </div>
      {error && <p className="chatbot-error" role="status">{error} Puedes volver a intentarlo.</p>}
      <form className="chatbot-form" onSubmit={sendMessage}><label className="chatbot-sr-only" htmlFor="chatbot-input">Escribe tu consulta</label><input id="chatbot-input" ref={inputRef} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Escribe tu consulta..." maxLength={1000} disabled={sending} /><button type="submit" aria-label="Enviar mensaje" disabled={!draft.trim() || sending}><Send size={18} /></button></form>
      <p className="chatbot-caption">Asistente virtual · A&J Servicio Automotriz</p>
    </section>}
    <button type="button" className="chatbot-toggle" aria-label={open ? 'Cerrar asistente virtual' : 'Abrir asistente virtual'} aria-expanded={open} onClick={() => setOpen((value) => !value)}>{open ? <X size={23} /> : <><MessageCircle size={22} /><span>¿Necesitas ayuda?</span></>}</button>
  </div>;
}
