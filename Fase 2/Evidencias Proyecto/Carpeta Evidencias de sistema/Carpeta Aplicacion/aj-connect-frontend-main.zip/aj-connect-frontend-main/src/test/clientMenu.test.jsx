import { beforeEach, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ClientMenu from '../components/ClientMenu.jsx';
import * as auth from '../api/clientAuth.js';
vi.mock('../api/clientAuth.js', () => ({ clearClientSession: vi.fn(), getClientSession: vi.fn(), getClientAccount: vi.fn() }));
beforeEach(() => vi.resetAllMocks());
it('muestra iniciar sesión cuando no hay acceso de cliente', () => {
  auth.getClientSession.mockReturnValue(null);
  render(<ClientMenu />);
  expect(screen.getByRole('link', { name: 'Iniciar sesión' })).toBeVisible();
});
it('muestra nombre y opciones de cuenta cuando la sesión está activa', async () => {
  auth.getClientSession.mockReturnValue({ access: 'client', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana', last_name: 'Perez' } });
  render(<ClientMenu />);
  expect(await screen.findByText('Ana Perez ▾')).toBeVisible();
  expect(screen.queryByRole('link', { name: 'Iniciar sesión' })).not.toBeInTheDocument();
  expect(screen.getByText('Datos personales')).toHaveAttribute('href', '/cliente#datos');
  expect(screen.getByText('Atenciones')).toHaveAttribute('href', '/cliente#atenciones');
  expect(screen.getByText('Cerrar sesión')).toBeInTheDocument();
});

it('cierra el menú al navegar a otra sección de la misma página', async () => {
  const originalUrl = window.location.href;
  window.history.replaceState({}, '', '/cliente#atenciones');
  auth.getClientSession.mockReturnValue({ access: 'client', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana', last_name: 'Perez' } });
  try {
    const user = userEvent.setup();
    render(<ClientMenu />);
    const summary = await screen.findByText('Ana Perez ▾');
    const details = summary.closest('details');
    await user.click(summary);
    expect(details).toHaveAttribute('open');
    await user.click(screen.getByRole('link', { name: 'Datos personales' }));
    expect(details).not.toHaveAttribute('open');
    await waitFor(() => expect(window.location.hash).toBe('#datos'));
    await user.click(summary);
    await user.click(screen.getByRole('link', { name: 'Atenciones' }));
    expect(details).not.toHaveAttribute('open');
    await waitFor(() => expect(window.location.hash).toBe('#atenciones'));
  } finally {
    window.history.replaceState({}, '', originalUrl);
  }
});
