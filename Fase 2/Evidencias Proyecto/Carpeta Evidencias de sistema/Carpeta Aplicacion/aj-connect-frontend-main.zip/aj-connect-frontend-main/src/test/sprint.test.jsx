import { beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ToastProvider from '../components/notifications/ToastProvider.jsx';
import BookingPage from '../pages/BookingPage.jsx';
import Tracking from '../pages/Tracking.jsx';
import AppointmentsAdmin from '../pages/AppointmentsAdmin.jsx';
import QuotePanel from '../components/QuotePanel.jsx';
import * as appointments from '../api/appointments.js';
import * as workshop from '../api/workshop.js';
import axios from 'axios';

vi.mock('../api/appointments.js', () => ({ getPublicServices: vi.fn(), getAppointmentAvailability: vi.fn(), requestBookingVerification: vi.fn(), createPublicAppointment: vi.fn(), listAppointments: vi.fn(), updateAppointment: vi.fn() }));
vi.mock('../api/workshop.js', () => ({ listQuotes: vi.fn(), listQuoteServices: vi.fn(), createQuote: vi.fn(), getQuotePdf: vi.fn(), getWorkOrderPdf: vi.fn(), emailQuote: vi.fn(), getEmailDelivery: vi.fn() }));
vi.mock('../api/axiosConfig.js', () => ({ BACKEND_URL: 'http://qa.test', default: {} }));
vi.mock('axios', () => ({ default: { create: () => ({ get: (...args) => publicGet(...args) }), isCancel: () => false } }));
const publicGet = vi.hoisted(() => vi.fn());
const slot = { start: '2030-01-07T10:00:00-03:00', end: '2030-01-07T11:00:00-03:00', remaining_capacity: 2 };
const quote = {
  id: '12345678-1234-4567-8123-123456789012', created_at: '2030-01-07T10:00:00Z',
  subtotal_amount: '20000.00', tax_rate: '19', tax_amount: '3800.00', total_amount: '23800.00',
  items: [{ id: 'quoted-line', item_name: 'Filtro de aceite', brand_name: 'Marca de prueba', quantity: 2, unit_price: '10000.00', subtotal: '20000.00' }],
};
beforeEach(() => {
  vi.clearAllMocks();
  appointments.getPublicServices.mockResolvedValue([]);
  appointments.getAppointmentAvailability.mockResolvedValue({ slots: [slot] });
  workshop.listQuotes.mockResolvedValue([]);
  workshop.listQuoteServices.mockResolvedValue({ services: [], default_service_id: null });
});

describe('Sprint: recorridos React', () => {
  it.each([
    { rows: [], label: 'Evaluación general' },
    { rows: [{ id: 'frenos', name: 'Frenos' }], label: 'Frenos' },
  ])('permite deseleccionar $label y pide un servicio para avanzar', async ({ rows, label }) => {
    appointments.getPublicServices.mockResolvedValue(rows);
    const user = userEvent.setup();
    render(<BookingPage />);
    const option = await screen.findByRole('button', { name: new RegExp(label) });
    expect(screen.getByRole('button', { name: /Evaluación general/ })).toBeVisible();
    await user.click(option);
    expect(option).toHaveAttribute('aria-pressed', 'true');
    await user.click(option);
    expect(option).toHaveAttribute('aria-pressed', 'false');
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    expect(screen.getByRole('alert')).toHaveTextContent('Selecciona un servicio para continuar.');
    await user.click(option);
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    expect(screen.getByRole('heading', { name: 'Elige fecha y hora' })).toBeVisible();
    expect(screen.getByRole('button', { name: 'Volver' })).not.toHaveClass('portal-button-primary');
    expect(screen.getByRole('button', { name: /Continuar/ })).toHaveClass('portal-button-primary');
  });

  it('reserva por pasos, verifica contacto y muestra una confirmación legible', async () => {
    const user = userEvent.setup();
    appointments.requestBookingVerification.mockResolvedValue({ verification_id: 'verification-qa', detail: 'Código enviado al contacto registrado.' });
    appointments.createPublicAppointment.mockResolvedValue({ id: 'booking-qa', status: 'PENDIENTE' });
    render(<BookingPage />);
    await user.click(await screen.findByRole('button', { name: /Evaluación general/ }));
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    await user.type(screen.getByLabelText('Fecha'), '2030-01-07');
    await user.click(await screen.findByRole('button', { name: /10:00/ }));
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    await user.type(screen.getByLabelText('RUT'), '123456785');
    await user.type(screen.getByLabelText('Correo electrónico'), 'ana@example.test');
    await user.type(screen.getByLabelText('Nombre'), 'Ana');
    await user.type(screen.getByLabelText('Apellido'), 'Perez');
    expect(screen.getByText(/WhatsApp aún no está disponible/)).toBeVisible();
    expect(screen.queryByLabelText(/Patente|Qué problema/)).not.toBeInTheDocument();
    const phone = screen.getByLabelText('Teléfono');
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    expect(phone).toHaveAttribute('aria-invalid', 'true');
    await user.type(phone, '1234567');
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    expect(phone).toHaveAttribute('aria-invalid', 'true');
    await user.type(phone, '8');
    expect(phone).toHaveValue('1234 5678');
    await user.click(screen.getByRole('button', { name: /Continuar/ }));
    await user.click(screen.getByRole('button', { name: /Enviar código de verificación/ }));
    expect(appointments.createPublicAppointment).not.toHaveBeenCalled();
    await user.type(await screen.findByLabelText('Código de seis dígitos'), '012345');
    await user.click(screen.getByRole('button', { name: 'Confirmar agendamiento' }));
    expect(await screen.findByText('¡Gracias, Ana!')).toBeVisible();
    expect(appointments.createPublicAppointment).toHaveBeenCalledWith(expect.objectContaining({ verification_id: 'verification-qa', code: '012345', scheduled_date: slot.start, notification_channel: 'EMAIL', email: 'ana@example.test', phone: '+56912345678' }));
    expect(screen.getByRole('link', { name: 'Volver al inicio' })).toHaveAttribute('href', '/');
  });

  it('presenta acciones claras cuando el código de tracking no existe', async () => {
    publicGet.mockRejectedValue({ response: { status: 404 } });
    render(<Tracking token="AJ222222222222" />);
    expect(await screen.findByRole('heading', { name: 'No pudimos consultar tu orden' })).toBeVisible();
    expect(screen.getByRole('button', { name: 'Intentar de nuevo' })).toBeVisible();
    expect(screen.getByRole('link', { name: 'Ingresar otro código' })).toHaveAttribute('href', '/seguimiento');
    expect(screen.queryByRole('link', { name: /Volver a mis atenciones/ })).not.toBeInTheDocument();
    expect(axios.isCancel({})).toBe(false);
  });

  it('rechaza citas desde administración y valida una fecha vacía sin lanzar excepción', async () => {
    const user = userEvent.setup();
    const row = { id: 'booking-qa', status: 'PENDIENTE', scheduled_date: slot.start, client: { first_name: 'Ana' } };
    appointments.listAppointments.mockResolvedValue([row]);
    appointments.updateAppointment.mockResolvedValue({ ...row, status: 'RECHAZADA' });
    render(<ToastProvider><AppointmentsAdmin /></ToastProvider>);
    await user.click(await screen.findByRole('button', { name: 'Reprogramar' }));
    const dateInput = screen.getByLabelText('Nueva fecha y hora');
    await user.clear(dateInput);
    await user.click(screen.getByRole('button', { name: 'Guardar horario' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Selecciona una fecha y hora válida.');
    expect(appointments.updateAppointment).not.toHaveBeenCalled();
    await user.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Cancelar' }));
    await user.click(screen.getByRole('button', { name: 'Rechazar' }));
    appointments.listAppointments.mockResolvedValue([{ ...row, status: 'RECHAZADA' }]);
    await user.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Rechazar cita' }));
    await waitFor(() => expect(appointments.updateAppointment).toHaveBeenCalledWith('booking-qa', { status: 'RECHAZADA' }));
    expect(await screen.findByText('Rechazada', { selector: 'span' })).toBeVisible();
  });

  it('genera una cotización, usa su endpoint PDF y libera el blob al cerrar', async () => {
    const user = userEvent.setup();
    const previous = { ...quote, id: 'abcdef01-1234-4567-8123-123456789012', created_at: '2030-01-06T10:00:00Z' };
    workshop.listQuotes.mockResolvedValue([previous]);
    workshop.createQuote.mockResolvedValue(quote);
    workshop.getQuotePdf.mockResolvedValue(new Blob(['%PDF-QA'], { type: 'application/pdf' }));
    render(<QuotePanel order={{ id: 'ot-qa', folio: 1001, parts: [{ id: 'part' }] }} />);
    await screen.findByRole('heading', { name: 'COT-ABCDEF01' });
    await user.click(screen.getByRole('button', { name: 'Generar cotización' }));
    const table = await screen.findByRole('table', { name: 'Detalle de COT-12345678' });
    expect(within(table).getByText('Filtro de aceite')).toBeVisible();
    expect(within(table).getByText('Marca de prueba')).toBeVisible();
    const latest = within(table.closest('.ot-quote-latest'));
    expect(latest.getByText('IVA (19 %)')).toBeVisible();
    expect(latest.getByText('$23.800')).toBeVisible();
    const history = screen.getByText(/Ver historial/).closest('details');
    expect(history).not.toHaveAttribute('open');
    await user.click(latest.getByRole('button', { name: 'Ver cotización PDF' }));
    expect(await screen.findByRole('link', { name: 'Descargar PDF' })).toHaveAttribute('download', 'Cotizacion_AJ_12345678.pdf');
    expect(workshop.getQuotePdf).toHaveBeenCalledWith(quote.id, expect.any(AbortSignal));
    expect(workshop.getWorkOrderPdf).not.toHaveBeenCalled();
    await user.click(screen.getByRole('button', { name: 'Cerrar vista previa' }));
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:qa-document');
    await user.click(within(history).getByText(/Ver historial/));
    expect(within(history).getByRole('heading', { name: 'COT-ABCDEF01' })).toBeVisible();
  });

  it('preselecciona el servicio agendado y permite cotizarlo sin repuestos', async () => {
    const user = userEvent.setup();
    workshop.listQuoteServices.mockResolvedValue({
      services: [{ id: 7, name: 'Diagnóstico computarizado', base_price: '25000.00' }], default_service_id: 7,
    });
    workshop.createQuote.mockResolvedValue({
      ...quote, items: [], service_name: 'Diagnóstico computarizado', service_amount: '25000.00',
      subtotal_amount: '25000.00', tax_amount: '4750.00', total_amount: '29750.00',
    });
    render(<QuotePanel order={{ id: 'ot-servicio', parts: [] }} />);
    const service = await screen.findByLabelText('Servicio para la próxima cotización');
    expect(service).toHaveValue('7');
    await user.click(screen.getByRole('button', { name: 'Generar cotización' }));
    expect(workshop.createQuote).toHaveBeenCalledWith('ot-servicio', { service: 7 });
    expect(await screen.findByRole('cell', { name: 'Servicio: Diagnóstico computarizado' })).toBeVisible();
    expect(screen.getByText('$29.750')).toBeVisible();
  });
});
