import { beforeEach, expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import AdminHome from '../pages/AdminHome.jsx';
import { listAllItems } from '../api/inventory.js';
import { getDemandForecast, getWorkshopAnalytics, getWorkshopOverview, requestDemandForecast } from '../api/workshop.js';

vi.mock('../api/inventory.js', () => ({ listAllItems: vi.fn(), mensajeDeError: vi.fn() }));
vi.mock('../api/workshop.js', () => ({
  getDemandForecast: vi.fn(),
  getWorkshopAnalytics: vi.fn(),
  getWorkshopOverview: vi.fn(),
  requestDemandForecast: vi.fn(),
}));

const orders = { total_orders: 8, orders_by_status: { in_progress: 3 }, average_service_time_hours: 2.5 };
const supplies = { total_items_consumed: 7, low_stock_count: 2, top_consumed_parts: [{ name: 'Aceite', quantity: 5 }] };

beforeEach(() => {
  vi.resetAllMocks();
  listAllItems.mockResolvedValue([{ current_stock: 1, minimum_stock: 2 }]);
  getDemandForecast.mockResolvedValue({ has_forecast: false });
});

it.each([
  { roles: { isMecanico: true }, hasOrders: true, hasSupplies: false },
  { roles: { isRecepcionista: true }, hasOrders: false, hasSupplies: true },
  { roles: { isMecanico: true, isRecepcionista: true }, hasOrders: true, hasSupplies: true },
])('muestra los bloques operativos según $roles', async ({ roles, hasOrders, hasSupplies }) => {
  getWorkshopOverview.mockResolvedValue({
    metrics: { ...(hasOrders && orders), ...(hasSupplies && { supplies_summary: supplies }) },
  });
  render(<AdminHome {...roles} />);
  await screen.findByText(hasOrders ? 'Órdenes del período' : 'Insumos consumidos');

  expect(Boolean(screen.queryByRole('heading', { name: 'Estado de órdenes' }))).toBe(hasOrders);
  expect(Boolean(screen.queryByRole('heading', { name: 'Insumos más utilizados' }))).toBe(hasSupplies);
  expect(screen.queryByRole('heading', { name: 'Proyección de demanda' })).not.toBeInTheDocument();
  expect(screen.queryByRole('columnheader', { name: 'Costo registrado' })).not.toBeInTheDocument();
  if (hasSupplies) {
    expect(screen.getByRole('cell', { name: 'Aceite' })).toBeVisible();
    expect(within(screen.getByText('Stock bajo').closest('article')).getByText('2')).toBeVisible();
  }
  expect(getWorkshopOverview).toHaveBeenCalledWith({ period: 'month' });
  expect(getWorkshopAnalytics).not.toHaveBeenCalled();
  expect(listAllItems).not.toHaveBeenCalled();
  expect(getDemandForecast).not.toHaveBeenCalled();
  expect(requestDemandForecast).not.toHaveBeenCalled();
});

it('muestra costos y permite consultar la proyección para Administración', async () => {
  getWorkshopAnalytics.mockResolvedValue({
    metrics: {
      ...orders,
      supplies_summary: { ...supplies, top_consumed_parts: [{ ...supplies.top_consumed_parts[0], total_cost: 10000 }] },
    },
  });
  render(<AdminHome isAdmin />);
  expect(await screen.findByRole('cell', { name: '$10.000' })).toBeVisible();
  expect(screen.getByRole('heading', { name: 'Estado de órdenes' })).toBeVisible();
  expect(screen.getByRole('heading', { name: 'Proyección de demanda' })).toBeVisible();
  expect(getDemandForecast).toHaveBeenCalledWith({ period: 'month', refresh_expired: 'true' });
  expect(getWorkshopOverview).not.toHaveBeenCalled();
});

it('conserva el encabezado para cuentas sin un rol del taller', () => {
  render(<AdminHome />);
  expect(screen.getByRole('heading', { name: 'Resumen del taller' })).toBeVisible();
  expect(screen.queryByLabelText('Período')).not.toBeInTheDocument();
  expect(getWorkshopOverview).not.toHaveBeenCalled();
});
