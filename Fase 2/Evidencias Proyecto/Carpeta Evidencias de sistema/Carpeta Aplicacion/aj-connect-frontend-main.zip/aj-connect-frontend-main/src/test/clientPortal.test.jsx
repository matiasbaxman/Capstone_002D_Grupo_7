import { beforeEach, expect, it, vi } from 'vitest';
import { act, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ClientPortal from '../pages/ClientPortal.jsx';
import * as auth from '../api/clientAuth.js';

vi.mock('../api/clientAuth.js', () => ({ clearClientSession: vi.fn(), getClientSession: vi.fn(), requestClientCode: vi.fn(), verifyClientCode: vi.fn(), getClientAccount: vi.fn(), requestProfileChange: vi.fn(), confirmProfileChange: vi.fn() }));
beforeEach(() => vi.resetAllMocks());

async function requestActivation(user) {
  await user.click(screen.getByRole('button', { name: 'Activar acceso con código' }));
  await user.click(screen.getByRole('button', { name: 'Enviar código' }));
}

it('muestra las acciones de acceso y enlaza a Privacidad y datos debajo de ellas', () => {
  render(<ClientPortal />);
  const activation = screen.getByRole('button', { name: 'Activar acceso con código' });
  const submit = screen.getByRole('button', { name: 'Ingresar' });
  const privacy = screen.getByRole('link', { name: 'Privacidad y datos' });
  expect(submit.compareDocumentPosition(activation) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  expect(privacy).toHaveAttribute('href', '/privacidad');
  expect(activation.compareDocumentPosition(privacy) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
});

it.each([400, 401, 404, 503])('formatea el RUT y muestra solo el error genérico con el estado %i al ingresar sin contraseña', async (status) => {
  const user = userEvent.setup();
  auth.requestClientCode.mockRejectedValue({ response: { status, data: { password: ['Detalle del ingreso.'] } } });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '223456782');
  expect(screen.getByLabelText('RUT')).toHaveValue('22.345.678-2');
  await requestActivation(user);
  expect((await screen.findByRole('alert')).textContent).toBe('Usuario y contraseña incorrectos.');
  expect(auth.requestClientCode).toHaveBeenCalledWith('223456782', '');
  expect(screen.queryByLabelText('Código de seis dígitos')).not.toBeInTheDocument();
  expect(screen.queryByRole('link', { name: 'Agendar una cita' })).not.toBeInTheDocument();
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
});

it('conserva el RUT al elegir activar acceso y exige contraseña para Ingresar', async () => {
  const user = userEvent.setup();
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(auth.requestClientCode).not.toHaveBeenCalled();
  await user.click(screen.getByRole('button', { name: 'Activar acceso con código' }));
  expect(screen.getByLabelText('RUT')).toHaveValue('12.345.678-5');
  expect(screen.queryByLabelText('Contraseña')).not.toBeInTheDocument();
  expect(auth.requestClientCode).not.toHaveBeenCalled();
});

it('normaliza el dígito K, limpia el desafío al cambiar el RUT y conserva el formato al pegar', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({});
  render(<ClientPortal />);
  await user.click(screen.getByLabelText('RUT'));
  await user.paste('21.865.259-k');
  expect(screen.getByLabelText('RUT')).toHaveValue('21.865.259-K');
  await user.clear(screen.getByLabelText('RUT'));
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await requestActivation(user);
  expect(await screen.findByLabelText('Código de seis dígitos')).toBeVisible();
  await user.click(screen.getByRole('button', { name: 'Volver a iniciar sesión' }));
  await user.clear(screen.getByLabelText('RUT'));
  expect(screen.queryByLabelText('Código de seis dígitos')).not.toBeInTheDocument();
});

it('envía al inicio después de activar la cuenta con el primer código', async () => {
  const user = userEvent.setup();
  const goHome = vi.fn();
  auth.requestClientCode.mockResolvedValue({});
  auth.verifyClientCode.mockResolvedValueOnce({ access: 'client-access', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana' }, orders: [] });
  render(<ClientPortal onAuthenticated={goHome} />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await requestActivation(user);
  await user.type(await screen.findByLabelText('Código de seis dígitos'), '012345');
  expect(screen.getByRole('heading', { name: 'Revisa tu correo' })).toBeVisible();
  expect(screen.queryByLabelText('Crea tu contraseña de primer ingreso')).not.toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Continuar' }));
  expect(screen.queryByLabelText('Código de seis dígitos')).not.toBeInTheDocument();
  await user.type(await screen.findByLabelText('Crea tu contraseña de primer ingreso'), 'MotorSeguro!2026');
  await user.type(screen.getByLabelText('Confirma tu contraseña'), 'MotorSeguro!2026');
  await user.click(screen.getByRole('button', { name: 'Crear contraseña e ingresar' }));
  expect(goHome).toHaveBeenCalledOnce();
  expect(auth.verifyClientCode).toHaveBeenLastCalledWith({ rut: '123456785', code: '012345', password: 'MotorSeguro!2026' });
  expect(screen.queryByRole('heading', { name: 'Mis atenciones' })).not.toBeInTheDocument();
});

it('envía al inicio al entrar con RUT y contraseña sin pedir un nuevo código', async () => {
  const user = userEvent.setup();
  const goHome = vi.fn();
  auth.requestClientCode.mockResolvedValue({ access: 'client-access', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana' }, orders: [] });
  render(<ClientPortal onAuthenticated={goHome} />);
  expect(screen.getByLabelText('Contraseña')).toBeVisible();
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.type(screen.getByLabelText('Contraseña'), 'MotorSeguro!2026');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  expect(goHome).toHaveBeenCalledOnce();
  expect(screen.queryByRole('heading', { name: 'Mis atenciones' })).not.toBeInTheDocument();
  expect(auth.requestClientCode).toHaveBeenCalledWith('123456785', 'MotorSeguro!2026');
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
});

it.each([401, 404, 503, 200])('muestra solo el error genérico al ingresar con contraseña y recibir %i sin sesión', async (status) => {
  const user = userEvent.setup();
  if (status === 200) auth.requestClientCode.mockResolvedValue({ detail: 'Código enviado.' });
  else auth.requestClientCode.mockRejectedValue({ response: { status, data: { detail: 'Detalle interno.' } } });
  render(<ClientPortal />);

  await user.type(screen.getByLabelText('RUT'), '123456785');
  await user.type(screen.getByLabelText('Contraseña'), 'incorrecta');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));

  expect((await screen.findByRole('alert')).textContent).toBe('Usuario y contraseña incorrectos.');
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  expect(screen.queryByRole('link', { name: 'Agendar una cita' })).not.toBeInTheDocument();
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
});

it('conserva el paso de verificación al reenviar y vuelve al código si el servidor lo rechaza', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockResolvedValue({});
  auth.verifyClientCode.mockRejectedValue({ response: { status: 400, data: { code: ['El código expiró.'] } } });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await requestActivation(user);
  await user.type(await screen.findByLabelText('Código de seis dígitos'), '012345');
  await user.click(screen.getByRole('button', { name: 'Solicitar otro código' }));
  expect(auth.requestClientCode).toHaveBeenCalledTimes(2);
  expect(screen.getByLabelText('Código de seis dígitos')).toHaveValue('');
  await user.type(screen.getByLabelText('Código de seis dígitos'), '123456');
  await user.click(screen.getByRole('button', { name: 'Continuar' }));
  await user.type(screen.getByLabelText('Crea tu contraseña de primer ingreso'), 'MotorSeguro!2026');
  await user.type(screen.getByLabelText('Confirma tu contraseña'), 'OtraClave!2026');
  await user.click(screen.getByRole('button', { name: 'Crear contraseña e ingresar' }));
  expect(screen.getByRole('alert')).toHaveTextContent('no coinciden');
  expect(auth.verifyClientCode).not.toHaveBeenCalled();
  await user.clear(screen.getByLabelText('Confirma tu contraseña'));
  await user.type(screen.getByLabelText('Confirma tu contraseña'), 'MotorSeguro!2026');
  await user.click(screen.getByRole('button', { name: 'Crear contraseña e ingresar' }));
  expect(await screen.findByRole('alert')).toHaveTextContent('El código expiró.');
  await user.click(screen.getByRole('button', { name: 'Volver a iniciar sesión' }));
  expect(screen.queryByLabelText('Código de seis dígitos')).not.toBeInTheDocument();
  expect(screen.getByRole('button', { name: 'Ingresar' })).toBeVisible();
});

it('muestra un mensaje recuperable en vez del HTML de un error del servidor', async () => {
  const user = userEvent.setup();
  auth.requestClientCode.mockRejectedValue({ response: { status: 500, data: '<html>OperationalError database is locked</html>' } });
  render(<ClientPortal />);
  await user.type(screen.getByLabelText('RUT'), '123456785');
  await requestActivation(user);
  expect(await screen.findByRole('alert')).toHaveTextContent('Usuario y contraseña incorrectos.');
  expect(screen.queryByText(/OperationalError/)).not.toBeInTheDocument();
});

it('separa los datos personales de las citas al cambiar de apartado', async () => {
  auth.getClientSession.mockReturnValue({ access: 'client-access', expiresAt: Date.now() + 60000 });
  auth.getClientAccount.mockResolvedValue({ client: { first_name: 'Ana', last_name: 'Perez', rut: '123456785', email: 'ana@example.test', phone: '' }, orders: [], appointments: [] });
  render(<ClientPortal />);
  expect(await screen.findByText('Aún no tienes atenciones registradas.')).toBeVisible();
  expect(screen.getByRole('link', { name: 'Mis atenciones' })).toHaveAttribute('aria-current', 'page');
  expect(screen.queryByRole('heading', { name: 'Datos personales' })).not.toBeInTheDocument();
  act(() => { window.location.hash = '#datos'; window.dispatchEvent(new Event('hashchange')); });
  expect(await screen.findByRole('heading', { name: 'Datos personales' })).toBeVisible();
  expect(screen.getByRole('link', { name: 'Datos personales' })).toHaveAttribute('aria-current', 'page');
  expect(screen.queryByText('Aún no tienes atenciones registradas.')).not.toBeInTheDocument();
  act(() => { window.location.hash = '#citas'; window.dispatchEvent(new Event('hashchange')); });
});
