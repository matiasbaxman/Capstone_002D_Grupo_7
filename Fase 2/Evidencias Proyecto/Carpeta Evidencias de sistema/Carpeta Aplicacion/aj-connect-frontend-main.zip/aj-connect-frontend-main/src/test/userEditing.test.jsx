import { expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Users from '../pages/Users.jsx';
import * as api from '../api/users.js';

vi.mock('../api/users.js', () => ({
  listUsers: vi.fn(), listRoles: vi.fn(), createUser: vi.fn(), updateUser: vi.fn(),
  parseFieldErrors: vi.fn(), parseGeneralError: vi.fn(),
}));

it('abre la ficha del empleado, cambia el rol y omite la contraseña vacía', async () => {
  const mechanic = { id: 1, code: 'MECANICO', name: 'Mecánico' };
  const receptionist = { id: 2, code: 'RECEPCIONISTA', name: 'Recepcionista' };
  const employee = {
    id: 8, username: 'cmunoz', first_name: 'Carla', last_name: 'Muñoz',
    email: 'carla@example.test', roles_detail: [mechanic], is_active: true,
  };
  api.listRoles.mockResolvedValue([mechanic, receptionist]);
  api.listUsers.mockResolvedValueOnce([employee])
    .mockResolvedValue([{ ...employee, first_name: 'Carolina', roles_detail: [receptionist] }]);
  api.updateUser.mockResolvedValue({});

  const user = userEvent.setup();
  render(<Users />);
  await user.click(await screen.findByRole('button', { name: 'Editar Carla Muñoz' }));
  const dialog = within(screen.getByRole('dialog', { name: 'Editar empleado' }));
  expect(dialog.getByRole('textbox', { name: /^Nombre$/ })).toHaveValue('Carla');
  expect(dialog.getByRole('checkbox', { name: 'Mecánico' })).toBeChecked();

  await user.clear(dialog.getByRole('textbox', { name: /^Nombre$/ }));
  await user.type(dialog.getByRole('textbox', { name: /^Nombre$/ }), 'Carolina');
  await user.click(dialog.getByRole('checkbox', { name: 'Mecánico' }));
  await user.click(dialog.getByRole('checkbox', { name: 'Recepcionista' }));
  await user.click(dialog.getByRole('button', { name: 'Guardar cambios' }));

  expect(await screen.findByRole('button', { name: 'Editar Carolina Muñoz' })).toBeVisible();
  expect(api.updateUser).toHaveBeenCalledWith(8, expect.objectContaining({
    first_name: 'Carolina', username: 'cmunoz', roles: [2],
  }));
  expect(JSON.parse(JSON.stringify(api.updateUser.mock.calls[0][1]))).not.toHaveProperty('password');
  expect(api.createUser).not.toHaveBeenCalled();
});
