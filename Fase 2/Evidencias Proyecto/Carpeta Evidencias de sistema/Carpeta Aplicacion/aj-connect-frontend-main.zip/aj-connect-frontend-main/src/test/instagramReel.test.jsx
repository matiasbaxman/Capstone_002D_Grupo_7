import { act, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import InstagramReel from '../components/InstagramReel.jsx';

const origin = 'https://www.instagram.com';
const reel = `${origin}/reel/DYE92ErOErB/`;
const frameTitle = 'Reel de A&J Servicio Automotriz';

afterEach(() => vi.useRealTimers());

it('conserva el enlace directo y retira el iframe si Instagram no confirma la carga', () => {
  vi.useFakeTimers();
  render(<InstagramReel />);

  const frame = screen.getByTitle(frameTitle);
  const link = screen.getByRole('link', { name: /Ver reel en Instagram/ });
  expect(link).toHaveAttribute('href', reel);
  expect(frame.parentElement).toHaveAttribute('aria-hidden', 'true');
  fireEvent.load(frame);
  expect(frame.parentElement).toHaveAttribute('aria-hidden', 'true');

  act(() => vi.advanceTimersByTime(10000));
  expect(screen.queryByTitle(frameTitle)).not.toBeInTheDocument();
  expect(link).toBeVisible();
});

it('solo revela el reel al recibir una medida válida del iframe de Instagram', () => {
  vi.useFakeTimers();
  render(<InstagramReel />);
  const frame = screen.getByTitle(frameTitle);
  const measure = JSON.stringify({ type: 'MEASURE', details: { height: 600 } });
  function sendMessage(overrides = {}) {
    fireEvent(window, new MessageEvent('message', { origin, source: frame.contentWindow, data: measure, ...overrides }));
  }

  sendMessage({ origin: 'https://example.test' });
  sendMessage({ source: window });
  sendMessage({ data: '{' });
  sendMessage({ data: { type: 'MEASURE', details: { height: 0 } } });
  expect(frame.parentElement).toHaveAttribute('aria-hidden', 'true');

  sendMessage();
  expect(frame.parentElement).not.toHaveAttribute('aria-hidden');
  expect(screen.queryByRole('link', { name: /Ver reel en Instagram/ })).not.toBeInTheDocument();
  act(() => vi.advanceTimersByTime(10000));
  expect(screen.getByTitle(frameTitle)).toBe(frame);
});
