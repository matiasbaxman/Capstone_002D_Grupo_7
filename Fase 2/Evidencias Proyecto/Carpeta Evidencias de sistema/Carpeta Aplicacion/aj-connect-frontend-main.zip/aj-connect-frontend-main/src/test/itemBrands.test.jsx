import { expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from '../App.jsx';
import InventoryModal from '../components/InventoryModal.jsx';
import ToastProvider from '../components/notifications/ToastProvider.jsx';
import { createItemBrand, listCategories, listItemBrands, listItems, updateItem, updateItemBrand } from '../api/inventory.js';
import { saveSession } from '../api/session.js';

vi.mock('../api/inventory.js', async (importOriginal) => ({
  ...await importOriginal(), createItemBrand: vi.fn(), listCategories: vi.fn(), listItemBrands: vi.fn(), listItems: vi.fn(),
  updateItem: vi.fn(), updateItemBrand: vi.fn(),
}));

function openBrandsAsReception() {
  const token = `qa.${btoa(JSON.stringify({ roles: ['Recepcionista'], exp: Date.now() / 1000 + 60 }))}.qa`;
  saveSession({ access: token, refresh: token });
  vi.spyOn(window, 'scrollTo').mockImplementation(() => {});
  window.history.replaceState(null, '', '/dashboard/inventario/marcas');
  render(<ToastProvider><App /></ToastProvider>);
}

it('abre los insumos de la marca elegida y permite volver al inventario completo', async () => {
  const brands = [
    { id: 1, name: 'Bosch', item_count: 1, is_active: true },
    { id: 2, name: 'Marca por identificar', item_count: 1, is_active: true, is_unidentified: true },
  ];
  const items = [
    { id: '1', brand: 1, brand_name: 'Bosch', name: 'Filtro de aceite', sku: 'FIL-1' },
    { id: '2', brand: 2, brand_name: '', name: 'Pastillas de freno', sku: 'FRE-1' },
  ];
  listItemBrands.mockResolvedValue(brands);
  listCategories.mockResolvedValue([]);
  listItems.mockImplementation(async ({ brand }) => items.filter((item) => !brand || String(item.brand) === brand));

  const user = userEvent.setup();
  openBrandsAsReception();
  const overview = await screen.findByRole('table', { name: 'Marcas de insumos' });
  expect(within(overview).getByRole('row', { name: /^Bosch 1 Activa/ })).toBeVisible();
  expect(within(overview).getByRole('link', { name: 'Marca por identificar' })).toHaveAttribute('href', '/dashboard/inventario?brand=2');
  expect(within(overview).queryByRole('button', { name: 'Editar Marca por identificar' })).not.toBeInTheDocument();
  await user.type(screen.getByRole('searchbox', { name: 'Buscar marcas' }), 'bosch');
  expect(within(overview).queryByText('Marca por identificar')).not.toBeInTheDocument();
  await user.click(within(overview).getByRole('link', { name: 'Bosch' }));

  expect(await screen.findByText('Filtro de aceite')).toBeVisible();
  expect(screen.queryByText('Pastillas de freno')).not.toBeInTheDocument();
  expect(screen.getByRole('combobox', { name: 'Marca' })).toHaveValue('1');
  expect(listItems).toHaveBeenCalledWith({ brand: '1', ordering: 'name', search: '' });
  await user.click(screen.getByRole('button', { name: 'Limpiar filtros' }));
  expect(await screen.findByText('Pastillas de freno')).toBeVisible();
});

it('crea, edita, archiva y reactiva una marca desde la vista', async () => {
  const brands = [];
  listItemBrands.mockImplementation(async () => [...brands]);
  createItemBrand.mockImplementation(async (name) => {
    const created = { id: 3, name, item_count: 0, is_active: true };
    brands.push(created);
    return created;
  });
  updateItemBrand.mockImplementation(async (id, values) => Object.assign(brands.find((brand) => brand.id === id), values));

  const user = userEvent.setup();
  openBrandsAsReception();
  await user.click(await screen.findByRole('button', { name: /Nueva marca/ }));
  let dialog = screen.getByRole('dialog', { name: 'Nueva marca' });
  await user.click(within(dialog).getByRole('button', { name: 'Crear marca' }));
  expect(within(dialog).getByRole('alert')).toHaveTextContent('Ingresa un nombre');
  await user.type(within(dialog).getByLabelText('Nombre'), 'Valeo{Enter}');
  expect(await screen.findByRole('row', { name: /^Valeo 0 Activa/ })).toBeVisible();
  expect(createItemBrand).toHaveBeenCalledWith('Valeo');
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();

  await user.click(screen.getByRole('button', { name: 'Editar Valeo' }));
  dialog = screen.getByRole('dialog', { name: 'Editar marca' });
  const name = within(dialog).getByLabelText('Nombre');
  await user.clear(name);
  await user.type(name, 'Valeo Pro');
  await user.click(within(dialog).getByRole('button', { name: 'Guardar cambios' }));
  expect(await screen.findByRole('row', { name: /^Valeo Pro 0 Activa/ })).toBeVisible();

  await user.click(screen.getByRole('button', { name: 'Archivar Valeo Pro' }));
  await user.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Archivar' }));
  expect(await screen.findByRole('row', { name: /^Valeo Pro 0 Archivada/ })).toBeVisible();
  await user.selectOptions(screen.getByRole('combobox', { name: 'Estado de la marca' }), 'active');
  expect(screen.queryByRole('link', { name: 'Valeo Pro' })).not.toBeInTheDocument();
  await user.selectOptions(screen.getByRole('combobox', { name: 'Estado de la marca' }), 'archived');
  await user.click(screen.getByRole('button', { name: 'Reactivar Valeo Pro' }));
  await user.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Reactivar' }));
  await user.selectOptions(screen.getByRole('combobox', { name: 'Estado de la marca' }), 'active');
  expect(await screen.findByRole('row', { name: /^Valeo Pro 0 Activa/ })).toBeVisible();
});

it('muestra todas las marcas activas en el selector y conserva la archivada del insumo', async () => {
  const onGuardado = vi.fn();
  listItemBrands.mockResolvedValue([{ id: 1, name: 'Bosch', is_active: true }, { id: 2, name: 'Valeo', is_active: true }]);
  updateItem.mockResolvedValue({});
  const user = userEvent.setup();
  render(<InventoryModal
    item={{ id: 'item-1', sku: 'FILTRO', name: 'Filtro', brand: 3, brand_name: 'Marca antigua', category: 1, unit_price: 100, current_stock: 5, minimum_stock: 2 }}
    categorias={[{ id: 1, name: 'Filtros' }]} onCerrar={vi.fn()} onGuardado={onGuardado} />);
  const brandSelect = screen.getByRole('combobox', { name: /^Marca/ });
  expect(await within(brandSelect).findByRole('option', { name: 'Marca antigua (archivada)' })).toBeVisible();
  expect(brandSelect).toHaveValue('3');
  expect(within(brandSelect).getAllByRole('option').map((option) => option.textContent)).toEqual([
    'Selecciona una marca', 'Bosch', 'Valeo', 'Marca antigua (archivada)',
  ]);
  await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
  expect(updateItem).toHaveBeenCalledWith('item-1', expect.objectContaining({ brand: '3' }));
  await user.selectOptions(brandSelect, 'Valeo');
  await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
  expect(updateItem).toHaveBeenLastCalledWith('item-1', expect.objectContaining({ brand: '2' }));
  expect(onGuardado).toHaveBeenCalledTimes(2);
});
