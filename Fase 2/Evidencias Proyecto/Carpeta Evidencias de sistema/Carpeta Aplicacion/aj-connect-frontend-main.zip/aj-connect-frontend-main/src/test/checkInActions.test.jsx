import { expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ToastProvider from '../components/notifications/ToastProvider.jsx';
import CheckIn from '../pages/CheckIn.jsx';

vi.mock('../utils/compressPhoto.js', () => ({
  compressPhoto: async (file) => file,
  photoSize: () => '1 KB',
}));

const button = (name) => screen.getByRole('button', { name });
const rutInput = () => screen.getByRole('textbox', { name: /Ingresa el RUT/ });

it('muestra Limpiar en el formulario y evita acciones redundantes durante la búsqueda', async () => {
  const lookupClient = vi.fn().mockResolvedValue({ client: null });
  const user = userEvent.setup();
  render(<ToastProvider><CheckIn lookupClient={lookupClient} /></ToastProvider>);
  expect(screen.queryByRole('button', { name: 'Limpiar' })).not.toBeInTheDocument();
  await user.type(rutInput(), '123456785');
  await user.click(button('Buscar cliente'));
  expect(await screen.findByRole('heading', { name: 'Cliente no registrado' })).toBeVisible();
  expect(screen.queryByRole('button', { name: 'Limpiar' })).not.toBeInTheDocument();
  expect(screen.queryByText(/Buscaremos si el cliente/)).not.toBeInTheDocument();
  await user.click(button(/Ingresar cliente al sistema/));
  expect(button('Limpiar')).toBeVisible();
  await user.click(button('Volver'));
  await user.click(button('Buscar por otro RUT'));
  expect(rutInput()).toHaveValue('');
});

it('completa la recepción de un cliente encontrado y abre la OT desde el aviso', async () => {
  const customer = {
    client: { id: 'cliente-1', firstName: 'Ana', lastName: 'Pérez' },
    vehicles: [{ id: 'auto-1', plate: 'BCDF12' }],
  };
  const appointment = { id: 'cita-1', vehicle_id: 'auto-1', scheduled_date: '2030-01-07T10:00:00-03:00', service__name: 'Revisión de frenos' };
  const lookupClient = vi.fn()
    .mockResolvedValueOnce({ ...customer, appointments: [appointment] })
    .mockResolvedValue({ ...customer, appointments: [] });
  const onSubmit = vi.fn().mockResolvedValue({ work_order: { id: 'ot-1', folio_number: 1005 } });
  const onNavigate = vi.fn();
  const user = userEvent.setup();
  render(<ToastProvider><CheckIn lookupClient={lookupClient} onSubmit={onSubmit} onNavigate={onNavigate} /></ToastProvider>);
  await user.type(rutInput(), '123456785');
  await user.click(button('Buscar cliente'));
  await screen.findByRole('button', { name: /Usar este cliente/ });
  expect(button('Volver')).toBeVisible();
  expect(screen.queryByRole('button', { name: 'Limpiar' })).not.toBeInTheDocument();
  await user.type(screen.getByRole('textbox', { name: 'Correo electrónico del cliente' }), 'ana@example.test');
  await user.click(button(/Usar este cliente/));
  await user.selectOptions(screen.getByRole('combobox', { name: /Cita asociada/ }), 'cita-1');
  expect(screen.getByRole('combobox', { name: 'Vehículo registrado' })).toHaveValue('auto-1');
  await user.click(button(/Continuar con este vehículo/));
  expect(button('Limpiar')).toBeVisible();
  await user.click(button(/Continuar a fotografías/));
  await user.click(button(/Confirmar y seguir a fotos/));
  await user.upload(screen.getByLabelText(/Seleccionar fotografías/), new File(['foto'], 'ingreso.jpg', { type: 'image/jpeg' }));
  await user.click(button(/Revisar orden/));
  expect(button('Limpiar')).toBeVisible();
  await user.click(button('Crear orden de trabajo'));
  const notice = within(screen.getByRole('region', { name: 'Mensajes del sistema' }));
  const link = await notice.findByRole('link', { name: 'Ver orden de trabajo' });
  expect(link).toHaveAttribute('href', '/dashboard/ordenes/ot-1');
  expect(onSubmit).toHaveBeenCalledWith(expect.objectContaining({ clientId: 'cliente-1', appointmentId: 'cita-1', vehicleId: 'auto-1', email: 'ana@example.test' }));
  await user.click(link);
  expect(onNavigate).toHaveBeenCalledWith('/dashboard/ordenes/ot-1');

  await user.type(rutInput(), '123456785');
  await user.click(button('Buscar cliente'));
  await screen.findByRole('button', { name: /Usar este cliente/ });
  await user.type(screen.getByRole('textbox', { name: 'Correo electrónico del cliente' }), 'ana@example.test');
  await user.click(button(/Usar este cliente/));
  const remaining = within(screen.getByRole('combobox', { name: /Cita asociada/ }));
  expect(remaining.getAllByRole('option').map((option) => option.textContent)).toEqual(['Ingreso sin cita']);
});
