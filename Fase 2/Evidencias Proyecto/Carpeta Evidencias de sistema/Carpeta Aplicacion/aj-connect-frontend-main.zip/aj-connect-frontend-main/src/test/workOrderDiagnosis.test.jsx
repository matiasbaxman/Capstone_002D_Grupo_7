import { expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import WorkOrderPhotos from '../components/WorkOrderPhotos.jsx';
import ToastProvider from '../components/notifications/ToastProvider.jsx';
import WorkOrders from '../pages/WorkOrders.jsx';

vi.mock('../api/workshop.js', () => ({
  listWorkOrders: vi.fn(),
  getWorkOrder: vi.fn(),
  updateOrderStatus: vi.fn(),
  updateWorkOrder: vi.fn(),
  addOrderPart: vi.fn(),
  listQuotes: vi.fn().mockResolvedValue([]),
  listQuoteServices: vi.fn().mockResolvedValue({ services: [], default_service_id: null }),
  createQuote: vi.fn(),
  getQuotePdf: vi.fn(),
  getWorkOrderPdf: vi.fn(),
  emailQuote: vi.fn(),
  getEmailDelivery: vi.fn(),
}));

const storedOrder = {
  id: 'ot-1', folio: 1001, reportedSymptoms: 'Vibración al frenar',
  aiDiagnosticSuggestion: '• Revisar discos.\n• Inspeccionar bujes.',
  vehicle: { plate: 'BCDF12', label: 'Toyota Yaris' },
  client: { name: 'Cliente de prueba', rut: '123456785', phone: '+56912345678' },
  status: { code: 'RECEPCIONADO', name: 'Recepcionado' },
  history: [], parts: [], allowedStatuses: [],
};

it('vuelve a mostrar el prediagnóstico guardado al reabrir la orden', async () => {
  const loadOrder = vi.fn().mockResolvedValue(storedOrder);
  const view = () => render(
    <ToastProvider><WorkOrders orderId="ot-1" loadOrder={loadOrder} /></ToastProvider>,
  );
  const title = 'Sugerencia orientativa de diagnóstico (IA)';

  const first = view();
  const heading = await screen.findByRole('heading', { name: title });
  const card = within(heading.closest('section'));
  expect(card.getByText(/Revisar discos/).textContent).toBe(storedOrder.aiDiagnosticSuggestion);
  expect(card.getByText(/Sujeta a revisión técnica/)).toBeVisible();
  expect(screen.getByText(storedOrder.reportedSymptoms)).toBeVisible();
  const clientDetails = within(screen.getByRole('heading', { name: 'Vehículo y cliente' }).closest('section'));
  expect(clientDetails.getByText('12.345.678-5')).toBeVisible();
  expect(clientDetails.getByText('+56 9 1234 5678')).toBeVisible();
  first.unmount();

  view();
  expect(await screen.findByRole('heading', { name: title })).toBeVisible();
  expect(loadOrder.mock.calls).toEqual([['ot-1'], ['ot-1']]);
});

it('muestra que falta guardar la sugerencia cuando se registró el motivo de ingreso', async () => {
  const loadOrder = vi.fn().mockResolvedValue({ ...storedOrder, aiDiagnosticSuggestion: null });
  render(<ToastProvider><WorkOrders orderId="ot-1" loadOrder={loadOrder} /></ToastProvider>);
  const heading = await screen.findByRole('heading', { name: 'Sugerencia orientativa de diagnóstico (IA)' });
  expect(within(heading.closest('section')).getByText('Todavía no se guardó una sugerencia para esta orden.')).toBeVisible();
  expect(heading.compareDocumentPosition(screen.getByRole('heading', { name: 'Cotizaciones' })) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  expect(loadOrder.mock.calls).toEqual([['ot-1']]);
});

it('abre la fotografía en un diálogo y permite cerrarlo en la misma página', async () => {
  const user = userEvent.setup();
  const photo = { id: 'foto-1', url: '/api/media/ingreso.jpg' };
  render(<WorkOrderPhotos photos={[photo]} />);
  await user.click(screen.getByRole('button', { name: 'Ver fotografía de ingreso 1' }));
  const preview = within(screen.getByRole('dialog', { name: 'Fotografía de ingreso 1' }));
  expect(preview.getByRole('img')).toHaveAttribute('src', photo.url);
  expect(preview.queryByRole('link')).not.toBeInTheDocument();
  await user.click(preview.getByRole('button', { name: 'Cerrar' }));
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
});
