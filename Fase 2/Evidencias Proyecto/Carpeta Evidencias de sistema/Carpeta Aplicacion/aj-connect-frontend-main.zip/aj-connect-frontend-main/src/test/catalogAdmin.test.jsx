import { expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import CatalogAdmin from '../pages/CatalogAdmin.jsx';
import { listAllItems } from '../api/inventory.js';

vi.mock('../api/inventory.js', () => ({
  listAllItems: vi.fn(),
  mensajeDeError: vi.fn(),
  publishCatalogItems: vi.fn(),
  updateItem: vi.fn(),
}));

it('separa los publicados de los pendientes y conserva la selección al cambiar de apartado', async () => {
  listAllItems.mockResolvedValue([
    { id: 'oil', name: 'Aceite publicado', sku: 'OIL', category_name: 'Lubricantes', is_published: true, unit_price: 1000, current_stock: 10 },
    { id: 'filter', name: 'Filtro pendiente', sku: 'FILTER', category_name: 'Filtros', is_published: false, unit_price: 2000, current_stock: 2 },
  ]);
  const scroll = vi.spyOn(window, 'scrollTo').mockImplementation(() => {});
  try {
    const user = userEvent.setup();
    render(<CatalogAdmin />);
    const published = await screen.findByRole('button', { name: 'Publicados en la Web 1' });
    const pending = screen.getByRole('button', { name: 'Por publicar 1' });
    expect(published).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getByText('Aceite publicado')).toBeVisible();
    expect(screen.queryByText('Filtro pendiente')).not.toBeInTheDocument();

    await user.click(pending);
    expect(pending).toHaveAttribute('aria-pressed', 'true');
    expect(scroll).toHaveBeenCalledWith(0, 0);
    expect(screen.queryByText('Aceite publicado')).not.toBeInTheDocument();
    await user.click(screen.getByRole('checkbox', { name: 'Seleccionar Filtro pendiente' }));
    await user.click(published);
    await user.click(pending);

    expect(screen.getByRole('checkbox', { name: 'Seleccionar Filtro pendiente' })).toBeChecked();
    expect(screen.getByRole('button', { name: 'Publicar seleccionados' })).toBeEnabled();
  } finally {
    scroll.mockRestore();
  }
});
