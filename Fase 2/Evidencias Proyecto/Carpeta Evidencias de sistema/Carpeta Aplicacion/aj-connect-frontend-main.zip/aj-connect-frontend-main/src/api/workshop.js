import api from './axiosConfig.js';

export async function getWorkshopAnalytics(params = {}) {
  const { data } = await api.get('/workshop/analytics/', { params });
  return data;
}

export async function getWorkshopOverview(params = {}) {
  const { data } = await api.get('/workshop/overview/', { params });
  return data;
}

export async function getDemandForecast(params = {}) {
  const { data } = await api.get('/workshop/demand-forecast/', { params });
  return data;
}

export async function requestDemandForecast(params = {}) {
  const { data } = await api.post('/workshop/demand-forecast/', params);
  return data;
}

export async function lookupClient(rut) {
  const { data } = await api.post('/workshop/clients/lookup/', { rut });
  return data;
}

// El check-in viaja como multipart porque incluye las fotografías del vehículo.
export async function createCheckIn(payload) {
  const formData = new FormData();
  const append = (key, value) => {
    if (value === null || value === undefined || value === '') return;
    formData.append(key, value);
  };

  append('client_id', payload.clientId);
  append('appointment_id', payload.appointmentId);
  append('vehicle_id', payload.vehicleId);
  append('first_name', payload.firstName);
  append('last_name', payload.lastName);
  append('rut', payload.rut);
  append('email', payload.email);
  append('phone', payload.phone);
  append('notification_channel', payload.notificationChannel);
  append('plate', payload.plate);
  append('brand', payload.brand);
  append('vehicle_model', payload.vehicleModel);
  append('year', payload.year);
  append('color', payload.color);
  append('odometer', payload.odometer);
  append('fuel', payload.fuel);
  append('spare', payload.spare == null ? null : String(payload.spare));
  append('tools', payload.tools == null ? null : String(payload.tools));
  append('notes', payload.notes);
  append('reported_symptoms', payload.reportedSymptoms?.trim());
  append('additional_equipment', JSON.stringify((payload.additionalEquipment || []).map(({ name, present }) => ({ name, present }))));

  (payload.photos || []).forEach((file) => formData.append('photos', file));

  const { data } = await api.post('/workshop/check-in/', formData);
  return data;
}

// --- Órdenes de trabajo -----------------------------------------------------
// `params` acepta los filtros opcionales del backend: status, status_id,
// mechanic, unassigned, plate y search.

export async function listWorkOrders(params = {}) {
  const { data } = await api.get('/workshop/work-orders/', { params });
  if (!Array.isArray(data)) throw new Error('Respuesta de órdenes inválida');
  return data.map(mapWorkOrder);
}

export async function getWorkOrder(id) {
  const { data } = await api.get(`/workshop/work-orders/${encodeURIComponent(id)}/`);
  return mapWorkOrder(data);
}

// Actualización parcial: mecánico, estado, diagnóstico o fecha estimada.
// `notes` documenta el cambio en el historial de estados.
export async function updateWorkOrder(id, cambios) {
  const { data } = await api.patch(`/workshop/work-orders/${encodeURIComponent(id)}/`, cambios);
  return mapWorkOrder(data);
}

export function updateOrderStatus(id, statusId) {
  return updateWorkOrder(id, { status_id: statusId });
}

export async function addOrderPart(id, itemId, quantity, requestId) {
  await api.post(`/workshop/work-orders/${encodeURIComponent(id)}/items/`, { item: itemId, quantity, request_id: requestId });
  // The association endpoint returns the created item; reload authoritative detail.
  return getWorkOrder(id);
}

function mapWorkOrder(data) {
  if (!data?.id || !data.status_code) throw new Error('Respuesta de orden inválida');
  const checkin = data.checkin;
  return {
    id: data.id, folio: data.folio_number, trackingCode: data.tracking_code, createdAt: data.created_at,
    updatedAt: data.updated_at, estimatedDeliveryAt: data.estimated_delivery_date,
    mechanicName: data.mecanico_nombre || data.assigned_mechanic || '', diagnosis: data.technical_diagnosis,
    reportedSymptoms: data.client_observations,
    aiDiagnosticSuggestion: data.ai_diagnostic_suggestion,
    client: { name: data.client?.full_name || data.client_name || '', rut: data.client?.rut || data.client_rut || '', phone: data.client?.phone || '', email: data.client?.email || '' },
    vehicle: { plate: data.vehicle?.plate || data.plate || '', label: data.vehicle?.label || data.vehicle_label || '' },
    status: { code: data.status_code, name: data.status, id: data.status_id },
    allowedStatuses: (data.allowed_statuses || []).map((status) => ({ code: status.code, name: status.name, id: status.id })),
    canAddParts: data.can_add_items === true,
    parts: (data.items || []).map((item) => ({ id: item.id, itemId: item.item, name: item.item_name, sku: item.item_sku, quantity: item.quantity, unitPrice: Number(item.unit_price), currentStock: item.current_stock })),
    history: (data.status_history || []).map((entry) => ({ id: entry.id, name: entry.to_status, createdAt: entry.changed_at, actor: entry.changed_by })),
    checkIn: checkin ? { odometer: checkin.initial_odometer, fuel: checkin.fuel_level, spare: checkin.has_spare_tire, tools: checkin.has_jack_and_tools, notes: checkin.bodywork_details, additionalEquipment: checkin.additional_equipment || [], photos: (checkin.photos || []).map((url, index) => ({ id: `${checkin.id}-${index}`, url })) } : null,
  };
}

export async function getWorkOrderPdf(id, signal) {
  const { data } = await api.get(`/workshop/work-orders/${encodeURIComponent(id)}/pdf/`, { responseType: 'blob', signal });
  if (data.type !== 'application/pdf' || !data.size) throw new Error('El documento recibido no es un PDF válido.');
  return data;
}

export async function listQuotes(orderId, signal) {
  const { data } = await api.get(`/workshop/work-orders/${encodeURIComponent(orderId)}/quotes/`, { signal });
  return data;
}
export async function listQuoteServices(orderId, signal) {
  const { data } = await api.get(`/workshop/work-orders/${encodeURIComponent(orderId)}/quote-services/`, { signal });
  return data;
}
export async function createQuote(orderId, options = {}) {
  const { data } = await api.post(`/workshop/work-orders/${encodeURIComponent(orderId)}/quotes/`, options);
  return data;
}
export async function getQuotePdf(id, signal) {
  const { data } = await api.get(`/workshop/quotes/${encodeURIComponent(id)}/pdf/`, { responseType: 'blob', signal });
  if (data.type !== 'application/pdf' || !data.size) throw new Error('La cotización recibida no es un PDF válido.');
  return data;
}
export async function emailQuote(id) {
  const { data } = await api.post(`/workshop/quotes/${encodeURIComponent(id)}/email/`, {});
  return data;
}
export async function getEmailDelivery(id, signal) {
  const { data } = await api.get(`/workshop/email-deliveries/${encodeURIComponent(id)}/`, { signal });
  return data;
}
