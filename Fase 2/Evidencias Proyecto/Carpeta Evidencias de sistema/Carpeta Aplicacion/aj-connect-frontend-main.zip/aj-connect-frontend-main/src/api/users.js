import api from './axiosConfig.js';

export async function listUsers() {
  const { data } = await api.get('/auth/users/');
  return data;
}

export async function listRoles() {
  const { data } = await api.get('/auth/roles/');
  return data;
}

export async function createUser(payload) {
  const { data } = await api.post('/auth/users/', payload);
  return data;
}

export async function updateUser(id, payload) {
  const { data } = await api.patch(`/auth/users/${id}/`, payload);
  return data;
}

export function parseFieldErrors(data) {
  if (!data || typeof data !== 'object') return {};

  const errores = {};
  for (const [campo, valor] of Object.entries(data)) {
    if (campo === 'detail') continue;
    errores[campo] = [].concat(valor).join(' ');
  }

  return errores;
}

export function parseGeneralError(err) {
  const data = err?.response?.data;

  const status = err?.response?.status;
  if (status === 404) return 'El servicio de personal todavía no está disponible. Contacta al administrador o intenta más tarde.';
  if (status === 403) return 'No tienes permiso para gestionar el personal.';
  if (status >= 500) return 'No pudimos cargar el personal. Intenta nuevamente en unos minutos.';
  if (typeof data === 'string') return 'El servidor devolvió una respuesta inesperada. Intenta nuevamente.';
  if (data?.detail) return data.detail;
  if (data?.non_field_errors) return [].concat(data.non_field_errors).join(' ');

  if (data && typeof data === 'object') {
    return Object.entries(data)
      .map(([campo, valor]) => `${campo}: ${[].concat(valor).join(' ')}`)
      .join(' · ');
  }

  return 'No se pudo conectar con el servidor. Revisa tu conexión e intenta nuevamente.';
}
