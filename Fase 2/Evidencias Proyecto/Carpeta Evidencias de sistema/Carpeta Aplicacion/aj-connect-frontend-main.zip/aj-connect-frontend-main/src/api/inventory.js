import api from './axiosConfig.js';

export async function listItems({ search = '', ordering = 'name', page, brand } = {}) {
  const params = { ordering, ...(page ? { page } : {}) };
  if (search) params.search = search;
  if (brand) params.brand = brand;

  const { data } = await api.get('/inventory/items/', {
    params,
  });

  return data;
}

export async function listAllItems() {
  const items = [];
  let page = 1;
  let next;
  do {
    const data = await listItems({ ordering: 'name', page });
    if (Array.isArray(data)) return data;
    items.push(...(data.results || []));
    next = data.next;
    page += 1;
  } while (next);
  return items;
}

export async function listCategoryPage(params = {}) {
  const { data } = await api.get('/inventory/categories/', { params });
  return data;
}

// Selectors need the whole catalog; the management table requests one page.
export async function listCategories() {
  const categories = [];
  let page = 1;
  let next;
  do {
    const data = await listCategoryPage({ page });
    if (Array.isArray(data)) return data;
    categories.push(...data.results);
    next = data.next;
    page += 1;
  } while (next);
  return categories;
}

export async function createItem(payload) {
  const { data } = await api.post('/inventory/items/', payload);

  return data;
}

export async function listItemBrands(signal, { includeUnidentified = false, includeArchived = false } = {}) {
  const params = {
    ...(includeUnidentified ? { include_unidentified: true } : {}),
    ...(includeArchived ? { include_archived: true } : {}),
  };
  const { data } = await api.get('/inventory/brands/', { signal, params });
  return data;
}

export async function createItemBrand(name) {
  const { data } = await api.post('/inventory/brands/', { name });
  return data;
}

export async function updateItemBrand(id, payload) {
  const { data } = await api.patch(`/inventory/brands/${id}/`, payload);
  return data;
}

export async function updateItem(id, payload) {
  const { data } = await api.patch(`/inventory/items/${id}/`, payload);

  return data;
}

export async function publishCatalogItems(items, drafts) {
  const payload = new FormData();
  const entries = items.map((id) => {
    const { public_image: image, ...fields } = drafts[id] || {};
    if (image) payload.append(`image_${id}`, image);
    return { id, ...fields };
  });
  payload.append('items', JSON.stringify(entries));
  const { data } = await api.post('/inventory/items/bulk-publish/', payload);
  return data;
}

export async function listPublicCatalog(signal) {
  const { data } = await api.get('/inventory/public-catalog/', { skipAuth: true, signal });
  return data;
}

// DRF responde 400 como { "campo": ["mensaje"] }. Esto lo usa el formulario
// para pintar el error debajo de cada input.
export function erroresPorCampo(data) {
  if (!data || typeof data !== 'object') return {};

  const errores = {};
  for (const [campo, valor] of Object.entries(data)) {
    if (campo === 'detail') continue;
    errores[campo] = [].concat(valor).join(' ');
  }

  return errores;
}

// Mensaje general para los banners de error de la vista y del modal.
export function mensajeDeError(err) {
  const data = err?.response?.data;

  if (typeof data === 'string') return data;
  if (data?.detail) return data.detail;
  if (data?.non_field_errors) return [].concat(data.non_field_errors).join(' ');

  if (data && typeof data === 'object') {
    return Object.entries(data)
      .map(([campo, valor]) => `${campo}: ${[].concat(valor).join(' ')}`)
      .join(' · ');
  }

  return err?.message || 'No se pudo conectar con el servidor.';
}

export async function createCategory(payload) {
  const { data } = await api.post('/inventory/categories/', payload);
  return data;
}

export async function updateCategory(id, payload) {
  const { data } = await api.patch(`/inventory/categories/${id}/`, payload);
  return data;
}
