import { useEffect, useMemo, useRef, useState } from 'react';
import '@fontsource-variable/manrope';
import './AdminLayout.css';
import { useTheme } from '../theme.js';
import { sessionIdentity } from '../utils/sessionIdentity.js';
import { hasRole } from '../api/session.js';

const ICON_PROPS = { width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true };
const drawerQuery = '(max-width: 1024px)';

export function AdminIcon({ name }) {
  if (name === 'calendar') return <svg {...ICON_PROPS}><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18m-13 4h3m-3 3h3" /></svg>;
  if (name === 'orders') return <svg {...ICON_PROPS}><rect x="5" y="4" width="14" height="17" rx="2" /><path d="M9 4V2h6v2M9 9h6m-6 4h6m-6 4h4" /></svg>;
  if (name === 'car') {
    return (
      <svg {...ICON_PROPS}>
        <path d="m5 7 2-4h10l2 4 2 3v8H3v-8Z" />
        <path d="M3 10h18M6 18v3m12-3v3M6 14h2m8 0h2" />
      </svg>
    );
  }
  if (name === 'home') {
    return (
      <svg {...ICON_PROPS}>
        <path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Z" />
        <path d="M9 21v-8h6v8" />
      </svg>
    );
  }
  if (name === 'users') {
    return (
      <svg {...ICON_PROPS}>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    );
  }
  return (
    <svg {...ICON_PROPS}>
      <path d="m3 7 9-4 9 4v10l-9 4-9-4Z" />
      <path d="m3 7 9 4 9-4M12 11v10M7 5l10 4" />
    </svg>
  );
}

export default function AdminLayout({ path, token, onNavigate, onLogout, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [compact, setCompact] = useState(() => localStorage.getItem('aj-sidebar-compact') === 'true');
  const [inventoryOpen, setInventoryOpen] = useState(true);
  const { theme, toggleTheme } = useTheme();
  const menu = useRef(null);
  const drawerToggle = useRef(null);
  const drawerClose = useRef(null);
  const user = useMemo(() => sessionIdentity(token), [token]);
  const isSuperUser = Boolean(user.isSuperUser);
  const isAdminRole = isSuperUser || hasRole(user.roles, 'Administrador') || user.isAdmin;
  const isMecanico = hasRole(user.roles, 'Mecanico') || user.isMecanico;
  const isRecepcionista = hasRole(user.roles, 'Recepcionista') || user.isRecepcionista;
  useEffect(() => {
    function close(event) {
      if (event.type === 'keydown' && event.key !== 'Escape') return;
      if (event.type === 'keydown' || !menu.current?.contains(event.target)) menu.current?.removeAttribute('open');
    }
    document.addEventListener('pointerdown', close);
    document.addEventListener('keydown', close);
    return () => {
      document.removeEventListener('pointerdown', close);
      document.removeEventListener('keydown', close);
    };
  }, []);

  useEffect(() => {
    if (!sidebarOpen) return;
    const viewport = window.matchMedia(drawerQuery);
    function closeOnDesktop(event) {
      if (!event.matches) setSidebarOpen(false);
    }
    function closeOnEscape(event) {
      if (event.key === 'Escape') {
        setSidebarOpen(false);
        requestAnimationFrame(() => drawerToggle.current?.focus());
      }
    }
    drawerClose.current?.focus();
    viewport.addEventListener('change', closeOnDesktop);
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      viewport.removeEventListener('change', closeOnDesktop);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [sidebarOpen]);

  function closeDrawer() {
    setSidebarOpen(false);
    requestAnimationFrame(() => drawerToggle.current?.focus());
  }

  function link(event, destination) {
    if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    setSidebarOpen(false);
    if (destination.startsWith('/dashboard/inventario')) setInventoryOpen(true);
    menu.current?.removeAttribute('open');
    onNavigate(destination);
  }

  const isPersonnelPage = path === '/dashboard/users' || path === '/dashboard/personal';
  const inventoryLinks = [
    ['/dashboard/inventario', 'Insumos'],
    ['/dashboard/inventario/categorias', 'Categorías'],
    ['/dashboard/inventario/marcas', 'Marcas'],
    ...(isAdminRole || isRecepcionista ? [['/dashboard/inventario/catalogo-web', 'Catálogo Web']] : []),
  ];
  const inventorySubpage = inventoryLinks.slice(1).find(([url]) => path === url)?.[1];

  const navItems = [
    ['/dashboard', 'Inicio', 'home'],
  ];

  if (isMecanico || isAdminRole) {
    navItems.push(['/dashboard/check-in', 'Recepción', 'car']);
    navItems.push(['/dashboard/ordenes', 'Órdenes de trabajo', 'orders']);
  }
  if (isAdminRole || isRecepcionista) {
    navItems.push(['/dashboard/citas', 'Citas', 'calendar']);
  }
  if (isAdminRole) {
    navItems.push(['/dashboard/users', 'Personal', 'users']);
  }

  function isActive(url) {
    if (url === '/dashboard/users') return isPersonnelPage;
    if (url === '/dashboard/ordenes') return path.startsWith('/dashboard/ordenes');
    return path === url || (url === '/dashboard/inventario' && path.startsWith('/dashboard/inventario/'));
  }

  function toggleCompact() {
    const next = !compact;
    setCompact(next);
    localStorage.setItem('aj-sidebar-compact', String(next));
  }

  function navigationLink(url, title, icon) {
    const active = isActive(url);
    return <a key={url} href={url} onClick={(event) => link(event, url)} aria-current={active ? 'page' : undefined} className={active ? 'active' : ''} title={title}>
      <AdminIcon name={icon} /><span className="admin-nav-text">{title}</span>
    </a>;
  }

  return (
    <div className={`admin-shell ${compact ? 'is-compact' : ''}`}>
      <div className={`admin-overlay ${sidebarOpen ? 'is-open' : ''}`} aria-hidden="true" onClick={closeDrawer} />
      <aside id="admin-sidebar" className={`admin-sidebar ${sidebarOpen ? 'is-open' : ''}`}>
        <div className="admin-sidebar-heading">
        <a className="admin-brand" href="/dashboard" aria-label="A&J Connect, inicio" onClick={(event) => link(event, '/dashboard')}>
          <strong>A&J</strong><span>connect.</span>
        </a>
        <button type="button" className="admin-collapse-toggle" onClick={toggleCompact} aria-label={compact ? 'Expandir navegación' : 'Contraer navegación'} aria-expanded={!compact} aria-controls="admin-sidebar" title={compact ? 'Expandir navegación' : 'Contraer navegación'}>
          <svg {...ICON_PROPS}><rect x="3" y="4" width="18" height="16" rx="3" /><path d="M9 4v16m7-11-3 3 3 3" /></svg>
        </button>
        <button ref={drawerClose} className="admin-drawer-close" type="button" aria-label="Cerrar navegación" onClick={closeDrawer}>×</button>
        </div>
        <span className="admin-nav-label">ESPACIO DE TRABAJO</span>
        <nav aria-label="Navegación principal">
          {navigationLink(...navItems[0])}
          {(isMecanico || isRecepcionista || isAdminRole) && <div className="admin-nav-group">
            <button type="button" className={`admin-nav-group-toggle ${path.startsWith('/dashboard/inventario') ? 'is-current' : ''}`} onClick={() => { if (compact && !sidebarOpen) { toggleCompact(); setInventoryOpen(true); } else setInventoryOpen(!inventoryOpen); }} aria-expanded={inventoryOpen} aria-controls="admin-inventory-links" title="Inventario">
              <AdminIcon name="box" /><span className="admin-nav-text">Inventario</span>
              <svg className={`admin-nav-chevron ${inventoryOpen ? 'is-open' : ''}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
            </button>
            <div id="admin-inventory-links" className={`admin-subnav-wrap ${inventoryOpen ? 'is-open' : ''}`} inert={!inventoryOpen ? true : undefined}>
              <div className="admin-subnav">
                {inventoryLinks.map(([url, title]) => <a key={url} href={url} onClick={(event) => link(event, url)} className={path === url ? 'active' : ''} aria-current={path === url ? 'page' : undefined}>{title}</a>)}
              </div>
            </div>
          </div>}
          {navItems.slice(1).map(([url, title, icon]) => navigationLink(url, title, icon))}
        </nav>
        <a className="admin-public-link" href="/" title="Visitar portal público" aria-label="Visitar portal público" onClick={(event) => link(event, '/')}><span className="admin-nav-text">Visitar portal público</span><svg {...ICON_PROPS}><path d="M14 3h7v7m0-7L10 14M10 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5" /></svg></a>
      </aside>
      <div className="admin-workspace" inert={sidebarOpen || undefined}>
        <header className="admin-topbar">
          <div className="admin-topbar-title">
            <button ref={drawerToggle} type="button" className="admin-menu-toggle" onClick={() => { menu.current?.removeAttribute('open'); setSidebarOpen(true); }} aria-label="Abrir navegación" aria-controls="admin-sidebar" aria-expanded={sidebarOpen}>☰</button>
            <nav className="admin-breadcrumbs" aria-label="Ubicación actual">
              <a href="/dashboard" onClick={(event) => link(event, '/dashboard')}>Dashboard</a>
              <span className="admin-breadcrumb-separator" aria-hidden="true">&gt;</span>
              {inventorySubpage ? (
                <>
                  <a href="/dashboard/inventario" onClick={(event) => link(event, '/dashboard/inventario')}>Inventario</a>
                  <span className="admin-breadcrumb-separator" aria-hidden="true">&gt;</span>
                  <span aria-current="page">{inventorySubpage}</span>
                </>
              ) : (
                <span aria-current="page">
                  {path === '/dashboard'
                    ? 'Inicio'
                    : path === '/dashboard/citas'
                      ? 'Gestión de citas'
                    : path === '/dashboard/check-in'
                      ? 'Recepción'
                      : path.startsWith('/dashboard/ordenes')
                        ? 'Órdenes de trabajo'
                      : path === '/dashboard/inventario'
                        ? 'Inventario'
                    : path === '/dashboard/cuenta'
                          ? 'Mi cuenta'
                          : isPersonnelPage
                            ? 'Personal'
                            : 'Dashboard'}
                </span>
              )}
            </nav>
          </div>
          <details className="admin-user-menu" ref={menu}>
            <summary>
              <span className="admin-avatar" aria-hidden="true">{user.name.slice(0, 2).toUpperCase()}</span>
              <span className="admin-user-name">{user.name}<small>{user.role}</small></span>
              <svg className="admin-user-chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
            </summary>
            <div className="admin-user-dropdown">
              <p>{user.name}<span>{user.role}</span><span className="admin-user-email">{user.email || 'Correo no registrado'}</span></p><a className="admin-account-link" href="/dashboard/cuenta" onClick={(event) => link(event, '/dashboard/cuenta')}>Mi cuenta <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" aria-hidden="true"><circle cx="12" cy="8" r="4" /><path d="M4 21v-2a8 8 0 0 1 16 0v2" /></svg></a>
              <div className="admin-theme-row">
                <span id="admin-theme-label">Tema</span>
                <button type="button" role="switch" aria-checked={theme === 'dark'} aria-label={theme === 'dark' ? 'Tema oscuro, cambiar a claro' : 'Tema claro, cambiar a oscuro'} aria-labelledby="admin-theme-label" className="admin-theme-switch" onClick={toggleTheme}>
                  <svg className="admin-theme-sun" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4" /><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5" /></svg>
                  <svg className="admin-theme-moon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 15a8.5 8.5 0 0 1-11-11A8.5 8.5 0 1 0 20 15Z" /></svg>
                  <span className="admin-theme-thumb" aria-hidden="true" />
                </button>
              </div>
              <button className="admin-logout" onClick={onLogout}>Cerrar sesión <span aria-hidden="true">↪</span></button>
            </div>
          </details>
        </header>
        <main className="admin-content" id="admin-main"><div className={`admin-page-enter${path.startsWith('/dashboard/inventario') ? ' inventory-page' : ''}`} key={path.startsWith('/dashboard/inventario') ? '/dashboard/inventario' : path}>{children}</div></main>
      </div>
      {(isAdminRole || isMecanico) && path !== '/dashboard/check-in' && !sidebarOpen && (
        <a className="new-order-shortcut" href="/dashboard/check-in" onClick={(event) => link(event, '/dashboard/check-in')}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
          <span>Nueva orden</span>
        </a>
      )}
    </div>
  );
}
